"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.triaxialFreeRotationCoefficients = void 0;
exports.prepareFreeRotation = prepareFreeRotation;
const math_js_1 = require("./math.js");
const validation_js_1 = require("./validation.js");
const exponents = Object.freeze([3, 5, 7]);
const roots = Object.freeze(exponents.map((exponent) => {
    // G1B_COEFFICIENT_POW: exactly one actual call per exponent and graph load.
    return Math.pow(2, 1 / exponent);
}));
const a = Object.freeze(roots.map((root) => 1 / (2 - root)));
const b = Object.freeze(a.map((value) => 1 - 2 * value));
let expanded = [1];
for (let level = 0; level < 3; level++) {
    expanded = [...expanded.map((value) => a[level] * value),
        ...expanded.map((value) => b[level] * value),
        ...expanded.map((value) => a[level] * value)];
}
exports.triaxialFreeRotationCoefficients = Object.freeze({
    exponents, roots, a, b, weights: Object.freeze(expanded),
});
const ROUNDING_UNIT = 2 ** -52;
const unitVectorBound = (value) => value.every((component) => Number.isFinite(component) && Math.abs(component) <= 1);
const maximumComponent = (value) => Math.max(Math.abs(value[0]), Math.abs(value[1]), Math.abs(value[2]));
function field(p, diagonal) {
    return [(diagonal[2] - diagonal[1]) * p[1] * p[2],
        (diagonal[0] - diagonal[2]) * p[2] * p[0],
        (diagonal[1] - diagonal[0]) * p[0] * p[1]];
}
function derivative(p, diagonal) {
    return [[0, (diagonal[2] - diagonal[1]) * p[2], (diagonal[2] - diagonal[1]) * p[1]],
        [(diagonal[0] - diagonal[2]) * p[2], 0, (diagonal[0] - diagonal[2]) * p[0]],
        [(diagonal[1] - diagonal[0]) * p[1], (diagonal[1] - diagonal[0]) * p[0], 0]];
}
function linearSolve(matrix, right) {
    // G1B_LINEAR_SOLVE_ENTRY: one direct solve per fixed Newton update.
    const rows = matrix.map((row, index) => [...row, right[index]]);
    for (let column = 0; column < 3; column++) {
        let selected = column;
        for (let row = column + 1; row < 3; row++) {
            if (Math.abs(rows[row][column]) > Math.abs(rows[selected][column]))
                selected = row;
        }
        if (selected !== column)
            [rows[selected], rows[column]] = [rows[column], rows[selected]];
        const selectedPivot = rows[column][column];
        const pivotMagnitude = Math.abs(selectedPivot);
        // G1B_LINEAR_PIVOT: observe column/selectedPivot/pivotMagnitude, no extra math.
        if (!Number.isFinite(selectedPivot) || pivotMagnitude < 1 / 4) {
            (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint pivot outside qualified bound');
        }
        for (let row = column + 1; row < 3; row++) {
            const multiplier = rows[row][column] / selectedPivot;
            rows[row][column] = 0;
            for (let entry = column + 1; entry < 4; entry++)
                rows[row][entry] -= multiplier * rows[column][entry];
        }
    }
    const result = [0, 0, 0];
    for (let row = 2; row >= 0; row--) {
        let total = rows[row][3];
        for (let column = row + 1; column < 3; column++)
            total -= rows[row][column] * result[column];
        result[row] = total / rows[row][row];
    }
    if (!result.every(Number.isFinite))
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'nonfinite triaxial midpoint correction');
    const residual = matrix.map((row, index) => row.reduce((sum, value, column) => sum + value * result[column], 0) - right[index]);
    const matrixNorm = Math.max(...matrix.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0)));
    const residualMaximum = maximumComponent(residual);
    const residualScale = Math.max(1, matrixNorm * maximumComponent(result) + maximumComponent(right));
    const residualBound = 64 * ROUNDING_UNIT * residualScale;
    if (!Number.isFinite(residualMaximum) || !Number.isFinite(residualBound) || residualMaximum > residualBound) {
        // G1B_LINEAR_RESIDUAL_FAILURE: test-only failed-prefix residual/bound, zero normal records.
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial linear correction residual outside qualified bound');
    }
    return { value: result, residualMaximum, residualBound };
}
function midpoint(p0, diagonal, signedStep) {
    // G1B_MIDPOINT_ENTRY: exactly27 signed stages per general macro flow.
    if (!Number.isFinite(signedStep) || !unitVectorBound(p0)) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint initial iterate outside bound');
    }
    const initialField = field(p0, diagonal);
    let guess = p0.map((value, index) => value + signedStep * initialField[index]);
    if (!unitVectorBound(guess))
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint predictor outside bound');
    for (let update = 0; update < 4; update++) {
        const middle = p0.map((value, index) => (value + guess[index]) / 2);
        const velocity = field(middle, diagonal);
        const residual = guess.map((value, index) => value - p0[index] - signedStep * velocity[index]);
        const jacobianField = derivative(middle, diagonal);
        const perturbation = maximumComponent(jacobianField.map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
        // G1B_NEWTON_CONDITION: observe update/middle/residual/perturbation.
        if (!unitVectorBound(middle) || !Number.isFinite(perturbation) || perturbation > 1 / 4) {
            (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint Jacobian outside qualified bound');
        }
        const jacobian = jacobianField.map((row, i) => row.map((value, j) => (i === j ? 1 : 0) - signedStep * value / 2));
        const linearResult = linearSolve(jacobian, residual.map((value) => -value));
        const correction = linearResult.value;
        const linearResidualMaximum = linearResult.residualMaximum;
        const linearResidualBound = linearResult.residualBound;
        guess = guess.map((value, index) => value + correction[index]);
        // G1B_NEWTON_UPDATE: one completed update; observe existing local values.
        if (!unitVectorBound(guess))
            (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint update outside bound');
    }
    const middle = p0.map((value, index) => (value + guess[index]) / 2);
    const velocity = field(middle, diagonal);
    const residual = guess.map((value, index) => value - p0[index] - signedStep * velocity[index]);
    const residualMaximum = maximumComponent(residual);
    const residualScale = Math.max(1, maximumComponent(p0), maximumComponent(guess), maximumComponent(velocity.map((value) => signedStep * value)));
    const residualBound = 64 * ROUNDING_UNIT * residualScale;
    const finalPerturbation = maximumComponent(derivative(middle, diagonal).map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
    // G1B_MIDPOINT_RESIDUAL: actual final residual/pivot/range evidence is test-only.
    if (!unitVectorBound(middle) || !Number.isFinite(residualMaximum) ||
        !Number.isFinite(finalPerturbation) || finalPerturbation > 1 / 4 || residualMaximum > residualBound) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial midpoint residual outside qualified bound');
    }
    return { p: guess, omegaMid: middle.map((value, index) => value * diagonal[index]) };
}
function prepareFreeRotation(body, dt) {
    // G1B_PREPARE_ENTRY: one call after actual angular actions/motors, before candidate writes.
    if (body.kind !== 'dynamic')
        return null;
    const moments = body.inertiaDiagonalKgM2 ??
        [body.inertiaKgM2, body.inertiaKgM2, body.inertiaKgM2];
    if (!moments.every((value) => Number.isFinite(value) && value > 0) ||
        !Number.isFinite(dt) || dt <= 0) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'triaxial flow outside qualified time/inertia bounds');
    }
    if (moments[0] === moments[1] && moments[1] === moments[2])
        return null;
    if (body.angularVelocityRadps.every((value) => value === 0)) {
        // Preserve the exact stationary state without scaling zero momentum.
        return { orientation: [...body.orientation], angularVelocityRadps: [...body.angularVelocityRadps] };
    }
    const magnitude = Math.hypot(...body.orientation);
    if (!Number.isFinite(magnitude) || magnitude === 0)
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'invalid triaxial orientation');
    let orientation = body.orientation.map((value) => value / magnitude);
    const localOmega = (0, math_js_1.rotate)((0, math_js_1.inverse)(orientation), body.angularVelocityRadps);
    if (!localOmega.every(Number.isFinite))
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'nonfinite triaxial body spin');
    const momentum = localOmega.map((value, index) => moments[index] * value);
    const momentumNorm = Math.hypot(...momentum);
    const momentumScale = 2 * momentumNorm;
    if (!momentum.every(Number.isFinite) || !Number.isFinite(momentumScale) || momentumNorm === 0) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'free rotation momentum outside finite range');
    }
    if (localOmega.filter((value) => value !== 0).length === 1) {
        // A single body-axis component has exact uniform rotation.
        return { orientation: (0, math_js_1.advanceOrientation)(orientation, body.angularVelocityRadps, dt),
            angularVelocityRadps: [...body.angularVelocityRadps] };
    }
    const diagonal = moments.map((value) => momentumScale / value);
    let p = momentum.map((value) => value / momentumScale);
    if (!diagonal.every(Number.isFinite) || Math.hypot(...p) > 1 / 2 + 4 * ROUNDING_UNIT) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'free rotation scaled momentum outside bound');
    }
    const maximumDifference = Math.max(Math.abs(diagonal[2] - diagonal[1]), Math.abs(diagonal[0] - diagonal[2]), Math.abs(diagonal[1] - diagonal[0]));
    const maximumWeight = Math.max(...exports.triaxialFreeRotationCoefficients.weights.map(Math.abs));
    // |p_i| <= 1 gives ||h F'(p)/2||_infinity <= |h| max |D_i-D_j|.
    const subdivisions = Math.max(1, Math.ceil(4 * maximumWeight * dt * maximumDifference));
    if (!Number.isFinite(subdivisions) || subdivisions > 64) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'free rotation exceeded internal subdivision limit');
    }
    for (let subdivision = 0; subdivision < subdivisions; subdivision++) {
        for (let stage = 0; stage < 27; stage++) {
            const weight = exports.triaxialFreeRotationCoefficients.weights[stage];
            if (!Number.isFinite(weight) || Math.abs(weight) >= 3)
                (0, validation_js_1.error)('NUMERIC_LIMIT', 'invalid triaxial composition coefficient');
            const signedStep = weight * (dt / subdivisions);
            const prepared = midpoint(p, diagonal, signedStep);
            const vector = prepared.omegaMid.map((value) => signedStep * value / 2);
            const deltaNorm = Math.hypot(...vector, 1);
            if (!Number.isFinite(deltaNorm) || deltaNorm === 0)
                (0, validation_js_1.error)('NUMERIC_LIMIT', 'invalid Cayley increment');
            const delta = [vector[0] / deltaNorm, vector[1] / deltaNorm, vector[2] / deltaNorm, 1 / deltaNorm];
            const composed = (0, math_js_1.multiplyQuaternion)(orientation, delta);
            const composedNorm = Math.hypot(...composed);
            if (!Number.isFinite(composedNorm) || composedNorm === 0)
                (0, validation_js_1.error)('NUMERIC_LIMIT', 'nonfinite Cayley orientation');
            orientation = composed.map((value) => value / composedNorm);
            p = prepared.p;
            // G1B_STAGE_COMPLETE: observe stage/weight/signedStep/p/orientation without recomputation.
        }
    }
    const angularVelocityRadps = (0, math_js_1.rotate)(orientation, p.map((value, index) => value * diagonal[index]));
    // G1B_GENERAL_RETURN: validate this result at the World boundary before assignment.
    return { orientation, angularVelocityRadps };
}
