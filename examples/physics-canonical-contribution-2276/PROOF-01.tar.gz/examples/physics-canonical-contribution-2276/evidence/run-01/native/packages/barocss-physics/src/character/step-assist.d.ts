import type { Vec3 } from '../internal-types.js';
import type { CharacterState, CharacterDiagnostics } from './types.js';
import type { QueryContext } from './query.js';
export declare function tryStep(position: Vec3, remaining: Vec3, candidate: CharacterState, context: QueryContext): Vec3 | null;
export declare function validateAssist(position: Vec3, candidate: CharacterState, context: QueryContext, diagnostic: CharacterDiagnostics): void;
