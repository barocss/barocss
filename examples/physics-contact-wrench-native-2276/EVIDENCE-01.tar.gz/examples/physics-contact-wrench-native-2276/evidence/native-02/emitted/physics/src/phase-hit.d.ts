import type { Hit, Vec3 } from './internal-types.js';
import type { Pair } from '../../B/candidate.js';
export interface PhasePoint {
    id: string;
    pointM: Vec3;
    aPointM: Vec3;
    bPointM: Vec3;
    exact: {
        a: string[];
        b: string[];
        midpoint: string[];
    };
}
export interface PhaseHitResult extends Record<string, unknown> {
    status: 'HIT';
    normal: Vec3;
    feature: {
        kind: 'FACE' | 'EDGE';
    };
    points: PhasePoint[];
}
export interface PhaseHit extends Hit {
    _phase: {
        queryId: number;
        result: PhaseHitResult;
        pair: Pair;
    };
}
/** Validate the real unknown geometry boundary; return the same data objects. */
export declare function checkedPhaseHit(normal: unknown, penetration: unknown, pointM: unknown, queryId: unknown, result: unknown, queryPair: unknown): PhaseHit;
export declare function isPhaseHit(hit: Hit): hit is PhaseHit;
