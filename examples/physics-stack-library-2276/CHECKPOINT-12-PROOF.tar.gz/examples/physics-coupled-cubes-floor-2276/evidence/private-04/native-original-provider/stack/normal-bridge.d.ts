import type { Body, Vec3 } from '../internal-types.js';
import { PhysicsError } from '../internal-types.js';
import type { NormalProblem, NormalSolverResult } from './normal-solver.js';
import type { StationaryResult, StationaryStats } from './stationary-normal.js';
import type { PointLedger } from './world-types.js';
export type StackNormalResult = Omit<NormalSolverResult, 'stats'> & {
    solver: 'EXACT_STATIONARY_FLOAT_J_V1';
    stats: StationaryStats;
};
export interface FrozenStackPatch {
    aIndex: number;
    bIndex: number;
    aId: string;
    bId: string;
    pairKey: string;
    family: 'face' | 'edge';
    normal: Vec3;
    points: readonly {
        id: string;
        pointM: Vec3;
        witnessAM: Vec3;
        witnessBM: Vec3;
        normalGapM: number;
        pointPenetrationM: number;
    }[];
}
export declare class NormalPhaseFailure extends PhysicsError {
    readonly problem: NormalProblem;
    readonly result: StackNormalResult | null;
    readonly stationaryWitness: StationaryResult | null;
    constructor(reason: PhysicsError, problem: NormalProblem, result: StackNormalResult | null, stationaryWitness: StationaryResult | null);
}
/** Rounded diagnostics are separate from the exact APPLIED-ratio certificate. */
export declare function diagnoseStationaryNormal(problem: NormalProblem, witness: StationaryResult): StackNormalResult;
/** One cold solve over frozen actual points. Caller owns unaccepted bodies. */
export declare function solveStackNormal(bodies: Body[], patches: readonly FrozenStackPatch[]): {
    problem: NormalProblem;
    result: StackNormalResult;
    pointLedger: PointLedger[];
    stationaryWitness: StationaryResult;
};
