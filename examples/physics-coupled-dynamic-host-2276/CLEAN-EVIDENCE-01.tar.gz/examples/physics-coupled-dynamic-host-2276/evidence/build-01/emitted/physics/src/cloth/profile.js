"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CLOTH_PROFILE = exports.CLOTH_PROFILE_NAME = exports.CLOTH_ITERATIONS = exports.CLOTH_SUBSTEPS = exports.CLOTH_MAX_STEPS = exports.CLOTH_STEP_SECONDS = void 0;
exports.CLOTH_STEP_SECONDS = 1 / 120;
exports.CLOTH_MAX_STEPS = 240;
exports.CLOTH_SUBSTEPS = 8;
exports.CLOTH_ITERATIONS = 2;
exports.CLOTH_PROFILE_NAME = 'pinned-sheet-sphere-v1';
// Preserve the measured #825 profile and arithmetic order. No tunable inputs.
exports.CLOTH_PROFILE = Object.freeze({
    size: 17, sideM: 1, heightM: 0.55, densityKgM2: 0.2,
    dt: exports.CLOTH_STEP_SECONDS / exports.CLOTH_SUBSTEPS,
    gravityMps2: Object.freeze([0, -9.81, 0]), velocityDecayPerSecond: 1,
    sphereCentreM: Object.freeze([0, 0.1, 0]), sphereRadiusM: 0.3, collisionOffsetM: 0.002,
    stretchComplianceMPerN: 0.001, bendComplianceMPerN: 0.1,
});
