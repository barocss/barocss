import type { Vec3 } from './internal-types.js';
export interface RoundedBoxHit {
    fraction: number;
    normalLocal: Vec3;
}
/**
 * Segment versus the Euclidean radius-offset of a box, in box coordinates.
 * At most six exact plane crossings split distance squared into seven quadratics.
 * Integer predicates retain tangencies and closed endpoints without sign epsilons.
 */
export declare function sweepRoundedBox(start: Vec3, end: Vec3, halfExtents: Vec3, radius: number): RoundedBoxHit | null;
