import {createPhysicsWorld} from "/Users/user/Documents/ChatGPT/barocss-physics-motion-2276/packages/barocss-physics/dist/index.js";
import {createPhysicsRecorder} from "/Users/user/Documents/ChatGPT/barocss-physics-motion-2276/packages/barocss-physics/dist/replay.js";
// @ts-expect-error Internal contribution is not a public export.
import {ContactPairAccumulator} from "/Users/user/Documents/ChatGPT/barocss-physics-motion-2276/packages/barocss-physics/dist/index.js";
const a: typeof createPhysicsWorld=createPhysicsWorld; const b: typeof createPhysicsRecorder=createPhysicsRecorder; void a; void b;
