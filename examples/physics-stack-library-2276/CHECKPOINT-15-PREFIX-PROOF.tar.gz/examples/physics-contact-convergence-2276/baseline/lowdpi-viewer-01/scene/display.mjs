import { createViewer } from '@barocss/viewer';

// Primitive display proxies only. No native CAD provenance or physics input.
function boxPacket(id, half) {
  const positions = [], normals = [], parameters = [], indices = [];
  for (let axis = 0; axis < 3; axis++) for (const sign of [-1, 1]) {
    const normal = [0, 0, 0]; normal[axis] = sign;
    const first = positions.length / 3;
    for (const [u, v] of [[-1,-1],[1,-1],[1,1],[-1,1]]) {
      const point = [0, 0, 0]; point[axis] = sign * half[axis];
      point[(axis + 1) % 3] = u * half[(axis + 1) % 3];
      point[(axis + 2) % 3] = v * half[(axis + 2) % 3];
      positions.push(...point.map(x => x * 1000)); normals.push(...normal);
      parameters.push((u + 1) / 2, (v + 1) / 2);
    }
    indices.push(...(sign > 0 ? [first,first+1,first+2,first,first+2,first+3]
      : [first,first+2,first+1,first,first+3,first+2]));
  }
  return { version: 0, surfaceId: id, revision: 0, lengthUnit: 'mm',
    coordinateSystem: 'right-handed-z-up', winding: 'ccw',
    positions, normals, parameters, indices,
    bounds: { min: half.map(x => -x * 1000), max: half.map(x => x * 1000) } };
}

export async function createDisplay(canvas, onError = () => {}) {
  const viewer = await createViewer(canvas, { mmToSceneUnit: 0.001,
    background: [0.95,0.96,0.98], onDeviceEvent: event => {
      if (event.type === 'lost' || event.type === 'recovery-failed')
        onError(new Error(event.message ?? 'Viewer GPU device lost'));
    } });
  viewer.resize(640, 360);
  const controls = viewer.attachPointerControls({ onError });
  let modelKey = null, packets = [], bindings = [], lastStep = null, camera = 0;
  function setCamera() {
    viewer.setView({ eye: [camera ? -6 : 6,4.5,7], target: [0,1,0],
      up: [0,1,0], fovY: 40, near: 0.01, far: 100 });
  }
  setCamera();
  return {
    present(state, model) {
      const key = JSON.stringify(model);
      if (key !== modelKey) {
        if (!Array.isArray(model.bodies) || model.bodies.length < 1 || model.bodies.length > 4)
          throw new Error('Viewer primitive path requires 1–4 bodies');
        packets = model.bodies.map(body => {
          const collider = model.colliders.find(c => c.bodyId === body.id);
          if (collider?.geometry.kind !== 'box') throw new Error('Display supports centered boxes only');
          return { modelId: 'contact_lab', packet: boxPacket(body.id, collider.geometry.halfExtentsM) };
        });
        bindings = model.bodies.map(body => ({ contextId: 'contact_lab', targetId: body.id,
          ref: { modelId: 'contact_lab', surfaceId: body.id } }));
        viewer.setPackets(packets); modelKey = key; camera = 0; setCamera();
      }
      if (state.bodies.length !== bindings.length || new Set(state.bodies.map(b => b.id)).size !== bindings.length)
        throw new Error('Accepted body population differs from the Viewer binding');
      viewer.applyMotionFrame({ contextId: 'contact_lab', timeSeconds: state.timeSeconds,
        poses: state.bodies.map(body => ({ targetId: body.id,
          translation: body.positionM.map(x => x * 1000),
          rotation: [...body.orientationXYZW], scale: [1,1,1] })) },
      bindings, { basis: 'part-xyz-matches-rhyup' });
      lastStep = state.stepIndex;
    },
    draw() {}, // applyMotionFrame schedules the actual Viewer/GPU presentation.
    async readPixels() {
      const rgba = await viewer.readPixels();
      if (rgba.length !== 640 * 360 * 4) throw new Error('Unexpected Viewer pixel size');
      return { width: 640, height: 360, rgba, sourceFormat: 'rgba8', origin: 'top-left' };
    },
    snapshot() {
      const state = viewer.getState();
      return { kind: '@barocss/viewer', bodyCount: state.surfaces.length,
        lastStep, frame: state.frame, sourceUnit: state.sourceUnit,
        mmToSceneUnit: state.mmToSceneUnit, motion: state.motion,
        surfaces: state.surfaces, camera: state.camera,
        packets: state.packets.map(entry => ({ modelId: entry.modelId,
          surfaceId: entry.packet.surfaceId, cornerMM: entry.packet.positions.slice(0,3) })),
        contactMarkers: 'NOT_SUPPORTED_BY_THIS_ADAPTER', nativeCadProvenance: false };
    },
    home() { camera = 1 - camera; setCamera(); },
    dispose() { controls.dispose(); viewer.dispose(); },
  };
}
