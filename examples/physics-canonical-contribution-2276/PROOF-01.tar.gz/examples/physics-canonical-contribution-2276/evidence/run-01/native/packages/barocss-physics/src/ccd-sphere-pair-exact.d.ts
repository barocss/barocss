import type { Vec3 } from './internal-types.js';
export interface SpherePairHit {
    fraction: number;
    normal: Vec3;
}
/**
 * First entry of two linearly swept spheres. Exact dyadic predicates classify
 * the closed segment; floating arithmetic only constructs the admitted hit.
 * There is one quadratic, no search, refinement, feature case or fallback.
 */
export declare function sweepSpherePairExact(markedStart: Vec3, markedEnd: Vec3, otherStart: Vec3, otherEnd: Vec3, markedRadius: number, otherRadius: number): SpherePairHit | null;
