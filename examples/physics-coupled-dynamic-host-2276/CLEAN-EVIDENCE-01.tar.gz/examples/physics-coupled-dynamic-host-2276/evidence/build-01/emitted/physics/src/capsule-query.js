"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUprightCapsuleQuery = void 0;
var snapshot_js_1 = require("./capsule-query/snapshot.js");
Object.defineProperty(exports, "createUprightCapsuleQuery", { enumerable: true, get: function () { return snapshot_js_1.createUprightCapsuleQuery; } });
