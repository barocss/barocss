import type { PhaseHit } from './phase-hit.js';
import type { Body } from './internal-types.js';
export declare const phaseLimits: {
    worlds: number;
    attempts: number;
    records: number;
    applications: number;
    queries: number;
    queryPoints: number;
    anchorChecks: number;
    bytes: number;
};
export declare const unknownMarker: Error;
export declare function bodyWords(b: any): any;
export declare function phaseWorld(read: any): {
    id: number;
    read: any;
    accepted: {
        cursor: number;
        stepIndex: number;
        cacheFrames: {};
    };
    current: null;
    history: never[];
    fault: null;
};
export declare function phaseInitial(c: any, prepare: any): any;
export declare function phaseBegin(c: any, stepIndex: any, bodies: any): void;
export declare function phaseBodies(kind: any, bodies: any, extra?: {}): void;
export declare function phaseBody(kind: any, before: any, after: any, extra?: {}): void;
export declare function phasePass(pass: any): void;
export declare function phaseQuery(a: Body, b: Body, final?: boolean): PhaseHit | null;
export declare function phaseCacheInit(key: any, point: any, normal: any, hit: any, impulse: any, prior: any): void;
export declare function phasePoint(key: any, point: any, normal: any, hit: any, impulse: any, iteration: any, order: any): void;
export declare function phaseKind(kind: any, branch?: {}): void;
export declare function phaseApplyBefore(a: any, b: any, p: any, j: any): {
    pointM: any;
    anchorOnAM: any;
    anchorOnBM: any;
    impulseOnANs: any;
    impulseOnBNs: any;
    bodyABefore: any;
    bodyBBefore: any;
};
export declare function phaseApplyAfter(token: any, a: any, b: any): void;
export declare function phaseNoNormal(): void;
export declare function phaseCorrectionBefore(a: any, b: any, n: any, depth: any): {
    queryId: any;
    feature: any;
    bodyABefore: any;
    bodyBBefore: any;
    normal: any;
    penetration: any;
};
export declare function phaseCorrectionAfter(token: any, a: any, b: any): void;
export declare function phasePrepare(c: any, cache: any): {
    cursor: any;
    stepIndex: any;
    cacheFrames: any;
    actualCache: any;
};
export declare function phasePrivateSnapshot(worldId: any): any;
export declare function phaseFault(worldId: any, mode: any): void;
export declare function phaseHistory(): any;
export declare function phaseProducerBucket(key: any, map: any, contribution: any): void;
export declare function phaseCoupledPlan(data: any): void;
