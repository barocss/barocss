"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.axisAlignedBox = axisAlignedBox;
exports.rejectAngularBoxCommand = rejectAngularBoxCommand;
exports.sweepDynamicBox = sweepDynamicBox;
const math_js_1 = require("./math.js");
const ccd_slab_js_1 = require("./ccd-slab.js");
const validation_js_1 = require("./validation.js");
const ANGULAR_TOLERANCE = 1e-12;
function axisAlignedBox(body) {
    return body.shape.kind === 'box' &&
        body.orientation.slice(0, 3).every((component) => Math.abs(component) <= ANGULAR_TOLERANCE) &&
        Math.abs(Math.abs(body.orientation[3]) - 1) <= ANGULAR_TOLERANCE &&
        body.angularVelocityRadps.every((component) => Math.abs(component) <= ANGULAR_TOLERANCE);
}
function rejectAngularBoxCommand(action) {
    if (action?.torqueNm?.some((component) => component !== 0) ||
        action?.angularImpulseNms?.some((component) => component !== 0)) {
        (0, validation_js_1.error)('INVALID_COMMAND', 'axis-aligned box CCD excludes angular commands');
    }
}
function sweepDynamicBox(previous, candidate, fixture) {
    if (!axisAlignedBox(previous) || !axisAlignedBox(candidate) || !axisAlignedBox(fixture)) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'box CCD candidate rotated outside the admitted profile');
    }
    if (previous.shape.kind !== 'box' || fixture.shape.kind !== 'box')
        return null;
    const fixtureHalfExtents = fixture.shape.halfExtentsM;
    const expanded = previous.shape.halfExtentsM.map((extent, axis) => extent + fixtureHalfExtents[axis]);
    const start = (0, math_js_1.sub)(previous.positionM, fixture.positionM);
    const end = (0, math_js_1.sub)(candidate.positionM, fixture.positionM);
    const hit = (0, ccd_slab_js_1.sweepBox)(start, end, expanded);
    if (!hit)
        return null;
    const travel = (0, math_js_1.sub)(candidate.positionM, previous.positionM);
    candidate.positionM = (0, math_js_1.sub)((0, math_js_1.add)(previous.positionM, (0, math_js_1.scale)(travel, hit.fraction)), (0, math_js_1.scale)(hit.normalLocal, 1e-9));
    return { bodyId: previous.id, fixtureId: fixture.id,
        toiFraction: hit.fraction, normalFixtureToBody: hit.normalLocal };
}
