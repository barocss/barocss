"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initialState = initialState;
exports.projectState = projectState;
exports.validateState = validateState;
exports.errorRecord = errorRecord;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
const math_js_1 = require("./math.js");
function initialState(positionM, sceneRevision) {
    return {
        stepIndex: 0, timeSeconds: 0, positionM: [...positionM], velocityMps: [0, 0, 0],
        fallVelocityYMps: 0, orientationXYZW: [0, 0, 0, 1], grounded: false, support: null,
        blocked: false, assist: null, sceneRevision, queryCount: 0,
        lastQueries: [], lastSegments: [], gravityPrediction: null,
    };
}
function projectState(state) {
    return {
        version: 1, profile: profile_js_1.PROFILE, sceneRevision: state.sceneRevision, stepIndex: state.stepIndex,
        timeSeconds: state.timeSeconds, positionM: [...state.positionM], velocityMps: [...state.velocityMps],
        orientationXYZW: [...state.orientationXYZW], fallVelocityYMps: state.fallVelocityYMps,
        grounded: state.grounded, support: (0, math_js_1.clone)(state.support), blocked: state.blocked,
        assist: (0, math_js_1.clone)(state.assist), queryCount: state.queryCount,
    };
}
function validateState(position, velocity, request, previous) {
    if (position.some(value => !Number.isFinite(value) || Math.abs(value) > 5) ||
        velocity.some(value => !Number.isFinite(value)) || (0, math_js_1.norm)(velocity) > 20) {
        throw new capsule_query_error_js_1.PhysicsError('NUMERIC_LIMIT', 'Controller state exceeds its bound');
    }
    const actual = position.map((value, index) => value - previous.positionM[index]);
    const horizontal = Math.hypot(actual[0], actual[2]), allowed = Math.hypot(request[0], request[2]) * profile_js_1.DT;
    if (horizontal > allowed + 1e-9 || Math.abs(actual[1]) > .1 + 1e-6) {
        throw new capsule_query_error_js_1.PhysicsError('NUMERIC_LIMIT', 'Controller movement exceeds its bound');
    }
}
function errorRecord(error) {
    const value = error;
    return { name: value.name ?? 'Error', code: value.code, message: value.message ?? String(error) };
}
