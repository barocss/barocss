import { createClothWorld } from '@barocss/physics/cloth';
const world = createClothWorld({
    format: 'barocss-cloth-scene', version: 1, revision: 'sheet-v1',
    basis: 'right-handed-xyz-metres', fixedStepSeconds: 1 / 120,
    profile: 'pinned-sheet-sphere-v1',
});
const frame = world.step(1 / 120);
// frame.positionsM and frame.triangles are independent copies for caller display.
world.reset();
world.dispose();
