"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROW_IDS = exports.DOF_ORDER = void 0;
exports.makeRows = makeRows;
const math_js_1 = require("../math.js");
const errors_js_1 = require("./errors.js");
exports.DOF_ORDER = ['vAx', 'vAy', 'vAz', 'wAx', 'wAy', 'wAz', 'vBx', 'vBy', 'vBz', 'wBx', 'wBy', 'wBz'];
exports.ROW_IDS = ['P.x', 'P.y', 'P.z', 'L.x', 'L.y', 'L.z', 'anchor.x', 'anchor.y', 'anchor.z', 'transverse.x', 'transverse.y'];
const skew = (r) => [[0, -r[2], r[1]], [r[2], 0, -r[0]], [-r[1], r[0], 0]];
const canonical = (value) => value === 0 ? 0 : value;
function makeRows(beforeBodies, finalBodies, joint, before, origin, target) {
    const masses = beforeBodies.map(body => 1 / body.inverseMass), inertias = beforeBodies.map(body => body.inertiaKgM2);
    const center = [...before.centerOfMassM], centeredTarget = (0, math_js_1.sub)(before.angularMomentumVectorKgM2ps, (0, math_js_1.cross)((0, math_js_1.sub)(center, origin), before.linearMomentumVectorKgMps));
    const physicalA = Array.from({ length: 11 }, () => Array(12).fill(0));
    const rA = (0, math_js_1.rotate)(finalBodies[0].orientation, joint.anchorALocalM), rB = (0, math_js_1.rotate)(finalBodies[1].orientation, joint.anchorBLocalM);
    const ra = skew(rA), rb = skew(rB), sa = skew((0, math_js_1.sub)(finalBodies[0].positionM, center)), sb = skew((0, math_js_1.sub)(finalBodies[1].positionM, center));
    for (let i = 0; i < 3; i++) {
        physicalA[i][i] = masses[0];
        physicalA[i][6 + i] = masses[1];
        for (let j = 0; j < 3; j++) {
            physicalA[3 + i][j] = masses[0] * sa[i][j];
            physicalA[3 + i][6 + j] = masses[1] * sb[i][j];
            physicalA[6 + i][3 + j] = -ra[i][j];
            physicalA[6 + i][9 + j] = rb[i][j];
        }
        physicalA[3 + i][3 + i] = inertias[0];
        physicalA[3 + i][9 + i] = inertias[1];
        physicalA[6 + i][i] = 1;
        physicalA[6 + i][6 + i] = -1;
    }
    physicalA[9][3] = -1;
    physicalA[9][9] = 1;
    physicalA[10][4] = -1;
    physicalA[10][10] = 1;
    for (const row of physicalA)
        for (let j = 0; j < 12; j++)
            row[j] = canonical(row[j]);
    const physicalB = [...before.linearMomentumVectorKgMps, ...centeredTarget, 0, 0, 0, 0, 0];
    const physicalH = [...Array(3).fill(masses[0]), ...Array(3).fill(inertias[0]), ...Array(3).fill(masses[1]), ...Array(3).fill(inertias[1])];
    const physicalX0 = beforeBodies.flatMap(body => [...body.velocityMps, ...body.angularVelocityRadps]);
    const columnScales = [1, 1, 1, 10, 10, 10, 1, 1, 1, 10, 10, 10], rowDivisors = [1, 1, 1, .1, .1, .1, 1, 1, 1, 10, 10];
    const dimensionlessA = physicalA.map((row, i) => row.map((value, j) => (value * columnScales[j]) / rowDivisors[i]));
    const dimensionlessB = physicalB.map((value, i) => value / rowDivisors[i]);
    const dimensionlessH = physicalH.map((value, j) => (value * columnScales[j]) * columnScales[j] / 1);
    const dimensionlessX0 = physicalX0.map((value, j) => value / columnScales[j]);
    const stopKind = target === joint.limitRad[1] ? 'upper' : target === joint.limitRad[0] ? 'lower' : 'none';
    const physicalStopRow = stopKind === 'none' ? [] : Array(12).fill(0);
    if (stopKind !== 'none') {
        physicalStopRow[5] = stopKind === 'upper' ? -1 : 1;
        physicalStopRow[11] = -physicalStopRow[5];
    }
    const dimensionlessStopRow = physicalStopRow.map((value, j) => (value * columnScales[j]) / 10);
    const h = (0, math_js_1.sub)(rA, rB), d = (0, math_js_1.sub)(finalBodies[1].positionM, finalBodies[0].positionM);
    const rankSufficientMarginKgM2 = 2 * inertias[0] - masses[0] * Math.hypot(...h) * Math.hypot(...(0, math_js_1.sub)(d, h));
    const problem = { a: dimensionlessA, b: dimensionlessB, h: dimensionlessH, y0: dimensionlessX0, stopKind, stopRow: dimensionlessStopRow };
    const result = { dofOrder: [...exports.DOF_ORDER], rowIds: [...exports.ROW_IDS], physicalA, physicalB, physicalH, physicalX0, columnScales, rowDivisors, dimensionlessA, dimensionlessB, dimensionlessH, dimensionlessX0,
        centerOfMassOriginM: center, originalOriginM: [...origin], stopKind, physicalStopRow, dimensionlessStopRow, rankSufficientMarginKgM2, problem };
    if (!(0, errors_js_1.finiteData)(result) || physicalH.some(value => value <= 0))
        (0, errors_js_1.fail)('linear');
    return result;
}
