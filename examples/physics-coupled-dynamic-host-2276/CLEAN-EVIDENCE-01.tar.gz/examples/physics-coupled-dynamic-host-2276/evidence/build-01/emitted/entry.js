"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.coupledContactTarget = exports.lifecycleCaptureStats = exports.lifecycleCaptures = exports.CoupledContactError = exports.coupledStaticTarget = exports.WarmTransportError = exports.transportWarmTangent = exports.privateDecodeRecording = exports.privateEncodeRecording = exports.unknownMarker = exports.phaseFault = exports.phasePrivateSnapshot = exports.phaseHistory = void 0;
__exportStar(require("./physics/src/index.js"), exports);
__exportStar(require("./physics/src/replay.js"), exports);
var private_phase_js_1 = require("./physics/src/private-phase.js");
Object.defineProperty(exports, "phaseHistory", { enumerable: true, get: function () { return private_phase_js_1.phaseHistory; } });
Object.defineProperty(exports, "phasePrivateSnapshot", { enumerable: true, get: function () { return private_phase_js_1.phasePrivateSnapshot; } });
Object.defineProperty(exports, "phaseFault", { enumerable: true, get: function () { return private_phase_js_1.phaseFault; } });
Object.defineProperty(exports, "unknownMarker", { enumerable: true, get: function () { return private_phase_js_1.unknownMarker; } });
var replay_json_js_1 = require("./physics/src/replay-json.js");
Object.defineProperty(exports, "privateEncodeRecording", { enumerable: true, get: function () { return replay_json_js_1.encodeRecordingData; } });
Object.defineProperty(exports, "privateDecodeRecording", { enumerable: true, get: function () { return replay_json_js_1.decodeRecordingData; } });
var warm_transport_js_1 = require("./physics/src/warm-transport.js");
Object.defineProperty(exports, "transportWarmTangent", { enumerable: true, get: function () { return warm_transport_js_1.transportWarmTangent; } });
Object.defineProperty(exports, "WarmTransportError", { enumerable: true, get: function () { return warm_transport_js_1.WarmTransportError; } });
var candidate_js_1 = require("./C/candidate.js");
Object.defineProperty(exports, "coupledStaticTarget", { enumerable: true, get: function () { return candidate_js_1.coupledStaticTarget; } });
var coupled_plan_js_1 = require("./physics/src/coupled-plan.js");
Object.defineProperty(exports, "CoupledContactError", { enumerable: true, get: function () { return coupled_plan_js_1.CoupledContactError; } });
var lifecycle_capture_js_1 = require("./physics/src/lifecycle-capture.js");
Object.defineProperty(exports, "lifecycleCaptures", { enumerable: true, get: function () { return lifecycle_capture_js_1.lifecycleCaptures; } });
Object.defineProperty(exports, "lifecycleCaptureStats", { enumerable: true, get: function () { return lifecycle_capture_js_1.lifecycleCaptureStats; } });
var production_entry_js_1 = require("./D/production-entry.js");
Object.defineProperty(exports, "coupledContactTarget", { enumerable: true, get: function () { return production_entry_js_1.coupledContactTarget; } });
