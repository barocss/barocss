"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPhysicsRecorder = createPhysicsRecorder;
exports.restorePhysicsRecording = restorePhysicsRecording;
exports.serializePhysicsRecording = serializePhysicsRecording;
exports.deserializePhysicsRecording = deserializePhysicsRecording;
const index_js_1 = require("./index.js");
const types_js_1 = require("./types.js");
const recording_owner_js_1 = require("./recording-owner.js");
const identity_js_1 = require("./identity.js");
const replay_json_js_1 = require("./replay-json.js");
const replay_compare_js_1 = require("./replay-compare.js");
const replay_validation_js_1 = require("./replay-validation.js");
function recordedState(state) {
    if (state.cloths.length || state.fluids.length)
        (0, replay_json_js_1.replayError)('INVALID_SNAPSHOT', 'domain recording is unsupported');
    return (0, replay_json_js_1.copyReplayJson)({ ...state, cloths: [], fluids: [] }, 'state');
}
function recordingBudget(prepare) {
    try {
        return prepare();
    }
    catch (error) {
        if (error instanceof types_js_1.PhysicsError && error.code === 'INVALID_SNAPSHOT') {
            (0, replay_json_js_1.replayError)('WORLD_LIMIT', 'recording data exceeds resource bounds');
        }
        throw error;
    }
}
function attachRecorder(world) {
    const access = recording_owner_js_1.recordingWorlds.get(world);
    if (!access)
        (0, replay_json_js_1.replayError)('INVALID_SNAPSHOT', 'recorder requires a genuine World');
    let recorder;
    access.attach(({ model, options, state }) => {
        if ((0, identity_js_1.canonicalEncode)(model).length > 128 * 1024)
            (0, replay_json_js_1.replayError)('WORLD_LIMIT', 'recording model exceeds byte limit');
        if (state.fluids.length)
            (0, replay_json_js_1.replayError)('INVALID_SNAPSHOT', 'visual fluid profile recording is unsupported');
        const initial = { format: 'barocss-physics-recording', version: 2,
            model, options, identity: state.identity, frames: [], finalState: recordedState(state) };
        (0, replay_json_js_1.encodeRecordingData)(initial);
        const preparedOwner = { recording: initial, commandCount: 0,
            prepareFrames(commands, stepIndex) {
                return recordingBudget(() => {
                    const frames = [...preparedOwner.recording.frames,
                        { stepIndex, commands: (0, replay_json_js_1.copyReplayJson)(commands, 'commands') }];
                    // Byte/resource preflight only; the accepted final cursor remains unchanged here.
                    (0, replay_json_js_1.encodeRecordingData)({ ...preparedOwner.recording, frames });
                    return frames;
                });
            },
            prepare(frames, next) {
                return recordingBudget(() => {
                    const recording = { ...preparedOwner.recording, frames,
                        finalState: recordedState(next) };
                    (0, replay_json_js_1.encodeRecordingData)(recording);
                    return recording;
                });
            } };
        let detached = false;
        recorder = {
            getState: () => access.read(preparedOwner),
            step: (commands = []) => access.step(preparedOwner, commands),
            saveRecording() { access.read(preparedOwner); return (0, replay_json_js_1.copyReplayJson)(preparedOwner.recording, 'recording'); },
            dispose() { if (!detached) {
                access.detach(preparedOwner);
                detached = true;
            } },
        };
        return preparedOwner;
    });
    return recorder;
}
function restoreRecording(input, expectedInput) {
    const recording = (0, replay_validation_js_1.admitRecording)(input);
    const expected = (0, replay_json_js_1.copyReplayJson)(expectedInput, 'expected identity');
    (0, replay_json_js_1.exactFields)(expected, ['model', 'options', 'providerDigest'], 'expected identity');
    if (!(0, replay_json_js_1.equivalentReplayIdentity)(recording.model, expected.model) ||
        !(0, replay_json_js_1.equivalentReplayIdentity)(recording.options, expected.options) || recording.identity.providerDigest !== expected.providerDigest)
        (0, replay_json_js_1.replayError)('STALE_SNAPSHOT', 'recording identity differs from expected inputs');
    let world;
    try {
        world = (0, index_js_1.createPhysicsWorld)(recording.model, recording.options);
        if (!(0, replay_json_js_1.equivalentReplayIdentity)(world.getState().identity, recording.identity))
            (0, replay_json_js_1.replayError)('STALE_SNAPSHOT', 'recording provider differs from current provider');
        const recorder = createPhysicsRecorder(world);
        for (const frame of recording.frames)
            recorder.step(frame.commands);
        if (!(0, replay_compare_js_1.equivalentReplayValue)(recorder.getState(), recording.finalState))
            (0, replay_json_js_1.replayError)('INVALID_SNAPSHOT', 'final state differs from reconstructed state');
        return { world, recorder };
    }
    catch (error) {
        world?.dispose();
        if (error instanceof types_js_1.PhysicsError && error.code === 'STALE_SNAPSHOT')
            throw error;
        (0, replay_json_js_1.replayError)('INVALID_SNAPSHOT', 'recording reconstruction failed');
    }
}
function serializeRecording(input) {
    const recording = (0, replay_validation_js_1.admitRecording)(input);
    const candidate = restorePhysicsRecording(recording, { model: recording.model, options: recording.options, providerDigest: recording.identity.providerDigest });
    try {
        return (0, replay_json_js_1.encodeRecordingData)(recording);
    }
    finally {
        candidate.world.dispose();
    }
}
function deserializeRecording(bytes) {
    const recording = (0, replay_validation_js_1.admitRecording)((0, replay_json_js_1.decodeRecordingData)(bytes));
    const candidate = restorePhysicsRecording(recording, { model: recording.model, options: recording.options, providerDigest: recording.identity.providerDigest });
    try {
        return (0, replay_json_js_1.copyReplayJson)(recording, 'recording');
    }
    finally {
        candidate.world.dispose();
    }
}
function recordingOperation(operation, action) {
    try {
        return action();
    }
    catch (failure) {
        if (!(failure instanceof types_js_1.PhysicsError))
            throw failure;
        const error = new types_js_1.PhysicsError(failure.code, failure.message, {
            operation, domain: 'recording', entityIds: failure.details.entityIds,
            accepted: operation === 'record' ? failure.details.accepted : null,
            phase: failure.code === 'STALE_SNAPSHOT' ? 'identity' :
                failure.code === 'WORLD_LIMIT' ? 'budget' :
                    ['DISPOSED', 'WORLD_OWNED', 'REENTRANT_CALL'].includes(failure.code) ? 'lifecycle' : 'validation',
        });
        error.stack = failure.stack;
        throw error;
    }
}
function createPhysicsRecorder(world) {
    return recordingOperation('record', () => attachRecorder(world));
}
function restorePhysicsRecording(recording, expected) {
    return recordingOperation('restore', () => restoreRecording(recording, expected));
}
function serializePhysicsRecording(recording) {
    return recordingOperation('record', () => serializeRecording(recording));
}
function deserializePhysicsRecording(bytes) {
    return recordingOperation('record', () => deserializeRecording(bytes));
}
