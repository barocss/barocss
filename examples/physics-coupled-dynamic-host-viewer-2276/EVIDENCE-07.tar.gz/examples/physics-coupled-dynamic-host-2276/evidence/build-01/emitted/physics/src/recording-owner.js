"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordingWorlds = void 0;
exports.recordingWorlds = new WeakMap();
