/** Example-only existing Float verifier view; no QR stats or bridge adoption. */
import type { NormalProblem } from '../../packages/barocss-physics/src/stack/normal-solver.js';
import type { StationaryResult } from '../../packages/barocss-physics/src/stack/stationary-normal.js';
export declare function verifierView(p: NormalProblem, r: StationaryResult): {
    ok: boolean;
    status: import("../../packages/barocss-physics/src/stack/stationary-normal.js", { with: { "resolution-mode": "import" } }).StationaryStatus;
    bodies: readonly import("../../packages/barocss-physics/src/stack/normal-solver.js", { with: { "resolution-mode": "import" } }).NormalBody[];
    normalImpulsesNs: null;
    rowResiduals: null;
    certificate: null;
    stationaryStats: import("../../packages/barocss-physics/src/stack/stationary-normal.js", { with: { "resolution-mode": "import" } }).StationaryStats;
} | {
    ok: boolean;
    status: string;
    bodies: readonly import("../../packages/barocss-physics/src/stack/normal-solver.js", { with: { "resolution-mode": "import" } }).NormalBody[];
    normalImpulsesNs: number[] | null;
    rowResiduals: {
        id: string;
        normalSpeedMps: number;
        negativeNormalImpulseNs: number;
        complementarityJ: number;
        tangentSpeedMps: number;
    }[];
    certificate: {
        maxClosingNormalSpeedMps: number;
        maxNegativeNormalImpulseNs: number;
        maxComplementarityJ: number;
        maxStationaritySqrtJ: number;
        maxLoadedTangentSpeedMps: number;
        zeroTangentFeasible: boolean;
    };
    stationaryStats: import("../../packages/barocss-physics/src/stack/stationary-normal.js", { with: { "resolution-mode": "import" } }).StationaryStats;
};
