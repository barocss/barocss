import { createUprightCapsuleQuery, PhysicsError } from '@barocss/physics';
const query = createUprightCapsuleQuery({
    version: 1, profile: 'upright-capsule-box-v1', revision: 'room1',
    boxes: [{ id: 'wall', centerM: [0.5, 0.6, 0], halfExtentsM: [0.05, 1, 1], orientationXYZW: [0, 0, 0, 1] }],
});
try {
    const hit = query.sweep({ revision: 'room1', centerM: [-0.5, 0.6, 0], displacementM: [2, 0, 0], excludeId: null });
    // hit?.toiFraction is about0.4. normalFixtureToCapsule is dimensionless.
    // pointM is a box witness; segmentPointM is on the capsule centreline.
}
catch (error) {
    if (!(error instanceof PhysicsError))
        throw error;
    // code is the stable refusal field.
}
finally {
    query.dispose();
}
