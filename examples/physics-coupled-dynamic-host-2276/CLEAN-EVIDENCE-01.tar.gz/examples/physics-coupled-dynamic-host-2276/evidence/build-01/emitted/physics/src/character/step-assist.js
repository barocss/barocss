"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tryStep = tryStep;
exports.validateAssist = validateAssist;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
const math_js_1 = require("./math.js");
function tryStep(position, remaining, candidate, context) {
    const horizontal = [remaining[0], 0, remaining[2]], length = (0, math_js_1.norm)(horizontal);
    if (length <= 1e-12 || !candidate.grounded)
        return null;
    const direction = (0, math_js_1.scale)(horizontal, 1 / length);
    const up = context.sweep(position, [0, profile_js_1.STEP_HEIGHT, 0], 'step-up-probe', true);
    if (up.hit)
        return null;
    const raised = (0, math_js_1.add)(position, [0, profile_js_1.STEP_HEIGHT, 0]);
    const forward = context.sweep(raised, (0, math_js_1.scale)(direction, profile_js_1.PREVIEW), 'step-ahead-probe', true);
    if (forward.hit)
        return null;
    const preview = (0, math_js_1.add)(raised, (0, math_js_1.scale)(direction, profile_js_1.PREVIEW));
    const down = context.sweep(preview, [0, -profile_js_1.STEP_DOWN, 0], 'step-down-probe', true);
    if (!down.hit || down.hit.normalFixtureToCapsule[1] < profile_js_1.WALKABLE)
        return null;
    const targetY = raised[1] - profile_js_1.STEP_DOWN * down.hit.toiFraction + profile_js_1.SKIN / down.hit.normalFixtureToCapsule[1];
    const rise = targetY - position[1];
    if (rise <= 1e-9 || rise > profile_js_1.STEP_HEIGHT + 1e-6)
        return null;
    const actualRaised = (0, math_js_1.add)(position, [0, rise, 0]);
    const actual = context.sweep(actualRaised, horizontal, 'step-actual-forward', false);
    if (actual.hit)
        return null;
    let moved = context.commit(position, [0, rise, 0], 'step-up', up.indices);
    moved = context.commit(moved, horizontal, 'step-forward', actual.indices);
    candidate.assist = { bodyId: down.hit.bodyId, heightM: targetY, directionXZ: [direction[0], direction[2]], frames: 0 };
    candidate.fallVelocityYMps = 0;
    candidate.grounded = false;
    candidate.support = null;
    return moved;
}
function validateAssist(position, candidate, context, diagnostic) {
    if (!candidate.assist)
        return;
    const direction = [candidate.assist.directionXZ[0], 0, candidate.assist.directionXZ[1]];
    const ahead = context.sweep(position, (0, math_js_1.scale)(direction, profile_js_1.PREVIEW), 'assist-ahead', true);
    if (ahead.hit)
        throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller assist forward path is blocked');
    const down = context.sweep((0, math_js_1.add)(position, (0, math_js_1.scale)(direction, profile_js_1.PREVIEW)), [0, -profile_js_1.STEP_DOWN, 0], 'assist-support', true);
    const hit = down.hit;
    const target = hit ? position[1] - profile_js_1.STEP_DOWN * hit.toiFraction + profile_js_1.SKIN / hit.normalFixtureToCapsule[1] : NaN;
    if (!hit || hit.normalFixtureToCapsule[1] < profile_js_1.WALKABLE || hit.bodyId !== candidate.assist.bodyId ||
        Math.abs(target - candidate.assist.heightM) > 1e-6) {
        throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller assist support is unresolved');
    }
    candidate.assist.frames++;
    if (candidate.assist.frames > (diagnostic.assistCap ?? profile_js_1.ASSIST_CAP)) {
        throw new capsule_query_error_js_1.PhysicsError('WORLD_LIMIT', 'Controller assist duration limit exhausted');
    }
}
