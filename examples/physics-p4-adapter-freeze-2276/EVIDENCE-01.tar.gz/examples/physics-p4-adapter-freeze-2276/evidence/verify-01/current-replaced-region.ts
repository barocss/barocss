  /** Initialize every point, warm every eligible patch, then solve globally. */
  solve(): void {
    this.#requirePhase('assembled');
    const warmRows: WarmRow[] = [];
    for (const patch of this.#patches) {
      const compatible = compatiblePatch(this.#prior, patch.pairKey, patch.points, patch.family);
      this.#warmStats.testedPatches++;
      if (compatible) this.#warmStats.compatiblePatches++;
      else this.#warmStats.incompatiblePatches++;
      for (const point of patch.points) {
        const key = `${patch.pairKey}\u0000${point.id}`;
        const prior = compatible ? this.#prior.get(key) : undefined;
        const impulse = prior ? copyImpulse(prior) : { normalNs: 0, tangentNs: [0, 0, 0] as Vec3 };
        this.#pointsMap.set(key, impulse);
        this.#pointLedger.push({
          aId: patch.aId, bId: patch.bId, aIndex: patch.aIndex, bIndex: patch.bIndex,
          pairKey: patch.pairKey, pointId: point.id, family: patch.family,
          pointM: [...point.pointM] as Vec3, normal: [...patch.normal] as Vec3,
          aPositionM: [...this.#bodies[patch.aIndex].positionM] as Vec3,
          bPositionM: [...this.#bodies[patch.bIndex].positionM] as Vec3,
          warm: copyImpulse(impulse), final: copyImpulse(impulse),
        });
        if (prior) {
          this.#warmStats.reusedPoints++;
          warmRows.push({ patch, point, impulse });
        } else {
          this.#warmStats.coldPoints++;
        }
      }
    }
    // All initialization and warm starts precede the first point solve.
    for (const { patch, point, impulse } of warmRows) {
      warmStartPoint(this.#bodies[patch.aIndex], this.#bodies[patch.bIndex],
        point.pointM, patch.normal, impulse);
    }
    for (let sweep = 0; sweep < GLOBAL_CONTACT_SWEEPS; sweep++) {
      this.#globalStats.globalSweeps++;
      for (const patch of this.#patches) {
        const order = sweep % 2 ? [...patch.points].reverse() : patch.points;
        for (const point of order) {
          const impulse = this.#pointsMap.get(`${patch.pairKey}\u0000${point.id}`)!;
          solvePersistentPoint(this.#bodies[patch.aIndex], this.#bodies[patch.bIndex],
            point.pointM, patch.normal, impulse, 0);
          this.#globalStats.pointUpdates++;
        }
      }
    }
    for (const point of this.#pointLedger) {
      point.final = copyImpulse(this.#pointsMap.get(`${point.pairKey}\u0000${point.pointId}`)!);
    }
    this.#phase = 'solved';
  }

