import type { Body, Vec3 } from './internal-types.js';
/** Solve the two physical tangent constraints; the caller owns the Coulomb branch. */
export declare function solveStaticTangent(a: Body, b: Body, armA: Vec3, armB: Vec3, normal: Vec3, direction: Vec3, speed: number, tangentMass: number): {
    impulseNs: Vec3;
    magnitudeNs: number;
};
