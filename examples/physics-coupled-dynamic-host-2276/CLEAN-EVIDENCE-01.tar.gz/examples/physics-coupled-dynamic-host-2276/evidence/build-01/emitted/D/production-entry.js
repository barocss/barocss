"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.coupledStaticTarget = exports.coupledContactTarget = void 0;
var candidate_js_1 = require("./candidate.js");
Object.defineProperty(exports, "coupledContactTarget", { enumerable: true, get: function () { return candidate_js_1.coupledContactTarget; } });
var candidate_js_2 = require("../C/candidate.js");
Object.defineProperty(exports, "coupledStaticTarget", { enumerable: true, get: function () { return candidate_js_2.coupledStaticTarget; } });
