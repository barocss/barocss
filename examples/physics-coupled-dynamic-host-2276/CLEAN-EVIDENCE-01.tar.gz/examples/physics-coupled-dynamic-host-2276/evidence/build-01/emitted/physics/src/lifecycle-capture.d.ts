/** Private bounded lifecycle observation. Never feeds a physics/producer decision. */
import type { PhysicsState, PhysicsModel, Recording } from './types.js';
interface OwnerInput {
    recording: Recording | null;
    commandCount: number;
}
interface Readers {
    view: () => unknown;
    state: () => PhysicsState;
    model: () => PhysicsModel;
    private: () => unknown;
    owner: () => OwnerInput | null;
}
interface Captured {
    status: 'CAPTURED';
    worldId: number;
    publicState: PhysicsState;
    model: PhysicsModel;
    privateSnapshot: unknown;
    owner: {
        status: 'ACTUAL_ATTACHED_OWNER';
        recording: Recording | null;
        commandCount: number;
    } | {
        status: 'NOT_APPLICABLE_NO_ATTACHED_OWNER';
    };
    preflightCells: number;
    reservedCopyBytes: number;
}
interface Unresolved {
    status: 'UNRESOLVED';
    worldId: number;
    reason: string;
}
type Capture = Captured | Unresolved;
/** Called only at original nonreentrant, nondisposed dispose boundary. Never throws. */
export declare function captureBeforeDispose(worldId: number, read: Readers): void;
export declare function lifecycleCaptureStats(): {
    captureCalls: number;
    duplicateHookCalls: number;
    readCalls: number;
    readCopyBytes: number;
    captureCopyBytes: number;
    globalFailure: string | null;
    budget: {
        traceBytes: number;
        lifecycleBytes: number;
        limitBytes: number;
    };
    limits: {
        worlds: number;
        cells: number;
        depth: number;
        string: number;
        reads: number;
    };
};
/** Every return has its own bounded clone. No stored capture is exposed. */
export declare function lifecycleCaptures(): {
    status: string;
    records: Capture[];
    stats: {
        captureCalls: number;
        duplicateHookCalls: number;
        readCalls: number;
        readCopyBytes: number;
        captureCopyBytes: number;
        globalFailure: string | null;
        budget: {
            traceBytes: number;
            lifecycleBytes: number;
            limitBytes: number;
        };
        limits: {
            worlds: number;
            cells: number;
            depth: number;
            string: number;
            reads: number;
        };
    };
};
export {};
