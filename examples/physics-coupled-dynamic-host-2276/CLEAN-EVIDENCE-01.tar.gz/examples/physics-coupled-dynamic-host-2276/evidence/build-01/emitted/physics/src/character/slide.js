"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.move = move;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
const math_js_1 = require("./math.js");
const step_assist_js_1 = require("./step-assist.js");
function move(position, delta, candidate, context, diagnostic) {
    let p = [...position], remaining = [...delta];
    for (let pass = 0; pass < (diagnostic.slideBudget ?? profile_js_1.SLIDE_CAP); pass++) {
        if ((0, math_js_1.norm)(remaining) <= 1e-12)
            return p;
        const length = (0, math_js_1.norm)(remaining), direction = (0, math_js_1.scale)(remaining, 1 / length), probeLength = length + profile_js_1.LOOKAHEAD;
        const result = context.sweep(p, (0, math_js_1.scale)(direction, probeLength), 'slide-lookahead', true), hit = result.hit;
        if (!hit)
            return context.commit(p, remaining, 'travel', result.indices);
        const normal = hit.normalFixtureToCapsule, closingUnit = -(0, math_js_1.dot)(normal, direction);
        if (closingUnit <= 1e-12)
            throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller lookahead closing normal is unresolved');
        const contactDistance = probeLength * hit.toiFraction;
        const safeDistance = Math.max(0, contactDistance - profile_js_1.SKIN / closingUnit);
        const fraction = Math.min(1, safeDistance / length);
        const travel = (0, math_js_1.scale)(remaining, fraction);
        if ((0, math_js_1.norm)(travel) > 0)
            p = context.commit(p, travel, 'travel', result.indices);
        if (fraction === 1)
            return p;
        remaining = (0, math_js_1.scale)(remaining, 1 - fraction);
        if (normal[1] < profile_js_1.WALKABLE) {
            const stepped = (0, step_assist_js_1.tryStep)(p, remaining, candidate, context);
            if (stepped)
                return stepped;
            candidate.blocked = true;
            const horizontalNormal = [normal[0], 0, normal[2]], size = (0, math_js_1.norm)(horizontalNormal);
            if (size > 1e-12) {
                const unit = (0, math_js_1.scale)(horizontalNormal, 1 / size), into = (0, math_js_1.dot)(remaining, unit);
                if (into < 0)
                    remaining = (0, math_js_1.add)(remaining, (0, math_js_1.scale)(unit, -into));
            }
            if (normal[1] > 1e-12 && remaining[1] < 0) {
                remaining[1] = 0;
                candidate.fallVelocityYMps = 0;
            }
            else if (normal[1] < -1e-12 && remaining[1] > 0)
                remaining[1] = 0;
        }
        else {
            const into = (0, math_js_1.dot)(remaining, normal);
            if (into < 0)
                remaining = (0, math_js_1.add)(remaining, (0, math_js_1.scale)(normal, -into));
            candidate.fallVelocityYMps = 0;
        }
    }
    if ((0, math_js_1.norm)(remaining) > 1e-12)
        throw new capsule_query_error_js_1.PhysicsError('WORLD_LIMIT', 'Controller slide limit exhausted');
    return p;
}
