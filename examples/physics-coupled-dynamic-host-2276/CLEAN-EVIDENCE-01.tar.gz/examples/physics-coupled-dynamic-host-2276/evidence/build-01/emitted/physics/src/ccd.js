"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.admitCcd = admitCcd;
exports.sweepSphere = sweepSphere;
const math_js_1 = require("./math.js");
const validation_js_1 = require("./validation.js");
const ccd_rounded_box_js_1 = require("./ccd-rounded-box.js");
const ccd_box_js_1 = require("./ccd-box.js");
function admitCcd(bodies, jointCount, gravity) {
    const selected = bodies.filter((body) => body.ccd);
    if (selected.length === 0)
        return { kind: 'none' };
    const sphereIndex = bodies.findIndex((body) => body.ccd);
    if (selected.length === 1 && bodies.length === 2 && jointCount === 0 &&
        gravity.every((component) => component === 0) &&
        bodies.every((body) => body.kind === 'dynamic' && body.shape.kind === 'sphere' && !body.sensor)) {
        return { kind: 'sphere-pair', sphereIndex, otherIndex: 1 - sphereIndex };
    }
    if (selected.length === 1 && selected[0].shape.kind === 'box' &&
        bodies.length === 2 && jointCount === 0) {
        const fixtureIndex = 1 - sphereIndex;
        if (bodies[sphereIndex].kind === 'dynamic' && bodies[fixtureIndex].kind === 'static' &&
            !bodies[fixtureIndex].sensor && (0, ccd_box_js_1.axisAlignedBox)(bodies[sphereIndex]) &&
            (0, ccd_box_js_1.axisAlignedBox)(bodies[fixtureIndex])) {
            return { kind: 'box-pair', boxIndex: sphereIndex, fixtureIndex };
        }
    }
    const fixtures = bodies.filter((body) => body.kind === 'static' && !body.sensor && body.shape.kind === 'box');
    if (selected.length !== 1 || bodies.length !== fixtures.length + 1 ||
        bodies.filter((body) => body.kind === 'dynamic').length !== 1 ||
        fixtures.length < 1 || fixtures.length > 8 || jointCount !== 0) {
        (0, validation_js_1.error)('INVALID_CONFIG', 'unsupported CCD body pair or world profile');
    }
    if (selected[0].shape.kind !== 'sphere') {
        (0, validation_js_1.error)('INVALID_CONFIG', 'static-box CCD requires a dynamic sphere');
    }
    return { kind: 'static-boxes', sphereIndex,
        fixtures: fixtures.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0) };
}
function sweepSphere(previous, candidate, fixtures) {
    if (previous.shape.kind !== 'sphere')
        return null;
    const radius = previous.shape.radiusM;
    const travel = (0, math_js_1.sub)(candidate.positionM, previous.positionM);
    let earliest = null;
    for (const fixture of fixtures) {
        if (fixture.shape.kind !== 'box')
            continue;
        const hit = (0, ccd_rounded_box_js_1.sweepRoundedBox)((0, math_js_1.localPoint)(fixture, previous.positionM), (0, math_js_1.localPoint)(fixture, candidate.positionM), fixture.shape.halfExtentsM, radius);
        if (!hit || earliest && hit.fraction >= earliest.toiFraction)
            continue;
        earliest = { bodyId: previous.id, fixtureId: fixture.id, toiFraction: hit.fraction,
            normalFixtureToBody: (0, math_js_1.rotate)(fixture.orientation, hit.normalLocal) };
    }
    if (earliest) {
        candidate.positionM = (0, math_js_1.sub)((0, math_js_1.add)(previous.positionM, (0, math_js_1.scale)(travel, earliest.toiFraction)), (0, math_js_1.scale)(earliest.normalFixtureToBody, 1e-9));
    }
    return earliest;
}
