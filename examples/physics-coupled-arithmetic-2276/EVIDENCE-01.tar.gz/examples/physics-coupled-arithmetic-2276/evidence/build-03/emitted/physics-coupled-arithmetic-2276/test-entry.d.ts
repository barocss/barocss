import { type LowerLimits } from './test-context.js';
import type { ArithmeticLimits } from './limits.js';
import type { DynamicCounts, RootCertificate } from './types.js';
interface Base {
    lowerLimits?: LowerLimits;
}
export type ArithmeticTestRequest = (Base & {
    kind: 'polynomial';
    coefficients: string[];
    normalNumerator: string[];
}) | (Base & {
    kind: 'multiply';
    left: string[];
    right: string[];
}) | (Base & {
    kind: 'presentation';
    interval: [string, string];
}) | (Base & {
    kind: 'round';
    value: string;
}) | (Base & {
    kind: 'operation';
    operation: 'initialize' | 'parse' | 'multiply-integers' | 'shift-integer';
    values?: string[];
    shift?: number;
});
interface Observation {
    context: 'CREATED';
    counts: DynamicCounts;
    limits: Readonly<ArithmeticLimits>;
}
export type ArithmeticTestResult = (Observation & {
    status: 'CLASSIFIED';
    polynomialAscending: string[];
    sturmAscending: string[][];
    roots: RootCertificate[];
    selectedRoot: number;
}) | (Observation & {
    status: 'PRESENTED' | 'ROUNDED_RATIONAL';
    value: number;
}) | (Observation & {
    status: 'PRESENTATION_UNRESOLVED';
    value: null;
}) | (Observation & {
    status: 'COMPLETED';
    result: null | string | string[];
}) | (Observation & {
    status: 'UNRESOLVED';
    reason: string;
}) | {
    status: 'UNRESOLVED';
    reason: 'TEST_REQUEST_INVALID' | 'TEST_LIMIT_INVALID';
    context: 'NOT_CREATED';
    counts: null;
    limits: null;
};
export declare function runArithmeticTest(request: ArithmeticTestRequest): ArithmeticTestResult;
export {};
