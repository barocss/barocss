// examples/physics-contact-coherence-2276/candidate-exact-normal.ts
var STRICT_LINE_LIMITS = Object.freeze({
  rationalOperations: 2e5,
  integerOperations: 2e6,
  integerBits: 16384,
  roundingSteps: 16
});
var StrictLineFailure = class extends Error {
};
var ZERO = { n: 0n, d: 1n };
var ieee = new DataView(new ArrayBuffer(8));
var Arithmetic = class {
  counters = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 };
  guardCached() {
    if (this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
    if (this.counters.peakIntegerBits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
  }
  tick(amount = 1) {
    this.counters.integerOperations += amount;
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
  }
  op() {
    if (++this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
  }
  checked(value) {
    const hex = (value < 0n ? -value : value).toString(16), first = hex.charCodeAt(0);
    const bits = 4 * (hex.length - 1) + (first <= 49 ? 1 : first <= 51 ? 2 : first <= 55 ? 3 : 4);
    this.counters.peakIntegerBits = Math.max(this.counters.peakIntegerBits, bits);
    if (bits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
    return value;
  }
  multiply(a, b) {
    this.tick();
    return this.checked(a * b);
  }
  sum(a, b) {
    this.tick();
    return this.checked(a + b);
  }
  shifted(value, bits) {
    this.tick();
    return this.checked(value << BigInt(bits));
  }
  make(n, d = 1n) {
    this.checked(n);
    this.checked(d);
    return this.normalizeChecked(n, d);
  }
  /** Both operands have already passed checked in this call's evaluation order. */
  normalizeChecked(n, d) {
    if (d === 0n) throw new StrictLineFailure("zero rational denominator");
    if (n === 0n) return ZERO;
    if (d < 0n) {
      this.tick(2);
      n = -n;
      d = -d;
    }
    if (d === 1n) {
      this.guardCached();
      return { n, d };
    }
    let a = n < 0n ? -n : n, b = d;
    this.tick(2);
    if ((d & d - 1n) === 0n) {
      this.tick(2);
      const factor = a & -a, divisor = factor < d ? factor : d;
      this.tick(2);
      return { n: n / divisor, d: d / divisor };
    }
    while (b !== 0n) {
      this.tick();
      const remainder = a % b;
      a = b;
      b = remainder;
    }
    this.tick(2);
    return { n: n / a, d: d / a };
  }
  from(value) {
    this.op();
    if (!Number.isFinite(value)) throw new StrictLineFailure("nonfinite exact operand");
    ieee.setFloat64(0, value, false);
    const bits = ieee.getBigUint64(0, false), negative = bits >> 63n !== 0n;
    const exponent = Number(bits >> 52n & 2047n), fraction = bits & (1n << 52n) - 1n;
    const significand = exponent === 0 ? fraction : fraction + (1n << 52n);
    const power = exponent === 0 ? -1074 : exponent - 1023 - 52;
    const n = negative ? -significand : significand;
    return power >= 0 ? this.make(this.shifted(n, power)) : this.make(n, this.shifted(1n, -power));
  }
  add(a, b) {
    this.op();
    if (a.d === b.d) return this.make(this.sum(a.n, b.n), a.d);
    if (a.d > 0n && b.d > 0n) {
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(this.sum(a.n, this.multiply(b.n, ratio)), a.d);
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.sum(this.multiply(a.n, ratio), b.n), b.d);
      }
    }
    return this.normalizeChecked(this.sum(this.multiply(a.n, b.d), this.multiply(b.n, a.d)), this.multiply(a.d, b.d));
  }
  neg(a) {
    this.op();
    this.tick();
    return { n: -a.n, d: a.d };
  }
  sub(a, b) {
    return this.add(a, this.neg(b));
  }
  mul(a, b) {
    this.op();
    return this.normalizeChecked(this.multiply(a.n, b.n), this.multiply(a.d, b.d));
  }
  sumSquare(a, b) {
    const sum = this.add(a, b);
    this.op();
    const n = this.multiply(sum.n, sum.n), d = this.multiply(sum.d, sum.d);
    if (n === 0n) return ZERO;
    if (d === 1n) this.guardCached();
    return { n, d };
  }
  div(a, b) {
    this.op();
    if (a.d > 0n && b.d > 0n && b.n !== 0n) {
      this.guardCached();
      if (a.d === b.d) return this.make(a.n, b.n);
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(a.n, this.multiply(ratio, b.n));
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.multiply(ratio, a.n), b.n);
      }
    }
    return this.normalizeChecked(this.multiply(a.n, b.d), this.multiply(a.d, b.n));
  }
  compare(a, b) {
    this.op();
    const difference = this.sum(this.multiply(a.n, b.d), -this.multiply(b.n, a.d));
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
  }
  abs(a) {
    return a.n < 0n ? this.neg(a) : a;
  }
  vec(value, length = 3) {
    if (value.length !== length || !Array.from({ length }, (_, i) => i).every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    return value.map((x) => this.from(x));
  }
  dot(a, b) {
    return a.reduce((value, x, i) => {
      const product = this.mul(x, b[i]);
      return value === null && product.n !== 0n && product.d !== 1n ? product : this.add(value ?? ZERO, product);
    }, null) ?? ZERO;
  }
  quotient(a, b) {
    this.tick();
    return this.checked(a / b);
  }
  /** Called only after both original boxes have fully decoded and normalized. */
  prepareRotation(rotation) {
    let denominator = 1n;
    for (const row of rotation) for (const value of row) {
      if (value.d === 1n) continue;
      let a = denominator, b = value.d;
      while (b !== 0n) {
        this.tick();
        const remainder = a % b;
        a = b;
        b = remainder;
      }
      denominator = this.multiply(this.quotient(denominator, a), value.d);
    }
    if (denominator === 1n) return { denominator, columns: [0, 1, 2].map((axis) => rotation.map((row) => row[axis].n)) };
    const columns = [0, 1, 2].map((axis) => rotation.map((row) => this.multiply(row[axis].n, this.quotient(denominator, row[axis].d))));
    return { denominator, columns };
  }
  /** Relative coordinates are owned dyadics from unchanged from/sub calls. */
  localProjection(rotation, relative) {
    this.guardCached();
    let denominator = 1n;
    for (const value of relative) if (value.d > denominator) denominator = value.d;
    const scaled = relative.map((value) => this.multiply(value.n, this.quotient(denominator, value.d)));
    const divisor = this.multiply(rotation.denominator, denominator);
    return rotation.columns.map((column) => {
      this.op();
      let numerator = this.multiply(column[0], scaled[0]);
      for (let i = 1; i < 3; i++) numerator = this.sum(numerator, this.multiply(column[i], scaled[i]));
      return this.normalizeChecked(numerator, divisor);
    });
  }
  /** Correct nearest-even conversion, including subnormals; no Number(BigInt)/Number(BigInt). */
  number(value) {
    this.op();
    if (value.n === 0n) return 0;
    const negative = value.n < 0n, n = negative ? -value.n : value.n, d = value.d;
    let exponent = n.toString(2).length - d.toString(2).length;
    if (exponent >= 0 ? n < this.shifted(d, exponent) : this.shifted(n, -exponent) < d) exponent--;
    const unit = Math.max(-1074, exponent - 52);
    const numerator = unit < 0 ? this.shifted(n, -unit) : n;
    const denominator = unit > 0 ? this.shifted(d, unit) : d;
    this.tick(2);
    let quotient = numerator / denominator;
    const remainder = numerator % denominator;
    const twice = this.shifted(remainder, 1);
    if (twice > denominator || twice === denominator && (quotient & 1n) !== 0n) {
      this.tick();
      quotient++;
    }
    const result = Number(quotient) * Math.pow(2, unit);
    if (!Number.isFinite(result)) throw new StrictLineFailure("rounded witness overflow");
    return negative ? -result : result;
  }
};
var ExactNormalFailure = class extends Error {
  constructor(message, stats) {
    super("exact normal: " + message);
    this.stats = stats;
    this.name = "ExactNormalFailure";
  }
  code = "NUMERIC_LIMIT";
};
function refineExactNormal(problem, physicalBodies, proposedImpulsesNs) {
  const m = new Arithmetic();
  const refuse = (reason) => {
    throw new ExactNormalFailure(reason, { ...m.counters });
  };
  const need = (condition, reason) => {
    if (!condition) refuse(reason);
  };
  const finite = (value) => {
    need(Number.isFinite(value), "finite represented arithmetic");
    return value;
  };
  const add = (a, b) => a.map((x, i) => m.add(x, b[i]));
  const sub = (a, b) => a.map((x, i) => m.sub(x, b[i]));
  const scale = (a, b) => a.map((x) => m.mul(x, b));
  const mv = (matrix, value) => matrix.map((row) => m.dot(row, value));
  const cross = (a, b) => [
    m.sub(m.mul(a[1], b[2]), m.mul(a[2], b[1])),
    m.sub(m.mul(a[2], b[0]), m.mul(a[0], b[2])),
    m.sub(m.mul(a[0], b[1]), m.mul(a[1], b[0]))
  ];
  const crossFloat = (a, b) => [
    finite(finite(a[1] * b[2]) - finite(a[2] * b[1])),
    finite(finite(a[2] * b[0]) - finite(a[0] * b[2])),
    finite(finite(a[0] * b[1]) - finite(a[1] * b[0]))
  ];
  let ratioBytes = 0;
  const encode = (value) => {
    m.guardCached();
    const n = value.n.toString(), d = value.d.toString();
    ratioBytes += n.length + d.length + 20;
    need(ratioBytes <= 512 * 1024, "exact ratio report admission");
    return { n, d };
  };
  const encodeVec = (value) => value.map(encode);
  const tolerance = m.from(1e-10);
  const difference = (a, b) => m.number(m.abs(m.sub(a, b)));
  const within = (value, reason) => need(m.compare(m.abs(value), tolerance) <= 0, reason);
  try {
    need(Array.isArray(problem.bodies) && problem.bodies.length >= 1 && problem.bodies.length <= 4 && Array.isArray(physicalBodies) && physicalBodies.length === problem.bodies.length && Array.isArray(problem.points) && problem.points.length <= 32 && Array.isArray(proposedImpulsesNs) && proposedImpulsesNs.length === problem.points.length, "bounded populations");
    const ids = /* @__PURE__ */ new Map(), offsets = /* @__PURE__ */ new Map();
    const local = [], orientations = [], centers = [];
    const free = [], metric = [];
    let dof = 0;
    for (let i = 0; i < problem.bodies.length; i++) {
      const body = problem.bodies[i], actual = physicalBodies[i];
      need(body.id === actual.id && !ids.has(body.id), "actual unique body order");
      ids.set(body.id, i);
      for (const key of ["positionM", "velocityMps", "angularVelocityRadps"])
        need(body[key].length === 3 && body[key].every((value, k) => Object.is(value, actual[key][k])), "actual normal body words");
      need(Object.is(body.inverseMass, actual.inverseMass), "actual inverse mass word");
      centers.push(m.vec(actual.positionM));
      orientations.push(m.vec(actual.orientation, 4));
      local.push(m.vec(actual.inverseInertiaLocal));
      need(m.dot(orientations[i], orientations[i]).n > 0n, "nonzero physical quaternion");
      need(body.inverseMass === 0 || body.inverseMass >= 1e-6 && body.inverseMass <= 1e6, "inverse mass bound");
      need(body.inverseInertiaWorld.length === 3 && body.inverseInertiaWorld.every((row) => row.length === 3 && row.every(Number.isFinite)), "world tensor shape");
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
        need(Object.is(body.inverseInertiaWorld[r][c], body.inverseInertiaWorld[c][r]) || body.inverseInertiaWorld[r][c] === body.inverseInertiaWorld[c][r], "exact matrix symmetry");
      if (body.inverseMass === 0) {
        need([...body.velocityMps, ...body.angularVelocityRadps, ...body.inverseInertiaWorld.flat(), ...actual.inverseInertiaLocal].every((x) => x === 0), "prescribed static");
      } else {
        need(local[i].every((x) => x.n > 0n), "positive local physical inertia");
        offsets.set(i, dof);
        dof += 6;
        free.push(...m.vec(body.velocityMps), ...m.vec(body.angularVelocityRadps));
      }
    }
    need(dof > 0 && dof <= 24, "dynamic degree bound");
    for (let i = 0; i < dof; i++) metric.push(Array(dof).fill(ZERO));
    for (const [index, offset] of offsets) {
      const body = problem.bodies[index], tensor = body.inverseInertiaWorld.map((row) => m.vec(row));
      const minor2 = m.sub(m.mul(tensor[0][0], tensor[1][1]), m.mul(tensor[0][1], tensor[0][1]));
      const determinant = m.dot(tensor[0], cross(tensor[1], tensor[2]));
      need(tensor[0][0].n > 0n && minor2.n > 0n && determinant.n > 0n, "exact positive metric");
      for (let k = 0; k < 3; k++) {
        metric[offset + k][offset + k] = m.from(body.inverseMass);
        for (let j = 0; j < 3; j++) metric[offset + 3 + k][offset + 3 + j] = tensor[k][j];
      }
    }
    const pointIds = /* @__PURE__ */ new Set(), representedRows = [];
    const rows = problem.points.map((point) => {
      need(!pointIds.has(point.id) && ids.has(point.aId) && ids.has(point.bId) && point.aId !== point.bId, "unique actual point links");
      pointIds.add(point.id);
      need(point.pointM.length === 3 && point.normalAtoB.length === 3 && [...point.pointM, ...point.normalAtoB].every(Number.isFinite), "finite point operands");
      const row = Array(dof).fill(0);
      let dynamic = false;
      for (const [id, sign] of [[point.aId, -1], [point.bId, 1]]) {
        const index = ids.get(id), offset = offsets.get(index), body = problem.bodies[index];
        const arm = point.pointM.map((value, k) => finite(value - body.positionM[k]));
        need(arm.every((value) => Math.abs(value) <= 10), "existing arm bound");
        if (offset === void 0) continue;
        dynamic = true;
        const torque = crossFloat(arm, point.normalAtoB);
        for (let k = 0; k < 3; k++) {
          row[offset + k] = finite(sign * point.normalAtoB[k]);
          row[offset + 3 + k] = finite(sign * torque[k]);
        }
      }
      need(dynamic, "dynamic contact endpoint");
      representedRows.push(row);
      return m.vec(row, dof);
    });
    const proposed = proposedImpulsesNs.map((value) => {
      need(Number.isFinite(value) && value >= 0, "nonnegative proposed support");
      return m.from(value);
    });
    const support = proposed.flatMap((value, i) => value.n > 0n ? [i] : []);
    const gradients = rows.map((row) => mv(metric, row));
    const marginsFree = rows.map((row) => m.dot(row, free));
    const system = support.map((i) => [...support.map((j) => m.dot(rows[i], gradients[j])), m.neg(marginsFree[i])]);
    const pivots = [];
    let pivotRow = 0;
    for (let column = 0; column < support.length; column++) {
      const selected = system.findIndex((row, i) => i >= pivotRow && row[column].n !== 0n);
      if (selected < 0) continue;
      [system[pivotRow], system[selected]] = [system[selected], system[pivotRow]];
      const divisor = system[pivotRow][column];
      system[pivotRow] = system[pivotRow].map((value) => m.div(value, divisor));
      for (let row = 0; row < system.length; row++) if (row !== pivotRow && system[row][column].n !== 0n) {
        const factor = system[row][column];
        system[row] = sub(system[row], scale(system[pivotRow], factor));
      }
      pivots.push(column);
      pivotRow++;
    }
    need(!system.some((row) => row.slice(0, -1).every((value) => value.n === 0n) && row.at(-1).n !== 0n), "EXACT_KKT_NOT_PROVEN inconsistent support");
    const selectedDual = support.map((i) => proposed[i]);
    for (let k = 0; k < pivots.length; k++) {
      let value = system[k].at(-1);
      for (let j = 0; j < support.length; j++) if (!pivots.includes(j)) value = m.sub(value, m.mul(system[k][j], selectedDual[j]));
      selectedDual[pivots[k]] = value;
    }
    const lambda = rows.map(() => ZERO);
    support.forEach((row, k) => {
      lambda[row] = selectedDual[k];
    });
    need(lambda.every((value) => value.n >= 0n), "EXACT_KKT_NOT_PROVEN negative dual");
    let qpVelocity = [...free];
    for (let i = 0; i < rows.length; i++) if (lambda[i].n !== 0n) qpVelocity = add(qpVelocity, scale(gradients[i], lambda[i]));
    const margins = rows.map((row) => m.dot(row, qpVelocity));
    need(margins.every((value, i) => value.n >= 0n && m.mul(value, lambda[i]).n === 0n), "EXACT_KKT_NOT_PROVEN primal/complementarity");
    const rotate = (index, value, backwards = false) => {
      const [x, y, z, w] = orientations[index], norm = m.dot(orientations[index], orientations[index]);
      const twice = m.from(2), u = [x, y, z];
      const diagonal = m.sub(m.mul(w, w), m.dot(u, u));
      const axial = scale(u, m.mul(twice, m.dot(u, value)));
      const twist = scale(cross(u, value), m.mul(twice, backwards ? m.neg(w) : w));
      return add(add(scale(value, diagonal), axial), twist).map((entry) => m.div(entry, norm));
    };
    const physicalAction = (index, value) => {
      const diagonal = local[index];
      if (diagonal.every((entry) => m.compare(entry, diagonal[0]) === 0)) return scale(value, diagonal[0]);
      return rotate(index, rotate(index, value, true).map((entry, k) => m.mul(entry, diagonal[k])));
    };
    const linear = physicalBodies.map(() => [ZERO, ZERO, ZERO]), angular = physicalBodies.map(() => [ZERO, ZERO, ZERO]);
    const exactApplications = [];
    for (let p = 0; p < problem.points.length; p++) {
      const point = problem.points[p], ai = ids.get(point.aId), bi = ids.get(point.bId);
      const location = m.vec(point.pointM), normal = m.vec(point.normalAtoB), force = scale(normal, lambda[p]);
      const side = (index, sign) => {
        const arm = sub(location, centers[index]), impulse = sign === 1 ? force : force.map((value) => m.neg(value));
        const torque = cross(arm, impulse);
        linear[index] = add(linear[index], impulse);
        angular[index] = add(angular[index], torque);
        return { comM: encodeVec(centers[index]), armM: encodeVec(arm), linearImpulseNs: encodeVec(impulse), armTorqueNms: encodeVec(torque) };
      };
      exactApplications.push({
        id: point.id,
        aIndex: ai,
        bIndex: bi,
        pointM: encodeVec(location),
        normalAtoB: encodeVec(normal),
        lambdaNs: encode(lambda[p]),
        onA: side(ai, -1),
        onB: side(bi, 1)
      });
    }
    let maxTensor = 0, maxDifference = 0;
    const appliedBodies = physicalBodies.map((body) => structuredClone(body)), aggregates = [];
    const qpBodies = problem.bodies.map((body) => ({
      ...body,
      positionM: [...body.positionM],
      velocityMps: [...body.velocityMps],
      angularVelocityRadps: [...body.angularVelocityRadps],
      inverseInertiaWorld: body.inverseInertiaWorld.map((row) => [...row])
    }));
    for (const [index, offset] of offsets) {
      for (let k = 0; k < 3; k++) {
        const basis = [ZERO, ZERO, ZERO];
        basis[k] = m.from(1);
        const physicalColumn = physicalAction(index, basis);
        for (let j = 0; j < 3; j++) {
          const delta = m.sub(physicalColumn[j], metric[offset + 3 + j][offset + 3 + k]);
          within(delta, "physical tensor versus represented tensor");
          maxTensor = Math.max(maxTensor, m.number(m.abs(delta)));
        }
      }
      const body = physicalBodies[index], dv = scale(linear[index], m.from(body.inverseMass)), dw = physicalAction(index, angular[index]);
      const v = add(m.vec(body.velocityMps), dv), w = add(m.vec(body.angularVelocityRadps), dw);
      const round = (old, value, action) => action.n === 0n ? old : m.number(value);
      appliedBodies[index].velocityMps = v.map((value, k) => round(body.velocityMps[k], value, dv[k]));
      appliedBodies[index].angularVelocityRadps = w.map((value, k) => round(body.angularVelocityRadps[k], value, dw[k]));
      qpBodies[index].velocityMps = qpVelocity.slice(offset, offset + 3).map((value) => m.number(value));
      qpBodies[index].angularVelocityRadps = qpVelocity.slice(offset + 3, offset + 6).map((value) => m.number(value));
      for (let k = 0; k < 6; k++) {
        const delta = m.sub([...v, ...w][k], qpVelocity[offset + k]);
        within(delta, "physical aggregate versus exact QP motion");
        maxDifference = Math.max(maxDifference, difference([...v, ...w][k], qpVelocity[offset + k]));
      }
      aggregates.push({
        id: body.id,
        linearImpulseNs: encodeVec(linear[index]),
        armTorqueNms: encodeVec(angular[index]),
        linearActionMps: encodeVec(dv),
        angularActionRadps: encodeVec(dw),
        velocityMps: encodeVec(v),
        angularVelocityRadps: encodeVec(w)
      });
    }
    let maxClosing = 0, maxComplementarity = 0;
    for (let p = 0; p < problem.points.length; p++) {
      const point = problem.points[p];
      const at = (id) => {
        const index = ids.get(id), body = appliedBodies[index];
        return add(m.vec(body.velocityMps), cross(m.vec(body.angularVelocityRadps), sub(m.vec(point.pointM), centers[index])));
      };
      const speed = m.dot(sub(at(point.bId), at(point.aId)), m.vec(point.normalAtoB));
      need(m.compare(speed, m.neg(tolerance)) >= 0, "rounded physical point closing");
      const complementarity = m.mul(speed, lambda[p]);
      within(complementarity, "rounded physical complementarity");
      maxClosing = Math.max(maxClosing, speed.n < 0n ? m.number(m.neg(speed)) : 0);
      maxComplementarity = Math.max(maxComplementarity, m.number(m.abs(complementarity)));
    }
    const result = {
      ok: true,
      status: "EXACT_KKT_PHYSICAL_AGGREGATE",
      representedRows,
      lambdaNs: encodeVec(lambda),
      qpVelocity: encodeVec(qpVelocity),
      marginsMps: encodeVec(margins),
      exactApplications,
      bodyAggregates: aggregates,
      appliedBodies,
      roundedReporting: { semantics: "ROUNDED_REPORT_ONLY_NOT_BODY_MUTATION", normalImpulsesNs: lambda.map((value) => m.number(value)), qpBodies },
      certificate: {
        supportRows: support,
        exactRank: pivots.length,
        exactKkt: true,
        maxPhysicalTensorDifference: maxTensor,
        maxPhysicalQpVelocityDifference: maxDifference,
        maxRoundedPhysicalClosingMps: maxClosing,
        maxRoundedComplementarityJ: maxComplementarity
      },
      stats: { ...m.counters }
    };
    m.guardCached();
    return result;
  } catch (error) {
    if (error instanceof StrictLineFailure) refuse(error.message);
    throw error;
  }
}
export {
  ExactNormalFailure,
  STRICT_LINE_LIMITS,
  refineExactNormal
};
