/** Eighth-order composition of implicit midpoint free rotation; no retained state. */
import type { Body, Quat, Vec3 } from './internal-types.js';
export interface FreeRotationResult {
    orientation: Quat;
    angularVelocityRadps: Vec3;
}
export declare const triaxialFreeRotationCoefficients: Readonly<{
    exponents: readonly [3, 5, 7];
    roots: readonly number[];
    a: readonly number[];
    b: readonly number[];
    weights: readonly number[];
}>;
export declare function prepareFreeRotation(body: Body, dt: number): FreeRotationResult | null;
