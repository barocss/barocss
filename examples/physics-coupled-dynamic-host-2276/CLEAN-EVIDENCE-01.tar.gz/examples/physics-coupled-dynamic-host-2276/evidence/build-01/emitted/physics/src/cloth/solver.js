"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClothSolver = void 0;
const constraints_js_1 = require("./constraints.js");
const profile_js_1 = require("./profile.js");
/** The measured XPBD order: eight inner steps, two projections per inner step. */
class ClothSolver {
    before = new Float64Array(289 * 3);
    decay = Math.exp(-profile_js_1.CLOTH_PROFILE.velocityDecayPerSecond * profile_js_1.CLOTH_PROFILE.dt);
    step(sheet, positions, velocities) {
        const p = positions, dt = profile_js_1.CLOTH_PROFILE.dt;
        for (let substep = 0; substep < profile_js_1.CLOTH_SUBSTEPS; substep++) {
            this.before.set(p);
            for (let i = 0; i < sheet.inverseMasses.length; i++) {
                if (sheet.inverseMasses[i] === 0)
                    continue;
                for (let axis = 0; axis < 3; axis++) {
                    const j = 3 * i + axis;
                    velocities[j] = this.decay * velocities[j] + dt * profile_js_1.CLOTH_PROFILE.gravityMps2[axis];
                    p[j] += dt * velocities[j];
                }
            }
            for (const constraint of sheet.constraints)
                constraint.lambda = 0;
            for (let iteration = 0; iteration < profile_js_1.CLOTH_ITERATIONS; iteration++) {
                for (const constraint of sheet.constraints)
                    (0, constraints_js_1.projectDistance)(sheet, constraint);
                (0, constraints_js_1.projectSphere)(sheet);
            }
            for (let j = 0; j < p.length; j++)
                velocities[j] = (p[j] - this.before[j]) / dt;
        }
    }
}
exports.ClothSolver = ClothSolver;
