"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseJoints = parseJoints;
exports.projectJoint = projectJoint;
const limits_js_1 = require("./limits.js");
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
const dynamic_fixed_joint_js_1 = require("./dynamic-fixed-joint.js");
const dynamic_hinge_joint_js_1 = require("./dynamic-hinge-joint.js");
function denseJointVector(value, bound, label) {
    if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 ||
        ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
        (0, validation_js_1.error)('INVALID_CONFIG', `${label} must be a dense 3-vector`);
    }
    return (0, validation_js_1.vector)(value, -bound, bound, label);
}
function parseJoints(value, bodies) {
    if (!Array.isArray(value) || value.length > 8 || Reflect.ownKeys(value).length !== value.length + 1 ||
        !Array.from({ length: value.length }, (_, index) => Object.hasOwn(value, index)).every(Boolean)) {
        (0, validation_js_1.error)('INVALID_CONFIG', 'joints must be a dense array of at most 8');
    }
    const byId = new Map(bodies.map((body, index) => [body.id, { body, index }]));
    const seenIds = new Set(), seenDynamic = new Set();
    const joints = value.map((raw) => {
        const input = (0, validation_js_1.record)(raw, 'joint');
        if (input.kind !== 'fixed' && input.kind !== 'hinge')
            (0, validation_js_1.error)('INVALID_CONFIG', 'unsupported joint kind');
        (0, validation_js_1.fields)(input, input.kind === 'fixed'
            ? ['id', 'kind', 'aId', 'bId', 'anchorALocalM', 'anchorBLocalM']
            : ['id', 'kind', 'aId', 'bId', 'anchorALocalM', 'anchorBLocalM', 'axisWorld', 'limitRad', 'motor'], 'joint');
        if (typeof input.id !== 'string' || !limits_js_1.ID.test(input.id) || seenIds.has(input.id)) {
            (0, validation_js_1.error)('INVALID_CONFIG', 'joint IDs must be unique valid identifiers');
        }
        const a = typeof input.aId === 'string' ? byId.get(input.aId) : undefined;
        const b = typeof input.bId === 'string' ? byId.get(input.bId) : undefined;
        if (!a || !b || a.index === b.index || b.body.kind !== 'dynamic' ||
            seenDynamic.has(b.body.id)) {
            (0, validation_js_1.error)('INVALID_CONFIG', 'joint needs a distinct A and unique dynamic B');
        }
        if (a.body.kind === 'dynamic' && (value.length !== 1 ||
            bodies.length !== 2 || a.body.shape.kind !== 'sphere' || b.body.shape.kind !== 'sphere')) {
            (0, validation_js_1.error)('INVALID_CONFIG', 'dynamic pair supports one joint between two dynamic spheres');
        }
        const anchorALocalM = denseJointVector(input.anchorALocalM, 100, 'anchorALocalM');
        const anchorBLocalM = denseJointVector(input.anchorBLocalM, 100, 'anchorBLocalM');
        if (Math.hypot(...(0, math_js_1.sub)((0, math_js_1.worldPoint)(a.body, anchorALocalM), (0, math_js_1.worldPoint)(b.body, anchorBLocalM))) > 1e-6) {
            (0, validation_js_1.error)('INVALID_CONFIG', 'initial joint anchors must coincide');
        }
        let axisWorld, limitRad;
        let motor;
        if (input.kind === 'hinge') {
            axisWorld = denseJointVector(input.axisWorld, 1 + 1e-9, 'axisWorld');
            if (Math.abs(Math.hypot(...axisWorld) - 1) > 1e-9)
                (0, validation_js_1.error)('INVALID_CONFIG', 'hinge axis must be unit length');
            const limits = input.limitRad;
            if (!Array.isArray(limits) || limits.length !== 2 || Reflect.ownKeys(limits).length !== 3 ||
                ![0, 1].every((index) => Object.hasOwn(limits, index))) {
                (0, validation_js_1.error)('INVALID_CONFIG', 'hinge limits must be a dense pair');
            }
            const low = (0, validation_js_1.finite)(limits[0], -Math.PI / 2, 0, 'limitRad[0]');
            const high = (0, validation_js_1.finite)(limits[1], 0, Math.PI / 2, 'limitRad[1]');
            limitRad = [low, high];
            if (Object.hasOwn(input, 'motor')) {
                const motorInput = (0, validation_js_1.record)(input.motor, 'motor');
                (0, validation_js_1.fields)(motorInput, ['targetSpeedRadps', 'maxImpulseNms', 'maxReactionNms'], 'motor');
                const targetSpeedRadps = (0, validation_js_1.finite)(motorInput.targetSpeedRadps, -2, 2, 'motor.targetSpeedRadps');
                const maxImpulseNms = (0, validation_js_1.finite)(motorInput.maxImpulseNms, 0, 0.05, 'motor.maxImpulseNms');
                const maxReactionNms = (0, validation_js_1.finite)(motorInput.maxReactionNms, 0, 1, 'motor.maxReactionNms');
                if (maxImpulseNms === 0 || maxReactionNms === 0) {
                    (0, validation_js_1.error)('INVALID_CONFIG', 'motor impulse and reaction limits must be positive');
                }
                motor = { targetSpeedRadps, maxImpulseNms, maxReactionNms };
            }
        }
        seenIds.add(input.id);
        seenDynamic.add(b.body.id);
        return { id: input.id, kind: input.kind, aIndex: a.index, bIndex: b.index,
            anchorALocalM, anchorBLocalM,
            referenceOrientation: input.kind === 'fixed'
                ? (0, math_js_1.multiplyQuaternion)((0, math_js_1.inverse)(a.body.orientation), b.body.orientation)
                : [...b.body.orientation],
            ...(axisWorld ? { axisWorld } : {}), ...(limitRad ? { limitRad } : {}),
            ...(motor ? { motor } : {}) };
    });
    return joints;
}
function projectJoint(joint, next, previous, dt) {
    const a = next[joint.aIndex], b = next[joint.bIndex];
    if (a.kind === 'dynamic')
        return joint.kind === 'fixed'
            ? (0, dynamic_fixed_joint_js_1.projectDynamicFixedJoint)(joint, next, dt) : (0, dynamic_hinge_joint_js_1.projectDynamicHingeJoint)(joint, next, dt);
    const beforeVelocity = [...b.velocityMps];
    const beforeAngular = [...b.angularVelocityRadps];
    let targetOrientation, angleRad;
    if (joint.kind === 'fixed') {
        targetOrientation = (0, math_js_1.multiplyQuaternion)(a.orientation, joint.referenceOrientation);
        b.angularVelocityRadps = [0, 0, 0];
    }
    else {
        const axis = joint.axisWorld;
        const delta = (0, math_js_1.multiplyQuaternion)(b.orientation, (0, math_js_1.inverse)(joint.referenceOrientation));
        const signed = (0, math_js_1.dot)([delta[0], delta[1], delta[2]], axis);
        const raw = 2 * Math.atan2(signed, delta[3]);
        const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
        angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
        const half = angleRad / 2;
        targetOrientation = (0, math_js_1.multiplyQuaternion)([axis[0] * Math.sin(half), axis[1] * Math.sin(half),
            axis[2] * Math.sin(half), Math.cos(half)], joint.referenceOrientation);
        let speed = (0, math_js_1.dot)(b.angularVelocityRadps, axis);
        if ((angleRad === joint.limitRad[0] && speed < 0) ||
            (angleRad === joint.limitRad[1] && speed > 0))
            speed = 0;
        b.angularVelocityRadps = (0, math_js_1.scale)(axis, speed);
    }
    const norm = Math.hypot(...targetOrientation);
    b.orientation = targetOrientation.map((value) => value / norm);
    const targetPosition = (0, math_js_1.sub)((0, math_js_1.worldPoint)(a, joint.anchorALocalM), (0, math_js_1.rotate)(b.orientation, joint.anchorBLocalM));
    if (Math.hypot(...(0, math_js_1.sub)(targetPosition, b.positionM)) > limits_js_1.MAX_STEP_DISPLACEMENT_M) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', `${joint.id} projection exceeded movement limit`);
    }
    b.positionM = targetPosition;
    b.velocityMps = (0, math_js_1.scale)((0, math_js_1.sub)(targetPosition, previous[joint.bIndex].positionM), 1 / dt);
    return { id: joint.id, kind: joint.kind, aId: a.id, bId: b.id,
        linearImpulseNs: (0, math_js_1.scale)((0, math_js_1.sub)(b.velocityMps, beforeVelocity), 1 / b.inverseMass),
        angularImpulseNms: (0, math_js_1.inertia)(b, (0, math_js_1.sub)(b.angularVelocityRadps, beforeAngular)),
        ...(angleRad === undefined ? {} : { angleRad }) };
}
