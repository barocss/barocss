import type { Body, Vec3 } from '../internal-types.js';
import { PhysicsError } from '../internal-types.js';
import type { FrozenStackPatch, StackNormalResult } from './normal-bridge.js';
import type { NormalProblem } from './normal-solver.js';
import type { StationaryResult } from './stationary-normal.js';
import type { FullPairPositionAttempt, FullPairPositionStats, PointLedger } from './world-types.js';
export interface StackStepDiagnostics {
    beforeBodies: Body[];
    freeBodies: Body[] | null;
    velocityBodies: Body[] | null;
    geometryPatches: FrozenStackPatch[];
    pointLedger: PointLedger[];
    normalProblem: NormalProblem | null;
    normalResult: StackNormalResult | null;
    stationaryNormalWitness: StationaryResult | null;
    positionAttempt: FullPairPositionAttempt | null;
    positionStats: FullPairPositionStats | null;
}
export interface PreparedStackStep {
    candidateBodies: Body[];
    diagnostics: StackStepDiagnostics;
}
export declare class StackStepFailure extends PhysicsError {
    readonly diagnostics: StackStepDiagnostics;
    constructor(reason: PhysicsError, diagnostics: StackStepDiagnostics);
}
/** Prepare one detached unforced step; never mutate accepted caller state. */
export declare function prepareStackStep(bodies: readonly Body[], dt: number, gravity: Vec3): PreparedStackStep;
