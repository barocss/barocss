// src/index.ts
export * from "./types.js";

// src/world.ts
import { PhysicsError as PhysicsError7 } from "./types.js";

// src/internal-types.ts
import { PhysicsError } from "./types.js";

// src/limits.ts
var ID = /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/;
var MAX_STEPS = 3600;
var MAX_STEP_DISPLACEMENT_M = 10;
var MAX_COMMANDS = 64;
var MAX_FORCE_N = 1e6;
var MAX_IMPULSE_NS = 1e5;
var MAX_TORQUE_NM = 1e6;
var MAX_ANGULAR_IMPULSE_NMS = 1e5;
var SOLVER_PASSES = 8;

// src/validation.ts
function error(code, message) {
  throw new PhysicsError(code, message);
}
function record(value, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) error("INVALID_CONFIG", `${label} must be an object`);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) error("INVALID_CONFIG", `${label} must be a plain object`);
  return value;
}
function fields(value, allowed, label) {
  if (Reflect.ownKeys(value).some((key) => typeof key !== "string" || !allowed.includes(key))) {
    error("INVALID_CONFIG", `${label} has an unsupported field`);
  }
}
function finite(value, min, max, label) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max) {
    error("INVALID_CONFIG", `${label} must be finite and in [${min}, ${max}]`);
  }
  return value;
}
function vector(value, min, max, label) {
  if (!Array.isArray(value) || value.length !== 3) error("INVALID_CONFIG", `${label} must be a 3-vector`);
  return [0, 1, 2].map((index) => finite(value[index], min, max, `${label}[${index}]`));
}
function angularVector(value) {
  if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "angularVelocityRadps must be a dense 3-vector");
  }
  return vector(value, -1e3, 1e3, "angularVelocityRadps");
}
function quaternion(value) {
  if (!Array.isArray(value) || value.length !== 4 || Reflect.ownKeys(value).length !== 5 || ![0, 1, 2, 3].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "orientation must be a dense [x,y,z,w] quaternion");
  }
  const values = value.map((component) => finite(component, -1, 1, "orientation"));
  const magnitude2 = Math.hypot(...values);
  if (Math.abs(magnitude2 - 1) > 1e-6) error("INVALID_CONFIG", "orientation must have unit norm");
  return values.map((component) => component / magnitude2);
}
function shape(value) {
  const input = record(value, "shape");
  if (input.kind === "sphere") {
    fields(input, ["kind", "radiusM"], "sphere");
    return { kind: "sphere", radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM") };
  }
  if (input.kind === "box") {
    fields(input, ["kind", "halfExtentsM"], "box");
    return { kind: "box", halfExtentsM: vector(input.halfExtentsM, 1e-4, 1e3, "halfExtentsM") };
  }
  if (input.kind === "capsule") {
    fields(input, ["kind", "radiusM", "halfLengthM"], "capsule");
    return {
      kind: "capsule",
      radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM"),
      halfLengthM: finite(input.halfLengthM, 1e-4, 1e3, "halfLengthM")
    };
  }
  return error("INVALID_CONFIG", "unsupported collider shape");
}
function friction(value) {
  const input = record(value, "friction");
  fields(input, ["static", "dynamic"], "friction");
  const staticCoefficient = finite(input.static, 0, 2, "friction.static");
  const dynamicCoefficient = finite(input.dynamic, 0, staticCoefficient, "friction.dynamic");
  return { static: staticCoefficient, dynamic: dynamicCoefficient };
}
function collisionFilter(value) {
  const input = record(value, "collisionFilter");
  fields(input, ["categoryBits", "maskBits"], "collisionFilter");
  if (!Number.isInteger(input.categoryBits) || !Number.isInteger(input.maskBits)) {
    error("INVALID_CONFIG", "collision filter bits must be integers");
  }
  return {
    categoryBits: finite(input.categoryBits, 1, 65535, "categoryBits"),
    maskBits: finite(input.maskBits, 0, 65535, "maskBits")
  };
}
function parseBody(value, largeMode = false) {
  const input = record(value, "body");
  if (typeof input.id !== "string" || !ID.test(input.id)) error("INVALID_CONFIG", "invalid body ID");
  if (input.kind !== "dynamic" && input.kind !== "static" && input.kind !== "kinematic") {
    error("INVALID_CONFIG", "invalid body kind");
  }
  const kind = input.kind;
  fields(input, kind === "dynamic" ? [
    "id",
    "kind",
    "shape",
    "positionM",
    "velocityMps",
    "massKg",
    "restitution",
    "orientation",
    "angularVelocityRadps",
    "inertiaKgM2",
    "friction",
    "ccd",
    ...largeMode ? ["collisionFilter"] : []
  ] : [
    "id",
    "kind",
    "shape",
    "positionM",
    "restitution",
    "orientation",
    "sensor",
    "friction",
    ...largeMode ? ["collisionFilter"] : []
  ], "body");
  if (Object.hasOwn(input, "sensor") && input.sensor !== true) error("INVALID_CONFIG", "sensor must be true");
  const sensor = input.sensor === true;
  const parsedShape = shape(input.shape);
  if (Object.hasOwn(input, "ccd") && (input.ccd !== true || parsedShape.kind !== "sphere" && parsedShape.kind !== "box")) {
    error("INVALID_CONFIG", "ccd is supported for dynamic spheres or boxes only and must be true");
  }
  const positionM = vector(input.positionM, -1e4, 1e4, "positionM");
  const restitution = finite(input.restitution, 0, 1, "restitution");
  const material = Object.hasOwn(input, "friction") ? friction(input.friction) : { static: 0, dynamic: 0 };
  const filter = largeMode ? Object.hasOwn(input, "collisionFilter") ? collisionFilter(input.collisionFilter) : { categoryBits: 1, maskBits: 65535 } : void 0;
  const orientation = Object.hasOwn(input, "orientation") ? quaternion(input.orientation) : [0, 0, 0, 1];
  if (kind !== "dynamic") {
    return {
      id: input.id,
      kind,
      shape: parsedShape,
      positionM,
      velocityMps: [0, 0, 0],
      orientation,
      angularVelocityRadps: [0, 0, 0],
      inverseInertiaLocal: [0, 0, 0],
      sensor,
      inverseMass: 0,
      restitution,
      frictionStatic: material.static,
      frictionDynamic: material.dynamic,
      ...filter ? { collisionFilter: filter } : {}
    };
  }
  const massKg = finite(input.massKg, 1e-6, 1e6, "massKg");
  if (parsedShape.kind !== "sphere" && Object.hasOwn(input, "inertiaKgM2")) {
    error("INVALID_CONFIG", "inertiaKgM2 override is supported for spheres only");
  }
  const inertiaKgM2 = parsedShape.kind === "sphere" ? Object.hasOwn(input, "inertiaKgM2") ? finite(input.inertiaKgM2, 1e-12, 1e12, "inertiaKgM2") : 0.4 * massKg * parsedShape.radiusM ** 2 : void 0;
  const inertiaDiagonalKgM2 = parsedShape.kind === "box" ? [
    massKg / 3 * (parsedShape.halfExtentsM[1] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[1] ** 2)
  ] : parsedShape.kind === "capsule" ? capsuleMoments(massKg, parsedShape.radiusM, parsedShape.halfLengthM) : void 0;
  const inertia2 = inertiaDiagonalKgM2 ?? [inertiaKgM2, inertiaKgM2, inertiaKgM2];
  return {
    id: input.id,
    kind,
    shape: parsedShape,
    positionM,
    sensor,
    ...filter ? { collisionFilter: filter, sleeping: false } : {},
    ...input.ccd === true ? { ccd: true } : {},
    velocityMps: vector(input.velocityMps, -1e3, 1e3, "velocityMps"),
    orientation,
    angularVelocityRadps: Object.hasOwn(input, "angularVelocityRadps") ? angularVector(input.angularVelocityRadps) : [0, 0, 0],
    ...inertiaKgM2 === void 0 ? {} : { inertiaKgM2 },
    ...inertiaDiagonalKgM2 === void 0 ? {} : { inertiaDiagonalKgM2 },
    inverseInertiaLocal: inertia2.map((value2) => 1 / value2),
    inverseMass: 1 / massKg,
    restitution,
    frictionStatic: material.static,
    frictionDynamic: material.dynamic
  };
}
function capsuleMoments(massKg, radiusM, halfLengthM) {
  const cylinderMass = massKg * (3 * halfLengthM) / (3 * halfLengthM + 2 * radiusM);
  const capMass = massKg - cylinderMass;
  const radiusSquared2 = radiusM * radiusM;
  const axial = cylinderMass * radiusSquared2 / 2 + capMass * 2 * radiusSquared2 / 5;
  const transverse = cylinderMass * (radiusSquared2 / 4 + halfLengthM * halfLengthM / 3) + capMass * (2 * radiusSquared2 / 5 + halfLengthM * halfLengthM + 3 * halfLengthM * radiusM / 4);
  return [transverse, axial, transverse];
}
function copyShape(value) {
  return value.kind === "sphere" ? { kind: "sphere", radiusM: value.radiusM } : value.kind === "box" ? { kind: "box", halfExtentsM: [...value.halfExtentsM] } : { kind: "capsule", radiusM: value.radiusM, halfLengthM: value.halfLengthM };
}
function copyBody(body) {
  return {
    ...body,
    shape: copyShape(body.shape),
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    orientation: [...body.orientation],
    angularVelocityRadps: [...body.angularVelocityRadps],
    ...body.collisionFilter ? { collisionFilter: { ...body.collisionFilter } } : {},
    ...body.inertiaDiagonalKgM2 ? { inertiaDiagonalKgM2: [...body.inertiaDiagonalKgM2] } : {},
    inverseInertiaLocal: [...body.inverseInertiaLocal]
  };
}
function commandVector(input, bound, label) {
  if (!Array.isArray(input) || input.length !== 3 || Reflect.ownKeys(input).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(input, index))) {
    error("INVALID_COMMAND", `${label} must be a dense 3-vector`);
  }
  const result = [input[0], input[1], input[2]];
  if (result.some((value) => typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > bound)) {
    error("INVALID_COMMAND", `${label} must have finite components within \xB1${bound}`);
  }
  return result;
}
function parseCommands(input, bodies) {
  if (!Array.isArray(input) || input.length > MAX_COMMANDS || Reflect.ownKeys(input).length !== input.length + 1 || !Array.from({ length: input.length }, (_, index) => Object.hasOwn(input, index)).every(Boolean)) {
    error("INVALID_COMMAND", `commands must be a dense array of at most ${MAX_COMMANDS}`);
  }
  const byId = new Map(bodies.map((body) => [body.id, body]));
  const admitted3 = /* @__PURE__ */ new Map();
  for (const [index, raw] of input.entries()) {
    if (raw === null || typeof raw !== "object" || Array.isArray(raw) || Object.getPrototypeOf(raw) !== Object.prototype && Object.getPrototypeOf(raw) !== null) {
      error("INVALID_COMMAND", `command ${index} must be a plain object`);
    }
    const descriptors = Object.getOwnPropertyDescriptors(raw);
    const keys = Reflect.ownKeys(raw);
    const kind = descriptors.kind?.value;
    const valueKey = kind === "force" ? "forceN" : kind === "impulse" ? "impulseNs" : kind === "torque" ? "torqueNm" : kind === "angularImpulse" ? "angularImpulseNms" : kind === "kinematicTarget" ? "positionM" : null;
    if (!valueKey || keys.length !== 3 || keys.some((key) => typeof key !== "string" || !["kind", "bodyId", valueKey].includes(key)) || ["kind", "bodyId", valueKey].some((key) => !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
      error("INVALID_COMMAND", `command ${index} has unsupported fields`);
    }
    const bodyId = descriptors.bodyId.value;
    const body = typeof bodyId === "string" ? byId.get(bodyId) : void 0;
    if (!body || (kind === "kinematicTarget" ? body.kind !== "kinematic" : body.kind !== "dynamic")) {
      error("INVALID_COMMAND", `command ${index} targets an unknown or unsupported body`);
    }
    const previous = admitted3.get(body.id) ?? {};
    if (Object.hasOwn(previous, valueKey)) error("INVALID_COMMAND", `duplicate ${kind} command for ${body.id}`);
    const bound = kind === "force" ? MAX_FORCE_N : kind === "impulse" ? MAX_IMPULSE_NS : kind === "torque" ? MAX_TORQUE_NM : kind === "angularImpulse" ? MAX_ANGULAR_IMPULSE_NMS : 1e4;
    const value = commandVector(descriptors[valueKey].value, bound, `command ${index}.${valueKey}`);
    admitted3.set(body.id, { ...previous, [valueKey]: value });
  }
  return admitted3;
}
function queryRecord(input, required, optional) {
  if (input === null || typeof input !== "object" || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype && Object.getPrototypeOf(input) !== null) {
    error("INVALID_QUERY", "query must be a plain object");
  }
  const descriptors = Object.getOwnPropertyDescriptors(input);
  const keys = Reflect.ownKeys(input);
  if (keys.some((key) => typeof key !== "string" || ![...required, ...optional].includes(key)) || required.some((key) => !Object.hasOwn(descriptors, key)) || keys.some((key) => !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
    error("INVALID_QUERY", "query has missing or unsupported fields");
  }
  return Object.fromEntries(keys.map((key) => [key, descriptors[key].value]));
}
function queryVector(input, bound, label) {
  if (!Array.isArray(input) || input.length !== 3 || Reflect.ownKeys(input).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(input, index))) {
    error("INVALID_QUERY", `${label} must be a dense 3-vector`);
  }
  const values = [input[0], input[1], input[2]];
  if (values.some((value) => typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > bound)) {
    error("INVALID_QUERY", `${label} components must be finite within \xB1${bound}`);
  }
  return values;
}
function queryNumber(input, min, max, label) {
  if (typeof input !== "number" || !Number.isFinite(input) || input < min || input > max) {
    error("INVALID_QUERY", `${label} must be finite and in [${min}, ${max}]`);
  }
  return input;
}
function includeSensors(query) {
  if (!Object.hasOwn(query, "includeSensors")) return true;
  if (typeof query.includeSensors !== "boolean") error("INVALID_QUERY", "includeSensors must be boolean");
  return query.includeSensors;
}

// src/stack/stationary-profile.ts
var STATIONARY_PROFILE = "rigid-stationary-cube-stack-v1";
var STATIONARY_MAX_STEPS = 1200;
var same = (actual, expected) => actual.length === expected.length && actual.every((value, index) => value === expected[index]);
function requireProfile(value, message) {
  if (!value) error("INVALID_CONFIG", "stationary cube stack: " + message);
}
function admitStationaryProfile(model2, options, bodies) {
  requireProfile(options.profile === STATIONARY_PROFILE && options.broadPhase === "direct" && options.fixedStepSeconds === 1 / 120 && same(model2.gravityMps2, [0, -9.81, 0]), "fixed direct dt/gravity");
  requireProfile(bodies.length === 9 && bodies.filter((body) => body.kind === "dynamic").length === 8 && bodies.filter((body) => body.kind === "static").length === 1 && model2.joints.length === 0 && model2.cloths.length === 0 && model2.fluids.length === 0, "eight cubes and one floor only");
  for (let index = 0; index < bodies.length; index++) {
    const body = bodies[index], authored = model2.bodies[index];
    requireProfile(
      body.shape.kind === "box" && !body.sensor && !body.ccd && !body.collisionFilter && !body.sleeping && body.restitution === 0 && body.frictionStatic === 1 && body.frictionDynamic === 0.7,
      "original unfiltered unsensed box material"
    );
    requireProfile(same(body.velocityMps, [0, 0, 0]) && same(body.angularVelocityRadps, [0, 0, 0]), "zero initial motion");
    if (body.kind === "dynamic") {
      requireProfile(authored.kind === "dynamic" && authored.massKg === 1 && authored.inertia.kind === "primitive-com" && body.inverseMass === 1 && same(body.inverseInertiaLocal, [24, 24, 24]) && same(body.shape.halfExtentsM, [0.25, 0.25, 0.25]), "unit primitive-COM isotropic cube");
      requireProfile(authored.initial.orientationXYZW[0] === 0 && authored.initial.orientationXYZW[2] === 0 && body.orientation[0] === 0 && body.orientation[2] === 0, "authored yaw-only orientation");
    } else {
      requireProfile(body.kind === "static" && body.inverseMass === 0 && same(body.inverseInertiaLocal, [0, 0, 0]) && same(body.shape.halfExtentsM, [2, 0.1, 2]) && same(body.positionM, [0, -0.1, 0]) && same(body.orientation, [0, 0, 0, 1]) && same(authored.initial.orientationXYZW, [0, 0, 0, 1]), "fixed original floor");
    }
  }
}
function admitStationaryCommands(commands) {
  if (commands.length !== 0) error("INVALID_COMMAND", "stationary cube stack admits empty commands only");
}

// src/identity.ts
import { PhysicsError as PhysicsError2 } from "./types.js";
function copyData(input) {
  let count = 0;
  function copy2(value, depth) {
    if (++count > 1e6 || depth > 32) throw new PhysicsError2("INVALID_CONFIG", "data exceeds bounded depth or size");
    if (value === null || typeof value === "boolean") return value;
    if (typeof value === "string") {
      for (const character of value) {
        const point2 = character.codePointAt(0);
        if (point2 >= 55296 && point2 <= 57343) throw new PhysicsError2("INVALID_CONFIG", "strings must be well-formed Unicode");
      }
      return value;
    }
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || value === null) throw new PhysicsError2("INVALID_CONFIG", "only finite plain data is supported");
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Reflect.ownKeys(value);
    if (Array.isArray(value)) {
      if (Object.getPrototypeOf(value) !== Array.prototype || keys.length !== value.length + 1 || !Array.from({ length: value.length }, (_, i) => descriptors[i]?.enumerable && "value" in descriptors[i]).every(Boolean)) {
        throw new PhysicsError2("INVALID_CONFIG", "arrays must be dense ordinary data arrays");
      }
      return Array.from({ length: value.length }, (_, i) => copy2(descriptors[i].value, depth + 1));
    }
    if (Object.getPrototypeOf(value) !== Object.prototype || keys.some((key) => typeof key !== "string" || !/^[\x20-\x7e]+$/.test(key) || !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
      throw new PhysicsError2("INVALID_CONFIG", "records must have plain ASCII data fields");
    }
    return Object.fromEntries(keys.map((key) => [key, copy2(descriptors[key].value, depth + 1)]));
  }
  return copy2(input, 0);
}
function canonicalEncode(input) {
  const value = copyData(input);
  const bytes = [];
  const encodeUtf8 = (text3) => {
    const result = [];
    for (const character of text3) {
      let point2 = character.codePointAt(0);
      if (point2 >= 55296 && point2 <= 57343) point2 = 65533;
      if (point2 < 128) result.push(point2);
      else if (point2 < 2048) result.push(192 | point2 >> 6, 128 | point2 & 63);
      else if (point2 < 65536) result.push(224 | point2 >> 12, 128 | point2 >> 6 & 63, 128 | point2 & 63);
      else result.push(240 | point2 >> 18, 128 | point2 >> 12 & 63, 128 | point2 >> 6 & 63, 128 | point2 & 63);
    }
    return result;
  };
  const uint32 = (number) => {
    for (let i = 0; i < 4; i++) bytes.push(number >>> i * 8 & 255);
  };
  function write(item) {
    if (item === null) {
      bytes.push(0);
      return;
    }
    if (typeof item === "boolean") {
      bytes.push(item ? 2 : 1);
      return;
    }
    if (typeof item === "string") {
      const encoded = encodeUtf8(item);
      bytes.push(3);
      uint32(encoded.length);
      for (const byte of encoded) bytes.push(byte);
      return;
    }
    if (typeof item === "number") {
      bytes.push(4);
      const data2 = new DataView(new ArrayBuffer(8));
      data2.setFloat64(0, item, true);
      for (let i = 0; i < 8; i++) bytes.push(data2.getUint8(i));
      return;
    }
    if (Array.isArray(item)) {
      bytes.push(5);
      uint32(item.length);
      for (const entry of item) write(entry);
      return;
    }
    const record5 = item;
    const keys = Object.keys(record5).sort();
    bytes.push(6);
    uint32(keys.length);
    for (const key of keys) {
      write(key);
      write(record5[key]);
    }
  }
  write(value);
  return Uint8Array.from(bytes);
}
var K = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
var rotate = (x, n) => x >>> n | x << 32 - n;
function sha256(bytes) {
  const padded = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  const bits2 = bytes.length * 8;
  view.setUint32(padded.length - 8, Math.floor(bits2 / 4294967296));
  view.setUint32(padded.length - 4, bits2 >>> 0);
  const h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4);
    for (let i = 16; i < 64; i++) {
      const a3 = w[i - 15], b3 = w[i - 2];
      w[i] = w[i - 16] + (rotate(a3, 7) ^ rotate(a3, 18) ^ a3 >>> 3) + w[i - 7] + (rotate(b3, 17) ^ rotate(b3, 19) ^ b3 >>> 10) >>> 0;
    }
    let [a2, b2, c, d, e, f, g, j] = h;
    for (let i = 0; i < 64; i++) {
      const t1 = j + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
      const t2 = (rotate(a2, 2) ^ rotate(a2, 13) ^ rotate(a2, 22)) + (a2 & b2 ^ a2 & c ^ b2 & c) >>> 0;
      j = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b2;
      b2 = a2;
      a2 = t1 + t2 >>> 0;
    }
    for (const [i, v] of [a2, b2, c, d, e, f, g, j].entries()) h[i] = h[i] + v >>> 0;
  }
  return `sha256:${h.map((word2) => word2.toString(16).padStart(8, "0")).join("")}`;
}
function digest(value) {
  return sha256(canonicalEncode(value));
}

// src/math.ts
function multiplyQuaternion(a2, b2) {
  const [ax, ay, az, aw] = a2, [bx, by, bz, bw] = b2;
  return [
    aw * bx + ax * bw + ay * bz - az * by,
    aw * by - ax * bz + ay * bw + az * bx,
    aw * bz + ax * by - ay * bx + az * bw,
    aw * bw - ax * bx - ay * by - az * bz
  ];
}
function advanceOrientation(orientation, angularVelocity, dt) {
  const speed = Math.hypot(...angularVelocity);
  if (speed === 0) return [...orientation];
  const halfAngle = speed * dt / 2;
  const scale4 = Math.sin(halfAngle) / speed;
  const delta = [
    angularVelocity[0] * scale4,
    angularVelocity[1] * scale4,
    angularVelocity[2] * scale4,
    Math.cos(halfAngle)
  ];
  const next = multiplyQuaternion(delta, orientation);
  const norm2 = Math.hypot(...next);
  return next.map((component) => component / norm2);
}
var add = (a2, b2) => a2.map((value, index) => value + b2[index]);
var sub = (a2, b2) => a2.map((value, index) => value - b2[index]);
var scale = (a2, value) => a2.map((component) => component * value);
var dot = (a2, b2) => a2.reduce((sum, value, index) => sum + value * b2[index], 0);
var cross = (a2, b2) => [a2[1] * b2[2] - a2[2] * b2[1], a2[2] * b2[0] - a2[0] * b2[2], a2[0] * b2[1] - a2[1] * b2[0]];
var inverse = (q) => [-q[0], -q[1], -q[2], q[3]];
function rotate2(q, v) {
  const axis = [q[0], q[1], q[2]];
  const t = scale(cross(axis, v), 2);
  return add(v, add(scale(t, q[3]), cross(axis, t)));
}
var localPoint = (body, point2) => rotate2(inverse(body.orientation), sub(point2, body.positionM));
var worldPoint = (body, point2) => add(body.positionM, rotate2(body.orientation, point2));
function inverseInertia(body, vector3) {
  const local = rotate2(inverse(body.orientation), vector3);
  return rotate2(body.orientation, local.map((value, index) => value * body.inverseInertiaLocal[index]));
}
function inertia(body, vector3) {
  const local = rotate2(inverse(body.orientation), vector3);
  return rotate2(body.orientation, local.map((value, index) => value / body.inverseInertiaLocal[index]));
}

// src/dynamic-anchor-pair.ts
function solvePairMatrix(columns, target) {
  const rows = [0, 1, 2].map((row) => [
    columns[0][row],
    columns[1][row],
    columns[2][row],
    target[row]
  ]);
  for (let column = 0; column < 3; column++) {
    let pivot = column;
    for (let row = column + 1; row < 3; row++) {
      if (Math.abs(rows[row][column]) > Math.abs(rows[pivot][column])) pivot = row;
    }
    if (!Number.isFinite(rows[pivot][column]) || Math.abs(rows[pivot][column]) < 1e-12) {
      error("NUMERIC_LIMIT", "dynamic pair effective mass is singular");
    }
    [rows[column], rows[pivot]] = [rows[pivot], rows[column]];
    const divisor = rows[column][column];
    for (let index = column; index < 4; index++) rows[column][index] /= divisor;
    for (let row = 0; row < 3; row++) {
      if (row === column) continue;
      const factor2 = rows[row][column];
      for (let index = column; index < 4; index++) rows[row][index] -= factor2 * rows[column][index];
    }
  }
  const result = rows.map((row) => row[3]);
  if (result.some((value) => !Number.isFinite(value))) {
    error("NUMERIC_LIMIT", "dynamic pair correction is not finite");
  }
  return result;
}
function applyPairAngle(body, angle2, dt) {
  if (Math.hypot(...angle2) > 1) error("NUMERIC_LIMIT", "dynamic pair angular correction exceeds limit");
  body.orientation = advanceOrientation(body.orientation, angle2, 1);
  body.angularVelocityRadps = add(body.angularVelocityRadps, scale(angle2, 1 / dt));
}
function projectDynamicPairAnchors(a2, b2, anchorA, anchorB, dt) {
  const armA = rotate2(a2.orientation, anchorA);
  const armB = rotate2(b2.orientation, anchorB);
  const separation = sub(worldPoint(b2, anchorB), worldPoint(a2, anchorA));
  if (Math.hypot(...separation) > MAX_STEP_DISPLACEMENT_M) {
    error("NUMERIC_LIMIT", "dynamic pair anchor separation exceeds limit");
  }
  const basis3 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const columns = basis3.map((axis) => add(
    scale(axis, a2.inverseMass + b2.inverseMass),
    add(
      cross(inverseInertia(a2, cross(armA, axis)), armA),
      cross(inverseInertia(b2, cross(armB, axis)), armB)
    )
  ));
  const correction = solvePairMatrix(columns, scale(separation, -1));
  const moveA = scale(correction, -a2.inverseMass);
  const moveB = scale(correction, b2.inverseMass);
  a2.positionM = add(a2.positionM, moveA);
  b2.positionM = add(b2.positionM, moveB);
  a2.velocityMps = add(a2.velocityMps, scale(moveA, 1 / dt));
  b2.velocityMps = add(b2.velocityMps, scale(moveB, 1 / dt));
  applyPairAngle(a2, scale(inverseInertia(a2, cross(armA, correction)), -1), dt);
  applyPairAngle(b2, inverseInertia(b2, cross(armB, correction)), dt);
}

// src/dynamic-fixed-joint.ts
function orientationError(actual, desired) {
  const relative = multiplyQuaternion(actual, inverse(desired));
  const sign = relative[3] < 0 ? -1 : 1;
  const vector3 = scale([relative[0], relative[1], relative[2]], sign);
  const sine = Math.hypot(...vector3);
  if (sine < 1e-12) return scale(vector3, 2);
  return scale(vector3, 2 * Math.atan2(sine, sign * relative[3]) / sine);
}
function projectDynamicFixedJoint(joint, bodies, dt) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const beforeLinear = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  const desired = multiplyQuaternion(a2.orientation, joint.referenceOrientation);
  const angularError = orientationError(b2.orientation, desired);
  if (Math.hypot(...angularError) > 1) {
    error("NUMERIC_LIMIT", "dynamic fixed joint relative orientation exceeds limit");
  }
  const basis3 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const angularColumns = basis3.map((axis) => add(inverseInertia(a2, axis), inverseInertia(b2, axis)));
  const angularImpulse = solvePairMatrix(angularColumns, scale(angularError, -1));
  applyPairAngle(a2, scale(inverseInertia(a2, angularImpulse), -1), dt);
  applyPairAngle(b2, inverseInertia(b2, angularImpulse), dt);
  projectDynamicPairAnchors(a2, b2, joint.anchorALocalM, joint.anchorBLocalM, dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeLinear), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular))
  };
}

// src/dynamic-hinge-joint.ts
var magnitude = (vector3) => Math.hypot(...vector3);
var near = (a2, b2) => magnitude(sub(a2, b2)) <= 1e-9;
function offsetFixture(joint, a2, b2) {
  return near(a2.positionM, [-0.1, 0, 0]) && near(b2.positionM, [0.1, 0, 0]) && near(joint.anchorALocalM, [0.1, 0, 0]) && near(joint.anchorBLocalM, [-0.1, 0, 0]) && near(joint.axisWorld, [0, 0, 1]) && Math.abs(joint.limitRad[0] + 0.8) <= 1e-9 && Math.abs(joint.limitRad[1] - 0.8) <= 1e-9 && a2.inverseMass === 1 && b2.inverseMass === 1 && a2.shape.kind === "sphere" && b2.shape.kind === "sphere" && a2.shape.radiusM === 0.1 && b2.shape.radiusM === 0.1 && joint.motor?.targetSpeedRadps === 0.5 && joint.motor.maxImpulseNms === 1e-4 && joint.motor.maxReactionNms === 0.01;
}
function admitDynamicHingeScene(joint, bodies, gravity) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const identity2 = [0, 0, 0, 1];
  const centred = near(a2.positionM, b2.positionM) && magnitude(joint.anchorALocalM) === 0 && magnitude(joint.anchorBLocalM) === 0;
  if (magnitude(gravity) !== 0 || !centred && !offsetFixture(joint, a2, b2) || [a2, b2].some((body) => magnitude(body.velocityMps) !== 0 || magnitude(body.angularVelocityRadps) !== 0 || body.orientation.some((value, index) => Math.abs(value - identity2[index]) > 1e-12))) {
    error("INVALID_CONFIG", "dynamic hinge needs an admitted resting pair and zero gravity");
  }
}
function admitDynamicHingeCommands(joint, bodies, actions) {
  const axis = joint.axisWorld;
  for (const bodyIndex of [joint.aIndex, joint.bIndex]) {
    const action = actions.get(bodies[bodyIndex].id);
    if (!action) continue;
    if (action.forceN || action.impulseNs || [action.torqueNm, action.angularImpulseNms].filter((vector3) => vector3 !== void 0).some((vector3) => magnitude(sub(vector3, scale(axis, dot(vector3, axis)))) > 1e-12)) {
      error("INVALID_COMMAND", "dynamic hinge admits axis-aligned angular commands only");
    }
  }
}
function projectDynamicHingeJoint(joint, bodies, dt) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const axis = joint.axisWorld;
  const beforeLinear = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  const relative = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const signed = dot([relative[0], relative[1], relative[2]], axis);
  if (magnitude(sub([relative[0], relative[1], relative[2]], scale(axis, signed))) > 1e-8) {
    error("NUMERIC_LIMIT", "dynamic hinge left its planar axis");
  }
  const raw = 2 * Math.atan2(signed, relative[3]);
  const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
  const angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
  const inverseA = dot(axis, inverseInertia(a2, axis));
  const inverseB = dot(axis, inverseInertia(b2, axis));
  const inverseSum = inverseA + inverseB;
  const excess = wrapped - angleRad;
  if (excess !== 0) {
    const angleA = excess * inverseA / inverseSum;
    const angleB = -excess * inverseB / inverseSum;
    a2.orientation = advanceOrientation(a2.orientation, scale(axis, angleA), 1);
    b2.orientation = advanceOrientation(b2.orientation, scale(axis, angleB), 1);
    a2.angularVelocityRadps = add(a2.angularVelocityRadps, scale(axis, angleA / dt));
    b2.angularVelocityRadps = add(b2.angularVelocityRadps, scale(axis, angleB / dt));
  }
  const relativeSpeed = dot(sub(b2.angularVelocityRadps, a2.angularVelocityRadps), axis);
  if (angleRad === joint.limitRad[0] && relativeSpeed < 0 || angleRad === joint.limitRad[1] && relativeSpeed > 0) {
    const impulse = -relativeSpeed / inverseSum;
    a2.angularVelocityRadps = sub(
      a2.angularVelocityRadps,
      inverseInertia(a2, scale(axis, impulse))
    );
    b2.angularVelocityRadps = add(
      b2.angularVelocityRadps,
      inverseInertia(b2, scale(axis, impulse))
    );
  }
  projectDynamicPairAnchors(a2, b2, joint.anchorALocalM, joint.anchorBLocalM, dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeLinear), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular)),
    angleRad
  };
}

// src/joints.ts
function denseJointVector(value, bound, label) {
  if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", `${label} must be a dense 3-vector`);
  }
  return vector(value, -bound, bound, label);
}
function parseJoints(value, bodies) {
  if (!Array.isArray(value) || value.length > 8 || Reflect.ownKeys(value).length !== value.length + 1 || !Array.from({ length: value.length }, (_, index) => Object.hasOwn(value, index)).every(Boolean)) {
    error("INVALID_CONFIG", "joints must be a dense array of at most 8");
  }
  const byId = new Map(bodies.map((body, index) => [body.id, { body, index }]));
  const seenIds = /* @__PURE__ */ new Set(), seenDynamic = /* @__PURE__ */ new Set();
  const joints = value.map((raw) => {
    const input = record(raw, "joint");
    if (input.kind !== "fixed" && input.kind !== "hinge") error("INVALID_CONFIG", "unsupported joint kind");
    fields(input, input.kind === "fixed" ? ["id", "kind", "aId", "bId", "anchorALocalM", "anchorBLocalM"] : ["id", "kind", "aId", "bId", "anchorALocalM", "anchorBLocalM", "axisWorld", "limitRad", "motor"], "joint");
    if (typeof input.id !== "string" || !ID.test(input.id) || seenIds.has(input.id)) {
      error("INVALID_CONFIG", "joint IDs must be unique valid identifiers");
    }
    const a2 = typeof input.aId === "string" ? byId.get(input.aId) : void 0;
    const b2 = typeof input.bId === "string" ? byId.get(input.bId) : void 0;
    if (!a2 || !b2 || a2.index === b2.index || b2.body.kind !== "dynamic" || seenDynamic.has(b2.body.id)) {
      error("INVALID_CONFIG", "joint needs a distinct A and unique dynamic B");
    }
    if (a2.body.kind === "dynamic" && (value.length !== 1 || bodies.length !== 2 || a2.body.shape.kind !== "sphere" || b2.body.shape.kind !== "sphere")) {
      error("INVALID_CONFIG", "dynamic pair supports one joint between two dynamic spheres");
    }
    const anchorALocalM = denseJointVector(input.anchorALocalM, 100, "anchorALocalM");
    const anchorBLocalM = denseJointVector(input.anchorBLocalM, 100, "anchorBLocalM");
    if (Math.hypot(...sub(worldPoint(a2.body, anchorALocalM), worldPoint(b2.body, anchorBLocalM))) > 1e-6) {
      error("INVALID_CONFIG", "initial joint anchors must coincide");
    }
    let axisWorld, limitRad;
    let motor;
    if (input.kind === "hinge") {
      axisWorld = denseJointVector(input.axisWorld, 1 + 1e-9, "axisWorld");
      if (Math.abs(Math.hypot(...axisWorld) - 1) > 1e-9) error("INVALID_CONFIG", "hinge axis must be unit length");
      const limits = input.limitRad;
      if (!Array.isArray(limits) || limits.length !== 2 || Reflect.ownKeys(limits).length !== 3 || ![0, 1].every((index) => Object.hasOwn(limits, index))) {
        error("INVALID_CONFIG", "hinge limits must be a dense pair");
      }
      const low = finite(limits[0], -Math.PI / 2, 0, "limitRad[0]");
      const high = finite(limits[1], 0, Math.PI / 2, "limitRad[1]");
      limitRad = [low, high];
      if (Object.hasOwn(input, "motor")) {
        const motorInput = record(input.motor, "motor");
        fields(motorInput, ["targetSpeedRadps", "maxImpulseNms", "maxReactionNms"], "motor");
        const targetSpeedRadps = finite(motorInput.targetSpeedRadps, -2, 2, "motor.targetSpeedRadps");
        const maxImpulseNms = finite(motorInput.maxImpulseNms, 0, 0.05, "motor.maxImpulseNms");
        const maxReactionNms = finite(motorInput.maxReactionNms, 0, 1, "motor.maxReactionNms");
        if (maxImpulseNms === 0 || maxReactionNms === 0) {
          error("INVALID_CONFIG", "motor impulse and reaction limits must be positive");
        }
        motor = { targetSpeedRadps, maxImpulseNms, maxReactionNms };
      }
    }
    seenIds.add(input.id);
    seenDynamic.add(b2.body.id);
    return {
      id: input.id,
      kind: input.kind,
      aIndex: a2.index,
      bIndex: b2.index,
      anchorALocalM,
      anchorBLocalM,
      referenceOrientation: input.kind === "fixed" ? multiplyQuaternion(inverse(a2.body.orientation), b2.body.orientation) : [...b2.body.orientation],
      ...axisWorld ? { axisWorld } : {},
      ...limitRad ? { limitRad } : {},
      ...motor ? { motor } : {}
    };
  });
  return joints;
}
function projectJoint(joint, next, previous, dt) {
  const a2 = next[joint.aIndex], b2 = next[joint.bIndex];
  if (a2.kind === "dynamic") return joint.kind === "fixed" ? projectDynamicFixedJoint(joint, next, dt) : projectDynamicHingeJoint(joint, next, dt);
  const beforeVelocity = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  let targetOrientation, angleRad;
  if (joint.kind === "fixed") {
    targetOrientation = multiplyQuaternion(a2.orientation, joint.referenceOrientation);
    b2.angularVelocityRadps = [0, 0, 0];
  } else {
    const axis = joint.axisWorld;
    const delta = multiplyQuaternion(b2.orientation, inverse(joint.referenceOrientation));
    const signed = dot([delta[0], delta[1], delta[2]], axis);
    const raw = 2 * Math.atan2(signed, delta[3]);
    const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
    angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
    const half = angleRad / 2;
    targetOrientation = multiplyQuaternion([
      axis[0] * Math.sin(half),
      axis[1] * Math.sin(half),
      axis[2] * Math.sin(half),
      Math.cos(half)
    ], joint.referenceOrientation);
    let speed = dot(b2.angularVelocityRadps, axis);
    if (angleRad === joint.limitRad[0] && speed < 0 || angleRad === joint.limitRad[1] && speed > 0) speed = 0;
    b2.angularVelocityRadps = scale(axis, speed);
  }
  const norm2 = Math.hypot(...targetOrientation);
  b2.orientation = targetOrientation.map((value) => value / norm2);
  const targetPosition = sub(worldPoint(a2, joint.anchorALocalM), rotate2(b2.orientation, joint.anchorBLocalM));
  if (Math.hypot(...sub(targetPosition, b2.positionM)) > MAX_STEP_DISPLACEMENT_M) {
    error("NUMERIC_LIMIT", `${joint.id} projection exceeded movement limit`);
  }
  b2.positionM = targetPosition;
  b2.velocityMps = scale(sub(targetPosition, previous[joint.bIndex].positionM), 1 / dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeVelocity), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular)),
    ...angleRad === void 0 ? {} : { angleRad }
  };
}

// src/disjoint-hinge/admission.ts
var RESTRICTION = "dynamic pair supports one joint between two dynamic spheres";
var equal = (values, wanted) => values.length === wanted.length && values.every((value, index) => value === wanted[index]);
var refuse = () => error("INVALID_CONFIG", RESTRICTION);
function parseDisjointHingeProfile(model2, options, inputs, bodies) {
  if (bodies.length !== 4 || bodies.some((body) => body.kind !== "dynamic") || inputs.length !== 2 || inputs.some((input) => input.kind !== "hinge")) return null;
  const byId = new Map(bodies.map((body, index) => [body.id, { body, index }]));
  const seenB = /* @__PURE__ */ new Set();
  const joints = inputs.map((input) => {
    const a2 = typeof input.aId === "string" ? byId.get(input.aId) : void 0;
    const b2 = typeof input.bId === "string" ? byId.get(input.bId) : void 0;
    if (!a2 || !b2 || a2.index === b2.index || seenB.has(b2.body.id)) {
      error("INVALID_CONFIG", "joint needs a distinct A and unique dynamic B");
    }
    const local = parseJoints([input], [a2.body, b2.body])[0];
    seenB.add(b2.body.id);
    return { ...local, aIndex: a2.index, bIndex: b2.index };
  });
  if (options.profile !== "rigid-discrete-v1" || options.broadPhase !== "direct" || options.fixedStepSeconds !== 1 / 120 || !equal(model2.gravityMps2, [0, 0, 0]) || model2.cloths.length !== 0 || model2.fluids.length !== 0 || model2.bodies.some((body) => body.kind !== "dynamic" || body.inertia.kind !== "primitive-com" || !body.initial.orientationXYZW.every((component, index) => Object.is(component, index === 3 ? 1 : 0)))) refuse();
  for (const body of bodies) {
    if (body.shape.kind !== "sphere" || body.shape.radiusM !== 0.1 || body.inverseMass !== 1 || body.inertiaKgM2 !== 0.4 * 0.1 ** 2 || body.restitution !== 0 || body.frictionStatic !== 1 || body.frictionDynamic !== 0.7 || body.sensor || body.ccd || body.collisionFilter || !equal(body.velocityMps, [0, 0, 0]) || !equal(body.angularVelocityRadps, [0, 0, 0]) || !equal(body.orientation, [0, 0, 0, 1])) refuse();
  }
  const used = /* @__PURE__ */ new Set();
  const pairs = joints.map((joint, jointInputIndex) => {
    const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
    if (used.has(joint.aIndex) || used.has(joint.bIndex)) refuse();
    used.add(joint.aIndex);
    used.add(joint.bIndex);
    const z = a2.positionM[2];
    if (z !== 0 && z !== 1 || !equal(a2.positionM, [-0.1, 0, z]) || !equal(b2.positionM, [0.1, 0, z]) || !equal(joint.anchorALocalM, [0.1, 0, 0]) || !equal(joint.anchorBLocalM, [-0.1, 0, 0]) || !equal(joint.axisWorld, [0, 0, 1]) || !equal(joint.limitRad, [-0.8, 0.8]) || joint.motor?.targetSpeedRadps !== 0.5 || joint.motor.maxImpulseNms !== 1e-4 || joint.motor.maxReactionNms !== 0.01) refuse();
    return {
      joint: { ...joint, aIndex: 0, bIndex: 1 },
      originM: [0, 0, z],
      bodyIndices: [joint.aIndex, joint.bIndex],
      jointInputIndex
    };
  });
  pairs.sort((a2, b2) => a2.originM[2] - b2.originM[2]);
  if (used.size !== 4 || pairs[0].originM[2] !== 0 || pairs[1].originM[2] !== 1) refuse();
  return { joints, pairs };
}

// src/cloth/profile.ts
var CLOTH_STEP_SECONDS = 1 / 120;
var CLOTH_MAX_STEPS = 240;
var CLOTH_SUBSTEPS = 8;
var CLOTH_ITERATIONS = 2;
var CLOTH_PROFILE = Object.freeze({
  size: 17,
  sideM: 1,
  heightM: 0.55,
  densityKgM2: 0.2,
  dt: CLOTH_STEP_SECONDS / CLOTH_SUBSTEPS,
  gravityMps2: Object.freeze([0, -9.81, 0]),
  velocityDecayPerSecond: 1,
  sphereCentreM: Object.freeze([0, 0.1, 0]),
  sphereRadiusM: 0.3,
  collisionOffsetM: 2e-3,
  stretchComplianceMPerN: 1e-3,
  bendComplianceMPerN: 0.1
});

// src/fluid/constants.ts
var FLUID_COUNT = 256;
var FLUID_STEP_SECONDS = 1 / 120;
var FLUID_MAX_STEPS = 3600;
var FLUID_BASIN_M = [0.7, 1.3, 0.5];
var FLUID_GRAVITY_MPS2 = [0, -9.81, 0];
var FLUID_SPACING_M = 0.05;
var FLUID_MIN_SPACING_M = 0.025;
var FLUID_PARTICLE_RADIUS_M = 0.0125;
var FLUID_SMOOTHING_RADIUS_M = 1.8 * FLUID_SPACING_M;

// src/fluid/static-box.ts
function inflatedBoxBounds(centerM, halfExtentsM) {
  return {
    low: centerM.map((value, axis) => value - halfExtentsM[axis] - FLUID_PARTICLE_RADIUS_M),
    high: centerM.map((value, axis) => value + halfExtentsM[axis] + FLUID_PARTICLE_RADIUS_M)
  };
}
function confineStaticBox(positions, velocities, index, box) {
  const offset = index * 3;
  const { low, high } = box;
  if (![0, 1, 2].every((axis) => positions[offset + axis] > low[axis] && positions[offset + axis] < high[axis])) return 0;
  let selectedAxis = 0;
  let selectedFace = low[0];
  let smallestDistance = Infinity;
  for (let axis = 0; axis < 3; axis++) {
    for (const face of [low[axis], high[axis]]) {
      const distance = Math.abs(positions[offset + axis] - face);
      if (distance < smallestDistance) {
        smallestDistance = distance;
        selectedAxis = axis;
        selectedFace = face;
      }
    }
  }
  positions[offset + selectedAxis] = selectedFace;
  velocities[offset + selectedAxis] = 0;
  return 1;
}
function stopIntoStaticBox(positions, velocities, index, box) {
  const offset = index * 3;
  const { low, high } = box;
  for (let axis = 0; axis < 3; axis++) {
    const first = (axis + 1) % 3, second = (axis + 2) % 3;
    if (positions[offset + first] <= low[first] || positions[offset + first] >= high[first] || positions[offset + second] <= low[second] || positions[offset + second] >= high[second]) continue;
    const point2 = offset + axis;
    if (Math.abs(positions[point2] - low[axis]) < 1e-9 && velocities[point2] > 0 || Math.abs(positions[point2] - high[axis]) < 1e-9 && velocities[point2] < 0) {
      velocities[point2] = 0;
    }
  }
}
function insideStaticBox(positions, box) {
  const { low, high } = box;
  for (let index = 0; index < positions.length / 3; index++) {
    if ([0, 1, 2].every((axis) => positions[index * 3 + axis] > low[axis] + 1e-9 && positions[index * 3 + axis] < high[axis] - 1e-9)) return true;
  }
  return false;
}

// src/domain/cloth-reference.generated.ts
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
var nativeClothReference = freeze({ "id": "p5Cloth", "restPositionsM": [[-0.5, 0.55, -0.5], [-0.4375, 0.55, -0.5], [-0.375, 0.55, -0.5], [-0.3125, 0.55, -0.5], [-0.25, 0.55, -0.5], [-0.1875, 0.55, -0.5], [-0.125, 0.55, -0.5], [-0.0625, 0.55, -0.5], [0, 0.55, -0.5], [0.0625, 0.55, -0.5], [0.125, 0.55, -0.5], [0.1875, 0.55, -0.5], [0.25, 0.55, -0.5], [0.3125, 0.55, -0.5], [0.375, 0.55, -0.5], [0.4375, 0.55, -0.5], [0.5, 0.55, -0.5], [-0.5, 0.55, -0.4375], [-0.4375, 0.55, -0.4375], [-0.375, 0.55, -0.4375], [-0.3125, 0.55, -0.4375], [-0.25, 0.55, -0.4375], [-0.1875, 0.55, -0.4375], [-0.125, 0.55, -0.4375], [-0.0625, 0.55, -0.4375], [0, 0.55, -0.4375], [0.0625, 0.55, -0.4375], [0.125, 0.55, -0.4375], [0.1875, 0.55, -0.4375], [0.25, 0.55, -0.4375], [0.3125, 0.55, -0.4375], [0.375, 0.55, -0.4375], [0.4375, 0.55, -0.4375], [0.5, 0.55, -0.4375], [-0.5, 0.55, -0.375], [-0.4375, 0.55, -0.375], [-0.375, 0.55, -0.375], [-0.3125, 0.55, -0.375], [-0.25, 0.55, -0.375], [-0.1875, 0.55, -0.375], [-0.125, 0.55, -0.375], [-0.0625, 0.55, -0.375], [0, 0.55, -0.375], [0.0625, 0.55, -0.375], [0.125, 0.55, -0.375], [0.1875, 0.55, -0.375], [0.25, 0.55, -0.375], [0.3125, 0.55, -0.375], [0.375, 0.55, -0.375], [0.4375, 0.55, -0.375], [0.5, 0.55, -0.375], [-0.5, 0.55, -0.3125], [-0.4375, 0.55, -0.3125], [-0.375, 0.55, -0.3125], [-0.3125, 0.55, -0.3125], [-0.25, 0.55, -0.3125], [-0.1875, 0.55, -0.3125], [-0.125, 0.55, -0.3125], [-0.0625, 0.55, -0.3125], [0, 0.55, -0.3125], [0.0625, 0.55, -0.3125], [0.125, 0.55, -0.3125], [0.1875, 0.55, -0.3125], [0.25, 0.55, -0.3125], [0.3125, 0.55, -0.3125], [0.375, 0.55, -0.3125], [0.4375, 0.55, -0.3125], [0.5, 0.55, -0.3125], [-0.5, 0.55, -0.25], [-0.4375, 0.55, -0.25], [-0.375, 0.55, -0.25], [-0.3125, 0.55, -0.25], [-0.25, 0.55, -0.25], [-0.1875, 0.55, -0.25], [-0.125, 0.55, -0.25], [-0.0625, 0.55, -0.25], [0, 0.55, -0.25], [0.0625, 0.55, -0.25], [0.125, 0.55, -0.25], [0.1875, 0.55, -0.25], [0.25, 0.55, -0.25], [0.3125, 0.55, -0.25], [0.375, 0.55, -0.25], [0.4375, 0.55, -0.25], [0.5, 0.55, -0.25], [-0.5, 0.55, -0.1875], [-0.4375, 0.55, -0.1875], [-0.375, 0.55, -0.1875], [-0.3125, 0.55, -0.1875], [-0.25, 0.55, -0.1875], [-0.1875, 0.55, -0.1875], [-0.125, 0.55, -0.1875], [-0.0625, 0.55, -0.1875], [0, 0.55, -0.1875], [0.0625, 0.55, -0.1875], [0.125, 0.55, -0.1875], [0.1875, 0.55, -0.1875], [0.25, 0.55, -0.1875], [0.3125, 0.55, -0.1875], [0.375, 0.55, -0.1875], [0.4375, 0.55, -0.1875], [0.5, 0.55, -0.1875], [-0.5, 0.55, -0.125], [-0.4375, 0.55, -0.125], [-0.375, 0.55, -0.125], [-0.3125, 0.55, -0.125], [-0.25, 0.55, -0.125], [-0.1875, 0.55, -0.125], [-0.125, 0.55, -0.125], [-0.0625, 0.55, -0.125], [0, 0.55, -0.125], [0.0625, 0.55, -0.125], [0.125, 0.55, -0.125], [0.1875, 0.55, -0.125], [0.25, 0.55, -0.125], [0.3125, 0.55, -0.125], [0.375, 0.55, -0.125], [0.4375, 0.55, -0.125], [0.5, 0.55, -0.125], [-0.5, 0.55, -0.0625], [-0.4375, 0.55, -0.0625], [-0.375, 0.55, -0.0625], [-0.3125, 0.55, -0.0625], [-0.25, 0.55, -0.0625], [-0.1875, 0.55, -0.0625], [-0.125, 0.55, -0.0625], [-0.0625, 0.55, -0.0625], [0, 0.55, -0.0625], [0.0625, 0.55, -0.0625], [0.125, 0.55, -0.0625], [0.1875, 0.55, -0.0625], [0.25, 0.55, -0.0625], [0.3125, 0.55, -0.0625], [0.375, 0.55, -0.0625], [0.4375, 0.55, -0.0625], [0.5, 0.55, -0.0625], [-0.5, 0.55, 0], [-0.4375, 0.55, 0], [-0.375, 0.55, 0], [-0.3125, 0.55, 0], [-0.25, 0.55, 0], [-0.1875, 0.55, 0], [-0.125, 0.55, 0], [-0.0625, 0.55, 0], [0, 0.55, 0], [0.0625, 0.55, 0], [0.125, 0.55, 0], [0.1875, 0.55, 0], [0.25, 0.55, 0], [0.3125, 0.55, 0], [0.375, 0.55, 0], [0.4375, 0.55, 0], [0.5, 0.55, 0], [-0.5, 0.55, 0.0625], [-0.4375, 0.55, 0.0625], [-0.375, 0.55, 0.0625], [-0.3125, 0.55, 0.0625], [-0.25, 0.55, 0.0625], [-0.1875, 0.55, 0.0625], [-0.125, 0.55, 0.0625], [-0.0625, 0.55, 0.0625], [0, 0.55, 0.0625], [0.0625, 0.55, 0.0625], [0.125, 0.55, 0.0625], [0.1875, 0.55, 0.0625], [0.25, 0.55, 0.0625], [0.3125, 0.55, 0.0625], [0.375, 0.55, 0.0625], [0.4375, 0.55, 0.0625], [0.5, 0.55, 0.0625], [-0.5, 0.55, 0.125], [-0.4375, 0.55, 0.125], [-0.375, 0.55, 0.125], [-0.3125, 0.55, 0.125], [-0.25, 0.55, 0.125], [-0.1875, 0.55, 0.125], [-0.125, 0.55, 0.125], [-0.0625, 0.55, 0.125], [0, 0.55, 0.125], [0.0625, 0.55, 0.125], [0.125, 0.55, 0.125], [0.1875, 0.55, 0.125], [0.25, 0.55, 0.125], [0.3125, 0.55, 0.125], [0.375, 0.55, 0.125], [0.4375, 0.55, 0.125], [0.5, 0.55, 0.125], [-0.5, 0.55, 0.1875], [-0.4375, 0.55, 0.1875], [-0.375, 0.55, 0.1875], [-0.3125, 0.55, 0.1875], [-0.25, 0.55, 0.1875], [-0.1875, 0.55, 0.1875], [-0.125, 0.55, 0.1875], [-0.0625, 0.55, 0.1875], [0, 0.55, 0.1875], [0.0625, 0.55, 0.1875], [0.125, 0.55, 0.1875], [0.1875, 0.55, 0.1875], [0.25, 0.55, 0.1875], [0.3125, 0.55, 0.1875], [0.375, 0.55, 0.1875], [0.4375, 0.55, 0.1875], [0.5, 0.55, 0.1875], [-0.5, 0.55, 0.25], [-0.4375, 0.55, 0.25], [-0.375, 0.55, 0.25], [-0.3125, 0.55, 0.25], [-0.25, 0.55, 0.25], [-0.1875, 0.55, 0.25], [-0.125, 0.55, 0.25], [-0.0625, 0.55, 0.25], [0, 0.55, 0.25], [0.0625, 0.55, 0.25], [0.125, 0.55, 0.25], [0.1875, 0.55, 0.25], [0.25, 0.55, 0.25], [0.3125, 0.55, 0.25], [0.375, 0.55, 0.25], [0.4375, 0.55, 0.25], [0.5, 0.55, 0.25], [-0.5, 0.55, 0.3125], [-0.4375, 0.55, 0.3125], [-0.375, 0.55, 0.3125], [-0.3125, 0.55, 0.3125], [-0.25, 0.55, 0.3125], [-0.1875, 0.55, 0.3125], [-0.125, 0.55, 0.3125], [-0.0625, 0.55, 0.3125], [0, 0.55, 0.3125], [0.0625, 0.55, 0.3125], [0.125, 0.55, 0.3125], [0.1875, 0.55, 0.3125], [0.25, 0.55, 0.3125], [0.3125, 0.55, 0.3125], [0.375, 0.55, 0.3125], [0.4375, 0.55, 0.3125], [0.5, 0.55, 0.3125], [-0.5, 0.55, 0.375], [-0.4375, 0.55, 0.375], [-0.375, 0.55, 0.375], [-0.3125, 0.55, 0.375], [-0.25, 0.55, 0.375], [-0.1875, 0.55, 0.375], [-0.125, 0.55, 0.375], [-0.0625, 0.55, 0.375], [0, 0.55, 0.375], [0.0625, 0.55, 0.375], [0.125, 0.55, 0.375], [0.1875, 0.55, 0.375], [0.25, 0.55, 0.375], [0.3125, 0.55, 0.375], [0.375, 0.55, 0.375], [0.4375, 0.55, 0.375], [0.5, 0.55, 0.375], [-0.5, 0.55, 0.4375], [-0.4375, 0.55, 0.4375], [-0.375, 0.55, 0.4375], [-0.3125, 0.55, 0.4375], [-0.25, 0.55, 0.4375], [-0.1875, 0.55, 0.4375], [-0.125, 0.55, 0.4375], [-0.0625, 0.55, 0.4375], [0, 0.55, 0.4375], [0.0625, 0.55, 0.4375], [0.125, 0.55, 0.4375], [0.1875, 0.55, 0.4375], [0.25, 0.55, 0.4375], [0.3125, 0.55, 0.4375], [0.375, 0.55, 0.4375], [0.4375, 0.55, 0.4375], [0.5, 0.55, 0.4375], [-0.5, 0.55, 0.5], [-0.4375, 0.55, 0.5], [-0.375, 0.55, 0.5], [-0.3125, 0.55, 0.5], [-0.25, 0.55, 0.5], [-0.1875, 0.55, 0.5], [-0.125, 0.55, 0.5], [-0.0625, 0.55, 0.5], [0, 0.55, 0.5], [0.0625, 0.55, 0.5], [0.125, 0.55, 0.5], [0.1875, 0.55, 0.5], [0.25, 0.55, 0.5], [0.3125, 0.55, 0.5], [0.375, 0.55, 0.5], [0.4375, 0.55, 0.5], [0.5, 0.55, 0.5]], "initialPositionsM": [[-0.5, 0.55, -0.5], [-0.4375, 0.55, -0.5], [-0.375, 0.55, -0.5], [-0.3125, 0.55, -0.5], [-0.25, 0.55, -0.5], [-0.1875, 0.55, -0.5], [-0.125, 0.55, -0.5], [-0.0625, 0.55, -0.5], [0, 0.55, -0.5], [0.0625, 0.55, -0.5], [0.125, 0.55, -0.5], [0.1875, 0.55, -0.5], [0.25, 0.55, -0.5], [0.3125, 0.55, -0.5], [0.375, 0.55, -0.5], [0.4375, 0.55, -0.5], [0.5, 0.55, -0.5], [-0.5, 0.55, -0.4375], [-0.4375, 0.55, -0.4375], [-0.375, 0.55, -0.4375], [-0.3125, 0.55, -0.4375], [-0.25, 0.55, -0.4375], [-0.1875, 0.55, -0.4375], [-0.125, 0.55, -0.4375], [-0.0625, 0.55, -0.4375], [0, 0.55, -0.4375], [0.0625, 0.55, -0.4375], [0.125, 0.55, -0.4375], [0.1875, 0.55, -0.4375], [0.25, 0.55, -0.4375], [0.3125, 0.55, -0.4375], [0.375, 0.55, -0.4375], [0.4375, 0.55, -0.4375], [0.5, 0.55, -0.4375], [-0.5, 0.55, -0.375], [-0.4375, 0.55, -0.375], [-0.375, 0.55, -0.375], [-0.3125, 0.55, -0.375], [-0.25, 0.55, -0.375], [-0.1875, 0.55, -0.375], [-0.125, 0.55, -0.375], [-0.0625, 0.55, -0.375], [0, 0.55, -0.375], [0.0625, 0.55, -0.375], [0.125, 0.55, -0.375], [0.1875, 0.55, -0.375], [0.25, 0.55, -0.375], [0.3125, 0.55, -0.375], [0.375, 0.55, -0.375], [0.4375, 0.55, -0.375], [0.5, 0.55, -0.375], [-0.5, 0.55, -0.3125], [-0.4375, 0.55, -0.3125], [-0.375, 0.55, -0.3125], [-0.3125, 0.55, -0.3125], [-0.25, 0.55, -0.3125], [-0.1875, 0.55, -0.3125], [-0.125, 0.55, -0.3125], [-0.0625, 0.55, -0.3125], [0, 0.55, -0.3125], [0.0625, 0.55, -0.3125], [0.125, 0.55, -0.3125], [0.1875, 0.55, -0.3125], [0.25, 0.55, -0.3125], [0.3125, 0.55, -0.3125], [0.375, 0.55, -0.3125], [0.4375, 0.55, -0.3125], [0.5, 0.55, -0.3125], [-0.5, 0.55, -0.25], [-0.4375, 0.55, -0.25], [-0.375, 0.55, -0.25], [-0.3125, 0.55, -0.25], [-0.25, 0.55, -0.25], [-0.1875, 0.55, -0.25], [-0.125, 0.55, -0.25], [-0.0625, 0.55, -0.25], [0, 0.55, -0.25], [0.0625, 0.55, -0.25], [0.125, 0.55, -0.25], [0.1875, 0.55, -0.25], [0.25, 0.55, -0.25], [0.3125, 0.55, -0.25], [0.375, 0.55, -0.25], [0.4375, 0.55, -0.25], [0.5, 0.55, -0.25], [-0.5, 0.55, -0.1875], [-0.4375, 0.55, -0.1875], [-0.375, 0.55, -0.1875], [-0.3125, 0.55, -0.1875], [-0.25, 0.55, -0.1875], [-0.1875, 0.55, -0.1875], [-0.125, 0.55, -0.1875], [-0.0625, 0.55, -0.1875], [0, 0.55, -0.1875], [0.0625, 0.55, -0.1875], [0.125, 0.55, -0.1875], [0.1875, 0.55, -0.1875], [0.25, 0.55, -0.1875], [0.3125, 0.55, -0.1875], [0.375, 0.55, -0.1875], [0.4375, 0.55, -0.1875], [0.5, 0.55, -0.1875], [-0.5, 0.55, -0.125], [-0.4375, 0.55, -0.125], [-0.375, 0.55, -0.125], [-0.3125, 0.55, -0.125], [-0.25, 0.55, -0.125], [-0.1875, 0.55, -0.125], [-0.125, 0.55, -0.125], [-0.0625, 0.55, -0.125], [0, 0.55, -0.125], [0.0625, 0.55, -0.125], [0.125, 0.55, -0.125], [0.1875, 0.55, -0.125], [0.25, 0.55, -0.125], [0.3125, 0.55, -0.125], [0.375, 0.55, -0.125], [0.4375, 0.55, -0.125], [0.5, 0.55, -0.125], [-0.5, 0.55, -0.0625], [-0.4375, 0.55, -0.0625], [-0.375, 0.55, -0.0625], [-0.3125, 0.55, -0.0625], [-0.25, 0.55, -0.0625], [-0.1875, 0.55, -0.0625], [-0.125, 0.55, -0.0625], [-0.0625, 0.55, -0.0625], [0, 0.55, -0.0625], [0.0625, 0.55, -0.0625], [0.125, 0.55, -0.0625], [0.1875, 0.55, -0.0625], [0.25, 0.55, -0.0625], [0.3125, 0.55, -0.0625], [0.375, 0.55, -0.0625], [0.4375, 0.55, -0.0625], [0.5, 0.55, -0.0625], [-0.5, 0.55, 0], [-0.4375, 0.55, 0], [-0.375, 0.55, 0], [-0.3125, 0.55, 0], [-0.25, 0.55, 0], [-0.1875, 0.55, 0], [-0.125, 0.55, 0], [-0.0625, 0.55, 0], [0, 0.55, 0], [0.0625, 0.55, 0], [0.125, 0.55, 0], [0.1875, 0.55, 0], [0.25, 0.55, 0], [0.3125, 0.55, 0], [0.375, 0.55, 0], [0.4375, 0.55, 0], [0.5, 0.55, 0], [-0.5, 0.55, 0.0625], [-0.4375, 0.55, 0.0625], [-0.375, 0.55, 0.0625], [-0.3125, 0.55, 0.0625], [-0.25, 0.55, 0.0625], [-0.1875, 0.55, 0.0625], [-0.125, 0.55, 0.0625], [-0.0625, 0.55, 0.0625], [0, 0.55, 0.0625], [0.0625, 0.55, 0.0625], [0.125, 0.55, 0.0625], [0.1875, 0.55, 0.0625], [0.25, 0.55, 0.0625], [0.3125, 0.55, 0.0625], [0.375, 0.55, 0.0625], [0.4375, 0.55, 0.0625], [0.5, 0.55, 0.0625], [-0.5, 0.55, 0.125], [-0.4375, 0.55, 0.125], [-0.375, 0.55, 0.125], [-0.3125, 0.55, 0.125], [-0.25, 0.55, 0.125], [-0.1875, 0.55, 0.125], [-0.125, 0.55, 0.125], [-0.0625, 0.55, 0.125], [0, 0.55, 0.125], [0.0625, 0.55, 0.125], [0.125, 0.55, 0.125], [0.1875, 0.55, 0.125], [0.25, 0.55, 0.125], [0.3125, 0.55, 0.125], [0.375, 0.55, 0.125], [0.4375, 0.55, 0.125], [0.5, 0.55, 0.125], [-0.5, 0.55, 0.1875], [-0.4375, 0.55, 0.1875], [-0.375, 0.55, 0.1875], [-0.3125, 0.55, 0.1875], [-0.25, 0.55, 0.1875], [-0.1875, 0.55, 0.1875], [-0.125, 0.55, 0.1875], [-0.0625, 0.55, 0.1875], [0, 0.55, 0.1875], [0.0625, 0.55, 0.1875], [0.125, 0.55, 0.1875], [0.1875, 0.55, 0.1875], [0.25, 0.55, 0.1875], [0.3125, 0.55, 0.1875], [0.375, 0.55, 0.1875], [0.4375, 0.55, 0.1875], [0.5, 0.55, 0.1875], [-0.5, 0.55, 0.25], [-0.4375, 0.55, 0.25], [-0.375, 0.55, 0.25], [-0.3125, 0.55, 0.25], [-0.25, 0.55, 0.25], [-0.1875, 0.55, 0.25], [-0.125, 0.55, 0.25], [-0.0625, 0.55, 0.25], [0, 0.55, 0.25], [0.0625, 0.55, 0.25], [0.125, 0.55, 0.25], [0.1875, 0.55, 0.25], [0.25, 0.55, 0.25], [0.3125, 0.55, 0.25], [0.375, 0.55, 0.25], [0.4375, 0.55, 0.25], [0.5, 0.55, 0.25], [-0.5, 0.55, 0.3125], [-0.4375, 0.55, 0.3125], [-0.375, 0.55, 0.3125], [-0.3125, 0.55, 0.3125], [-0.25, 0.55, 0.3125], [-0.1875, 0.55, 0.3125], [-0.125, 0.55, 0.3125], [-0.0625, 0.55, 0.3125], [0, 0.55, 0.3125], [0.0625, 0.55, 0.3125], [0.125, 0.55, 0.3125], [0.1875, 0.55, 0.3125], [0.25, 0.55, 0.3125], [0.3125, 0.55, 0.3125], [0.375, 0.55, 0.3125], [0.4375, 0.55, 0.3125], [0.5, 0.55, 0.3125], [-0.5, 0.55, 0.375], [-0.4375, 0.55, 0.375], [-0.375, 0.55, 0.375], [-0.3125, 0.55, 0.375], [-0.25, 0.55, 0.375], [-0.1875, 0.55, 0.375], [-0.125, 0.55, 0.375], [-0.0625, 0.55, 0.375], [0, 0.55, 0.375], [0.0625, 0.55, 0.375], [0.125, 0.55, 0.375], [0.1875, 0.55, 0.375], [0.25, 0.55, 0.375], [0.3125, 0.55, 0.375], [0.375, 0.55, 0.375], [0.4375, 0.55, 0.375], [0.5, 0.55, 0.375], [-0.5, 0.55, 0.4375], [-0.4375, 0.55, 0.4375], [-0.375, 0.55, 0.4375], [-0.3125, 0.55, 0.4375], [-0.25, 0.55, 0.4375], [-0.1875, 0.55, 0.4375], [-0.125, 0.55, 0.4375], [-0.0625, 0.55, 0.4375], [0, 0.55, 0.4375], [0.0625, 0.55, 0.4375], [0.125, 0.55, 0.4375], [0.1875, 0.55, 0.4375], [0.25, 0.55, 0.4375], [0.3125, 0.55, 0.4375], [0.375, 0.55, 0.4375], [0.4375, 0.55, 0.4375], [0.5, 0.55, 0.4375], [-0.5, 0.55, 0.5], [-0.4375, 0.55, 0.5], [-0.375, 0.55, 0.5], [-0.3125, 0.55, 0.5], [-0.25, 0.55, 0.5], [-0.1875, 0.55, 0.5], [-0.125, 0.55, 0.5], [-0.0625, 0.55, 0.5], [0, 0.55, 0.5], [0.0625, 0.55, 0.5], [0.125, 0.55, 0.5], [0.1875, 0.55, 0.5], [0.25, 0.55, 0.5], [0.3125, 0.55, 0.5], [0.375, 0.55, 0.5], [0.4375, 0.55, 0.5], [0.5, 0.55, 0.5]], "initialVelocitiesMps": [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]], "vertexMassesKg": [13020833333333333e-20, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 26041666666666666e-20, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 26041666666666666e-20, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 13020833333333333e-20], "triangles": [[0, 17, 1], [1, 17, 18], [1, 18, 2], [2, 18, 19], [2, 19, 3], [3, 19, 20], [3, 20, 4], [4, 20, 21], [4, 21, 5], [5, 21, 22], [5, 22, 6], [6, 22, 23], [6, 23, 7], [7, 23, 24], [7, 24, 8], [8, 24, 25], [8, 25, 9], [9, 25, 26], [9, 26, 10], [10, 26, 27], [10, 27, 11], [11, 27, 28], [11, 28, 12], [12, 28, 29], [12, 29, 13], [13, 29, 30], [13, 30, 14], [14, 30, 31], [14, 31, 15], [15, 31, 32], [15, 32, 16], [16, 32, 33], [17, 34, 18], [18, 34, 35], [18, 35, 19], [19, 35, 36], [19, 36, 20], [20, 36, 37], [20, 37, 21], [21, 37, 38], [21, 38, 22], [22, 38, 39], [22, 39, 23], [23, 39, 40], [23, 40, 24], [24, 40, 41], [24, 41, 25], [25, 41, 42], [25, 42, 26], [26, 42, 43], [26, 43, 27], [27, 43, 44], [27, 44, 28], [28, 44, 45], [28, 45, 29], [29, 45, 46], [29, 46, 30], [30, 46, 47], [30, 47, 31], [31, 47, 48], [31, 48, 32], [32, 48, 49], [32, 49, 33], [33, 49, 50], [34, 51, 35], [35, 51, 52], [35, 52, 36], [36, 52, 53], [36, 53, 37], [37, 53, 54], [37, 54, 38], [38, 54, 55], [38, 55, 39], [39, 55, 56], [39, 56, 40], [40, 56, 57], [40, 57, 41], [41, 57, 58], [41, 58, 42], [42, 58, 59], [42, 59, 43], [43, 59, 60], [43, 60, 44], [44, 60, 61], [44, 61, 45], [45, 61, 62], [45, 62, 46], [46, 62, 63], [46, 63, 47], [47, 63, 64], [47, 64, 48], [48, 64, 65], [48, 65, 49], [49, 65, 66], [49, 66, 50], [50, 66, 67], [51, 68, 52], [52, 68, 69], [52, 69, 53], [53, 69, 70], [53, 70, 54], [54, 70, 71], [54, 71, 55], [55, 71, 72], [55, 72, 56], [56, 72, 73], [56, 73, 57], [57, 73, 74], [57, 74, 58], [58, 74, 75], [58, 75, 59], [59, 75, 76], [59, 76, 60], [60, 76, 77], [60, 77, 61], [61, 77, 78], [61, 78, 62], [62, 78, 79], [62, 79, 63], [63, 79, 80], [63, 80, 64], [64, 80, 81], [64, 81, 65], [65, 81, 82], [65, 82, 66], [66, 82, 83], [66, 83, 67], [67, 83, 84], [68, 85, 69], [69, 85, 86], [69, 86, 70], [70, 86, 87], [70, 87, 71], [71, 87, 88], [71, 88, 72], [72, 88, 89], [72, 89, 73], [73, 89, 90], [73, 90, 74], [74, 90, 91], [74, 91, 75], [75, 91, 92], [75, 92, 76], [76, 92, 93], [76, 93, 77], [77, 93, 94], [77, 94, 78], [78, 94, 95], [78, 95, 79], [79, 95, 96], [79, 96, 80], [80, 96, 97], [80, 97, 81], [81, 97, 98], [81, 98, 82], [82, 98, 99], [82, 99, 83], [83, 99, 100], [83, 100, 84], [84, 100, 101], [85, 102, 86], [86, 102, 103], [86, 103, 87], [87, 103, 104], [87, 104, 88], [88, 104, 105], [88, 105, 89], [89, 105, 106], [89, 106, 90], [90, 106, 107], [90, 107, 91], [91, 107, 108], [91, 108, 92], [92, 108, 109], [92, 109, 93], [93, 109, 110], [93, 110, 94], [94, 110, 111], [94, 111, 95], [95, 111, 112], [95, 112, 96], [96, 112, 113], [96, 113, 97], [97, 113, 114], [97, 114, 98], [98, 114, 115], [98, 115, 99], [99, 115, 116], [99, 116, 100], [100, 116, 117], [100, 117, 101], [101, 117, 118], [102, 119, 103], [103, 119, 120], [103, 120, 104], [104, 120, 121], [104, 121, 105], [105, 121, 122], [105, 122, 106], [106, 122, 123], [106, 123, 107], [107, 123, 124], [107, 124, 108], [108, 124, 125], [108, 125, 109], [109, 125, 126], [109, 126, 110], [110, 126, 127], [110, 127, 111], [111, 127, 128], [111, 128, 112], [112, 128, 129], [112, 129, 113], [113, 129, 130], [113, 130, 114], [114, 130, 131], [114, 131, 115], [115, 131, 132], [115, 132, 116], [116, 132, 133], [116, 133, 117], [117, 133, 134], [117, 134, 118], [118, 134, 135], [119, 136, 120], [120, 136, 137], [120, 137, 121], [121, 137, 138], [121, 138, 122], [122, 138, 139], [122, 139, 123], [123, 139, 140], [123, 140, 124], [124, 140, 141], [124, 141, 125], [125, 141, 142], [125, 142, 126], [126, 142, 143], [126, 143, 127], [127, 143, 144], [127, 144, 128], [128, 144, 145], [128, 145, 129], [129, 145, 146], [129, 146, 130], [130, 146, 147], [130, 147, 131], [131, 147, 148], [131, 148, 132], [132, 148, 149], [132, 149, 133], [133, 149, 150], [133, 150, 134], [134, 150, 151], [134, 151, 135], [135, 151, 152], [136, 153, 137], [137, 153, 154], [137, 154, 138], [138, 154, 155], [138, 155, 139], [139, 155, 156], [139, 156, 140], [140, 156, 157], [140, 157, 141], [141, 157, 158], [141, 158, 142], [142, 158, 159], [142, 159, 143], [143, 159, 160], [143, 160, 144], [144, 160, 161], [144, 161, 145], [145, 161, 162], [145, 162, 146], [146, 162, 163], [146, 163, 147], [147, 163, 164], [147, 164, 148], [148, 164, 165], [148, 165, 149], [149, 165, 166], [149, 166, 150], [150, 166, 167], [150, 167, 151], [151, 167, 168], [151, 168, 152], [152, 168, 169], [153, 170, 154], [154, 170, 171], [154, 171, 155], [155, 171, 172], [155, 172, 156], [156, 172, 173], [156, 173, 157], [157, 173, 174], [157, 174, 158], [158, 174, 175], [158, 175, 159], [159, 175, 176], [159, 176, 160], [160, 176, 177], [160, 177, 161], [161, 177, 178], [161, 178, 162], [162, 178, 179], [162, 179, 163], [163, 179, 180], [163, 180, 164], [164, 180, 181], [164, 181, 165], [165, 181, 182], [165, 182, 166], [166, 182, 183], [166, 183, 167], [167, 183, 184], [167, 184, 168], [168, 184, 185], [168, 185, 169], [169, 185, 186], [170, 187, 171], [171, 187, 188], [171, 188, 172], [172, 188, 189], [172, 189, 173], [173, 189, 190], [173, 190, 174], [174, 190, 191], [174, 191, 175], [175, 191, 192], [175, 192, 176], [176, 192, 193], [176, 193, 177], [177, 193, 194], [177, 194, 178], [178, 194, 195], [178, 195, 179], [179, 195, 196], [179, 196, 180], [180, 196, 197], [180, 197, 181], [181, 197, 198], [181, 198, 182], [182, 198, 199], [182, 199, 183], [183, 199, 200], [183, 200, 184], [184, 200, 201], [184, 201, 185], [185, 201, 202], [185, 202, 186], [186, 202, 203], [187, 204, 188], [188, 204, 205], [188, 205, 189], [189, 205, 206], [189, 206, 190], [190, 206, 207], [190, 207, 191], [191, 207, 208], [191, 208, 192], [192, 208, 209], [192, 209, 193], [193, 209, 210], [193, 210, 194], [194, 210, 211], [194, 211, 195], [195, 211, 212], [195, 212, 196], [196, 212, 213], [196, 213, 197], [197, 213, 214], [197, 214, 198], [198, 214, 215], [198, 215, 199], [199, 215, 216], [199, 216, 200], [200, 216, 217], [200, 217, 201], [201, 217, 218], [201, 218, 202], [202, 218, 219], [202, 219, 203], [203, 219, 220], [204, 221, 205], [205, 221, 222], [205, 222, 206], [206, 222, 223], [206, 223, 207], [207, 223, 224], [207, 224, 208], [208, 224, 225], [208, 225, 209], [209, 225, 226], [209, 226, 210], [210, 226, 227], [210, 227, 211], [211, 227, 228], [211, 228, 212], [212, 228, 229], [212, 229, 213], [213, 229, 230], [213, 230, 214], [214, 230, 231], [214, 231, 215], [215, 231, 232], [215, 232, 216], [216, 232, 233], [216, 233, 217], [217, 233, 234], [217, 234, 218], [218, 234, 235], [218, 235, 219], [219, 235, 236], [219, 236, 220], [220, 236, 237], [221, 238, 222], [222, 238, 239], [222, 239, 223], [223, 239, 240], [223, 240, 224], [224, 240, 241], [224, 241, 225], [225, 241, 242], [225, 242, 226], [226, 242, 243], [226, 243, 227], [227, 243, 244], [227, 244, 228], [228, 244, 245], [228, 245, 229], [229, 245, 246], [229, 246, 230], [230, 246, 247], [230, 247, 231], [231, 247, 248], [231, 248, 232], [232, 248, 249], [232, 249, 233], [233, 249, 250], [233, 250, 234], [234, 250, 251], [234, 251, 235], [235, 251, 252], [235, 252, 236], [236, 252, 253], [236, 253, 237], [237, 253, 254], [238, 255, 239], [239, 255, 256], [239, 256, 240], [240, 256, 257], [240, 257, 241], [241, 257, 258], [241, 258, 242], [242, 258, 259], [242, 259, 243], [243, 259, 260], [243, 260, 244], [244, 260, 261], [244, 261, 245], [245, 261, 262], [245, 262, 246], [246, 262, 263], [246, 263, 247], [247, 263, 264], [247, 264, 248], [248, 264, 265], [248, 265, 249], [249, 265, 266], [249, 266, 250], [250, 266, 267], [250, 267, 251], [251, 267, 268], [251, 268, 252], [252, 268, 269], [252, 269, 253], [253, 269, 270], [253, 270, 254], [254, 270, 271], [255, 272, 256], [256, 272, 273], [256, 273, 257], [257, 273, 274], [257, 274, 258], [258, 274, 275], [258, 275, 259], [259, 275, 276], [259, 276, 260], [260, 276, 277], [260, 277, 261], [261, 277, 278], [261, 278, 262], [262, 278, 279], [262, 279, 263], [263, 279, 280], [263, 280, 264], [264, 280, 281], [264, 281, 265], [265, 281, 282], [265, 282, 266], [266, 282, 283], [266, 283, 267], [267, 283, 284], [267, 284, 268], [268, 284, 285], [268, 285, 269], [269, 285, 286], [269, 286, 270], [270, 286, 287], [270, 287, 271], [271, 287, 288]], "pinnedVertexIndices": [0, 16], "constraints": [{ "a": 0, "b": 1, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 0, "b": 17, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 0, "b": 18, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 1, "b": 17, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 0, "b": 2, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 0, "b": 34, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 1, "b": 2, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 1, "b": 18, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 1, "b": 19, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 2, "b": 18, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 1, "b": 3, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 1, "b": 35, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 2, "b": 3, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 2, "b": 19, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 2, "b": 20, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 3, "b": 19, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 2, "b": 4, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 2, "b": 36, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 3, "b": 4, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 3, "b": 20, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 3, "b": 21, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 4, "b": 20, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 3, "b": 5, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 3, "b": 37, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 4, "b": 5, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 4, "b": 21, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 4, "b": 22, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 5, "b": 21, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 4, "b": 6, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 4, "b": 38, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 5, "b": 6, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 5, "b": 22, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 5, "b": 23, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 6, "b": 22, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 5, "b": 7, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 5, "b": 39, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 6, "b": 7, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 6, "b": 23, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 6, "b": 24, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 7, "b": 23, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 6, "b": 8, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 6, "b": 40, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 7, "b": 8, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 7, "b": 24, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 7, "b": 25, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 8, "b": 24, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 7, "b": 9, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 7, "b": 41, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 8, "b": 9, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 8, "b": 25, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 8, "b": 26, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 9, "b": 25, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 8, "b": 10, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 8, "b": 42, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 9, "b": 10, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 9, "b": 26, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 9, "b": 27, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 10, "b": 26, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 9, "b": 11, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 9, "b": 43, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 10, "b": 11, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 10, "b": 27, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 10, "b": 28, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 11, "b": 27, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 10, "b": 12, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 10, "b": 44, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 11, "b": 12, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 11, "b": 28, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 11, "b": 29, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 12, "b": 28, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 11, "b": 13, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 11, "b": 45, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 12, "b": 13, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 12, "b": 29, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 12, "b": 30, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 13, "b": 29, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 12, "b": 14, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 12, "b": 46, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 13, "b": 14, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 13, "b": 30, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 13, "b": 31, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 14, "b": 30, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 13, "b": 15, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 13, "b": 47, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 14, "b": 15, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 14, "b": 31, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 14, "b": 32, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 15, "b": 31, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 14, "b": 16, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 14, "b": 48, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 15, "b": 16, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 15, "b": 32, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 15, "b": 33, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 16, "b": 32, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 15, "b": 49, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 16, "b": 33, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 16, "b": 50, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 17, "b": 18, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 17, "b": 34, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 17, "b": 35, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 18, "b": 34, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 17, "b": 19, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 17, "b": 51, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 18, "b": 19, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 18, "b": 35, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 18, "b": 36, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 19, "b": 35, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 18, "b": 20, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 18, "b": 52, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 19, "b": 20, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 19, "b": 36, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 19, "b": 37, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 20, "b": 36, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 19, "b": 21, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 19, "b": 53, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 20, "b": 21, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 20, "b": 37, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 20, "b": 38, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 21, "b": 37, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 20, "b": 22, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 20, "b": 54, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 21, "b": 22, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 21, "b": 38, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 21, "b": 39, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 22, "b": 38, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 21, "b": 23, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 21, "b": 55, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 22, "b": 23, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 22, "b": 39, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 22, "b": 40, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 23, "b": 39, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 22, "b": 24, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 22, "b": 56, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 23, "b": 24, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 23, "b": 40, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 23, "b": 41, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 24, "b": 40, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 23, "b": 25, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 23, "b": 57, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 24, "b": 25, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 24, "b": 41, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 24, "b": 42, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 25, "b": 41, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 24, "b": 26, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 24, "b": 58, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 25, "b": 26, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 25, "b": 42, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 25, "b": 43, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 26, "b": 42, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 25, "b": 27, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 25, "b": 59, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 26, "b": 27, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 26, "b": 43, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 26, "b": 44, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 27, "b": 43, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 26, "b": 28, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 26, "b": 60, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 27, "b": 28, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 27, "b": 44, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 27, "b": 45, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 28, "b": 44, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 27, "b": 29, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 27, "b": 61, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 28, "b": 29, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 28, "b": 45, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 28, "b": 46, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 29, "b": 45, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 28, "b": 30, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 28, "b": 62, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 29, "b": 30, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 29, "b": 46, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 29, "b": 47, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 30, "b": 46, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 29, "b": 31, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 29, "b": 63, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 30, "b": 31, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 30, "b": 47, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 30, "b": 48, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 31, "b": 47, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 30, "b": 32, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 30, "b": 64, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 31, "b": 32, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 31, "b": 48, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 31, "b": 49, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 32, "b": 48, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 31, "b": 33, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 31, "b": 65, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 32, "b": 33, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 32, "b": 49, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 32, "b": 50, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 33, "b": 49, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 32, "b": 66, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 33, "b": 50, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 33, "b": 67, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 34, "b": 35, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 34, "b": 51, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 34, "b": 52, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 35, "b": 51, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 34, "b": 36, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 34, "b": 68, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 35, "b": 36, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 35, "b": 52, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 35, "b": 53, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 36, "b": 52, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 35, "b": 37, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 35, "b": 69, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 36, "b": 37, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 36, "b": 53, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 36, "b": 54, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 37, "b": 53, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 36, "b": 38, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 36, "b": 70, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 37, "b": 38, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 37, "b": 54, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 37, "b": 55, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 38, "b": 54, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 37, "b": 39, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 37, "b": 71, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 38, "b": 39, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 38, "b": 55, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 38, "b": 56, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 39, "b": 55, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 38, "b": 40, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 38, "b": 72, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 39, "b": 40, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 39, "b": 56, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 39, "b": 57, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 40, "b": 56, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 39, "b": 41, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 39, "b": 73, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 40, "b": 41, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 40, "b": 57, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 40, "b": 58, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 41, "b": 57, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 40, "b": 42, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 40, "b": 74, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 41, "b": 42, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 41, "b": 58, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 41, "b": 59, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 42, "b": 58, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 41, "b": 43, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 41, "b": 75, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 42, "b": 43, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 42, "b": 59, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 42, "b": 60, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 43, "b": 59, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 42, "b": 44, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 42, "b": 76, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 43, "b": 44, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 43, "b": 60, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 43, "b": 61, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 44, "b": 60, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 43, "b": 45, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 43, "b": 77, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 44, "b": 45, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 44, "b": 61, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 44, "b": 62, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 45, "b": 61, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 44, "b": 46, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 44, "b": 78, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 45, "b": 46, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 45, "b": 62, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 45, "b": 63, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 46, "b": 62, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 45, "b": 47, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 45, "b": 79, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 46, "b": 47, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 46, "b": 63, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 46, "b": 64, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 47, "b": 63, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 46, "b": 48, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 46, "b": 80, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 47, "b": 48, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 47, "b": 64, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 47, "b": 65, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 48, "b": 64, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 47, "b": 49, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 47, "b": 81, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 48, "b": 49, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 48, "b": 65, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 48, "b": 66, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 49, "b": 65, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 48, "b": 50, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 48, "b": 82, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 49, "b": 50, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 49, "b": 66, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 49, "b": 67, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 50, "b": 66, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 49, "b": 83, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 50, "b": 67, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 50, "b": 84, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 51, "b": 52, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 51, "b": 68, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 51, "b": 69, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 52, "b": 68, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 51, "b": 53, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 51, "b": 85, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 52, "b": 53, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 52, "b": 69, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 52, "b": 70, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 53, "b": 69, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 52, "b": 54, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 52, "b": 86, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 53, "b": 54, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 53, "b": 70, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 53, "b": 71, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 54, "b": 70, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 53, "b": 55, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 53, "b": 87, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 54, "b": 55, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 54, "b": 71, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 54, "b": 72, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 55, "b": 71, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 54, "b": 56, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 54, "b": 88, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 55, "b": 56, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 55, "b": 72, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 55, "b": 73, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 56, "b": 72, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 55, "b": 57, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 55, "b": 89, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 56, "b": 57, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 56, "b": 73, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 56, "b": 74, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 57, "b": 73, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 56, "b": 58, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 56, "b": 90, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 57, "b": 58, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 57, "b": 74, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 57, "b": 75, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 58, "b": 74, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 57, "b": 59, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 57, "b": 91, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 58, "b": 59, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 58, "b": 75, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 58, "b": 76, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 59, "b": 75, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 58, "b": 60, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 58, "b": 92, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 59, "b": 60, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 59, "b": 76, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 59, "b": 77, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 60, "b": 76, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 59, "b": 61, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 59, "b": 93, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 60, "b": 61, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 60, "b": 77, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 60, "b": 78, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 61, "b": 77, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 60, "b": 62, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 60, "b": 94, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 61, "b": 62, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 61, "b": 78, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 61, "b": 79, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 62, "b": 78, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 61, "b": 63, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 61, "b": 95, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 62, "b": 63, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 62, "b": 79, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 62, "b": 80, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 63, "b": 79, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 62, "b": 64, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 62, "b": 96, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 63, "b": 64, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 63, "b": 80, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 63, "b": 81, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 64, "b": 80, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 63, "b": 65, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 63, "b": 97, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 64, "b": 65, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 64, "b": 81, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 64, "b": 82, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 65, "b": 81, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 64, "b": 66, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 64, "b": 98, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 65, "b": 66, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 65, "b": 82, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 65, "b": 83, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 66, "b": 82, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 65, "b": 67, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 65, "b": 99, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 66, "b": 67, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 66, "b": 83, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 66, "b": 84, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 67, "b": 83, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 66, "b": 100, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 67, "b": 84, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 67, "b": 101, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 68, "b": 69, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 68, "b": 85, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 68, "b": 86, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 69, "b": 85, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 68, "b": 70, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 68, "b": 102, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 69, "b": 70, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 69, "b": 86, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 69, "b": 87, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 70, "b": 86, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 69, "b": 71, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 69, "b": 103, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 70, "b": 71, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 70, "b": 87, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 70, "b": 88, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 71, "b": 87, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 70, "b": 72, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 70, "b": 104, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 71, "b": 72, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 71, "b": 88, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 71, "b": 89, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 72, "b": 88, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 71, "b": 73, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 71, "b": 105, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 72, "b": 73, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 72, "b": 89, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 72, "b": 90, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 73, "b": 89, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 72, "b": 74, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 72, "b": 106, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 73, "b": 74, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 73, "b": 90, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 73, "b": 91, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 74, "b": 90, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 73, "b": 75, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 73, "b": 107, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 74, "b": 75, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 74, "b": 91, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 74, "b": 92, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 75, "b": 91, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 74, "b": 76, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 74, "b": 108, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 75, "b": 76, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 75, "b": 92, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 75, "b": 93, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 76, "b": 92, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 75, "b": 77, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 75, "b": 109, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 76, "b": 77, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 76, "b": 93, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 76, "b": 94, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 77, "b": 93, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 76, "b": 78, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 76, "b": 110, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 77, "b": 78, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 77, "b": 94, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 77, "b": 95, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 78, "b": 94, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 77, "b": 79, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 77, "b": 111, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 78, "b": 79, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 78, "b": 95, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 78, "b": 96, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 79, "b": 95, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 78, "b": 80, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 78, "b": 112, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 79, "b": 80, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 79, "b": 96, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 79, "b": 97, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 80, "b": 96, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 79, "b": 81, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 79, "b": 113, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 80, "b": 81, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 80, "b": 97, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 80, "b": 98, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 81, "b": 97, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 80, "b": 82, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 80, "b": 114, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 81, "b": 82, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 81, "b": 98, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 81, "b": 99, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 82, "b": 98, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 81, "b": 83, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 81, "b": 115, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 82, "b": 83, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 82, "b": 99, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 82, "b": 100, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 83, "b": 99, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 82, "b": 84, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 82, "b": 116, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 83, "b": 84, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 83, "b": 100, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 83, "b": 101, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 84, "b": 100, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 83, "b": 117, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 84, "b": 101, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 84, "b": 118, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 85, "b": 86, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 85, "b": 102, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 85, "b": 103, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 86, "b": 102, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 85, "b": 87, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 85, "b": 119, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 86, "b": 87, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 86, "b": 103, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 86, "b": 104, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 87, "b": 103, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 86, "b": 88, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 86, "b": 120, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 87, "b": 88, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 87, "b": 104, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 87, "b": 105, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 88, "b": 104, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 87, "b": 89, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 87, "b": 121, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 88, "b": 89, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 88, "b": 105, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 88, "b": 106, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 89, "b": 105, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 88, "b": 90, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 88, "b": 122, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 89, "b": 90, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 89, "b": 106, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 89, "b": 107, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 90, "b": 106, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 89, "b": 91, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 89, "b": 123, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 90, "b": 91, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 90, "b": 107, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 90, "b": 108, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 91, "b": 107, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 90, "b": 92, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 90, "b": 124, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 91, "b": 92, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 91, "b": 108, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 91, "b": 109, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 92, "b": 108, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 91, "b": 93, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 91, "b": 125, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 92, "b": 93, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 92, "b": 109, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 92, "b": 110, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 93, "b": 109, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 92, "b": 94, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 92, "b": 126, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 93, "b": 94, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 93, "b": 110, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 93, "b": 111, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 94, "b": 110, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 93, "b": 95, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 93, "b": 127, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 94, "b": 95, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 94, "b": 111, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 94, "b": 112, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 95, "b": 111, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 94, "b": 96, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 94, "b": 128, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 95, "b": 96, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 95, "b": 112, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 95, "b": 113, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 96, "b": 112, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 95, "b": 97, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 95, "b": 129, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 96, "b": 97, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 96, "b": 113, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 96, "b": 114, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 97, "b": 113, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 96, "b": 98, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 96, "b": 130, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 97, "b": 98, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 97, "b": 114, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 97, "b": 115, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 98, "b": 114, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 97, "b": 99, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 97, "b": 131, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 98, "b": 99, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 98, "b": 115, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 98, "b": 116, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 99, "b": 115, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 98, "b": 100, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 98, "b": 132, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 99, "b": 100, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 99, "b": 116, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 99, "b": 117, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 100, "b": 116, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 99, "b": 101, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 99, "b": 133, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 100, "b": 101, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 100, "b": 117, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 100, "b": 118, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 101, "b": 117, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 100, "b": 134, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 101, "b": 118, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 101, "b": 135, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 102, "b": 103, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 102, "b": 119, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 102, "b": 120, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 103, "b": 119, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 102, "b": 104, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 102, "b": 136, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 103, "b": 104, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 103, "b": 120, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 103, "b": 121, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 104, "b": 120, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 103, "b": 105, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 103, "b": 137, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 104, "b": 105, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 104, "b": 121, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 104, "b": 122, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 105, "b": 121, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 104, "b": 106, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 104, "b": 138, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 105, "b": 106, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 105, "b": 122, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 105, "b": 123, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 106, "b": 122, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 105, "b": 107, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 105, "b": 139, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 106, "b": 107, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 106, "b": 123, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 106, "b": 124, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 107, "b": 123, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 106, "b": 108, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 106, "b": 140, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 107, "b": 108, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 107, "b": 124, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 107, "b": 125, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 108, "b": 124, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 107, "b": 109, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 107, "b": 141, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 108, "b": 109, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 108, "b": 125, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 108, "b": 126, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 109, "b": 125, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 108, "b": 110, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 108, "b": 142, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 109, "b": 110, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 109, "b": 126, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 109, "b": 127, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 110, "b": 126, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 109, "b": 111, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 109, "b": 143, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 110, "b": 111, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 110, "b": 127, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 110, "b": 128, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 111, "b": 127, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 110, "b": 112, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 110, "b": 144, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 111, "b": 112, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 111, "b": 128, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 111, "b": 129, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 112, "b": 128, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 111, "b": 113, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 111, "b": 145, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 112, "b": 113, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 112, "b": 129, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 112, "b": 130, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 113, "b": 129, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 112, "b": 114, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 112, "b": 146, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 113, "b": 114, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 113, "b": 130, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 113, "b": 131, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 114, "b": 130, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 113, "b": 115, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 113, "b": 147, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 114, "b": 115, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 114, "b": 131, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 114, "b": 132, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 115, "b": 131, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 114, "b": 116, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 114, "b": 148, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 115, "b": 116, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 115, "b": 132, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 115, "b": 133, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 116, "b": 132, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 115, "b": 117, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 115, "b": 149, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 116, "b": 117, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 116, "b": 133, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 116, "b": 134, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 117, "b": 133, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 116, "b": 118, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 116, "b": 150, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 117, "b": 118, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 117, "b": 134, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 117, "b": 135, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 118, "b": 134, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 117, "b": 151, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 118, "b": 135, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 118, "b": 152, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 119, "b": 120, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 119, "b": 136, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 119, "b": 137, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 120, "b": 136, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 119, "b": 121, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 119, "b": 153, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 120, "b": 121, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 120, "b": 137, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 120, "b": 138, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 121, "b": 137, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 120, "b": 122, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 120, "b": 154, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 121, "b": 122, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 121, "b": 138, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 121, "b": 139, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 122, "b": 138, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 121, "b": 123, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 121, "b": 155, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 122, "b": 123, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 122, "b": 139, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 122, "b": 140, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 123, "b": 139, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 122, "b": 124, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 122, "b": 156, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 123, "b": 124, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 123, "b": 140, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 123, "b": 141, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 124, "b": 140, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 123, "b": 125, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 123, "b": 157, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 124, "b": 125, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 124, "b": 141, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 124, "b": 142, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 125, "b": 141, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 124, "b": 126, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 124, "b": 158, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 125, "b": 126, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 125, "b": 142, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 125, "b": 143, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 126, "b": 142, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 125, "b": 127, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 125, "b": 159, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 126, "b": 127, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 126, "b": 143, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 126, "b": 144, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 127, "b": 143, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 126, "b": 128, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 126, "b": 160, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 127, "b": 128, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 127, "b": 144, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 127, "b": 145, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 128, "b": 144, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 127, "b": 129, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 127, "b": 161, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 128, "b": 129, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 128, "b": 145, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 128, "b": 146, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 129, "b": 145, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 128, "b": 130, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 128, "b": 162, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 129, "b": 130, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 129, "b": 146, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 129, "b": 147, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 130, "b": 146, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 129, "b": 131, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 129, "b": 163, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 130, "b": 131, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 130, "b": 147, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 130, "b": 148, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 131, "b": 147, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 130, "b": 132, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 130, "b": 164, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 131, "b": 132, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 131, "b": 148, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 131, "b": 149, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 132, "b": 148, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 131, "b": 133, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 131, "b": 165, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 132, "b": 133, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 132, "b": 149, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 132, "b": 150, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 133, "b": 149, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 132, "b": 134, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 132, "b": 166, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 133, "b": 134, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 133, "b": 150, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 133, "b": 151, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 134, "b": 150, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 133, "b": 135, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 133, "b": 167, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 134, "b": 135, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 134, "b": 151, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 134, "b": 152, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 135, "b": 151, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 134, "b": 168, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 135, "b": 152, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 135, "b": 169, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 136, "b": 137, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 136, "b": 153, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 136, "b": 154, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 137, "b": 153, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 136, "b": 138, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 136, "b": 170, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 137, "b": 138, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 137, "b": 154, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 137, "b": 155, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 138, "b": 154, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 137, "b": 139, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 137, "b": 171, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 138, "b": 139, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 138, "b": 155, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 138, "b": 156, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 139, "b": 155, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 138, "b": 140, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 138, "b": 172, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 139, "b": 140, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 139, "b": 156, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 139, "b": 157, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 140, "b": 156, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 139, "b": 141, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 139, "b": 173, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 140, "b": 141, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 140, "b": 157, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 140, "b": 158, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 141, "b": 157, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 140, "b": 142, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 140, "b": 174, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 141, "b": 142, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 141, "b": 158, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 141, "b": 159, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 142, "b": 158, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 141, "b": 143, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 141, "b": 175, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 142, "b": 143, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 142, "b": 159, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 142, "b": 160, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 143, "b": 159, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 142, "b": 144, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 142, "b": 176, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 143, "b": 144, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 143, "b": 160, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 143, "b": 161, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 144, "b": 160, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 143, "b": 145, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 143, "b": 177, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 144, "b": 145, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 144, "b": 161, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 144, "b": 162, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 145, "b": 161, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 144, "b": 146, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 144, "b": 178, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 145, "b": 146, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 145, "b": 162, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 145, "b": 163, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 146, "b": 162, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 145, "b": 147, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 145, "b": 179, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 146, "b": 147, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 146, "b": 163, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 146, "b": 164, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 147, "b": 163, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 146, "b": 148, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 146, "b": 180, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 147, "b": 148, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 147, "b": 164, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 147, "b": 165, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 148, "b": 164, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 147, "b": 149, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 147, "b": 181, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 148, "b": 149, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 148, "b": 165, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 148, "b": 166, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 149, "b": 165, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 148, "b": 150, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 148, "b": 182, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 149, "b": 150, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 149, "b": 166, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 149, "b": 167, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 150, "b": 166, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 149, "b": 151, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 149, "b": 183, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 150, "b": 151, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 150, "b": 167, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 150, "b": 168, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 151, "b": 167, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 150, "b": 152, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 150, "b": 184, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 151, "b": 152, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 151, "b": 168, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 151, "b": 169, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 152, "b": 168, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 151, "b": 185, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 152, "b": 169, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 152, "b": 186, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 153, "b": 154, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 153, "b": 170, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 153, "b": 171, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 154, "b": 170, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 153, "b": 155, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 153, "b": 187, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 154, "b": 155, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 154, "b": 171, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 154, "b": 172, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 155, "b": 171, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 154, "b": 156, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 154, "b": 188, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 155, "b": 156, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 155, "b": 172, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 155, "b": 173, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 156, "b": 172, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 155, "b": 157, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 155, "b": 189, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 156, "b": 157, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 156, "b": 173, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 156, "b": 174, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 157, "b": 173, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 156, "b": 158, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 156, "b": 190, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 157, "b": 158, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 157, "b": 174, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 157, "b": 175, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 158, "b": 174, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 157, "b": 159, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 157, "b": 191, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 158, "b": 159, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 158, "b": 175, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 158, "b": 176, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 159, "b": 175, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 158, "b": 160, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 158, "b": 192, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 159, "b": 160, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 159, "b": 176, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 159, "b": 177, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 160, "b": 176, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 159, "b": 161, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 159, "b": 193, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 160, "b": 161, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 160, "b": 177, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 160, "b": 178, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 161, "b": 177, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 160, "b": 162, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 160, "b": 194, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 161, "b": 162, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 161, "b": 178, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 161, "b": 179, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 162, "b": 178, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 161, "b": 163, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 161, "b": 195, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 162, "b": 163, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 162, "b": 179, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 162, "b": 180, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 163, "b": 179, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 162, "b": 164, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 162, "b": 196, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 163, "b": 164, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 163, "b": 180, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 163, "b": 181, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 164, "b": 180, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 163, "b": 165, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 163, "b": 197, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 164, "b": 165, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 164, "b": 181, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 164, "b": 182, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 165, "b": 181, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 164, "b": 166, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 164, "b": 198, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 165, "b": 166, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 165, "b": 182, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 165, "b": 183, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 166, "b": 182, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 165, "b": 167, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 165, "b": 199, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 166, "b": 167, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 166, "b": 183, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 166, "b": 184, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 167, "b": 183, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 166, "b": 168, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 166, "b": 200, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 167, "b": 168, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 167, "b": 184, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 167, "b": 185, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 168, "b": 184, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 167, "b": 169, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 167, "b": 201, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 168, "b": 169, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 168, "b": 185, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 168, "b": 186, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 169, "b": 185, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 168, "b": 202, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 169, "b": 186, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 169, "b": 203, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 170, "b": 171, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 170, "b": 187, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 170, "b": 188, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 171, "b": 187, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 170, "b": 172, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 170, "b": 204, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 171, "b": 172, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 171, "b": 188, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 171, "b": 189, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 172, "b": 188, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 171, "b": 173, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 171, "b": 205, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 172, "b": 173, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 172, "b": 189, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 172, "b": 190, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 173, "b": 189, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 172, "b": 174, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 172, "b": 206, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 173, "b": 174, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 173, "b": 190, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 173, "b": 191, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 174, "b": 190, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 173, "b": 175, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 173, "b": 207, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 174, "b": 175, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 174, "b": 191, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 174, "b": 192, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 175, "b": 191, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 174, "b": 176, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 174, "b": 208, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 175, "b": 176, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 175, "b": 192, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 175, "b": 193, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 176, "b": 192, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 175, "b": 177, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 175, "b": 209, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 176, "b": 177, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 176, "b": 193, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 176, "b": 194, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 177, "b": 193, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 176, "b": 178, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 176, "b": 210, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 177, "b": 178, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 177, "b": 194, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 177, "b": 195, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 178, "b": 194, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 177, "b": 179, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 177, "b": 211, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 178, "b": 179, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 178, "b": 195, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 178, "b": 196, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 179, "b": 195, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 178, "b": 180, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 178, "b": 212, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 179, "b": 180, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 179, "b": 196, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 179, "b": 197, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 180, "b": 196, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 179, "b": 181, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 179, "b": 213, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 180, "b": 181, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 180, "b": 197, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 180, "b": 198, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 181, "b": 197, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 180, "b": 182, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 180, "b": 214, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 181, "b": 182, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 181, "b": 198, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 181, "b": 199, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 182, "b": 198, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 181, "b": 183, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 181, "b": 215, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 182, "b": 183, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 182, "b": 199, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 182, "b": 200, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 183, "b": 199, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 182, "b": 184, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 182, "b": 216, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 183, "b": 184, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 183, "b": 200, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 183, "b": 201, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 184, "b": 200, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 183, "b": 185, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 183, "b": 217, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 184, "b": 185, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 184, "b": 201, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 184, "b": 202, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 185, "b": 201, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 184, "b": 186, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 184, "b": 218, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 185, "b": 186, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 185, "b": 202, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 185, "b": 203, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 186, "b": 202, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 185, "b": 219, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 186, "b": 203, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 186, "b": 220, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 187, "b": 188, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 187, "b": 204, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 187, "b": 205, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 188, "b": 204, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 187, "b": 189, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 187, "b": 221, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 188, "b": 189, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 188, "b": 205, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 188, "b": 206, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 189, "b": 205, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 188, "b": 190, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 188, "b": 222, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 189, "b": 190, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 189, "b": 206, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 189, "b": 207, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 190, "b": 206, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 189, "b": 191, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 189, "b": 223, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 190, "b": 191, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 190, "b": 207, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 190, "b": 208, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 191, "b": 207, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 190, "b": 192, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 190, "b": 224, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 191, "b": 192, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 191, "b": 208, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 191, "b": 209, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 192, "b": 208, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 191, "b": 193, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 191, "b": 225, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 192, "b": 193, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 192, "b": 209, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 192, "b": 210, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 193, "b": 209, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 192, "b": 194, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 192, "b": 226, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 193, "b": 194, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 193, "b": 210, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 193, "b": 211, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 194, "b": 210, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 193, "b": 195, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 193, "b": 227, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 194, "b": 195, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 194, "b": 211, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 194, "b": 212, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 195, "b": 211, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 194, "b": 196, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 194, "b": 228, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 195, "b": 196, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 195, "b": 212, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 195, "b": 213, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 196, "b": 212, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 195, "b": 197, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 195, "b": 229, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 196, "b": 197, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 196, "b": 213, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 196, "b": 214, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 197, "b": 213, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 196, "b": 198, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 196, "b": 230, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 197, "b": 198, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 197, "b": 214, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 197, "b": 215, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 198, "b": 214, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 197, "b": 199, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 197, "b": 231, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 198, "b": 199, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 198, "b": 215, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 198, "b": 216, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 199, "b": 215, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 198, "b": 200, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 198, "b": 232, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 199, "b": 200, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 199, "b": 216, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 199, "b": 217, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 200, "b": 216, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 199, "b": 201, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 199, "b": 233, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 200, "b": 201, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 200, "b": 217, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 200, "b": 218, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 201, "b": 217, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 200, "b": 202, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 200, "b": 234, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 201, "b": 202, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 201, "b": 218, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 201, "b": 219, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 202, "b": 218, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 201, "b": 203, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 201, "b": 235, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 202, "b": 203, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 202, "b": 219, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 202, "b": 220, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 203, "b": 219, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 202, "b": 236, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 203, "b": 220, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 203, "b": 237, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 204, "b": 205, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 204, "b": 221, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 204, "b": 222, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 205, "b": 221, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 204, "b": 206, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 204, "b": 238, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 205, "b": 206, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 205, "b": 222, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 205, "b": 223, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 206, "b": 222, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 205, "b": 207, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 205, "b": 239, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 206, "b": 207, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 206, "b": 223, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 206, "b": 224, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 207, "b": 223, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 206, "b": 208, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 206, "b": 240, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 207, "b": 208, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 207, "b": 224, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 207, "b": 225, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 208, "b": 224, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 207, "b": 209, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 207, "b": 241, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 208, "b": 209, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 208, "b": 225, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 208, "b": 226, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 209, "b": 225, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 208, "b": 210, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 208, "b": 242, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 209, "b": 210, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 209, "b": 226, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 209, "b": 227, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 210, "b": 226, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 209, "b": 211, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 209, "b": 243, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 210, "b": 211, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 210, "b": 227, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 210, "b": 228, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 211, "b": 227, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 210, "b": 212, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 210, "b": 244, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 211, "b": 212, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 211, "b": 228, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 211, "b": 229, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 212, "b": 228, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 211, "b": 213, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 211, "b": 245, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 212, "b": 213, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 212, "b": 229, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 212, "b": 230, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 213, "b": 229, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 212, "b": 214, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 212, "b": 246, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 213, "b": 214, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 213, "b": 230, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 213, "b": 231, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 214, "b": 230, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 213, "b": 215, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 213, "b": 247, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 214, "b": 215, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 214, "b": 231, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 214, "b": 232, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 215, "b": 231, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 214, "b": 216, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 214, "b": 248, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 215, "b": 216, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 215, "b": 232, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 215, "b": 233, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 216, "b": 232, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 215, "b": 217, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 215, "b": 249, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 216, "b": 217, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 216, "b": 233, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 216, "b": 234, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 217, "b": 233, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 216, "b": 218, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 216, "b": 250, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 217, "b": 218, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 217, "b": 234, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 217, "b": 235, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 218, "b": 234, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 217, "b": 219, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 217, "b": 251, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 218, "b": 219, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 218, "b": 235, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 218, "b": 236, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 219, "b": 235, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 218, "b": 220, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 218, "b": 252, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 219, "b": 220, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 219, "b": 236, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 219, "b": 237, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 220, "b": 236, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 219, "b": 253, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 220, "b": 237, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 220, "b": 254, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 221, "b": 222, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 221, "b": 238, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 221, "b": 239, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 222, "b": 238, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 221, "b": 223, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 221, "b": 255, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 222, "b": 223, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 222, "b": 239, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 222, "b": 240, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 223, "b": 239, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 222, "b": 224, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 222, "b": 256, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 223, "b": 224, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 223, "b": 240, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 223, "b": 241, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 224, "b": 240, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 223, "b": 225, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 223, "b": 257, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 224, "b": 225, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 224, "b": 241, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 224, "b": 242, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 225, "b": 241, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 224, "b": 226, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 224, "b": 258, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 225, "b": 226, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 225, "b": 242, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 225, "b": 243, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 226, "b": 242, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 225, "b": 227, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 225, "b": 259, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 226, "b": 227, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 226, "b": 243, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 226, "b": 244, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 227, "b": 243, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 226, "b": 228, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 226, "b": 260, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 227, "b": 228, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 227, "b": 244, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 227, "b": 245, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 228, "b": 244, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 227, "b": 229, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 227, "b": 261, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 228, "b": 229, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 228, "b": 245, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 228, "b": 246, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 229, "b": 245, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 228, "b": 230, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 228, "b": 262, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 229, "b": 230, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 229, "b": 246, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 229, "b": 247, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 230, "b": 246, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 229, "b": 231, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 229, "b": 263, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 230, "b": 231, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 230, "b": 247, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 230, "b": 248, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 231, "b": 247, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 230, "b": 232, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 230, "b": 264, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 231, "b": 232, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 231, "b": 248, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 231, "b": 249, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 232, "b": 248, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 231, "b": 233, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 231, "b": 265, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 232, "b": 233, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 232, "b": 249, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 232, "b": 250, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 233, "b": 249, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 232, "b": 234, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 232, "b": 266, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 233, "b": 234, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 233, "b": 250, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 233, "b": 251, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 234, "b": 250, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 233, "b": 235, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 233, "b": 267, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 234, "b": 235, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 234, "b": 251, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 234, "b": 252, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 235, "b": 251, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 234, "b": 236, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 234, "b": 268, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 235, "b": 236, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 235, "b": 252, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 235, "b": 253, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 236, "b": 252, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 235, "b": 237, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 235, "b": 269, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 236, "b": 237, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 236, "b": 253, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 236, "b": 254, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 237, "b": 253, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 236, "b": 270, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 237, "b": 254, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 237, "b": 271, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 238, "b": 239, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 238, "b": 255, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 238, "b": 256, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 239, "b": 255, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 238, "b": 240, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 238, "b": 272, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 239, "b": 240, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 239, "b": 256, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 239, "b": 257, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 240, "b": 256, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 239, "b": 241, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 239, "b": 273, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 240, "b": 241, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 240, "b": 257, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 240, "b": 258, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 241, "b": 257, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 240, "b": 242, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 240, "b": 274, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 241, "b": 242, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 241, "b": 258, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 241, "b": 259, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 242, "b": 258, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 241, "b": 243, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 241, "b": 275, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 242, "b": 243, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 242, "b": 259, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 242, "b": 260, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 243, "b": 259, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 242, "b": 244, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 242, "b": 276, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 243, "b": 244, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 243, "b": 260, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 243, "b": 261, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 244, "b": 260, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 243, "b": 245, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 243, "b": 277, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 244, "b": 245, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 244, "b": 261, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 244, "b": 262, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 245, "b": 261, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 244, "b": 246, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 244, "b": 278, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 245, "b": 246, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 245, "b": 262, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 245, "b": 263, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 246, "b": 262, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 245, "b": 247, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 245, "b": 279, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 246, "b": 247, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 246, "b": 263, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 246, "b": 264, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 247, "b": 263, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 246, "b": 248, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 246, "b": 280, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 247, "b": 248, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 247, "b": 264, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 247, "b": 265, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 248, "b": 264, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 247, "b": 249, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 247, "b": 281, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 248, "b": 249, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 248, "b": 265, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 248, "b": 266, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 249, "b": 265, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 248, "b": 250, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 248, "b": 282, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 249, "b": 250, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 249, "b": 266, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 249, "b": 267, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 250, "b": 266, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 249, "b": 251, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 249, "b": 283, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 250, "b": 251, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 250, "b": 267, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 250, "b": 268, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 251, "b": 267, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 250, "b": 252, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 250, "b": 284, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 251, "b": 252, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 251, "b": 268, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 251, "b": 269, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 252, "b": 268, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 251, "b": 253, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 251, "b": 285, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 252, "b": 253, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 252, "b": 269, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 252, "b": 270, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 253, "b": 269, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 252, "b": 254, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 252, "b": 286, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 253, "b": 254, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 253, "b": 270, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 253, "b": 271, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 254, "b": 270, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 253, "b": 287, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 254, "b": 271, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 254, "b": 288, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 255, "b": 256, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 255, "b": 272, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 255, "b": 273, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 256, "b": 272, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 255, "b": 257, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 256, "b": 257, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 256, "b": 273, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 256, "b": 274, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 257, "b": 273, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 256, "b": 258, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 257, "b": 258, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 257, "b": 274, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 257, "b": 275, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 258, "b": 274, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 257, "b": 259, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 258, "b": 259, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 258, "b": 275, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 258, "b": 276, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 259, "b": 275, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 258, "b": 260, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 259, "b": 260, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 259, "b": 276, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 259, "b": 277, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 260, "b": 276, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 259, "b": 261, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 260, "b": 261, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 260, "b": 277, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 260, "b": 278, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 261, "b": 277, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 260, "b": 262, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 261, "b": 262, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 261, "b": 278, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 261, "b": 279, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 262, "b": 278, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 261, "b": 263, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 262, "b": 263, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 262, "b": 279, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 262, "b": 280, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 263, "b": 279, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 262, "b": 264, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 263, "b": 264, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 263, "b": 280, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 263, "b": 281, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 264, "b": 280, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 263, "b": 265, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 264, "b": 265, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 264, "b": 281, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 264, "b": 282, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 265, "b": 281, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 264, "b": 266, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 265, "b": 266, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 265, "b": 282, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 265, "b": 283, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 266, "b": 282, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 265, "b": 267, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 266, "b": 267, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 266, "b": 283, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 266, "b": 284, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 267, "b": 283, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 266, "b": 268, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 267, "b": 268, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 267, "b": 284, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 267, "b": 285, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 268, "b": 284, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 267, "b": 269, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 268, "b": 269, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 268, "b": 285, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 268, "b": 286, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 269, "b": 285, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 268, "b": 270, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 269, "b": 270, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 269, "b": 286, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 269, "b": 287, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 270, "b": 286, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 269, "b": 271, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 270, "b": 271, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 270, "b": 287, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 270, "b": 288, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 271, "b": 287, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 271, "b": 288, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 272, "b": 273, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 272, "b": 274, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 273, "b": 274, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 273, "b": 275, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 274, "b": 275, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 274, "b": 276, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 275, "b": 276, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 275, "b": 277, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 276, "b": 277, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 276, "b": 278, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 277, "b": 278, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 277, "b": 279, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 278, "b": 279, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 278, "b": 280, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 279, "b": 280, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 279, "b": 281, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 280, "b": 281, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 280, "b": 282, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 281, "b": 282, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 281, "b": 283, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 282, "b": 283, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 282, "b": 284, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 283, "b": 284, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 283, "b": 285, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 284, "b": 285, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 284, "b": 286, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 285, "b": 286, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 285, "b": 287, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 286, "b": 287, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 286, "b": 288, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 287, "b": 288, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }], "staticColliderIds": ["p5SphereCollider"] });

// src/domain/admission.ts
var PROFILES = [
  "cloth-pinned-sphere-visual-v1",
  "fluid-basin-visual-v1",
  "fluid-basin-xsph-visual-v1",
  "fluid-static-box-visual-v1"
];
var CLOTH_FIELDS = [
  "id",
  "restPositionsM",
  "initialPositionsM",
  "initialVelocitiesMps",
  "vertexMassesKg",
  "triangles",
  "pinnedVertexIndices",
  "constraints",
  "staticColliderIds"
];
var FLUID_FIELDS = [
  "id",
  "initialPositionsM",
  "initialVelocitiesMps",
  "massModel",
  "particleRadiusM",
  "smoothingRadiusM",
  "staticColliderIds",
  "visualSmoothing"
];
function check(value, message) {
  if (!value) error("INVALID_CONFIG", message);
}
function exact(value, keys, label) {
  check(value !== null && typeof value === "object" && !Array.isArray(value), `${label} requires a record`);
  const input = value;
  check(Object.keys(input).length === keys.length && keys.every((key) => Object.hasOwn(input, key)), `${label} requires exact fields`);
  return input;
}
function array(value, count, label) {
  check(Array.isArray(value) && value.length === count, `${label} requires exactly ${count} entries`);
  return value;
}
function triple(value, label) {
  const result = array(value, 3, label);
  result.forEach((part, index) => finite(part, -1e4, 1e4, `${label}[${index}]`));
  return result;
}
function same2(value, expected, label) {
  if (typeof expected !== "object" || expected === null) {
    check(Object.is(value, expected), `${label} differs from the fixed native profile`);
    return;
  }
  if (Array.isArray(expected)) {
    array(value, expected.length, label).forEach((item, index) => same2(item, expected[index], `${label}[${index}]`));
    return;
  }
  const reference = expected, input = exact(value, Object.keys(reference), label);
  for (const key of Object.keys(reference)) same2(input[key], reference[key], `${label}.${key}`);
}
function transform(value, label, local = false) {
  const input = exact(value, ["positionM", "orientationXYZW"], label);
  triple(input.positionM, `${label}.positionM`);
  same2(input.orientationXYZW, [0, 0, 0, 1], `${label}.orientationXYZW`);
  if (local) same2(input.positionM, [0, 0, 0], `${label}.positionM`);
  return input;
}
function admitDomainModel(model2, options) {
  if (!PROFILES.includes(options.profile)) return null;
  const profile = options.profile;
  check(options.broadPhase === "domain-fixed" && Object.is(options.fixedStepSeconds, CLOTH_STEP_SECONDS), "Unsupported domain options");
  same2(model2.gravityMps2, CLOTH_PROFILE.gravityMps2, "gravityMps2");
  const clothProfile = profile === "cloth-pinned-sphere-visual-v1";
  const boxProfile = profile === "fluid-static-box-visual-v1";
  const count = boxProfile ? 2 : 1;
  const bodyInputs = array(model2.bodies, count, "bodies");
  const colliderInputs = array(model2.colliders, count, "colliders");
  array(model2.joints, 0, "joints");
  const clothInputs = array(model2.cloths, clothProfile ? 1 : 0, "cloths");
  const fluidInputs = array(model2.fluids, clothProfile ? 0 : 1, "fluids");
  check(Array.isArray(model2.sourceBindings) && model2.sourceBindings.length <= 128, "Unsupported source binding population");
  const ids = /* @__PURE__ */ new Set();
  function id(value) {
    check(typeof value === "string" && ID.test(value) && !ids.has(value), "Invalid or duplicate global entity ID");
    ids.add(value);
    return value;
  }
  const bodies = /* @__PURE__ */ new Map();
  for (const value of bodyInputs) {
    const body = exact(value, ["id", "kind", "initial"], "static body");
    const bodyId = id(body.id);
    check(body.kind === "static", "Domain owners must be static");
    transform(body.initial, "static initial");
    bodies.set(bodyId, body);
  }
  const colliders = /* @__PURE__ */ new Map();
  const owners = /* @__PURE__ */ new Set();
  for (const value of colliderInputs) {
    const collider = exact(value, ["id", "bodyId", "geometry", "local", "material", "sensor", "ccd", "filter"], "collider");
    const colliderId = id(collider.id);
    check(typeof collider.bodyId === "string" && bodies.has(collider.bodyId) && !owners.has(collider.bodyId), "Collider requires one declared static owner");
    owners.add(collider.bodyId);
    const geometry = exact(collider.geometry, collider.geometry?.kind === "sphere" ? ["kind", "radiusM"] : ["kind", "halfExtentsM"], "geometry");
    if (geometry.kind === "sphere") finite(geometry.radiusM, 1e-4, 1e3, "radiusM");
    else {
      check(geometry.kind === "box" || geometry.kind === "box-interior", "Unsupported domain geometry");
      array(geometry.halfExtentsM, 3, "halfExtentsM").forEach((value2) => finite(value2, 1e-4, 1e3, "halfExtentsM"));
    }
    transform(collider.local, "collider.local", true);
    const material = exact(collider.material, ["restitution", "friction"], "material");
    same2(material.restitution, 0, "restitution");
    same2(material.friction, { static: 0, dynamic: 0 }, "friction");
    same2(collider.sensor, false, "sensor");
    same2(collider.ccd, false, "ccd");
    same2(collider.filter, { categoryBits: 1, maskBits: 65535 }, "filter");
    colliders.set(colliderId, collider);
  }
  check(owners.size === bodies.size, "Every static owner requires one collider");
  const data2 = clothProfile ? exact(clothInputs[0], CLOTH_FIELDS, "cloth") : exact(fluidInputs[0], FLUID_FIELDS, "fluid");
  id(data2.id);
  const refs = array(data2.staticColliderIds, count, "staticColliderIds");
  check(new Set(refs).size === refs.length && refs.every((ref) => typeof ref === "string" && colliders.has(ref)), "Invalid domain collider references");
  const numericalIds = new Set(ids);
  for (const value of model2.sourceBindings) {
    const binding = exact(value, ["id", "sourceRevision", "sourceDigest", "modelId", "occurrenceId", "entityIds", "approximation"], "sourceBinding");
    id(binding.id);
    for (const key of ["sourceRevision", "modelId", "occurrenceId"]) check(typeof binding[key] === "string" && binding[key].length > 0 && binding[key].length <= 4096, `Invalid ${key}`);
    check(typeof binding.sourceDigest === "string" && /^sha256:[0-9a-f]{64}$/.test(binding.sourceDigest), "Invalid source digest");
    check(Array.isArray(binding.entityIds) && binding.entityIds.length > 0 && binding.entityIds.length <= 128 && new Set(binding.entityIds).size === binding.entityIds.length && binding.entityIds.every((ref) => typeof ref === "string" && numericalIds.has(ref)), "Invalid source binding references");
    const approximation = exact(binding.approximation, ["kind", "lossLabel"], "approximation");
    check(approximation.kind === "control-net-box" || approximation.kind === "control-net-sphere", "Unsupported approximation");
    check(typeof approximation.lossLabel === "string" && approximation.lossLabel.length > 0 && approximation.lossLabel.length <= 4096, "Invalid loss label");
  }
  const staticData = { profile, gravityMps2: model2.gravityMps2, bodies: model2.bodies, colliders: model2.colliders };
  if (clothProfile) {
    for (const key of CLOTH_FIELDS) if (key !== "id" && key !== "staticColliderIds") same2(data2[key], nativeClothReference[key], `cloth.${key}`);
    const collider = colliderInputs[0], body = bodies.get(collider.bodyId);
    same2(collider.geometry, { kind: "sphere", radiusM: CLOTH_PROFILE.sphereRadiusM }, "cloth sphere");
    same2(body.initial.positionM, CLOTH_PROFILE.sphereCentreM, "cloth sphere position");
    return { kind: "cloth", data: model2.cloths[0], staticData };
  }
  same2(data2.massModel, { kind: "visual-unit-weights" }, "massModel");
  same2(data2.particleRadiusM, FLUID_PARTICLE_RADIUS_M, "particleRadiusM");
  same2(data2.smoothingRadiusM, FLUID_SMOOTHING_RADIUS_M, "smoothingRadiusM");
  same2(data2.visualSmoothing, profile === "fluid-basin-xsph-visual-v1" ? { kind: "xsph", coefficient: 0.15 } : { kind: "none" }, "visualSmoothing");
  const points = array(data2.initialPositionsM, 256, "initialPositionsM").map((point2, index) => triple(point2, `initialPositionsM[${index}]`));
  array(data2.initialVelocitiesMps, 256, "initialVelocitiesMps").forEach((velocity, index) => same2(velocity, [0, 0, 0], `initialVelocitiesMps[${index}]`));
  for (const point2 of points) for (let axis = 0; axis < 3; axis++) check(point2[axis] >= FLUID_PARTICLE_RADIUS_M && point2[axis] <= FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M, "Initial particle is outside the basin");
  const minimumSquared = FLUID_MIN_SPACING_M ** 2;
  for (let first = 0; first < 256; first++) for (let second = first + 1; second < 256; second++) {
    const dx = points[first][0] - points[second][0], dy = points[first][1] - points[second][1], dz = points[first][2] - points[second][2];
    check(!(dx * dx + dy * dy + dz * dz < minimumSquared - 1e-12), "Initial particles must be at least 0.025 m apart");
  }
  const basin = colliderInputs.find((value) => value.geometry.kind === "box-interior");
  check(basin, "Fluid requires one basin");
  const basinHalf = FLUID_BASIN_M.map((value) => value / 2);
  same2(basin.geometry.halfExtentsM, basinHalf, "basin half extents");
  same2(bodies.get(basin.bodyId).initial.positionM, basinHalf, "basin position");
  if (boxProfile) {
    const box = colliderInputs.find((value) => value.geometry.kind === "box");
    check(box, "Static fluid profile requires one box");
    const body = bodies.get(box.bodyId);
    const bounds = inflatedBoxBounds(
      body.initial.positionM,
      box.geometry.halfExtentsM
    );
    for (let axis = 0; axis < 3; axis++) check(bounds.low[axis] >= FLUID_PARTICLE_RADIUS_M && bounds.high[axis] <= FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M, "Static box exceeds the basin");
    const overlapScratch = Float64Array.from(points.flat());
    check(!insideStaticBox(overlapScratch, bounds), "Static box overlaps initial particles");
  } else check(colliderInputs.length === 1, "Unsupported fluid collider population");
  return { kind: "fluid", data: model2.fluids[0], staticData };
}

// src/model-admission.ts
function exact2(value, keys, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) error("INVALID_CONFIG", `${label} must be a record`);
  const input = value;
  if (Object.keys(input).length !== keys.length || keys.some((key) => !Object.hasOwn(input, key))) error("INVALID_CONFIG", `${label} requires exact fields: ${keys.join(",")}`);
  return input;
}
function text(value, label) {
  if (typeof value !== "string" || value.length === 0 || value.length > 4096) error("INVALID_CONFIG", `${label} must be a bounded nonempty string`);
  return value;
}
function list(value, maximum2, label) {
  if (!Array.isArray(value) || value.length > maximum2) error("INVALID_CONFIG", `${label} exceeds the profile bound`);
  return value;
}
function transform2(value, label) {
  const t = exact2(value, ["positionM", "orientationXYZW"], label);
  vector(t.positionM, -1e4, 1e4, `${label}.positionM`);
  if (!Array.isArray(t.orientationXYZW) || t.orientationXYZW.length !== 4) error("INVALID_CONFIG", `${label} requires an XYZW quaternion`);
  const q = t.orientationXYZW.map((x) => finite(x, -1, 1, label));
  if (Math.abs(Math.hypot(...q) - 1) > 1e-6) error("INVALID_CONFIG", `${label} quaternion must have unit norm`);
}
function admitModel(rawModel, rawOptions) {
  const model2 = copyData(rawModel);
  const options = copyData(rawOptions);
  const input = exact2(model2, ["format", "version", "revision", "frame", "units", "gravityMps2", "bodies", "colliders", "joints", "cloths", "fluids", "sourceBindings"], "model");
  if (input.format !== "barocss-physics-model" || input.version !== 1) error("INVALID_CONFIG", "unsupported model format or version");
  text(input.revision, "revision");
  const frame = exact2(input.frame, ["id", "basis", "rotation"], "frame");
  text(frame.id, "frame.id");
  if (frame.basis !== "right-handed-xyz" || frame.rotation !== "local-to-world-xyzw") error("INVALID_CONFIG", "unsupported frame convention");
  const units = exact2(input.units, ["length", "mass", "time", "angle"], "units");
  if (units.length !== "m" || units.mass !== "kg" || units.time !== "s" || units.angle !== "rad") error("INVALID_CONFIG", "model units must be m/kg/s/rad");
  vector(input.gravityMps2, -1e3, 1e3, "gravityMps2");
  const opt = exact2(options, ["profile", "fixedStepSeconds", "broadPhase"], "options");
  const domain = admitDomainModel(model2, options);
  if (domain) return { model: model2, options, bodies: [], joints: [], disjointHinges: null, domain, stationary: false };
  if (!["rigid-discrete-v1", "rigid-persistent-box-v1", "rigid-large-v1", STATIONARY_PROFILE].includes(opt.profile)) error("INVALID_CONFIG", "profile is not implemented");
  finite(opt.fixedStepSeconds, 1 / 240, 1 / 30, "fixedStepSeconds");
  const large = opt.profile === "rigid-large-v1", stationary = opt.profile === STATIONARY_PROFILE;
  if (stationary && opt.broadPhase !== "direct") error("INVALID_CONFIG", "stationary profile requires direct broadPhase");
  if (opt.broadPhase !== "aabb" && (large || opt.broadPhase !== "direct")) error("INVALID_CONFIG", "unsupported broadPhase for profile");
  const bodyInputs = list(input.bodies, stationary ? 9 : large ? 64 : opt.profile === "rigid-persistent-box-v1" ? 4 : 32, "bodies");
  if (bodyInputs.length === 0) error("INVALID_CONFIG", "at least one body is required");
  const colliders = list(input.colliders, bodyInputs.length, "colliders");
  const jointInputs = list(input.joints, stationary || large ? 0 : 8, "joints");
  list(input.cloths, 0, "cloths");
  list(input.fluids, 0, "fluids");
  const bindings = list(input.sourceBindings, 128, "sourceBindings");
  const ids = /* @__PURE__ */ new Set();
  function id(value) {
    if (typeof value !== "string" || !ID.test(value) || ids.has(value)) error("INVALID_CONFIG", "invalid or duplicate global entity ID");
    ids.add(value);
    return value;
  }
  const bodiesById = /* @__PURE__ */ new Map();
  for (const value of bodyInputs) {
    const raw = value;
    const b2 = exact2(value, raw?.kind === "dynamic" ? ["id", "kind", "massKg", "inertia", "initial"] : ["id", "kind", "initial"], "body");
    const bodyId = id(b2.id);
    if (!["dynamic", "static", "kinematic"].includes(b2.kind)) error("INVALID_CONFIG", "unsupported body kind");
    if (b2.kind === "dynamic") {
      const initial = exact2(b2.initial, ["positionM", "orientationXYZW", "velocityMps", "angularVelocityRadps"], "initial");
      transform2({ positionM: initial.positionM, orientationXYZW: initial.orientationXYZW }, "initial");
      vector(initial.velocityMps, -1e3, 1e3, "velocityMps");
      vector(initial.angularVelocityRadps, -1e3, 1e3, "angularVelocityRadps");
      finite(b2.massKg, 1e-6, 1e6, "massKg");
      const i = b2.inertia;
      exact2(i, i?.kind === "sphere-isotropic" ? ["kind", "about", "frame", "kgM2"] : ["kind", "about", "frame"], "inertia");
      if (i.about !== "com" || i.frame !== "body-local" || !["primitive-com", "sphere-isotropic"].includes(i.kind)) error("INVALID_CONFIG", "unsupported inertia");
      if (i.kind === "sphere-isotropic") finite(i.kgM2, 1e-12, 1e12, "inertia.kgM2");
    } else transform2(b2.initial, "initial");
    bodiesById.set(bodyId, b2);
  }
  const colliderByBody = /* @__PURE__ */ new Map();
  for (const value of colliders) {
    const c = exact2(value, ["id", "bodyId", "geometry", "local", "material", "sensor", "ccd", "filter"], "collider");
    id(c.id);
    if (typeof c.bodyId !== "string" || !bodiesById.has(c.bodyId) || colliderByBody.has(c.bodyId)) error("INVALID_CONFIG", "collider requires a unique declared owner");
    transform2(c.local, "collider.local");
    const local = c.local;
    if (local.positionM.some((x) => x !== 0) || local.orientationXYZW.some((x, i) => x !== (i === 3 ? 1 : 0))) error("INVALID_CONFIG", "only identity-local colliders are admitted");
    if (typeof c.sensor !== "boolean" || typeof c.ccd !== "boolean") error("INVALID_CONFIG", "sensor and ccd must be explicit booleans");
    const material = exact2(c.material, ["restitution", "friction"], "material");
    exact2(material.friction, ["static", "dynamic"], "friction");
    const filter = exact2(c.filter, ["categoryBits", "maskBits"], "filter");
    if (!large && (filter.categoryBits !== 1 || filter.maskBits !== 65535)) error("INVALID_CONFIG", "non-large profile requires no-filter values");
    const body = bodiesById.get(c.bodyId);
    if (c.sensor && body.kind === "dynamic" || c.ccd && body.kind !== "dynamic") error("INVALID_CONFIG", "unsupported sensor or CCD body role");
    colliderByBody.set(c.bodyId, c);
  }
  if (colliderByBody.size !== bodyInputs.length) error("INVALID_CONFIG", "each rigid body requires exactly one collider");
  const bodies = bodyInputs.map((value) => {
    const b2 = value;
    const c = colliderByBody.get(b2.id);
    const initial = b2.initial;
    const material = c.material;
    const inertia2 = b2.inertia;
    return parseBody({
      id: b2.id,
      kind: b2.kind,
      shape: c.geometry,
      positionM: initial.positionM,
      orientation: initial.orientationXYZW,
      restitution: material.restitution,
      friction: material.friction,
      ...large ? { collisionFilter: c.filter } : {},
      ...c.sensor ? { sensor: true } : {},
      ...c.ccd ? { ccd: true } : {},
      ...b2.kind === "dynamic" ? {
        massKg: b2.massKg,
        velocityMps: initial.velocityMps,
        angularVelocityRadps: initial.angularVelocityRadps,
        ...inertia2?.kind === "sphere-isotropic" ? { inertiaKgM2: inertia2.kgM2 } : {}
      } : {}
    }, large);
  });
  if (!bodies.some((b2) => b2.kind === "dynamic")) error("INVALID_CONFIG", "at least one dynamic body is required");
  if (large && bodies.some((b2) => b2.ccd)) error("INVALID_CONFIG", "large profile excludes CCD");
  const numericJoints = jointInputs.map((value) => {
    const raw = value;
    const j = exact2(value, raw?.kind === "hinge" ? ["id", "kind", "bodyAId", "bodyBId", "anchorALocalM", "anchorBLocalM", "axisWorld", "limitRad", "motor"] : ["id", "kind", "bodyAId", "bodyBId", "anchorALocalM", "anchorBLocalM"], "joint");
    id(j.id);
    if (j.kind !== "fixed" && j.kind !== "hinge") error("INVALID_CONFIG", "unsupported joint kind");
    if (j.kind === "hinge" && j.motor !== null) exact2(j.motor, ["targetSpeedRadps", "maxImpulseNms", "maxReactionNms"], "motor");
    return {
      id: j.id,
      kind: j.kind,
      aId: j.bodyAId,
      bId: j.bodyBId,
      anchorALocalM: j.anchorALocalM,
      anchorBLocalM: j.anchorBLocalM,
      ...j.kind === "hinge" ? { axisWorld: j.axisWorld, limitRad: j.limitRad, ...j.motor === null ? {} : { motor: j.motor } } : {}
    };
  });
  const disjoint = parseDisjointHingeProfile(model2, options, numericJoints, bodies);
  const joints = disjoint ? disjoint.joints : parseJoints(numericJoints, bodies);
  const numericalIds = new Set(ids);
  for (const value of bindings) {
    const s = exact2(value, ["id", "sourceRevision", "sourceDigest", "modelId", "occurrenceId", "entityIds", "approximation"], "sourceBinding");
    id(s.id);
    for (const key of ["sourceRevision", "modelId", "occurrenceId"]) text(s[key], key);
    if (typeof s.sourceDigest !== "string" || !/^sha256:[0-9a-f]{64}$/.test(s.sourceDigest)) error("INVALID_CONFIG", "invalid source digest");
    const refs = list(s.entityIds, 128, "entityIds");
    if (refs.length === 0 || new Set(refs).size !== refs.length || refs.some((ref) => typeof ref !== "string" || !numericalIds.has(ref))) error("INVALID_CONFIG", "invalid source binding references");
    const a2 = exact2(s.approximation, ["kind", "lossLabel"], "approximation");
    if (a2.kind !== "control-net-box" && a2.kind !== "control-net-sphere") error("INVALID_CONFIG", "unsupported approximation");
    text(a2.lossLabel, "lossLabel");
  }
  if (stationary) admitStationaryProfile(model2, options, bodies);
  return { model: model2, options, bodies, joints, disjointHinges: disjoint?.pairs ?? null, domain: null, stationary };
}

// src/world.ts
import { recordingWorlds } from "./recording-owner.js";
import { providerManifest } from "./provider-manifest.generated.js";

// src/joint-motor.ts
function driveHingeMotor(joint, body, angleRad) {
  const motor = joint.motor;
  const axis = joint.axisWorld;
  const [low, high] = joint.limitRad;
  if (angleRad <= low && motor.targetSpeedRadps < 0 || angleRad >= high && motor.targetSpeedRadps > 0) return 0;
  const inverseAxisInertia = dot(axis, inverseInertia(body, axis));
  const speed = dot(body.angularVelocityRadps, axis);
  const needed = (motor.targetSpeedRadps - speed) / inverseAxisInertia;
  const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
  body.angularVelocityRadps = add(
    body.angularVelocityRadps,
    inverseInertia(body, scale(axis, impulse))
  );
  return impulse;
}
function driveDynamicHingeMotor(joint, a2, b2, angleRad) {
  const motor = joint.motor;
  const axis = joint.axisWorld;
  const [low, high] = joint.limitRad;
  if (angleRad <= low && motor.targetSpeedRadps < 0 || angleRad >= high && motor.targetSpeedRadps > 0) return 0;
  const inverseSum = dot(axis, inverseInertia(a2, axis)) + dot(axis, inverseInertia(b2, axis));
  const speed = dot(sub(b2.angularVelocityRadps, a2.angularVelocityRadps), axis);
  const needed = (motor.targetSpeedRadps - speed) / inverseSum;
  const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
  a2.angularVelocityRadps = sub(
    a2.angularVelocityRadps,
    inverseInertia(a2, scale(axis, impulse))
  );
  b2.angularVelocityRadps = add(
    b2.angularVelocityRadps,
    inverseInertia(b2, scale(axis, impulse))
  );
  return impulse;
}

// src/capsule-contact.ts
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
function capsuleEnds(body) {
  const half = body.shape.halfLengthM;
  return [worldPoint(body, [0, -half, 0]), worldPoint(body, [0, half, 0])];
}
function segmentPair(a0, a1, b0, b1) {
  const u = sub(a1, a0), v = sub(b1, b0), w = sub(a0, b0);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v);
  const dd = dot(u, w), ee = dot(v, w), determinant = aa * cc - bb * bb;
  const candidates = [
    [0, clamp(ee / cc, 0, 1)],
    [1, clamp((bb + ee) / cc, 0, 1)],
    [clamp(-dd / aa, 0, 1), 0],
    [clamp((bb - dd) / aa, 0, 1), 1],
    [0.5, clamp((bb * 0.5 + ee) / cc, 0, 1)],
    [clamp((bb * 0.5 - dd) / aa, 0, 1), 0.5]
  ];
  if (determinant > 1e-12 * aa * cc) {
    const s = (bb * ee - cc * dd) / determinant;
    const t = (aa * ee - bb * dd) / determinant;
    if (s >= 0 && s <= 1 && t >= 0 && t <= 1) candidates.push([s, t]);
  }
  let best = candidates[0], bestDistance = Infinity, bestTie = Infinity;
  for (const candidate of candidates) {
    const difference = sub(add(a0, scale(u, candidate[0])), add(b0, scale(v, candidate[1])));
    const distance = dot(difference, difference);
    const tie = Math.abs(candidate[0] - 0.5) + Math.abs(candidate[1] - 0.5);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && tie < bestTie) {
      best = candidate;
      bestDistance = distance;
      bestTie = tie;
    }
  }
  return [add(a0, scale(u, best[0])), add(b0, scale(v, best[1]))];
}
function segmentBox(segmentStart, segmentEnd, extents2) {
  const direction2 = sub(segmentEnd, segmentStart);
  const breaks = [0, 1];
  for (let axis = 0; axis < 3; axis++) {
    if (Math.abs(direction2[axis]) < 1e-15) continue;
    for (const face of [-extents2[axis], extents2[axis]]) {
      const t = (face - segmentStart[axis]) / direction2[axis];
      if (t > 0 && t < 1) breaks.push(t);
    }
  }
  breaks.sort((a2, b2) => a2 - b2);
  let bestT = 0.5, bestDistance = Infinity;
  for (let interval = 0; interval < breaks.length - 1; interval++) {
    const low = breaks[interval], high = breaks[interval + 1];
    if (high - low < 1e-15) continue;
    const midpoint2 = (low + high) / 2;
    let numerator = 0, denominator = 0;
    for (let axis = 0; axis < 3; axis++) {
      const value = segmentStart[axis] + midpoint2 * direction2[axis];
      const face = value < -extents2[axis] ? -extents2[axis] : value > extents2[axis] ? extents2[axis] : null;
      if (face === null) continue;
      numerator += direction2[axis] * (segmentStart[axis] - face);
      denominator += direction2[axis] ** 2;
    }
    const t = clamp(denominator ? -numerator / denominator : 0.5, low, high);
    const point3 = add(segmentStart, scale(direction2, t));
    const nearest = point3.map((value, axis) => clamp(value, -extents2[axis], extents2[axis]));
    const delta = sub(point3, nearest), distance = dot(delta, delta);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && Math.abs(t - 0.5) < Math.abs(bestT - 0.5)) {
      bestT = t;
      bestDistance = distance;
    }
  }
  const point2 = add(segmentStart, scale(direction2, bestT));
  return [point2, point2.map((value, axis) => clamp(value, -extents2[axis], extents2[axis]))];
}
function capsuleCapsule(a2, b2) {
  const [aPoint, bPoint] = segmentPair(...capsuleEnds(a2), ...capsuleEnds(b2));
  const delta = sub(bPoint, aPoint), distance = Math.hypot(...delta);
  const aRadius = a2.shape.radiusM;
  const bRadius = b2.shape.radiusM;
  if (distance > aRadius + bRadius) return null;
  const centerDelta = sub(b2.positionM, a2.positionM);
  const normal = distance > 1e-12 ? scale(delta, 1 / distance) : Math.hypot(...centerDelta) > 1e-12 ? scale(centerDelta, 1 / Math.hypot(...centerDelta)) : a2.id < b2.id ? [1, 0, 0] : [-1, 0, 0];
  const surfaceA = add(aPoint, scale(normal, aRadius));
  const surfaceB = sub(bPoint, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add(surfaceA, surfaceB), 0.5)
  };
}
function capsuleBox(capsule, box) {
  const [start, end] = capsuleEnds(capsule).map((point2) => localPoint(box, point2));
  const extents2 = box.shape.halfExtentsM;
  const [axisPoint, boxPoint] = segmentBox(start, end, extents2);
  const delta = sub(boxPoint, axisPoint), distance = Math.hypot(...delta);
  const radius = capsule.shape.radiusM;
  if (distance > radius) return null;
  if (distance > 1e-12) return {
    normal: rotate2(box.orientation, scale(delta, 1 / distance)),
    penetration: radius - distance,
    pointM: worldPoint(box, boxPoint)
  };
  let bestAxis = 0, bestSide = -1, bestGap = Infinity;
  for (let axis = 0; axis < 3; axis++) for (const side2 of [-1, 1]) {
    const gap = extents2[axis] - side2 * axisPoint[axis];
    if (gap < bestGap) {
      bestGap = gap;
      bestAxis = axis;
      bestSide = side2;
    }
  }
  const normalLocal = [0, 0, 0];
  normalLocal[bestAxis] = -bestSide;
  boxPoint[bestAxis] = bestSide * extents2[bestAxis];
  return {
    normal: rotate2(box.orientation, normalLocal),
    penetration: radius + bestGap,
    pointM: worldPoint(box, boxPoint)
  };
}

// src/contact-tangent.ts
function unsafeTangent() {
  return error("NUMERIC_LIMIT", "unsafe static tangent response");
}
function solveStaticTangent(a2, b2, armA, armB, normal, direction2, speed, tangentMass) {
  const perpendicular = cross(normal, direction2);
  const length = Math.hypot(...perpendicular);
  if (!(length > 0) || !Number.isFinite(length)) unsafeTangent();
  const second = scale(perpendicular, 1 / length);
  const firstAxisA = cross(armA, direction2), firstAxisB = cross(armB, direction2);
  const secondAxisA = cross(armA, second), secondAxisB = cross(armB, second);
  const secondResponseA = inverseInertia(a2, secondAxisA);
  const secondResponseB = inverseInertia(b2, secondAxisB);
  const coupledMass = dot(firstAxisA, secondResponseA) + dot(firstAxisB, secondResponseB);
  const secondMass = a2.inverseMass + b2.inverseMass + dot(secondAxisA, secondResponseA) + dot(secondAxisB, secondResponseB);
  if (![tangentMass, coupledMass, secondMass].every(Number.isFinite) || !(tangentMass > 0) || !(secondMass > 0)) unsafeTangent();
  let firstImpulse, secondImpulse;
  if (coupledMass === 0) {
    firstImpulse = -speed / tangentMass;
    secondImpulse = 0;
  } else if (tangentMass >= secondMass) {
    const ratio4 = coupledMass / tangentMass;
    const schur = secondMass - coupledMass * ratio4;
    if (!Number.isFinite(ratio4) || !(schur > 0) || !Number.isFinite(schur)) unsafeTangent();
    secondImpulse = speed * ratio4 / schur;
    firstImpulse = (-speed - coupledMass * secondImpulse) / tangentMass;
  } else {
    const ratio4 = coupledMass / secondMass;
    const schur = tangentMass - coupledMass * ratio4;
    if (!Number.isFinite(ratio4) || !(schur > 0) || !Number.isFinite(schur)) unsafeTangent();
    firstImpulse = -speed / schur;
    secondImpulse = -ratio4 * firstImpulse;
  }
  const magnitudeNs = coupledMass === 0 ? Math.abs(firstImpulse) : Math.hypot(firstImpulse, secondImpulse);
  const impulseNs = coupledMass === 0 ? scale(direction2, firstImpulse) : add(scale(direction2, firstImpulse), scale(second, secondImpulse));
  if (!Number.isFinite(magnitudeNs) || ![firstImpulse, secondImpulse, ...impulseNs].every(Number.isFinite)) {
    unsafeTangent();
  }
  return { impulseNs, magnitudeNs };
}

// src/contact-contribution.ts
import { PhysicsError as PhysicsError3 } from "./types.js";
var zero = () => ({ linearImpulseNs: [0, 0, 0], angularImpulseAboutWorldOriginNms: [0, 0, 0] });
var copy = (v) => [...v];
function check2(v) {
  if (v.length !== 3 || v.some((value) => !Number.isFinite(value))) {
    throw new PhysicsError3("NUMERIC_LIMIT", "unsafe actual contact contribution");
  }
}
function side(com, arm, impulse, torque) {
  for (const v of [com, arm, impulse, torque]) check2(v);
  return { comM: copy(com), armM: copy(arm), linearImpulseNs: copy(impulse), armTorqueNms: copy(torque) };
}
function emptyContactContribution() {
  return { applications: [] };
}
function contactApplication(comA, comB, armA, armB, impulseOnB) {
  const impulseOnA = scale(impulseOnB, -1);
  return { applications: [{
    onA: side(comA, armA, impulseOnA, scale(cross(armA, impulseOnB), -1)),
    onB: side(comB, armB, impulseOnB, cross(armB, impulseOnB))
  }] };
}
function normalContactApplication(comA, comB, armA, armB, direction2, torqueAxisA, torqueAxisB, scalarNs) {
  const impulseOnB = scale(direction2, scalarNs);
  const contribution = { applications: [{
    onA: side(comA, armA, scale(impulseOnB, -1), scale(scale(torqueAxisA, scalarNs), -1)),
    onB: side(comB, armB, impulseOnB, scale(torqueAxisB, scalarNs)),
    normalOperands: {
      direction: copy(direction2),
      torqueAxisA: copy(torqueAxisA),
      torqueAxisB: copy(torqueAxisB),
      scalarNs
    }
  }] };
  return contribution;
}
function combineContactContributions(a2, b2) {
  return { applications: [...a2.applications, ...b2.applications] };
}
var ContactPairAccumulator = class {
  pairs = /* @__PURE__ */ new Map();
  add(aId, bId, contribution) {
    if (contribution.applications.length === 0) return;
    const key = aId + "\0" + bId;
    let pair = this.pairs.get(key);
    if (!pair) {
      pair = { aId, bId, anyNonzero: false, onA: zero(), onB: zero() };
      this.pairs.set(key, pair);
    }
    for (const application of contribution.applications) {
      for (const owner of ["onA", "onB"]) {
        const applied = application[owner];
        for (const v of [applied.comM, applied.armM, applied.linearImpulseNs, applied.armTorqueNms]) check2(v);
        pair.anyNonzero ||= applied.linearImpulseNs.some((value) => value !== 0) || applied.armTorqueNms.some((value) => value !== 0);
        const moment = add(cross(applied.comM, applied.linearImpulseNs), applied.armTorqueNms);
        pair[owner].linearImpulseNs = add(pair[owner].linearImpulseNs, applied.linearImpulseNs);
        pair[owner].angularImpulseAboutWorldOriginNms = add(pair[owner].angularImpulseAboutWorldOriginNms, moment);
      }
    }
  }
  /** Validate the complete candidate ledger before World's existing commit. */
  finish() {
    for (const pair of this.pairs.values()) for (const owner of ["onA", "onB"]) {
      check2(pair[owner].linearImpulseNs);
      check2(pair[owner].angularImpulseAboutWorldOriginNms);
    }
    return [...this.pairs.values()].map((pair) => ({
      aId: pair.aId,
      bId: pair.bId,
      anyNonzero: pair.anyNonzero,
      onA: {
        linearImpulseNs: copy(pair.onA.linearImpulseNs),
        angularImpulseAboutWorldOriginNms: copy(pair.onA.angularImpulseAboutWorldOriginNms)
      },
      onB: {
        linearImpulseNs: copy(pair.onB.linearImpulseNs),
        angularImpulseAboutWorldOriginNms: copy(pair.onB.angularImpulseAboutWorldOriginNms)
      }
    }));
  }
};

// src/collision.ts
function capsuleCenter(body, point2) {
  const half = body.shape.halfLengthM;
  const local = localPoint(body, point2);
  return worldPoint(body, [0, Math.max(-half, Math.min(half, local[1])), 0]);
}
function boxAxes(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
}
function boxSupport(body, direction2) {
  const axes = boxAxes(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function sphereSphere(a2, b2) {
  const aRadius = a2.shape.radiusM;
  const bRadius = b2.shape.radiusM;
  const delta = sub(b2.positionM, a2.positionM);
  const distance = Math.hypot(...delta);
  if (distance > aRadius + bRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  const aSurface = add(a2.positionM, scale(normal, aRadius));
  const bSurface = sub(b2.positionM, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add(aSurface, bSurface), 0.5)
  };
}
function sphereBox(sphere, box) {
  const radius = sphere.shape.radiusM;
  const extents2 = box.shape.halfExtentsM;
  const relative = localPoint(box, sphere.positionM);
  const nearest = relative.map((value, index) => Math.max(-extents2[index], Math.min(extents2[index], value)));
  const towardBox = sub(nearest, relative);
  const distance = Math.hypot(...towardBox);
  if (distance > radius) return null;
  if (distance > 0) return {
    normal: rotate2(box.orientation, scale(towardBox, 1 / distance)),
    penetration: Math.max(0, radius - distance),
    pointM: worldPoint(box, nearest)
  };
  let axis = 0, side2 = -1, faceDistance = Infinity;
  for (let index = 0; index < 3; index++) for (const candidate of [-1, 1]) {
    const gap = extents2[index] - candidate * relative[index];
    if (gap < faceDistance) {
      faceDistance = gap;
      axis = index;
      side2 = candidate;
    }
  }
  const localNormal = [0, 0, 0];
  localNormal[axis] = -side2;
  nearest[axis] = side2 * extents2[axis];
  return {
    normal: rotate2(box.orientation, localNormal),
    penetration: radius + faceDistance,
    pointM: worldPoint(box, nearest)
  };
}
function capsuleSphere(capsule, sphere) {
  const center = capsuleCenter(capsule, sphere.positionM);
  const delta = sub(sphere.positionM, center);
  const distance = Math.hypot(...delta);
  const capsuleRadius = capsule.shape.radiusM;
  const sphereRadius = sphere.shape.radiusM;
  if (distance > capsuleRadius + sphereRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  return {
    normal,
    penetration: Math.max(0, capsuleRadius + sphereRadius - distance),
    pointM: scale(add(
      add(center, scale(normal, capsuleRadius)),
      sub(sphere.positionM, scale(normal, sphereRadius))
    ), 0.5)
  };
}
function boxBox(a2, b2) {
  const axesA = boxAxes(a2), axesB = boxAxes(b2);
  const extentA = a2.shape.halfExtentsM, extentB = b2.shape.halfExtentsM;
  const delta = sub(b2.positionM, a2.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  for (const candidate of candidates) {
    const length = Math.hypot(...candidate);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis3, index) => sum + extentA[index] * Math.abs(dot(basis3, axis)), 0);
    const radiusB = axesB.reduce((sum, basis3, index) => sum + extentB[index] * Math.abs(dot(basis3, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    if (overlap < -1e-12) return null;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
    }
  }
  const aPoint = boxSupport(a2, bestAxis);
  const bPoint = boxSupport(b2, scale(bestAxis, -1));
  return { normal: bestAxis, penetration: Math.max(0, bestOverlap), pointM: scale(add(aPoint, bPoint), 0.5) };
}
function detect(a2, b2) {
  if (a2.shape.kind === "sphere" && b2.shape.kind === "sphere") return sphereSphere(a2, b2);
  if (a2.shape.kind === "sphere" && b2.shape.kind === "box") return sphereBox(a2, b2);
  if (a2.shape.kind === "box" && b2.shape.kind === "sphere") {
    const hit = sphereBox(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "capsule" && b2.shape.kind === "sphere") return capsuleSphere(a2, b2);
  if (a2.shape.kind === "sphere" && b2.shape.kind === "capsule") {
    const hit = capsuleSphere(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "box" && b2.shape.kind === "box") return boxBox(a2, b2);
  if (a2.shape.kind === "capsule" && b2.shape.kind === "box") return capsuleBox(a2, b2);
  if (a2.shape.kind === "box" && b2.shape.kind === "capsule") {
    const hit = capsuleBox(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "capsule" && b2.shape.kind === "capsule") return capsuleCapsule(a2, b2);
  return null;
}
function sphereOverlaps(center, radius, body) {
  if (body.shape.kind === "sphere") {
    return Math.hypot(...sub(center, body.positionM)) <= radius + body.shape.radiusM;
  }
  if (body.shape.kind === "capsule") {
    return Math.hypot(...sub(center, capsuleCenter(body, center))) <= radius + body.shape.radiusM;
  }
  const extents2 = body.shape.halfExtentsM;
  const local = localPoint(body, center);
  const delta = local.map((value, index) => Math.max(0, Math.abs(value) - extents2[index]));
  return Math.hypot(...delta) <= radius;
}
function raySphere(origin, direction2, center, radius) {
  const relative = sub(origin, center);
  const c = dot(relative, relative) - radius ** 2;
  if (c <= 0) return 0;
  const projection = dot(relative, direction2);
  const discriminant = projection ** 2 - c;
  return projection > 0 || discriminant < 0 ? null : -projection - Math.sqrt(discriminant);
}
function rayDistance(origin, direction2, body) {
  if (body.shape.kind === "sphere") return raySphere(origin, direction2, body.positionM, body.shape.radiusM);
  const localOrigin = localPoint(body, origin);
  const localDirection = rotate2(inverse(body.orientation), direction2);
  if (body.shape.kind === "capsule") {
    const { radiusM: radius, halfLengthM: half } = body.shape;
    const closest = [0, Math.max(-half, Math.min(half, localOrigin[1])), 0];
    if (Math.hypot(...sub(localOrigin, closest)) <= radius) return 0;
    const results = [];
    for (const y of [-half, half]) {
      const hit = raySphere(localOrigin, localDirection, [0, y, 0], radius);
      if (hit !== null) results.push(hit);
    }
    const a2 = localDirection[0] ** 2 + localDirection[2] ** 2;
    if (a2 > 1e-12) {
      const b2 = 2 * (localOrigin[0] * localDirection[0] + localOrigin[2] * localDirection[2]);
      const c = localOrigin[0] ** 2 + localOrigin[2] ** 2 - radius ** 2;
      const discriminant = b2 ** 2 - 4 * a2 * c;
      if (discriminant >= 0) for (const sign of [-1, 1]) {
        const hit = (-b2 + sign * Math.sqrt(discriminant)) / (2 * a2);
        const y = localOrigin[1] + localDirection[1] * hit;
        if (hit >= 0 && y >= -half && y <= half) results.push(hit);
      }
    }
    return results.length ? Math.min(...results) : null;
  }
  let near2 = -Infinity, far = Infinity;
  for (let index = 0; index < 3; index++) {
    const lower = -body.shape.halfExtentsM[index];
    const upper = body.shape.halfExtentsM[index];
    const component = localDirection[index];
    if (Math.abs(component) < 1e-12) {
      if (localOrigin[index] < lower || localOrigin[index] > upper) return null;
      continue;
    }
    const first = (lower - localOrigin[index]) / component;
    const second = (upper - localOrigin[index]) / component;
    near2 = Math.max(near2, Math.min(first, second));
    far = Math.min(far, Math.max(first, second));
    if (far < near2) return null;
  }
  return far < 0 ? null : Math.max(0, near2);
}
function solve(a2, b2, hit) {
  const inverseTotal = a2.inverseMass + b2.inverseMass;
  if (inverseTotal === 0) return { normalImpulseNs: 0, tangentImpulseNs: [0, 0, 0], contribution: emptyContactContribution() };
  const armA = sub(hit.pointM, a2.positionM), armB = sub(hit.pointM, b2.positionM);
  const pointVelocityA = add(a2.velocityMps, cross(a2.angularVelocityRadps, armA));
  const pointVelocityB = add(b2.velocityMps, cross(b2.angularVelocityRadps, armB));
  const relativeSpeed = dot(hit.normal, sub(pointVelocityB, pointVelocityA));
  const torqueAxisA = cross(armA, hit.normal), torqueAxisB = cross(armB, hit.normal);
  const effectiveMass = inverseTotal + dot(torqueAxisA, inverseInertia(a2, torqueAxisA)) + dot(torqueAxisB, inverseInertia(b2, torqueAxisB));
  let impulse = 0;
  if (relativeSpeed < 0) {
    const bounce = -relativeSpeed > 0.5 ? Math.min(a2.restitution, b2.restitution) : 0;
    impulse = -(1 + bounce) * relativeSpeed / effectiveMass;
  }
  const contribution = normalContactApplication(
    a2.positionM,
    b2.positionM,
    armA,
    armB,
    hit.normal,
    torqueAxisA,
    torqueAxisB,
    impulse
  );
  a2.angularVelocityRadps = sub(a2.angularVelocityRadps, scale(inverseInertia(a2, torqueAxisA), impulse));
  b2.angularVelocityRadps = add(b2.angularVelocityRadps, scale(inverseInertia(b2, torqueAxisB), impulse));
  for (let i = 0; i < 3; i++) {
    a2.velocityMps[i] -= hit.normal[i] * impulse * a2.inverseMass;
    b2.velocityMps[i] += hit.normal[i] * impulse * b2.inverseMass;
    a2.positionM[i] -= hit.normal[i] * hit.penetration * a2.inverseMass / inverseTotal;
    b2.positionM[i] += hit.normal[i] * hit.penetration * b2.inverseMass / inverseTotal;
  }
  const staticFriction = Math.sqrt(a2.frictionStatic * b2.frictionStatic);
  if (impulse === 0 || staticFriction === 0) {
    return { normalImpulseNs: impulse, tangentImpulseNs: [0, 0, 0], contribution };
  }
  const frictionArmA = a2.shape.kind === "sphere" && b2.kind === "static" && b2.shape.kind === "box" ? scale(hit.normal, a2.shape.radiusM) : sub(hit.pointM, a2.positionM);
  const frictionArmB = b2.shape.kind === "sphere" && a2.kind === "static" && a2.shape.kind === "box" ? scale(hit.normal, -b2.shape.radiusM) : sub(hit.pointM, b2.positionM);
  const afterA = add(a2.velocityMps, cross(a2.angularVelocityRadps, frictionArmA));
  const afterB = add(b2.velocityMps, cross(b2.angularVelocityRadps, frictionArmB));
  const relative = sub(afterB, afterA);
  const normalSquared = dot(hit.normal, hit.normal);
  if (!(normalSquared > 0) || !Number.isFinite(normalSquared)) {
    error("NUMERIC_LIMIT", "unsafe tangent projection");
  }
  const tangent = scale(cross(cross(hit.normal, relative), hit.normal), 1 / normalSquared);
  const speed = Math.hypot(...tangent);
  if (speed === 0) return { normalImpulseNs: impulse, tangentImpulseNs: [0, 0, 0], contribution };
  const direction2 = scale(tangent, 1 / speed);
  const tangentAxisA = cross(frictionArmA, direction2), tangentAxisB = cross(frictionArmB, direction2);
  const tangentMass = inverseTotal + dot(tangentAxisA, inverseInertia(a2, tangentAxisA)) + dot(tangentAxisB, inverseInertia(b2, tangentAxisB));
  const required = speed / tangentMass;
  const sticking = solveStaticTangent(
    a2,
    b2,
    frictionArmA,
    frictionArmB,
    hit.normal,
    direction2,
    speed,
    tangentMass
  );
  const dynamicFriction = Math.sqrt(a2.frictionDynamic * b2.frictionDynamic);
  const tangentImpulse = sticking.magnitudeNs <= staticFriction * impulse ? sticking.impulseNs : scale(direction2, -Math.min(required, dynamicFriction * impulse));
  const tangentContribution = contactApplication(a2.positionM, b2.positionM, frictionArmA, frictionArmB, tangentImpulse);
  a2.velocityMps = sub(a2.velocityMps, scale(tangentImpulse, a2.inverseMass));
  b2.velocityMps = add(b2.velocityMps, scale(tangentImpulse, b2.inverseMass));
  a2.angularVelocityRadps = sub(
    a2.angularVelocityRadps,
    inverseInertia(a2, cross(frictionArmA, tangentImpulse))
  );
  b2.angularVelocityRadps = add(
    b2.angularVelocityRadps,
    inverseInertia(b2, cross(frictionArmB, tangentImpulse))
  );
  return {
    normalImpulseNs: impulse,
    tangentImpulseNs: tangentImpulse,
    contribution: combineContactContributions(contribution, tangentContribution)
  };
}
function validateResult(bodies, contacts) {
  for (const body of bodies) {
    for (const [label, values, bound] of [
      ["position", body.positionM, 1e4],
      ["velocity", body.velocityMps, 1e3],
      ["angularVelocity", body.angularVelocityRadps, 1e3]
    ]) {
      if (values.some((value) => !Number.isFinite(value) || Math.abs(value) > bound)) error("NUMERIC_LIMIT", `${body.id} ${label} exceeded bounds`);
    }
    if (body.orientation.some((value) => !Number.isFinite(value)) || Math.abs(Math.hypot(...body.orientation) - 1) > 1e-12) error("NUMERIC_LIMIT", `${body.id} orientation exceeded tolerance`);
  }
  if (contacts.some((contact) => !Number.isFinite(contact.impulseNs) || !Number.isFinite(contact.penetrationM) || contact.normalAtoB.some((value) => !Number.isFinite(value)) || contact.pointM.some((value) => !Number.isFinite(value)) || contact.tangentImpulseNs.some((value) => !Number.isFinite(value)))) error("NUMERIC_LIMIT", "unsafe contact result");
}

// src/contact-manifold.ts
var basis = (body) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
function referenceFace(body, axes, normal) {
  for (let axis = 0; axis < 3; axis++) {
    const alignment = dot(axes[axis], normal);
    if (Math.abs(alignment) >= 1 - 1e-6) {
      return {
        body,
        axes,
        extents: body.shape.halfExtentsM,
        axis,
        side: Math.sign(alignment)
      };
    }
  }
  return null;
}
function clip(polygon, centre, axis, limit) {
  const result = [];
  for (let index = 0; index < polygon.length; index++) {
    const current = polygon[index], next = polygon[(index + 1) % polygon.length];
    const a2 = dot(sub(current, centre), axis) - limit - 1e-9;
    const b2 = dot(sub(next, centre), axis) - limit - 1e-9;
    const insideA = a2 <= 0, insideB = b2 <= 0;
    if (insideA) result.push(current);
    if (insideA !== insideB) result.push(add(current, scale(sub(next, current), a2 / (a2 - b2))));
  }
  return result;
}
function faceVertices(face) {
  const tangents = [0, 1, 2].filter((axis) => axis !== face.axis);
  const centre = add(face.body.positionM, scale(
    face.axes[face.axis],
    face.side * face.extents[face.axis]
  ));
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => add(
    add(centre, scale(face.axes[tangents[0]], u * face.extents[tangents[0]])),
    scale(face.axes[tangents[1]], v * face.extents[tangents[1]])
  ));
}
function boxFaceManifold(a2, b2, hit) {
  if (a2.shape.kind !== "box" || b2.shape.kind !== "box") return null;
  const axesA = basis(a2), axesB = basis(b2);
  const faceA = referenceFace(a2, axesA, hit.normal);
  const faceB = referenceFace(b2, axesB, scale(hit.normal, -1));
  const reference = faceA ?? faceB;
  if (!reference) return null;
  const incidentBody = reference.body === a2 ? b2 : a2;
  const incidentAxes = reference.body === a2 ? axesB : axesA;
  const normal = reference.body === a2 ? hit.normal : scale(hit.normal, -1);
  let incidentAxis = 0, greatest = -Infinity;
  for (let axis = 0; axis < 3; axis++) {
    const alignment = Math.abs(dot(incidentAxes[axis], normal));
    if (alignment > greatest) {
      greatest = alignment;
      incidentAxis = axis;
    }
  }
  const incident = {
    body: incidentBody,
    axes: incidentAxes,
    extents: incidentBody.shape.halfExtentsM,
    axis: incidentAxis,
    side: dot(incidentAxes[incidentAxis], normal) > 0 ? -1 : 1
  };
  const centre = add(reference.body.positionM, scale(
    reference.axes[reference.axis],
    reference.side * reference.extents[reference.axis]
  ));
  const tangents = [0, 1, 2].filter((axis) => axis !== reference.axis);
  let polygon = faceVertices(incident);
  for (const axis of tangents) {
    polygon = clip(polygon, centre, reference.axes[axis], reference.extents[axis]);
    polygon = clip(polygon, centre, scale(reference.axes[axis], -1), reference.extents[axis]);
  }
  const candidates = polygon.map((point2) => {
    const separation = dot(sub(point2, centre), normal);
    const midpoint2 = sub(point2, scale(normal, separation / 2));
    return {
      pointM: midpoint2,
      separation,
      u: dot(sub(midpoint2, centre), reference.axes[tangents[0]]),
      v: dot(sub(midpoint2, centre), reference.axes[tangents[1]])
    };
  }).filter((point2) => point2.separation <= 1e-6);
  if (!candidates.length) return null;
  const selected2 = candidates.length <= 4 ? candidates : [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => candidates.reduce((best, point2) => u * point2.u + v * point2.v > u * best.u + v * best.v ? point2 : best, candidates[0]));
  const unique = selected2.filter((point2, index) => selected2.findIndex((other) => Math.hypot(...sub(point2.pointM, other.pointM)) <= 1e-9) === index);
  unique.sort((first, second) => first.u - second.u || first.v - second.v);
  return unique.map((point2, index) => ({ id: `${reference.body.id}:${reference.axis}:${reference.side}:${index}`, pointM: point2.pointM }));
}

// src/persistent-box-contact.ts
function apply(a2, b2, pointM, impulse) {
  const armA = sub(pointM, a2.positionM), armB = sub(pointM, b2.positionM);
  const contribution = contactApplication(a2.positionM, b2.positionM, armA, armB, impulse);
  a2.velocityMps = sub(a2.velocityMps, scale(impulse, a2.inverseMass));
  b2.velocityMps = add(b2.velocityMps, scale(impulse, b2.inverseMass));
  a2.angularVelocityRadps = sub(
    a2.angularVelocityRadps,
    inverseInertia(a2, cross(armA, impulse))
  );
  b2.angularVelocityRadps = add(
    b2.angularVelocityRadps,
    inverseInertia(b2, cross(armB, impulse))
  );
  return contribution;
}
function relativeVelocity(a2, b2, pointM) {
  const armA = sub(pointM, a2.positionM), armB = sub(pointM, b2.positionM);
  return sub(
    add(b2.velocityMps, cross(b2.angularVelocityRadps, armB)),
    add(a2.velocityMps, cross(a2.angularVelocityRadps, armA))
  );
}
function effectiveInverseMass(a2, b2, pointM, direction2) {
  const torqueA = cross(sub(pointM, a2.positionM), direction2);
  const torqueB = cross(sub(pointM, b2.positionM), direction2);
  return a2.inverseMass + b2.inverseMass + dot(torqueA, inverseInertia(a2, torqueA)) + dot(torqueB, inverseInertia(b2, torqueB));
}
function warmStartPoint(a2, b2, pointM, normal, impulse) {
  return apply(a2, b2, pointM, add(scale(normal, impulse.normalNs), impulse.tangentNs));
}
function solvePersistentPoint(a2, b2, pointM, normal, impulse, normalTargetMps) {
  const normalSpeed = dot(relativeVelocity(a2, b2, pointM), normal);
  const normalMass = effectiveInverseMass(a2, b2, pointM, normal);
  const nextNormal = Math.max(0, normalTargetMps === 0 ? impulse.normalNs - normalSpeed / normalMass : impulse.normalNs + (normalTargetMps - normalSpeed) / normalMass);
  const deltaNormal = nextNormal - impulse.normalNs;
  impulse.normalNs = nextNormal;
  const normalContribution = deltaNormal !== 0 ? apply(a2, b2, pointM, scale(normal, deltaNormal)) : emptyContactContribution();
  const relative = relativeVelocity(a2, b2, pointM);
  const tangent = sub(relative, scale(normal, dot(relative, normal)));
  const tangentSpeed = Math.hypot(...tangent);
  let requested = impulse.tangentNs;
  if (tangentSpeed >= 1e-12) {
    const direction2 = scale(tangent, 1 / tangentSpeed);
    const tangentMass = effectiveInverseMass(a2, b2, pointM, direction2);
    requested = sub(impulse.tangentNs, scale(direction2, tangentSpeed / tangentMass));
  }
  const requestedMagnitude = Math.hypot(...requested);
  const staticLimit = Math.sqrt(a2.frictionStatic * b2.frictionStatic) * impulse.normalNs;
  const dynamicLimit = Math.sqrt(a2.frictionDynamic * b2.frictionDynamic) * impulse.normalNs;
  const limit = requestedMagnitude <= staticLimit ? staticLimit : dynamicLimit;
  const nextTangent = requestedMagnitude > limit && requestedMagnitude > 0 ? scale(requested, limit / requestedMagnitude) : requested;
  const deltaTangent = sub(nextTangent, impulse.tangentNs);
  impulse.tangentNs = nextTangent;
  const tangentContribution = apply(a2, b2, pointM, deltaTangent);
  return combineContactContributions(normalContribution, tangentContribution);
}
function correctPersistentPair(a2, b2, normal, penetration) {
  const inverseTotal = a2.inverseMass + b2.inverseMass;
  if (inverseTotal === 0 || penetration <= 0) return;
  const correction = scale(normal, penetration / inverseTotal);
  a2.positionM = sub(a2.positionM, scale(correction, a2.inverseMass));
  b2.positionM = add(b2.positionM, scale(correction, b2.inverseMass));
}

// src/ccd-rounded-box.ts
var ZERO = { n: 0n, d: 1n };
var ONE = { n: 1n, d: 1n };
function numericLimit() {
  return error("NUMERIC_LIMIT", "sphere CCD rounded-box calculation exceeded numeric limits");
}
function compare(a2, b2) {
  const difference = a2.n * b2.d - b2.n * a2.d;
  return difference < 0n ? -1 : difference > 0n ? 1 : 0;
}
function integerCoordinates(values) {
  const words = new DataView(new ArrayBuffer(8));
  const parts = values.map((value) => {
    if (!Number.isFinite(value)) numericLimit();
    words.setFloat64(0, value, false);
    const bits2 = words.getBigUint64(0, false);
    const exponent2 = Number(bits2 >> 52n & 2047n);
    const significand = bits2 & 0xfffffffffffffn | (exponent2 === 0 ? 0n : 0x10000000000000n);
    return {
      significand: bits2 >> 63n ? -significand : significand,
      exponent: exponent2 === 0 ? -1074 : exponent2 - 1075
    };
  });
  const exponent = Math.min(...parts.filter((part) => part.significand !== 0n).map((part) => part.exponent));
  return parts.map((part) => part.significand === 0n ? 0n : part.significand << BigInt(part.exponent - exponent));
}
function leading(value) {
  const magnitude2 = value < 0n ? -value : value;
  if (magnitude2 === 0n) return { value: 0, exponent: 0 };
  const exponent = Math.max(0, magnitude2.toString(2).length - 53);
  return { value: Number(magnitude2 >> BigInt(exponent)) * (value < 0n ? -1 : 1), exponent };
}
function powerOfTwo(value, exponent) {
  if (exponent < -1022) return value * 2 ** (exponent + 1022) * 2 ** -1022;
  if (exponent > 1023) return value * 2 ** (exponent - 1023) * 2 ** 1023;
  return value * 2 ** exponent;
}
function ratio(numerator, denominator) {
  const n = leading(numerator);
  const d = leading(denominator);
  return powerOfTwo(n.value / d.value, n.exponent - d.exponent);
}
function scaled(value, exponent) {
  const head = leading(value);
  return powerOfTwo(head.value, head.exponent - exponent);
}
function rootCompare(a2, b2, discriminant, branch, boundary) {
  const offset = -b2 * boundary.d - 2n * a2 * boundary.n;
  if (branch === -1 && offset < 0n) return -1;
  if (branch === 1 && offset > 0n) return 1;
  const squaredDifference = offset * offset - discriminant * boundary.d * boundary.d;
  const sign = squaredDifference < 0n ? -1 : squaredDifference > 0n ? 1 : 0;
  return branch === -1 ? sign : -sign;
}
function sweepRoundedBox(start, end, halfExtents, radius) {
  if (!(radius > 0) || halfExtents.some((value) => !(value > 0))) numericLimit();
  const coordinates = integerCoordinates([...start, ...end, ...halfExtents, radius]);
  const p = coordinates.slice(0, 3);
  const velocity = coordinates.slice(3, 6).map((value, axis) => value - p[axis]);
  const half = coordinates.slice(6, 9);
  const r = coordinates[9];
  const radiusSquared2 = r * r;
  let initialDistanceSquared = 0n;
  const breaks = [ZERO, ONE];
  for (let axis = 0; axis < 3; axis++) {
    const gap = p[axis] < -half[axis] ? p[axis] + half[axis] : p[axis] > half[axis] ? p[axis] - half[axis] : 0n;
    initialDistanceSquared += gap * gap;
    if (velocity[axis] === 0n) continue;
    for (const side2 of [-1n, 1n]) {
      let n = side2 * half[axis] - p[axis];
      let d = velocity[axis];
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      if (n > 0n && n < d) breaks.push({ n, d });
    }
  }
  if (initialDistanceSquared <= radiusSquared2) return null;
  if (velocity.every((value) => value === 0n)) return null;
  breaks.sort(compare);
  const boundaries = breaks.filter((value, index) => index === 0 || compare(value, breaks[index - 1]) !== 0);
  for (let interval = 0; interval + 1 < boundaries.length; interval++) {
    const lo = boundaries[interval];
    const hi = boundaries[interval + 1];
    const middle = { n: lo.n * hi.d + hi.n * lo.d, d: 2n * lo.d * hi.d };
    const gap = [0n, 0n, 0n];
    const motion = [0n, 0n, 0n];
    const sides = [0, 0, 0];
    let a2 = 0n;
    let b2 = 0n;
    let c = -radiusSquared2;
    for (let axis = 0; axis < 3; axis++) {
      const point2 = p[axis] * middle.d + velocity[axis] * middle.n;
      const bound = half[axis] * middle.d;
      const side2 = point2 < -bound ? -1 : point2 > bound ? 1 : 0;
      sides[axis] = side2;
      if (side2 === 0) continue;
      gap[axis] = p[axis] - BigInt(side2) * half[axis];
      motion[axis] = velocity[axis];
      a2 += motion[axis] * motion[axis];
      b2 += 2n * gap[axis] * motion[axis];
      c += gap[axis] * gap[axis];
    }
    if (a2 === 0n) {
      if (c > 0n) continue;
      if (c < 0n) numericLimit();
      const normal = gap.map((value) => ratio(value, r));
      return finish(ratio(lo.n, lo.d), normal, sides);
    }
    const discriminant = b2 * b2 - 4n * a2 * c;
    if (discriminant < 0n) continue;
    for (const branch of [-1, 1]) {
      if (branch === 1 && discriminant === 0n) continue;
      if (rootCompare(a2, b2, discriminant, branch, lo) < 0 || rootCompare(a2, b2, discriminant, branch, hi) > 0) continue;
      if (discriminant === 0n) {
        const normal2 = gap.map((value, axis) => ratio(
          2n * a2 * value - motion[axis] * b2,
          2n * a2 * r
        ));
        return finish(ratio(-b2, 2n * a2), normal2, sides);
      }
      const sqrtExponent = Math.ceil(discriminant.toString(2).length / 2);
      const sqrtMantissa = Math.sqrt(scaled(discriminant, 2 * sqrtExponent));
      const coefficientExponent = Math.max(
        a2.toString(2).length,
        (b2 < 0n ? -b2 : b2).toString(2).length,
        (c < 0n ? -c : c).toString(2).length
      );
      const aa = scaled(a2, coefficientExponent);
      const bb = scaled(b2, coefficientExponent);
      const cc = scaled(c, coefficientExponent);
      const rootDiscriminant = powerOfTwo(sqrtMantissa, sqrtExponent - coefficientExponent);
      const q = -0.5 * (bb + (b2 < 0n ? -rootDiscriminant : rootDiscriminant));
      if (!(aa > 0) || !(rootDiscriminant > 0) || q === 0 || ![aa, bb, cc, q].every(Number.isFinite)) numericLimit();
      const fraction = branch === (b2 < 0n ? 1 : -1) ? q / aa : cc / q;
      const normal = gap.map((value, axis) => {
        const projected = ratio(2n * a2 * value - motion[axis] * b2, 2n * a2 * r);
        const offset = ratio(motion[axis] << BigInt(sqrtExponent), 2n * a2 * r) * sqrtMantissa;
        return projected + branch * offset;
      });
      return finish(fraction, normal, sides);
    }
  }
  return null;
}
function finish(fraction, normal, sides) {
  if (!Number.isFinite(fraction) || fraction < 0 || fraction > 1 || normal.some((value, axis) => !Number.isFinite(value) || value * sides[axis] < 0)) numericLimit();
  const magnitude2 = Math.hypot(...normal);
  if (!(magnitude2 > 0) || Math.abs(magnitude2 - 1) > 1e-12) numericLimit();
  return { fraction, normalLocal: normal.map((value) => value / magnitude2) };
}

// src/ccd-slab.ts
function sweepBox(start, end, halfExtents) {
  if (start.every((value, axis) => Math.abs(value) <= halfExtents[axis])) return null;
  const travel = sub(end, start);
  let entry = 0;
  let exit = 1;
  let normalLocal = null;
  for (let axis = 0; axis < 3; axis++) {
    const velocity = travel[axis];
    if (velocity === 0) {
      if (Math.abs(start[axis]) > halfExtents[axis]) return null;
      continue;
    }
    const first = (-halfExtents[axis] - start[axis]) / velocity;
    const second = (halfExtents[axis] - start[axis]) / velocity;
    const near2 = Math.min(first, second);
    const far = Math.max(first, second);
    if (near2 > entry) {
      entry = near2;
      normalLocal = [0, 0, 0];
      normalLocal[axis] = velocity > 0 ? -1 : 1;
    }
    exit = Math.min(exit, far);
    if (entry > exit) return null;
  }
  return normalLocal && entry <= 1 && exit >= 0 ? { fraction: entry, normalLocal } : null;
}

// src/ccd-box.ts
var ANGULAR_TOLERANCE = 1e-12;
function axisAlignedBox(body) {
  return body.shape.kind === "box" && body.orientation.slice(0, 3).every((component) => Math.abs(component) <= ANGULAR_TOLERANCE) && Math.abs(Math.abs(body.orientation[3]) - 1) <= ANGULAR_TOLERANCE && body.angularVelocityRadps.every((component) => Math.abs(component) <= ANGULAR_TOLERANCE);
}
function rejectAngularBoxCommand(action) {
  if (action?.torqueNm?.some((component) => component !== 0) || action?.angularImpulseNms?.some((component) => component !== 0)) {
    error("INVALID_COMMAND", "axis-aligned box CCD excludes angular commands");
  }
}
function sweepDynamicBox(previous, candidate, fixture) {
  if (!axisAlignedBox(previous) || !axisAlignedBox(candidate) || !axisAlignedBox(fixture)) {
    error("NUMERIC_LIMIT", "box CCD candidate rotated outside the admitted profile");
  }
  if (previous.shape.kind !== "box" || fixture.shape.kind !== "box") return null;
  const fixtureHalfExtents = fixture.shape.halfExtentsM;
  const expanded2 = previous.shape.halfExtentsM.map((extent, axis) => extent + fixtureHalfExtents[axis]);
  const start = sub(previous.positionM, fixture.positionM);
  const end = sub(candidate.positionM, fixture.positionM);
  const hit = sweepBox(start, end, expanded2);
  if (!hit) return null;
  const travel = sub(candidate.positionM, previous.positionM);
  candidate.positionM = sub(
    add(previous.positionM, scale(travel, hit.fraction)),
    scale(hit.normalLocal, 1e-9)
  );
  return {
    bodyId: previous.id,
    fixtureId: fixture.id,
    toiFraction: hit.fraction,
    normalFixtureToBody: hit.normalLocal
  };
}

// src/ccd.ts
function admitCcd(bodies, jointCount, gravity) {
  const selected2 = bodies.filter((body) => body.ccd);
  if (selected2.length === 0) return { kind: "none" };
  const sphereIndex = bodies.findIndex((body) => body.ccd);
  if (selected2.length === 1 && bodies.length === 2 && jointCount === 0 && gravity.every((component) => component === 0) && bodies.every((body) => body.kind === "dynamic" && body.shape.kind === "sphere" && !body.sensor)) {
    return { kind: "sphere-pair", sphereIndex, otherIndex: 1 - sphereIndex };
  }
  if (selected2.length === 1 && selected2[0].shape.kind === "box" && bodies.length === 2 && jointCount === 0) {
    const fixtureIndex = 1 - sphereIndex;
    if (bodies[sphereIndex].kind === "dynamic" && bodies[fixtureIndex].kind === "static" && !bodies[fixtureIndex].sensor && axisAlignedBox(bodies[sphereIndex]) && axisAlignedBox(bodies[fixtureIndex])) {
      return { kind: "box-pair", boxIndex: sphereIndex, fixtureIndex };
    }
  }
  const fixtures = bodies.filter((body) => body.kind === "static" && !body.sensor && body.shape.kind === "box");
  if (selected2.length !== 1 || bodies.length !== fixtures.length + 1 || bodies.filter((body) => body.kind === "dynamic").length !== 1 || fixtures.length < 1 || fixtures.length > 8 || jointCount !== 0) {
    error("INVALID_CONFIG", "unsupported CCD body pair or world profile");
  }
  if (selected2[0].shape.kind !== "sphere") {
    error("INVALID_CONFIG", "static-box CCD requires a dynamic sphere");
  }
  return {
    kind: "static-boxes",
    sphereIndex,
    fixtures: fixtures.sort((a2, b2) => a2.id < b2.id ? -1 : a2.id > b2.id ? 1 : 0)
  };
}
function sweepSphere(previous, candidate, fixtures) {
  if (previous.shape.kind !== "sphere") return null;
  const radius = previous.shape.radiusM;
  const travel = sub(candidate.positionM, previous.positionM);
  let earliest = null;
  for (const fixture of fixtures) {
    if (fixture.shape.kind !== "box") continue;
    const hit = sweepRoundedBox(
      localPoint(fixture, previous.positionM),
      localPoint(fixture, candidate.positionM),
      fixture.shape.halfExtentsM,
      radius
    );
    if (!hit || earliest && hit.fraction >= earliest.toiFraction) continue;
    earliest = {
      bodyId: previous.id,
      fixtureId: fixture.id,
      toiFraction: hit.fraction,
      normalFixtureToBody: rotate2(fixture.orientation, hit.normalLocal)
    };
  }
  if (earliest) {
    candidate.positionM = sub(
      add(previous.positionM, scale(travel, earliest.toiFraction)),
      scale(earliest.normalFixtureToBody, 1e-9)
    );
  }
  return earliest;
}

// src/ccd-sphere-pair-exact.ts
function numericLimit2() {
  return error("NUMERIC_LIMIT", "unsafe exact sphere-pair sweep");
}
function integerCoordinates2(values) {
  const words = new DataView(new ArrayBuffer(8));
  const parts = values.map((value) => {
    if (!Number.isFinite(value)) numericLimit2();
    words.setFloat64(0, value, false);
    const bits2 = words.getBigUint64(0, false);
    const exponent2 = Number(bits2 >> 52n & 2047n);
    const significand = bits2 & 0xfffffffffffffn | (exponent2 === 0 ? 0n : 0x10000000000000n);
    return {
      significand: bits2 >> 63n ? -significand : significand,
      exponent: exponent2 === 0 ? -1074 : exponent2 - 1075
    };
  });
  const exponent = Math.min(...parts.filter((part) => part.significand !== 0n).map((part) => part.exponent));
  return parts.map((part) => part.significand === 0n ? 0n : part.significand << BigInt(part.exponent - exponent));
}
function leading2(value) {
  const magnitude2 = value < 0n ? -value : value;
  if (magnitude2 === 0n) return { value: 0, exponent: 0 };
  const exponent = Math.max(0, magnitude2.toString(2).length - 53);
  return { value: Number(magnitude2 >> BigInt(exponent)) * (value < 0n ? -1 : 1), exponent };
}
function powerOfTwo2(value, exponent) {
  if (exponent < -1022) return value * 2 ** (exponent + 1022) * 2 ** -1022;
  if (exponent > 1023) return value * 2 ** (exponent - 1023) * 2 ** 1023;
  return value * 2 ** exponent;
}
function ratio2(numerator, denominator) {
  const n = leading2(numerator);
  const d = leading2(denominator);
  return powerOfTwo2(n.value / d.value, n.exponent - d.exponent);
}
function scaled2(value, exponent) {
  const head = leading2(value);
  return powerOfTwo2(head.value, head.exponent - exponent);
}
function sweepSpherePairExact(markedStart, markedEnd, otherStart, otherEnd, markedRadius, otherRadius) {
  if (!(markedRadius > 0) || !(otherRadius > 0)) numericLimit2();
  const coordinates = integerCoordinates2([
    ...markedStart,
    ...markedEnd,
    ...otherStart,
    ...otherEnd,
    markedRadius,
    otherRadius
  ]);
  const p = coordinates.slice(0, 3).map((value, axis) => value - coordinates[6 + axis]);
  const v = coordinates.slice(3, 6).map((value, axis) => value - coordinates[axis] - coordinates[9 + axis] + coordinates[6 + axis]);
  const radius = coordinates[12] + coordinates[13];
  let a2 = 0n;
  let b2 = 0n;
  let c = -radius * radius;
  for (let axis = 0; axis < 3; axis++) {
    a2 += v[axis] * v[axis];
    b2 += 2n * p[axis] * v[axis];
    c += p[axis] * p[axis];
  }
  if (c <= 0n || a2 === 0n || b2 >= 0n) return null;
  const discriminant = b2 * b2 - 4n * a2 * c;
  if (discriminant < 0n) return null;
  const endpointOffset = -b2 - 2n * a2;
  const endpointDifference = endpointOffset < 0n ? -1n : endpointOffset * endpointOffset - discriminant;
  if (endpointDifference > 0n) return null;
  let fraction;
  let normal;
  if (discriminant === 0n) {
    fraction = endpointDifference === 0n ? 1 : ratio2(-b2, 2n * a2);
    normal = p.map((value, axis) => ratio2(2n * a2 * value - b2 * v[axis], 2n * a2 * radius));
  } else {
    const sqrtExponent = Math.ceil(discriminant.toString(2).length / 2);
    const sqrtMantissa = Math.sqrt(scaled2(discriminant, 2 * sqrtExponent));
    const coefficientExponent = Math.max(
      a2.toString(2).length,
      (-b2).toString(2).length,
      c.toString(2).length
    );
    const bb = scaled2(b2, coefficientExponent);
    const cc = scaled2(c, coefficientExponent);
    const rootDiscriminant = powerOfTwo2(sqrtMantissa, sqrtExponent - coefficientExponent);
    const q = -0.5 * (bb - rootDiscriminant);
    if (!(rootDiscriminant > 0) || !(q > 0) || ![bb, cc, q].every(Number.isFinite)) numericLimit2();
    fraction = endpointDifference === 0n ? 1 : cc / q;
    normal = p.map((value, axis) => {
      const projected = ratio2(2n * a2 * value - b2 * v[axis], 2n * a2 * radius);
      const offset = ratio2(v[axis] << BigInt(sqrtExponent), 2n * a2 * radius) * sqrtMantissa;
      return projected - offset;
    });
  }
  if (!Number.isFinite(fraction) || fraction < 0 || fraction > 1 || normal.some((value) => !Number.isFinite(value))) numericLimit2();
  const magnitude2 = Math.hypot(...normal);
  if (!(magnitude2 > 0) || Math.abs(magnitude2 - 1) > 1e-12) numericLimit2();
  return { fraction, normal: normal.map((value) => value / magnitude2) };
}

// src/ccd-pair.ts
function sweepSpherePair(markedStart, markedEnd, otherStart, otherEnd) {
  if (markedStart.shape.kind !== "sphere" || otherStart.shape.kind !== "sphere") return null;
  const hit = sweepSpherePairExact(
    markedStart.positionM,
    markedEnd.positionM,
    otherStart.positionM,
    otherEnd.positionM,
    markedStart.shape.radiusM,
    otherStart.shape.radiusM
  );
  if (!hit) return null;
  const markedTravel = sub(markedEnd.positionM, markedStart.positionM);
  const otherTravel = sub(otherEnd.positionM, otherStart.positionM);
  const { fraction, normal: normalFixtureToBody } = hit;
  const markedAtHit = add(markedStart.positionM, scale(markedTravel, fraction));
  const otherAtHit = add(otherStart.positionM, scale(otherTravel, fraction));
  markedEnd.positionM = sub(markedAtHit, scale(normalFixtureToBody, 5e-10));
  otherEnd.positionM = add(otherAtHit, scale(normalFixtureToBody, 5e-10));
  return {
    bodyId: markedStart.id,
    fixtureId: otherStart.id,
    toiFraction: fraction,
    normalFixtureToBody
  };
}

// src/broadphase.ts
function bodyBounds(body) {
  const shape2 = body.shape;
  let half;
  if (shape2.kind === "sphere") {
    half = [shape2.radiusM, shape2.radiusM, shape2.radiusM];
  } else if (shape2.kind === "capsule") {
    const axis = rotate2(body.orientation, [0, 1, 0]);
    half = axis.map((value) => shape2.radiusM + shape2.halfLengthM * Math.abs(value));
  } else {
    const axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
    half = [0, 1, 2].map((axis) => axes.reduce((extent, basis3, localAxis) => extent + Math.abs(basis3[axis]) * shape2.halfExtentsM[localAxis], 0));
  }
  const min = body.positionM.map((value, axis) => value - half[axis]);
  const max = body.positionM.map((value, axis) => value + half[axis]);
  if ([...min, ...max].some((value) => !Number.isFinite(value))) error("NUMERIC_LIMIT", "nonfinite broad-phase bounds");
  return { min, max };
}
function boundsOverlap(a2, b2) {
  for (let axis = 0; axis < 3; axis++) {
    if (a2.max[axis] + 1e-9 < b2.min[axis] || b2.max[axis] + 1e-9 < a2.min[axis]) return false;
  }
  return true;
}

// src/scene-profile.ts
function filterAllowsPair(a2, b2) {
  const left = a2.collisionFilter;
  const right = b2.collisionFilter;
  if (!left || !right) return true;
  return (left.maskBits & right.categoryBits) !== 0 && (right.maskBits & left.categoryBits) !== 0;
}
function dormantPair(a2, b2) {
  const dynamics = [a2, b2].filter((body) => body.kind === "dynamic");
  return dynamics.length > 0 && dynamics.every((body) => body.sleeping === true) && [a2, b2].every((body) => body.kind !== "kinematic" || Math.hypot(...body.velocityMps) === 0);
}
function wakeOnContact(a2, b2, sleepFrames, aIndex, bIndex) {
  if (dormantPair(a2, b2)) return;
  if (a2.kind === "dynamic" && a2.sleeping && (b2.kind === "dynamic" && !b2.sleeping || b2.kind === "kinematic" && Math.hypot(...b2.velocityMps) > 0)) {
    a2.sleeping = false;
    sleepFrames[aIndex] = 0;
  }
  if (b2.kind === "dynamic" && b2.sleeping && (a2.kind === "dynamic" && !a2.sleeping || a2.kind === "kinematic" && Math.hypot(...a2.velocityMps) > 0)) {
    b2.sleeping = false;
    sleepFrames[bIndex] = 0;
  }
}

// src/sleep.ts
var REST_STEPS = 60;
var LINEAR_REST_MPS = 0.02;
var ANGULAR_REST_RADPS = 0.02;
function nonzero(value) {
  return value?.some((component) => component !== 0) ?? false;
}
function wakeForActions(bodies, previousContacts, actions, sleepFrames) {
  const indexById = new Map(bodies.map((body, index) => [body.id, index]));
  const neighbors = bodies.map(() => []);
  for (const contact of previousContacts) {
    const a2 = indexById.get(contact.aId);
    const b2 = indexById.get(contact.bId);
    if (bodies[a2].kind === "dynamic" && bodies[b2].kind === "dynamic") {
      neighbors[a2].push(b2);
      neighbors[b2].push(a2);
    }
  }
  const queue = [];
  for (let index = 0; index < bodies.length; index++) {
    const body = bodies[index];
    const action = actions.get(body.id);
    if (body.kind === "dynamic" && (nonzero(action?.forceN) || nonzero(action?.impulseNs) || nonzero(action?.torqueNm) || nonzero(action?.angularImpulseNms))) queue.push(index);
    if (body.kind === "kinematic" && action?.positionM && action.positionM.some((value, axis) => value !== body.positionM[axis])) {
      for (const contact of previousContacts) {
        const otherId = contact.aId === body.id ? contact.bId : contact.bId === body.id ? contact.aId : null;
        const other = otherId ? indexById.get(otherId) : void 0;
        if (other !== void 0 && bodies[other].kind === "dynamic") queue.push(other);
      }
    }
  }
  const seen = /* @__PURE__ */ new Set();
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const index = queue[cursor];
    if (seen.has(index)) continue;
    seen.add(index);
    bodies[index].sleeping = false;
    sleepFrames[index] = 0;
    for (const other of neighbors[index]) if (!seen.has(other)) queue.push(other);
  }
}
function updateSleeping(bodies, contacts, sleepFrames) {
  const indexById = new Map(bodies.map((body, index) => [body.id, index]));
  const neighbors = bodies.map(() => []);
  const supported = bodies.map(() => false);
  const movingFixture = bodies.map(() => false);
  for (const contact of contacts) {
    const a2 = indexById.get(contact.aId);
    const b2 = indexById.get(contact.bId);
    const left = bodies[a2], right = bodies[b2];
    if (left.kind === "dynamic" && right.kind === "dynamic") {
      neighbors[a2].push(b2);
      neighbors[b2].push(a2);
    } else if (left.kind === "dynamic" || right.kind === "dynamic") {
      const dynamic = left.kind === "dynamic" ? a2 : b2;
      const fixture = left.kind === "dynamic" ? right : left;
      supported[dynamic] = true;
      movingFixture[dynamic] ||= fixture.kind === "kinematic" && Math.hypot(...fixture.velocityMps) > 0;
    }
  }
  const visited = /* @__PURE__ */ new Set();
  for (let index = 0; index < bodies.length; index++) {
    if (bodies[index].kind !== "dynamic" || visited.has(index)) continue;
    const island = [index];
    visited.add(index);
    for (let cursor = 0; cursor < island.length; cursor++) {
      for (const other of neighbors[island[cursor]]) if (!visited.has(other)) {
        visited.add(other);
        island.push(other);
      }
    }
    const asleep = island.filter((member) => bodies[member].sleeping).length;
    if (!island.some((member) => supported[member]) || island.some((member) => movingFixture[member]) || asleep > 0 && asleep < island.length) {
      for (const member of island) {
        bodies[member].sleeping = false;
        sleepFrames[member] = 0;
      }
      continue;
    }
    if (asleep === island.length) continue;
    const atRest = island.every((member) => Math.hypot(...bodies[member].velocityMps) <= LINEAR_REST_MPS && Math.hypot(...bodies[member].angularVelocityRadps) <= ANGULAR_REST_RADPS);
    for (const member of island) sleepFrames[member] = atRest ? sleepFrames[member] + 1 : 0;
    if (island.every((member) => sleepFrames[member] >= REST_STEPS)) {
      for (const member of island) {
        bodies[member].sleeping = true;
        bodies[member].velocityMps = [0, 0, 0];
        bodies[member].angularVelocityRadps = [0, 0, 0];
      }
    }
  }
}

// src/disjoint-hinge/measure.ts
function measureBodies(bodies, joint, origin) {
  const masses = bodies.map((b3) => 1 / b3.inverseMass), total = masses[0] + masses[1];
  const centerOfMassM = scale(add(scale(bodies[0].positionM, masses[0]), scale(bodies[1].positionM, masses[1])), 1 / total);
  const linearMomentumVectorKgMps = bodies.reduce((sum, b3, i) => add(sum, scale(b3.velocityMps, masses[i])), [0, 0, 0]);
  const orbitalAngularMomentumVectorKgM2ps = bodies.reduce((sum, b3, i) => add(sum, scale(cross(sub(b3.positionM, origin), b3.velocityMps), masses[i])), [0, 0, 0]);
  const spinAngularMomentumVectorKgM2ps = bodies.reduce((sum, b3) => add(sum, scale(b3.angularVelocityRadps, b3.inertiaKgM2)), [0, 0, 0]);
  const angularMomentumVectorKgM2ps = add(orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps);
  const energyJ = bodies.reduce((sum, b3, i) => sum + 0.5 * masses[i] * dot(b3.velocityMps, b3.velocityMps) + 0.5 * b3.inertiaKgM2 * dot(b3.angularVelocityRadps, b3.angularVelocityRadps), 0);
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], relative = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const raw = 2 * Math.atan2(dot([relative[0], relative[1], relative[2]], joint.axisWorld), relative[3]);
  const relativeAngleRad = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
  const anchorAM = worldPoint(a2, joint.anchorALocalM), anchorBM = worldPoint(b2, joint.anchorBLocalM);
  const anchorVelocityAMps = add(a2.velocityMps, cross(a2.angularVelocityRadps, rotate2(a2.orientation, joint.anchorALocalM)));
  const anchorVelocityBMps = add(b2.velocityMps, cross(b2.angularVelocityRadps, rotate2(b2.orientation, joint.anchorBLocalM)));
  const axisDeviationRad = Math.max(...bodies.map((body) => {
    const axis = rotate2(body.orientation, [0, 0, 1]);
    return Math.atan2(Math.hypot(axis[0], axis[1]), axis[2]);
  }));
  return {
    relativeAngleRad,
    anchorAM,
    anchorBM,
    anchorGapM: Math.hypot(...sub(anchorBM, anchorAM)),
    axisDeviationRad,
    quaternionNormError: Math.max(...bodies.map((body) => Math.abs(Math.hypot(...body.orientation) - 1))),
    limitExcessRad: Math.max(0, joint.limitRad[0] - relativeAngleRad, relativeAngleRad - joint.limitRad[1]),
    centerOfMassM,
    linearMomentumVectorKgMps,
    orbitalAngularMomentumVectorKgM2ps,
    spinAngularMomentumVectorKgM2ps,
    angularMomentumVectorKgM2ps,
    energyJ,
    anchorVelocityAMps,
    anchorVelocityBMps,
    anchorRelativeVelocityMps: sub(anchorVelocityAMps, anchorVelocityBMps),
    relativeAngularVelocityRadps: sub(b2.angularVelocityRadps, a2.angularVelocityRadps)
  };
}
function angle(a2, b2, axis) {
  const q = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const raw = 2 * Math.atan2(dot([q[0], q[1], q[2]], axis), q[3]);
  return raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
}
function momentum(bodies, origin) {
  const masses = bodies.map((b2) => 1 / b2.inverseMass), total = masses[0] + masses[1];
  const centerOfMassM = scale(add(scale(bodies[0].positionM, masses[0]), scale(bodies[1].positionM, masses[1])), 1 / total);
  const linearMomentumVectorKgMps = bodies.reduce((sum, b2, i) => add(sum, scale(b2.velocityMps, masses[i])), [0, 0, 0]);
  const orbitalAngularMomentumVectorKgM2ps = bodies.reduce((sum, b2, i) => add(sum, scale(cross(sub(b2.positionM, origin), b2.velocityMps), masses[i])), [0, 0, 0]);
  const spinAngularMomentumVectorKgM2ps = bodies.reduce((sum, b2) => add(sum, scale(b2.angularVelocityRadps, b2.inertiaKgM2)), [0, 0, 0]);
  const angularMomentumVectorKgM2ps = add(orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps);
  const energyJ = bodies.reduce((sum, b2, i) => sum + 0.5 * masses[i] * dot(b2.velocityMps, b2.velocityMps) + 0.5 * b2.inertiaKgM2 * dot(b2.angularVelocityRadps, b2.angularVelocityRadps), 0);
  return { centerOfMassM, linearMomentumVectorKgMps, orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps, angularMomentumVectorKgM2ps, energyJ };
}
function measurePose(bodies, joint, origin) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], relativeAngleRad = angle(a2, b2, joint.axisWorld), anchorAM = worldPoint(a2, joint.anchorALocalM), anchorBM = worldPoint(b2, joint.anchorBLocalM);
  const axisDeviationRad = Math.max(...bodies.map((body) => {
    const axis = rotate2(body.orientation, [0, 0, 1]);
    return Math.atan2(Math.hypot(axis[0], axis[1]), axis[2]);
  }));
  return { relativeAngleRad, anchorAM, anchorBM, anchorGapM: Math.hypot(...sub(anchorBM, anchorAM)), axisDeviationRad, quaternionNormError: Math.max(...bodies.map((b3) => Math.abs(Math.hypot(...b3.orientation) - 1))), limitExcessRad: Math.max(0, joint.limitRad[0] - relativeAngleRad, relativeAngleRad - joint.limitRad[1]), ...momentum(bodies, origin) };
}

// src/disjoint-hinge/errors.ts
var ERRORS = {
  pose: "hinge pose state is invalid",
  result: "hinge projection result is invalid",
  linear: "hinge velocity problem is invalid",
  system: "hinge velocity system is singular or unsafe",
  certificate: "hinge velocity certificate is invalid"
};
var GATE = 1e-10;
function fail(kind) {
  return error("NUMERIC_LIMIT", ERRORS[kind]);
}
function exactFields(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return false;
  const own = Reflect.ownKeys(value);
  return own.length === keys.length && own.every((k) => typeof k === "string" && keys.includes(k) && Object.hasOwn(Object.getOwnPropertyDescriptor(value, k), "value"));
}
function dense(value, size2) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === size2 && Reflect.ownKeys(value).length === size2 + 1 && Array.from({ length: size2 }, (_, i) => i).every((i) => Object.hasOwn(value, i) && typeof value[i] === "number" && Number.isFinite(value[i]));
}
function matrix(value, rows, columns) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === rows && Reflect.ownKeys(value).length === rows + 1 && Array.from({ length: rows }, (_, i) => i).every((i) => Object.hasOwn(value, i) && dense(value[i], columns));
}
function finiteData(value) {
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (Array.isArray(value)) return Object.getPrototypeOf(value) === Array.prototype && Reflect.ownKeys(value).length === value.length + 1 && Array.from({ length: value.length }, (_, i) => i).every((i) => Object.hasOwn(value, i) && finiteData(value[i]));
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return (proto === Object.prototype || proto === null) && Reflect.ownKeys(value).every((k) => typeof k === "string" && finiteData(value[k]));
}
function readProblem(value) {
  if (!exactFields(value, ["a", "b", "h", "y0", "stopKind", "stopRow"]) || !matrix(value.a, 11, 12) || !dense(value.b, 11) || !dense(value.h, 12) || value.h.some((x) => x <= 0) || !dense(value.y0, 12)) fail("linear");
  if (value.stopKind !== "none" && value.stopKind !== "upper" && value.stopKind !== "lower") fail("linear");
  if (!dense(value.stopRow, value.stopKind === "none" ? 0 : 12)) fail("linear");
  return structuredClone(value);
}

// src/disjoint-hinge/pose.ts
function finiteData2(value) {
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (Array.isArray(value)) return value.every(finiteData2);
  if (value && typeof value === "object") return Object.values(value).every(finiteData2);
  return false;
}
function projectCoupledHinge(input) {
  const before = input.bodies.map(copyBody), bodies = input.bodies.map(copyBody), joint = input.pair.joint;
  const origin = [...input.pair.originM], beforeMetric = measurePose(before, joint, origin);
  const targetAngleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], beforeMetric.relativeAngleRad)), excess = beforeMetric.relativeAngleRad - targetAngleRad;
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], axis = joint.axisWorld, inverseA = dot(axis, inverseInertia(a2, axis)), inverseB = dot(axis, inverseInertia(b2, axis)), inverseSum = inverseA + inverseB;
  const angleCorrectionsRad = [excess * inverseA / inverseSum, -excess * inverseB / inverseSum];
  a2.orientation = advanceOrientation(a2.orientation, scale(axis, angleCorrectionsRad[0]), 1);
  b2.orientation = advanceOrientation(b2.orientation, scale(axis, angleCorrectionsRad[1]), 1);
  const massA = 1 / a2.inverseMass, massB = 1 / b2.inverseMass, totalMass = massA + massB;
  const center = scale(add(scale(before[joint.aIndex].positionM, massA), scale(before[joint.bIndex].positionM, massB)), 1 / totalMass);
  const offset = sub(rotate2(b2.orientation, joint.anchorBLocalM), rotate2(a2.orientation, joint.anchorALocalM));
  a2.positionM = add(center, scale(offset, massB / totalMass));
  b2.positionM = sub(center, scale(offset, massA / totalMass));
  validateResult(bodies, []);
  const afterMetric = measurePose(bodies, joint, origin), velocityBitsUnchanged = bodies.every((body, i) => body.velocityMps.every((v, k) => Object.is(v, before[i].velocityMps[k]))), angularVelocityBitsUnchanged = bodies.every((body, i) => body.angularVelocityRadps.every((v, k) => Object.is(v, before[i].angularVelocityRadps[k])));
  const poseReport = { jointId: joint.id, finalAngleRad: afterMetric.relativeAngleRad, targetAngleRad };
  const diagnostics = { before: beforeMetric, after: afterMetric, targetAngleRad, angleCorrectionsRad, translationCorrectionsM: bodies.map((body, i) => sub(body.positionM, before[i].positionM)), sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds, velocityBitsUnchanged, angularVelocityBitsUnchanged, lawEvaluations: 1 };
  if (!finiteData2(poseReport) || !finiteData2(diagnostics) || !velocityBitsUnchanged || !angularVelocityBitsUnchanged) fail("result");
  return { bodies: bodies.map(copyBody), poseReport: structuredClone(poseReport), diagnostics: structuredClone(diagnostics) };
}

// src/disjoint-hinge/rows.ts
var DOF_ORDER = ["vAx", "vAy", "vAz", "wAx", "wAy", "wAz", "vBx", "vBy", "vBz", "wBx", "wBy", "wBz"];
var ROW_IDS = ["P.x", "P.y", "P.z", "L.x", "L.y", "L.z", "anchor.x", "anchor.y", "anchor.z", "transverse.x", "transverse.y"];
var skew = (r) => [[0, -r[2], r[1]], [r[2], 0, -r[0]], [-r[1], r[0], 0]];
var canonical = (value) => value === 0 ? 0 : value;
function makeRows(beforeBodies, finalBodies, joint, before, origin, target) {
  const masses = beforeBodies.map((body) => 1 / body.inverseMass), inertias = beforeBodies.map((body) => body.inertiaKgM2);
  const center = [...before.centerOfMassM], centeredTarget = sub(before.angularMomentumVectorKgM2ps, cross(sub(center, origin), before.linearMomentumVectorKgMps));
  const physicalA = Array.from({ length: 11 }, () => Array(12).fill(0));
  const rA = rotate2(finalBodies[0].orientation, joint.anchorALocalM), rB = rotate2(finalBodies[1].orientation, joint.anchorBLocalM);
  const ra = skew(rA), rb = skew(rB), sa = skew(sub(finalBodies[0].positionM, center)), sb = skew(sub(finalBodies[1].positionM, center));
  for (let i = 0; i < 3; i++) {
    physicalA[i][i] = masses[0];
    physicalA[i][6 + i] = masses[1];
    for (let j = 0; j < 3; j++) {
      physicalA[3 + i][j] = masses[0] * sa[i][j];
      physicalA[3 + i][6 + j] = masses[1] * sb[i][j];
      physicalA[6 + i][3 + j] = -ra[i][j];
      physicalA[6 + i][9 + j] = rb[i][j];
    }
    physicalA[3 + i][3 + i] = inertias[0];
    physicalA[3 + i][9 + i] = inertias[1];
    physicalA[6 + i][i] = 1;
    physicalA[6 + i][6 + i] = -1;
  }
  physicalA[9][3] = -1;
  physicalA[9][9] = 1;
  physicalA[10][4] = -1;
  physicalA[10][10] = 1;
  for (const row of physicalA) for (let j = 0; j < 12; j++) row[j] = canonical(row[j]);
  const physicalB = [...before.linearMomentumVectorKgMps, ...centeredTarget, 0, 0, 0, 0, 0];
  const physicalH = [...Array(3).fill(masses[0]), ...Array(3).fill(inertias[0]), ...Array(3).fill(masses[1]), ...Array(3).fill(inertias[1])];
  const physicalX0 = beforeBodies.flatMap((body) => [...body.velocityMps, ...body.angularVelocityRadps]);
  const columnScales = [1, 1, 1, 10, 10, 10, 1, 1, 1, 10, 10, 10], rowDivisors = [1, 1, 1, 0.1, 0.1, 0.1, 1, 1, 1, 10, 10];
  const dimensionlessA = physicalA.map((row, i) => row.map((value, j) => value * columnScales[j] / rowDivisors[i]));
  const dimensionlessB = physicalB.map((value, i) => value / rowDivisors[i]);
  const dimensionlessH = physicalH.map((value, j) => value * columnScales[j] * columnScales[j] / 1);
  const dimensionlessX0 = physicalX0.map((value, j) => value / columnScales[j]);
  const stopKind = target === joint.limitRad[1] ? "upper" : target === joint.limitRad[0] ? "lower" : "none";
  const physicalStopRow = stopKind === "none" ? [] : Array(12).fill(0);
  if (stopKind !== "none") {
    physicalStopRow[5] = stopKind === "upper" ? -1 : 1;
    physicalStopRow[11] = -physicalStopRow[5];
  }
  const dimensionlessStopRow = physicalStopRow.map((value, j) => value * columnScales[j] / 10);
  const h = sub(rA, rB), d = sub(finalBodies[1].positionM, finalBodies[0].positionM);
  const rankSufficientMarginKgM2 = 2 * inertias[0] - masses[0] * Math.hypot(...h) * Math.hypot(...sub(d, h));
  const problem = { a: dimensionlessA, b: dimensionlessB, h: dimensionlessH, y0: dimensionlessX0, stopKind, stopRow: dimensionlessStopRow };
  const result = {
    dofOrder: [...DOF_ORDER],
    rowIds: [...ROW_IDS],
    physicalA,
    physicalB,
    physicalH,
    physicalX0,
    columnScales,
    rowDivisors,
    dimensionlessA,
    dimensionlessB,
    dimensionlessH,
    dimensionlessX0,
    centerOfMassOriginM: center,
    originalOriginM: [...origin],
    stopKind,
    physicalStopRow,
    dimensionlessStopRow,
    rankSufficientMarginKgM2,
    problem
  };
  if (!finiteData(result) || physicalH.some((value) => value <= 0)) fail("linear");
  return result;
}

// src/disjoint-hinge/linear-solver.ts
function checked(value, kind = "system") {
  if (!Number.isFinite(value)) fail(kind);
  return value;
}
function dot2(a2, b2, kind = "system") {
  let sum = 0;
  for (let j = 0; j < a2.length; j++) sum = checked(sum + checked(a2[j] * b2[j], kind), kind);
  return sum;
}
function normInf(a2, kind = "system") {
  let maximum2 = 0;
  for (const row of a2) {
    let sum = 0;
    for (const value of row) sum = checked(sum + Math.abs(value), kind);
    maximum2 = Math.max(maximum2, sum);
  }
  return maximum2;
}
function selected(problem, active) {
  return { a: active ? [...problem.a.map((row) => [...row]), [...problem.stopRow]] : problem.a.map((row) => [...row]), b: active ? [...problem.b, 0] : [...problem.b] };
}
function gram(a2, h, kind = "system") {
  for (const value of h) checked(1 / value, kind);
  return a2.map((row) => a2.map((other) => {
    let sum = 0;
    for (let j = 0; j < 12; j++) {
      const divided = checked(row[j] / h[j], kind);
      sum = checked(sum + checked(divided * other[j], kind), kind);
    }
    return sum;
  }));
}
function safeReciprocals(problem) {
  for (const value of problem.h) checked(1 / value);
}
function fromLambda(problem, a2, lambda, kind = "system") {
  const y = [];
  for (let j = 0; j < 12; j++) {
    let sum = 0;
    for (let i = 0; i < a2.length; i++) sum = checked(sum + checked(a2[i][j] * lambda[i], kind), kind);
    y.push(checked(problem.y0[j] + checked(sum / problem.h[j], kind), kind));
  }
  return y;
}
function objective(problem, y) {
  let sum = 0;
  for (let j = 0; j < 12; j++) {
    const difference = checked(y[j] - problem.y0[j], "certificate");
    const square = checked(difference * difference, "certificate");
    sum = checked(sum + checked(problem.h[j] * square, "certificate"), "certificate");
  }
  return checked(0.5 * sum, "certificate");
}
function phaseResiduals(g, rhs, lambda, inverse2, kind = "system") {
  let linear = 0, inverseError = 0;
  for (let i = 0; i < g.length; i++) {
    linear = Math.max(linear, Math.abs(checked(dot2(g[i], lambda, kind) - rhs[i], kind)));
    let rowError = 0;
    for (let j = 0; j < g.length; j++) {
      let sum = 0;
      for (let k = 0; k < g.length; k++) sum = checked(sum + checked(g[i][k] * inverse2[k][j], kind), kind);
      rowError = checked(rowError + Math.abs(checked(sum - (i === j ? 1 : 0), kind)), kind);
    }
    inverseError = Math.max(inverseError, rowError);
  }
  return { linear, inverse: inverseError };
}
function solvePhase(problem, active) {
  const system = selected(problem, active), a2 = system.a, b2 = system.b, n = a2.length, g = gram(a2, problem.h), rhs = b2.map((value, i) => checked(value - dot2(a2[i], problem.y0)));
  const norm2 = normInf(g), threshold = checked(1e-12 * Math.max(1, norm2));
  const augmented = g.map((row, i) => [...row, rhs[i], ...Array.from({ length: n }, (_, j) => i === j ? 1 : 0)]), pivots = [];
  for (let k = 0; k < n; k++) {
    let chosen = k;
    for (let i = k + 1; i < n; i++) if (Math.abs(augmented[i][k]) > Math.abs(augmented[chosen][k])) chosen = i;
    if (Math.abs(augmented[chosen][k]) <= threshold) fail("system");
    if (chosen !== k) [augmented[k], augmented[chosen]] = [augmented[chosen], augmented[k]];
    const pivot = augmented[k][k];
    pivots.push(pivot);
    for (let i = k + 1; i < n; i++) {
      const factor2 = checked(augmented[i][k] / pivot);
      augmented[i][k] = 0;
      for (let j = k + 1; j <= 2 * n; j++) augmented[i][j] = checked(augmented[i][j] - checked(factor2 * augmented[k][j]));
    }
  }
  const solutions = [];
  for (let column = n; column <= 2 * n; column++) {
    const x = Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      let sum = 0;
      for (let j = i + 1; j < n; j++) sum = checked(sum + checked(augmented[i][j] * x[j]));
      x[i] = checked(checked(augmented[i][column] - sum) / augmented[i][i]);
    }
    solutions.push(x);
  }
  const lambda = solutions[0], inverse2 = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_2, j) => solutions[j + 1][i]));
  const conditionInf = checked(norm2 * normInf(inverse2));
  if (conditionInf > 1e12) fail("system");
  const y = fromLambda(problem, a2, lambda), residuals = phaseResiduals(g, rhs, lambda, inverse2);
  if (residuals.linear > GATE || residuals.inverse > GATE) fail("certificate");
  return { rowIds: Array.from({ length: n }, (_, i) => i), rowCount: n, pivots, inverse: inverse2, normInf: norm2, conditionInf, lambda, y, residuals };
}
function certificate(problem, result) {
  const system = selected(problem, result.activeStop), a2 = system.a, b2 = system.b;
  let primal = 0, stationarity = 0;
  for (let i = 0; i < a2.length; i++) primal = Math.max(primal, Math.abs(checked(dot2(a2[i], result.y, "certificate") - b2[i], "certificate")));
  for (let j = 0; j < 12; j++) {
    let sum = 0;
    for (let i = 0; i < a2.length; i++) sum = checked(sum + checked(a2[i][j] * result.lambda[i], "certificate"), "certificate");
    const lhs = checked(problem.h[j] * checked(result.y[j] - problem.y0[j], "certificate"), "certificate");
    stationarity = Math.max(stationarity, Math.abs(checked(lhs - sum, "certificate")));
  }
  const signed = problem.stopKind === "none" ? 0 : dot2(problem.stopRow, result.y, "certificate"), mu = result.activeStop ? -result.lambda[11] : 0;
  const negativeMu = Math.max(0, -mu), complementarity = Math.abs(checked(mu * signed, "certificate"));
  const objectiveError = Math.abs(checked(objective(problem, result.y) - result.objectiveDimensionless, "certificate"));
  const value = { primal, stationarity, negativeMu, complementarity, objective: objectiveError };
  if (problem.stopKind !== "none" && signed > GATE || Object.values(value).some((v) => v > GATE) || result.objectiveDimensionless < 0) fail("certificate");
  return value;
}
function exactIdentity(problem) {
  return problem.a.every((row, i) => checked(dot2(row, problem.y0) - problem.b[i]) === 0) && (problem.stopKind === "none" || dot2(problem.stopRow, problem.y0) <= 0);
}
function readPhase(value, n) {
  if (!exactFields(value, ["rowIds", "rowCount", "pivots", "inverse", "normInf", "conditionInf", "lambda", "y", "residuals"]) || value.rowCount !== n || !dense(value.rowIds, n) || value.rowIds.some((id, i) => id !== i) || !dense(value.pivots, n) || !matrix(value.inverse, n, n) || !dense(value.lambda, n) || !dense(value.y, 12) || typeof value.normInf !== "number" || !Number.isFinite(value.normInf) || value.normInf < 0 || typeof value.conditionInf !== "number" || !Number.isFinite(value.conditionInf) || value.conditionInf < 0 || !exactFields(value.residuals, ["linear", "inverse"]) || ![value.residuals.linear, value.residuals.inverse].every((v) => typeof v === "number" && Number.isFinite(v) && v >= 0)) fail("certificate");
  return value;
}
function validatePhase(problem, phase, active) {
  const system = selected(problem, active), g = gram(system.a, problem.h, "certificate"), rhs = system.b.map((value, i) => checked(value - dot2(system.a[i], problem.y0, "certificate"), "certificate"));
  const norm2 = normInf(g, "certificate"), condition = checked(norm2 * normInf(phase.inverse, "certificate"), "certificate");
  if (!Object.is(norm2, phase.normInf) || !Object.is(condition, phase.conditionInf) || condition > 1e12 || phase.pivots.some((value) => Math.abs(value) <= 1e-12 * Math.max(1, norm2))) fail("certificate");
  const residuals = phaseResiduals(g, rhs, phase.lambda, phase.inverse, "certificate");
  if (residuals.linear > GATE || residuals.inverse > GATE || !Object.is(residuals.linear, phase.residuals.linear) || !Object.is(residuals.inverse, phase.residuals.inverse)) fail("certificate");
  const y = fromLambda(problem, system.a, phase.lambda, "certificate");
  if (y.some((v, i) => !Object.is(v, phase.y[i]))) fail("certificate");
}
function validateVelocityCertificate(problemValue, resultValue) {
  const problem = readProblem(problemValue);
  safeReciprocals(problem);
  if (!exactFields(resultValue, ["y", "lambda", "activeStop", "identity", "solveAttempts", "phases", "objectiveDimensionless", "certificate"]) || typeof resultValue.activeStop !== "boolean" || typeof resultValue.identity !== "boolean" || !dense(resultValue.y, 12) || !dense(resultValue.lambda, resultValue.activeStop ? 12 : 11) || typeof resultValue.objectiveDimensionless !== "number" || !Number.isFinite(resultValue.objectiveDimensionless) || !Number.isInteger(resultValue.solveAttempts) || !Array.isArray(resultValue.phases) || Object.getPrototypeOf(resultValue.phases) !== Array.prototype || Reflect.ownKeys(resultValue.phases).length !== resultValue.phases.length + 1 || !Array.from({ length: resultValue.phases.length }, (_, i) => i).every((i) => Object.hasOwn(resultValue.phases, i)) || !exactFields(resultValue.certificate, ["primal", "stationarity", "negativeMu", "complementarity", "objective"]) || Object.values(resultValue.certificate).some((v) => typeof v !== "number" || !Number.isFinite(v) || v < 0)) fail("certificate");
  const result = resultValue, identity2 = exactIdentity(problem);
  if (result.identity !== identity2 || result.phases.length !== result.solveAttempts) fail("certificate");
  if (identity2) {
    if (result.solveAttempts !== 0 || result.activeStop || result.lambda.some((value) => value !== 0) || result.y.some((value, j) => !Object.is(value, problem.y0[j]))) fail("certificate");
  } else {
    if (result.solveAttempts !== 1 && result.solveAttempts !== 2) fail("certificate");
    const equality2 = readPhase(result.phases[0], 11);
    validatePhase(problem, equality2, false);
    const active = problem.stopKind !== "none" && dot2(problem.stopRow, equality2.y, "certificate") > 0;
    if (result.activeStop !== active || result.solveAttempts !== (active ? 2 : 1)) fail("certificate");
    if (active) validatePhase(problem, readPhase(result.phases[1], 12), true);
    const final = result.phases[result.phases.length - 1];
    if (result.y.some((value, j) => !Object.is(value, final.y[j])) || result.lambda.some((value, i) => !Object.is(value, final.lambda[i]))) fail("certificate");
  }
  const computed = certificate(problem, result);
  for (const key of Object.keys(computed)) if (Math.abs(computed[key] - result.certificate[key]) > GATE) fail("certificate");
  return { ...computed };
}
function solveDimensionlessVelocity(value) {
  const problem = readProblem(value);
  safeReciprocals(problem);
  const identity2 = exactIdentity(problem);
  let phases = [], activeStop = false, y, lambda;
  if (identity2) {
    y = [...problem.y0];
    lambda = Array(11).fill(0);
  } else {
    phases = [solvePhase(problem, false)];
    activeStop = problem.stopKind !== "none" && dot2(problem.stopRow, phases[0].y) > 0;
    if (activeStop) phases.push(solvePhase(problem, true));
    const final = phases[phases.length - 1];
    y = [...final.y];
    lambda = [...final.lambda];
  }
  const result = { y, lambda, activeStop, identity: identity2, solveAttempts: phases.length, phases, objectiveDimensionless: objective(problem, y), certificate: { primal: 0, stationarity: 0, negativeMu: 0, complementarity: 0, objective: 0 } };
  result.certificate = certificate(problem, result);
  validateVelocityCertificate(problem, result);
  return structuredClone(result);
}

// src/disjoint-hinge/projection.ts
function projectHingePoseVelocity(input) {
  const beforeBodies = input.bodies.map(copyBody);
  const originalOriginM = [...input.pair.originM];
  const before = measureBodies(beforeBodies, input.pair.joint, originalOriginM);
  const pose = projectCoupledHinge(input);
  const bodies = pose.bodies.map(copyBody), rows = makeRows(beforeBodies, bodies, input.pair.joint, before, originalOriginM, pose.poseReport.targetAngleRad);
  const result = solveDimensionlessVelocity(rows.problem);
  if (!result.identity) {
    for (let i = 0; i < 2; i++) {
      bodies[i].velocityMps = result.y.slice(i * 6, i * 6 + 3).map((value, j) => value * rows.columnScales[i * 6 + j]);
      bodies[i].angularVelocityRadps = result.y.slice(i * 6 + 3, i * 6 + 6).map((value, j) => value * rows.columnScales[i * 6 + 3 + j]);
    }
  }
  validateResult(bodies, []);
  const after = measureBodies(bodies, input.pair.joint, originalOriginM);
  const velocityCorrections = { linearMps: bodies.map((body, i) => sub(body.velocityMps, beforeBodies[i].velocityMps)), angularRadps: bodies.map((body, i) => sub(body.angularVelocityRadps, beforeBodies[i].angularVelocityRadps)) };
  const changedComponents = bodies.map((body, i) => [...body.velocityMps, ...body.angularVelocityRadps].map((value, j) => !Object.is(value, [...beforeBodies[i].velocityMps, ...beforeBodies[i].angularVelocityRadps][j])));
  const identityVelocityBitsPreserved = result.identity && changedComponents.every((row) => row.every((changed) => !changed));
  const finalX = bodies.flatMap((body) => [...body.velocityMps, ...body.angularVelocityRadps]);
  let sum = 0;
  for (let j = 0; j < 12; j++) {
    const delta = finalX[j] - rows.physicalX0[j];
    sum += rows.physicalH[j] * (delta * delta);
  }
  const objectiveJ = 0.5 * sum;
  const physicalLambda = result.lambda.map((value, i) => 1 * value / (i === 11 ? 10 : rows.rowDivisors[i]));
  const projection = {
    dofOrder: rows.dofOrder,
    rowIds: result.activeStop ? [...rows.rowIds, `stop.${rows.stopKind}`] : rows.rowIds,
    physicalA: rows.physicalA,
    physicalB: rows.physicalB,
    physicalH: rows.physicalH,
    physicalX0: rows.physicalX0,
    columnScales: rows.columnScales,
    rowDivisors: rows.rowDivisors,
    dimensionlessA: rows.dimensionlessA,
    dimensionlessB: rows.dimensionlessB,
    dimensionlessH: rows.dimensionlessH,
    dimensionlessX0: rows.dimensionlessX0,
    centerOfMassOriginM: rows.centerOfMassOriginM,
    originalOriginM: rows.originalOriginM,
    stopKind: rows.stopKind,
    physicalStopRow: rows.physicalStopRow,
    dimensionlessStopRow: rows.dimensionlessStopRow,
    result,
    physicalLambda,
    objectiveJ,
    rankSufficientMarginKgM2: rows.rankSufficientMarginKgM2
  };
  const diagnostics = { poseStage: pose.diagnostics, before, after, velocityCorrections, projection, changedComponents, identityVelocityBitsPreserved, poseLawEvaluations: 1, sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds };
  if (!finiteData(diagnostics) || !finiteData(pose.poseReport) || objectiveJ < 0 || result.identity && !identityVelocityBitsPreserved) fail("result");
  return { bodies: bodies.map(copyBody), poseReport: structuredClone(pose.poseReport), diagnostics: structuredClone(diagnostics) };
}

// src/disjoint-hinge/report.ts
var REPORT_KEYS = ["id", "kind", "aId", "bId", "angleRad", "linearImpulseNs", "angularImpulseNms", "motorImpulseNms"];
var nonempty = (value) => typeof value === "string" && value.length > 0;
var finite2 = (value) => typeof value === "number" && Number.isFinite(value);
function validateHingeMotorReport(value, identity2) {
  const ids = ownData(identity2, ["id", "aId", "bId"]);
  const report = ownData(value, REPORT_KEYS);
  if (!ids || !nonempty(ids.id) || !nonempty(ids.aId) || !nonempty(ids.bId) || !report || report.id !== ids.id || report.aId !== ids.aId || report.bId !== ids.bId || report.kind !== "hinge" || !finite2(report.angleRad) || !finite2(report.motorImpulseNms)) reactionError();
  const linear = denseNumbers(report.linearImpulseNs, 3), angular = denseNumbers(report.angularImpulseNms, 3);
  if (!linear || !angular) reactionError();
  return {
    id: ids.id,
    kind: "hinge",
    aId: ids.aId,
    bId: ids.bId,
    angleRad: report.angleRad,
    linearImpulseNs: linear,
    angularImpulseNms: angular,
    motorImpulseNms: report.motorImpulseNms
  };
}
function enforceHingeMotorReactionCap(jointId, angularImpulseNms) {
  const vector3 = denseNumbers(angularImpulseNms, 3);
  if (!nonempty(jointId) || !vector3) reactionError();
  const norm2 = Math.hypot(...vector3);
  if (!Number.isFinite(norm2)) reactionError();
  if (norm2 > 0.01) throw new PhysicsError("NUMERIC_LIMIT", `${jointId} exceeded motor reaction limit`);
}
function bodyCorrections(free, projected) {
  return projected.map((body, i) => ({
    bodyId: body.id,
    linearImpulseNs: scale(sub(body.velocityMps, free[i].velocityMps), 1 / free[i].inverseMass),
    angularImpulseNms: scale(sub(body.angularVelocityRadps, free[i].angularVelocityRadps), free[i].inertiaKgM2)
  }));
}
function makeReport(joint, free, projected, targetAngleRad, motorImpulseNms) {
  const corrections = bodyCorrections(free, projected);
  for (const c of corrections) if (!denseNumbers(c.linearImpulseNs, 3) || !denseNumbers(c.angularImpulseNms, 3)) reactionError();
  const identity2 = { id: joint.id, aId: free[joint.aIndex].id, bId: free[joint.bIndex].id };
  const b2 = corrections[joint.bIndex];
  const jointReport = validateHingeMotorReport({
    ...identity2,
    kind: "hinge",
    angleRad: targetAngleRad,
    linearImpulseNs: [...b2.linearImpulseNs],
    angularImpulseNms: [...b2.angularImpulseNms],
    motorImpulseNms
  }, identity2);
  const angularReactionNormNms = Math.hypot(...b2.angularImpulseNms);
  if (!Number.isFinite(angularReactionNormNms)) reactionError();
  return {
    jointReport,
    bodyCorrections: copyData2(corrections),
    reportCap: { angularReactionNormNms, maxReactionNms: 0.01, exceedsCap: angularReactionNormNms > 0.01 }
  };
}
function reactionError() {
  throw new PhysicsError("NUMERIC_LIMIT", "unsafe joint reaction");
}
function copyData2(value) {
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map((item) => copyData2(item));
  const copied = {};
  for (const key of Object.keys(value)) {
    Object.defineProperty(copied, key, {
      value: copyData2(value[key]),
      enumerable: true,
      configurable: true,
      writable: true
    });
  }
  return copied;
}
function ownData(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return null;
  const actual = Reflect.ownKeys(value);
  if (actual.length !== keys.length || actual.some((k) => typeof k !== "string" || !keys.includes(k))) return null;
  const result = {};
  for (const key of keys) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return null;
    Object.defineProperty(result, key, { value: descriptor.value, enumerable: true, configurable: true, writable: true });
  }
  return result;
}
function denseNumbers(value, length) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length !== length || Reflect.ownKeys(value).length !== length + 1) return null;
  const result = [];
  for (let i = 0; i < length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor) || typeof descriptor.value !== "number" || !Number.isFinite(descriptor.value)) return null;
    result.push(descriptor.value);
  }
  return result;
}

// src/disjoint-hinge/postcontact.ts
function publicBody(body) {
  return {
    id: body.id,
    kind: body.kind,
    shape: copyShape(body.shape),
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    orientation: [...body.orientation],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inertiaKgM2: body.inertiaKgM2
  };
}
function rawHex(bodies) {
  const bytes = new Uint8Array(104 * bodies.length), view = new DataView(bytes.buffer);
  let cursor = 0;
  for (const body of bodies) for (const value of [
    ...body.positionM,
    ...body.velocityMps,
    ...body.orientation,
    ...body.angularVelocityRadps
  ]) {
    view.setFloat64(cursor, value, true);
    cursor += 8;
  }
  return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
}
function projectDisjointPostContact(input) {
  const next = input.bodies.map(copyBody);
  const jointReports = [];
  const bodyCorrections2 = [];
  const reportCaps = [];
  const calls = { projectionCalls: 0, reportCalls: 0 };
  for (const index of [0, 1]) {
    const pair = input.pairs[index];
    const before = [
      copyBody(input.bodies[pair.bodyIndices[0]]),
      copyBody(input.bodies[pair.bodyIndices[1]])
    ];
    calls.projectionCalls++;
    const projected = projectHingePoseVelocity({
      pair,
      bodies: before,
      sourceStepIndex: input.sourceStepIndex,
      sourceTimeSeconds: input.sourceTimeSeconds
    });
    const returned = [copyBody(projected.bodies[0]), copyBody(projected.bodies[1])];
    next[pair.bodyIndices[0]] = returned[0];
    next[pair.bodyIndices[1]] = returned[1];
    calls.reportCalls++;
    const report = makeReport(
      pair.joint,
      before,
      returned,
      projected.poseReport.targetAngleRad,
      input.motorImpulsesNms[index]
    );
    jointReports[pair.jointInputIndex] = report.jointReport;
    bodyCorrections2.push(report.bodyCorrections);
    reportCaps.push(report.reportCap);
  }
  for (const report of jointReports) enforceHingeMotorReactionCap(report.id, report.angularImpulseNms);
  return {
    projectedBodies: next.map(publicBody),
    projectedRawHex: rawHex(next),
    jointReports,
    bodyCorrections: bodyCorrections2,
    reportCaps,
    calls
  };
}

// src/disjoint-hinge/stage.ts
function admitDisjointHingeCommands(pairs, bodies, actions, commandCount) {
  for (const pair of pairs) {
    admitDynamicHingeCommands(
      pair.joint,
      [bodies[pair.bodyIndices[0]], bodies[pair.bodyIndices[1]]],
      actions
    );
  }
  if (commandCount !== 0) error("INVALID_COMMAND", "disjoint hinge profile supports empty commands only");
}
function driveDisjointHingeMotors(pairs, bodies, reports, impulses) {
  for (const pair of pairs) impulses[pair.jointInputIndex] = driveDynamicHingeMotor(
    pair.joint,
    bodies[pair.bodyIndices[0]],
    bodies[pair.bodyIndices[1]],
    reports[pair.jointInputIndex].angleRad
  );
}
function applyDisjointHingePostContact(pairs, bodies, reports, motorImpulses, sourceStepIndex, sourceTimeSeconds) {
  const canonical2 = [
    { ...pairs[0], jointInputIndex: 0 },
    { ...pairs[1], jointInputIndex: 1 }
  ];
  const result = projectDisjointPostContact({
    bodies,
    pairs: canonical2,
    motorImpulsesNms: [motorImpulses[pairs[0].jointInputIndex], motorImpulses[pairs[1].jointInputIndex]],
    sourceStepIndex,
    sourceTimeSeconds
  });
  for (let index = 0; index < bodies.length; index++) {
    const target = bodies[index], returned = result.projectedBodies[index];
    target.positionM = [...returned.positionM];
    target.velocityMps = [...returned.velocityMps];
    target.orientation = [...returned.orientation];
    target.angularVelocityRadps = [...returned.angularVelocityRadps];
  }
  for (const index of [0, 1]) reports[pairs[index].jointInputIndex] = result.jointReports[index];
}

// src/domain/cloth.ts
import { PhysicsError as PhysicsError5 } from "./types.js";

// src/cloth/constraints.ts
function projectDistance(sheet2, constraint) {
  const fixture = CLOTH_PROFILE;
  const { positions: p, inverseMasses: w } = sheet2;
  const { a: a2, b: b2, rest, kind } = constraint;
  const ia = 3 * a2, ib = 3 * b2;
  const x = p[ia] - p[ib], y = p[ia + 1] - p[ib + 1], z = p[ia + 2] - p[ib + 2];
  const length = Math.hypot(x, y, z);
  const weight = w[a2] + w[b2];
  if (length === 0 || weight === 0) return;
  const bend = kind === "bend-distance";
  const compliance = bend ? fixture.bendComplianceMPerN : fixture.stretchComplianceMPerN;
  const alpha = compliance / fixture.dt ** 2;
  const delta = (-(length - rest) - alpha * constraint.lambda) / (weight + alpha);
  constraint.lambda += delta;
  const scaleA = w[a2] * delta / length, scaleB = w[b2] * delta / length;
  p[ia] += scaleA * x;
  p[ia + 1] += scaleA * y;
  p[ia + 2] += scaleA * z;
  p[ib] -= scaleB * x;
  p[ib + 1] -= scaleB * y;
  p[ib + 2] -= scaleB * z;
}
function projectSphere(sheet2) {
  const fixture = CLOTH_PROFILE;
  const { positions: p, inverseMasses: w } = sheet2;
  const [cx, cy, cz] = fixture.sphereCentreM;
  const radius = fixture.sphereRadiusM + fixture.collisionOffsetM;
  for (let i = 0; i < w.length; i++) {
    if (w[i] === 0) continue;
    const j = 3 * i, x = p[j] - cx, y = p[j + 1] - cy, z = p[j + 2] - cz;
    const distance = Math.hypot(x, y, z);
    if (distance >= radius) continue;
    if (distance === 0) {
      p[j] = cx;
      p[j + 1] = cy + radius;
      p[j + 2] = cz;
    } else {
      p[j] = cx + radius * x / distance;
      p[j + 1] = cy + radius * y / distance;
      p[j + 2] = cz + radius * z / distance;
    }
  }
}

// src/cloth/solver.ts
var ClothSolver = class {
  before = new Float64Array(289 * 3);
  decay = Math.exp(-CLOTH_PROFILE.velocityDecayPerSecond * CLOTH_PROFILE.dt);
  step(sheet2, positions, velocities) {
    const p = positions, dt = CLOTH_PROFILE.dt;
    for (let substep = 0; substep < CLOTH_SUBSTEPS; substep++) {
      this.before.set(p);
      for (let i = 0; i < sheet2.inverseMasses.length; i++) {
        if (sheet2.inverseMasses[i] === 0) continue;
        for (let axis = 0; axis < 3; axis++) {
          const j = 3 * i + axis;
          velocities[j] = this.decay * velocities[j] + dt * CLOTH_PROFILE.gravityMps2[axis];
          p[j] += dt * velocities[j];
        }
      }
      for (const constraint of sheet2.constraints) constraint.lambda = 0;
      for (let iteration = 0; iteration < CLOTH_ITERATIONS; iteration++) {
        for (const constraint of sheet2.constraints) projectDistance(sheet2, constraint);
        projectSphere(sheet2);
      }
      for (let j = 0; j < p.length; j++) velocities[j] = (p[j] - this.before[j]) / dt;
    }
  }
};

// src/cloth/metrics.ts
function clothDiagnostics(sheet2) {
  const p = sheet2.positions;
  let maxStructuralExtension = 0, maxStructuralCompression = 0;
  let maxVertexPenetrationM = 0, maxPinDriftM = 0;
  for (const edge of sheet2.constraints) {
    if (edge.kind !== "stretch") continue;
    const length = Math.hypot(...[0, 1, 2].map((axis) => p[3 * edge.a + axis] - p[3 * edge.b + axis]));
    const strain = length / edge.rest - 1;
    maxStructuralExtension = Math.max(maxStructuralExtension, strain);
    maxStructuralCompression = Math.max(maxStructuralCompression, -strain);
  }
  for (let i = 0; i < p.length / 3; i++) {
    const distance = Math.hypot(...[0, 1, 2].map((axis) => p[3 * i + axis] - CLOTH_PROFILE.sphereCentreM[axis]));
    maxVertexPenetrationM = Math.max(
      maxVertexPenetrationM,
      CLOTH_PROFILE.sphereRadiusM + CLOTH_PROFILE.collisionOffsetM - distance
    );
  }
  for (const pin of sheet2.pins) maxPinDriftM = Math.max(
    maxPinDriftM,
    Math.hypot(...[0, 1, 2].map((axis) => p[3 * pin + axis] - sheet2.restPositions[3 * pin + axis]))
  );
  return {
    maxStructuralExtension,
    maxStructuralCompression,
    maxVertexPenetrationM,
    maxPinDriftM,
    totalMassKg: sheet2.totalMassKg
  };
}
function withinClothBounds(positions, velocities, diagnostics) {
  return positions.every((value) => Number.isFinite(value) && Math.abs(value) <= 10) && velocities.every((value) => Number.isFinite(value) && Math.abs(value) <= 1e3) && Object.values(diagnostics).every(Number.isFinite) && diagnostics.maxStructuralExtension <= 0.1 && diagnostics.maxVertexPenetrationM <= 1e-6 && diagnostics.maxPinDriftM === 0;
}

// src/domain/types.ts
import { PhysicsError as PhysicsError4 } from "./types.js";
function invalid(condition, message) {
  if (!condition) throw new PhysicsError4("INVALID_CONFIG", message);
}
function immutableCopy(input) {
  const result = copyData(input);
  function freeze2(value) {
    if (value !== null && typeof value === "object") {
      for (const child of Object.values(value)) freeze2(child);
      Object.freeze(value);
    }
  }
  freeze2(result);
  return result;
}
function flat(points, count) {
  invalid(points.length === count, "Unexpected domain point count");
  invalid(points.every((p) => p.length === 3 && p.every(Number.isFinite)), "Expected finite domain triples");
  return new Float64Array(points.flat());
}
function validateStatic(data2, colliderIds) {
  invalid(data2.gravityMps2.length === 3 && data2.gravityMps2.every((x, i) => x === [0, -9.81, 0][i]), "Unsupported domain gravity");
  invalid(new Set(colliderIds).size === colliderIds.length && data2.colliders.length === colliderIds.length, "Static collider population mismatch");
  invalid(data2.bodies.length === data2.colliders.length, "Static owner population mismatch");
  const ids = /* @__PURE__ */ new Set();
  const owners = /* @__PURE__ */ new Set();
  for (const c of data2.colliders) {
    invalid(colliderIds.includes(c.id) && !ids.has(c.id), "Invalid static collider identity");
    ids.add(c.id);
    invalid(!owners.has(c.bodyId), "Duplicate static collider owner");
    owners.add(c.bodyId);
    const b2 = data2.bodies.find((b3) => b3.id === c.bodyId);
    invalid(b2?.kind === "static", "Domain colliders require static bodies");
    invalid(b2.initial.orientationXYZW.every((x, i) => x === (i === 3 ? 1 : 0)), "Unsupported static rotation");
    invalid(c.local.positionM.every((x) => x === 0) && c.local.orientationXYZW.every((x, i) => x === (i === 3 ? 1 : 0)), "Unsupported collider transform");
    invalid(!c.sensor && !c.ccd, "Unsupported domain sensor or CCD");
  }
}

// src/domain/cloth.ts
function sheet(definition, positions) {
  const c = definition.cloth;
  return {
    positions,
    restPositions: flat(c.restPositionsM, 289),
    inverseMasses: Float64Array.from(c.vertexMassesKg, (mass, index) => c.pinnedVertexIndices.includes(index) ? 0 : 1 / mass),
    pins: [...c.pinnedVertexIndices],
    triangles: Uint16Array.from(c.triangles.flat()),
    constraints: c.constraints.map((e) => ({ a: e.a, b: e.b, kind: e.kind, rest: e.restLengthM, lambda: 0 })),
    totalMassKg: c.vertexMassesKg.reduce((sum, mass) => sum + mass, 0)
  };
}
function copyClothCandidateOutput(id, candidate) {
  return {
    id,
    positionsM: candidate.positions.slice(),
    velocitiesMps: candidate.velocities.slice(),
    diagnostics: { ...candidate.diagnostics }
  };
}
function initializeCloth(cloth, staticData) {
  const definition = immutableCopy({ cloth, staticData });
  const c = definition.cloth, data2 = definition.staticData;
  invalid(data2.profile === "cloth-pinned-sphere-visual-v1", "Unsupported cloth profile");
  validateStatic(data2, c.staticColliderIds);
  invalid(c.staticColliderIds.length === 1, "Cloth requires one fixed sphere");
  const collider = data2.colliders[0], body = data2.bodies[0];
  invalid(collider.geometry.kind === "sphere" && collider.geometry.radiusM === CLOTH_PROFILE.sphereRadiusM && body.initial.positionM.every((x, i) => x === CLOTH_PROFILE.sphereCentreM[i]), "Unsupported cloth sphere");
  invalid(c.vertexMassesKg.length === 289 && c.vertexMassesKg.every((m) => Number.isFinite(m) && m > 0), "Invalid cloth masses");
  invalid(c.triangles.length === 512 && c.triangles.every((t) => t.length === 3 && t.every((i) => Number.isInteger(i) && i >= 0 && i < 289)), "Invalid cloth triangles");
  invalid(c.pinnedVertexIndices.length === 2 && c.pinnedVertexIndices[0] === 0 && c.pinnedVertexIndices[1] === 16, "Unsupported pins");
  invalid(c.constraints.length === 1566 && c.constraints.every((e) => Number.isInteger(e.a) && e.a >= 0 && e.a < 289 && Number.isInteger(e.b) && e.b >= 0 && e.b < 289 && e.a !== e.b && Number.isFinite(e.restLengthM) && e.restLengthM > 0 && ["stretch", "shear", "bend-distance"].includes(e.kind) && e.complianceMPerN === (e.kind === "bend-distance" ? CLOTH_PROFILE.bendComplianceMPerN : CLOTH_PROFILE.stretchComplianceMPerN)), "Unsupported cloth constraints");
  const positions = flat(c.initialPositionsM, 289), velocities = flat(c.initialVelocitiesMps, 289);
  invalid(velocities.every((x) => x === 0), "Unsupported initial cloth velocities");
  const initialSheet = sheet(definition, positions);
  invalid(positions.every((x, i) => Object.is(x, initialSheet.restPositions[i])), "Initial cloth must match rest data");
  const diagnostics = clothDiagnostics(initialSheet);
  invalid(withinClothBounds(positions, velocities, diagnostics), "Invalid initial cloth state");
  return { definition, initial: { positions, velocities, constraints: initialSheet.constraints, diagnostics } };
}
function prepareCloth(definition, accepted) {
  const positions = accepted.positions.slice(), velocities = accepted.velocities.slice();
  const candidateSheet = sheet(definition, positions);
  const solver = new ClothSolver();
  solver.step(candidateSheet, positions, velocities);
  const diagnostics = clothDiagnostics(candidateSheet);
  if (!withinClothBounds(positions, velocities, diagnostics)) throw new PhysicsError5("NUMERIC_LIMIT", "Cloth candidate exceeded the fixed profile bounds");
  const candidate = { positions, velocities, constraints: candidateSheet.constraints, diagnostics };
  const output = copyClothCandidateOutput(definition.cloth.id, candidate);
  return { candidate, output };
}

// src/domain/fluid.ts
import { PhysicsError as PhysicsError6 } from "./types.js";

// src/fluid/boundary.ts
function floorSamples() {
  const points = [];
  const xSteps = Math.round(FLUID_BASIN_M[0] / FLUID_SPACING_M);
  const zSteps = Math.round(FLUID_BASIN_M[2] / FLUID_SPACING_M);
  for (const y of [0, -FLUID_SPACING_M]) {
    for (let z = 0; z <= zSteps; z++) {
      for (let x = 0; x <= xSteps; x++) {
        points.push(x * FLUID_SPACING_M, y, z * FLUID_SPACING_M);
      }
    }
  }
  return new Float64Array(points);
}
function confine(positions, velocities, index) {
  let hits = 0;
  const offset = index * 3;
  for (let axis = 0; axis < 3; axis++) {
    const point2 = offset + axis;
    const low = FLUID_PARTICLE_RADIUS_M;
    const high = FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M;
    if (positions[point2] < low || positions[point2] > high) {
      positions[point2] = Math.max(low, Math.min(high, positions[point2]));
      velocities[point2] *= -0.1;
      hits++;
    }
  }
  return hits;
}
function stopOutwardVelocity(positions, velocities, index) {
  const offset = index * 3;
  for (let axis = 0; axis < 3; axis++) {
    const point2 = offset + axis;
    const low = FLUID_PARTICLE_RADIUS_M;
    const high = FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M;
    if (positions[point2] <= low + 1e-9 && velocities[point2] < 0 || positions[point2] >= high - 1e-9 && velocities[point2] > 0) {
      velocities[point2] *= -0.1;
    }
  }
}
function insideBasin(positions) {
  for (let index = 0; index < positions.length / 3; index++) {
    for (let axis = 0; axis < 3; axis++) {
      const value = positions[index * 3 + axis];
      if (!Number.isFinite(value) || value < FLUID_PARTICLE_RADIUS_M - 1e-9 || value > FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M + 1e-9) return false;
    }
  }
  return true;
}

// src/fluid/neighbors.ts
var minimum = [-1, -2, -1];
var size = FLUID_BASIN_M.map((extent, axis) => Math.floor(extent / FLUID_SMOOTHING_RADIUS_M) + 2 - minimum[axis]);
var cellCount = size[0] * size[1] * size[2];
function cellIndex(x, y, z) {
  const gx = x - minimum[0], gy = y - minimum[1], gz = z - minimum[2];
  if (gx < 0 || gx >= size[0] || gy < 0 || gy >= size[1] || gz < 0 || gz >= size[2]) return -1;
  return (gz * size[1] + gy) * size[0] + gx;
}
var NeighborGrid = class {
  head = new Int32Array(cellCount);
  tail = new Int32Array(cellCount);
  next = new Int32Array(0);
  positions = new Float64Array(0);
  radiusSquared = FLUID_SMOOTHING_RADIUS_M ** 2;
  rebuild(positions) {
    this.positions = positions;
    this.head.fill(-1);
    this.tail.fill(-1);
    const count = positions.length / 3;
    if (this.next.length < count) this.next = new Int32Array(count);
    for (let index = 0; index < count; index++) {
      const offset = index * 3;
      const x = Math.floor(positions[offset] / FLUID_SMOOTHING_RADIUS_M);
      const y = Math.floor(positions[offset + 1] / FLUID_SMOOTHING_RADIUS_M);
      const z = Math.floor(positions[offset + 2] / FLUID_SMOOTHING_RADIUS_M);
      const cell = cellIndex(x, y, z);
      if (cell < 0) throw new Error("Fluid neighbor cell is outside the admitted basin");
      this.next[index] = -1;
      const last = this.tail[cell];
      if (last < 0) this.head[cell] = index;
      else this.next[last] = index;
      this.tail[cell] = index;
    }
  }
  each(index, visit) {
    const offset = index * 3;
    const cx = Math.floor(this.positions[offset] / FLUID_SMOOTHING_RADIUS_M);
    const cy = Math.floor(this.positions[offset + 1] / FLUID_SMOOTHING_RADIUS_M);
    const cz = Math.floor(this.positions[offset + 2] / FLUID_SMOOTHING_RADIUS_M);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const cell = cellIndex(cx + dx, cy + dy, cz + dz);
          if (cell < 0) continue;
          for (let other = this.head[cell]; other >= 0; other = this.next[other]) {
            const otherOffset = other * 3;
            const rx = this.positions[offset] - this.positions[otherOffset];
            const ry = this.positions[offset + 1] - this.positions[otherOffset + 1];
            const rz = this.positions[offset + 2] - this.positions[otherOffset + 2];
            const distanceSquared = rx * rx + ry * ry + rz * rz;
            if (distanceSquared < this.radiusSquared) visit(other, rx, ry, rz, distanceSquared);
          }
        }
      }
    }
  }
};

// src/fluid/kernel.ts
var radiusSquared = FLUID_SMOOTHING_RADIUS_M ** 2;
function densityKernel(distanceSquared) {
  const q = 1 - distanceSquared / radiusSquared;
  return q > 0 ? q * q * q : 0;
}
function gradientScale(distanceSquared) {
  const q = 1 - distanceSquared / radiusSquared;
  return q > 0 ? -6 * q * q / radiusSquared : 0;
}
function densities(positions, grid, output) {
  grid.rebuild(positions);
  for (let index = 0; index < output.length; index++) {
    let density = 0;
    grid.each(index, (_other, _x, _y, _z, distanceSquared) => {
      density += densityKernel(distanceSquared);
    });
    output[index] = density;
  }
}
function initialRestDensity(positions) {
  const count = positions.length / 3;
  const result = new Float64Array(count);
  densities(positions, new NeighborGrid(), result);
  return result.reduce((sum, density) => sum + density, 0) / count;
}

// src/fluid/visual-viscosity.ts
function blendVisualViscosity(positions, velocities, grid, output, coefficient) {
  grid.rebuild(positions);
  for (let index = 0; index < FLUID_COUNT; index++) {
    const offset = index * 3;
    let weightSum = 0;
    let vx = 0, vy = 0, vz = 0;
    grid.each(index, (other, _rx, _ry, _rz, distanceSquared) => {
      const weight = densityKernel(distanceSquared);
      const otherOffset = other * 3;
      weightSum += weight;
      vx += weight * velocities[otherOffset];
      vy += weight * velocities[otherOffset + 1];
      vz += weight * velocities[otherOffset + 2];
    });
    const blend = weightSum > 0 ? coefficient / weightSum : 0;
    output[offset] = velocities[offset] + blend * (vx - weightSum * velocities[offset]);
    output[offset + 1] = velocities[offset + 1] + blend * (vy - weightSum * velocities[offset + 1]);
    output[offset + 2] = velocities[offset + 2] + blend * (vz - weightSum * velocities[offset + 2]);
  }
  velocities.set(output);
}

// src/fluid/pbf.ts
var PbfSolver = class {
  constructor(restDensity, visualViscosityCoefficient, staticBox = null) {
    this.restDensity = restDensity;
    this.visualViscosityCoefficient = visualViscosityCoefficient;
    this.staticBox = staticBox;
    this.smoothedVelocities = visualViscosityCoefficient > 0 ? new Float64Array(FLUID_COUNT * 3) : null;
    const floor2 = floorSamples();
    this.combined = new Float64Array(this.predicted.length + floor2.length);
    this.combined.set(floor2, this.predicted.length);
  }
  grid = new NeighborGrid();
  predicted = new Float64Array(FLUID_COUNT * 3);
  combined;
  density = new Float64Array(FLUID_COUNT);
  lambda = new Float64Array(FLUID_COUNT);
  corrections = new Float64Array(FLUID_COUNT * 3);
  smoothedVelocities;
  obstacleHits = 0;
  projectDensity(velocities) {
    this.combined.set(this.predicted);
    densities(this.combined, this.grid, this.density);
    for (let index = 0; index < FLUID_COUNT; index++) {
      const compression = Math.max(0, this.density[index] / this.restDensity - 1);
      if (compression === 0) {
        this.lambda[index] = 0;
        continue;
      }
      let ownX = 0, ownY = 0, ownZ = 0, gradientSum = 0;
      this.grid.each(index, (other, rx, ry, rz, distanceSquared) => {
        if (other === index) return;
        const scale4 = gradientScale(distanceSquared) / this.restDensity;
        const gx = scale4 * rx, gy = scale4 * ry, gz = scale4 * rz;
        ownX += gx;
        ownY += gy;
        ownZ += gz;
        gradientSum += gx * gx + gy * gy + gz * gz;
      });
      gradientSum += ownX * ownX + ownY * ownY + ownZ * ownZ;
      this.lambda[index] = -compression / (gradientSum + 0.01);
    }
    for (let index = 0; index < FLUID_COUNT; index++) {
      const offset = index * 3;
      let dx = 0, dy = 0, dz = 0;
      this.grid.each(index, (other, rx, ry, rz, distanceSquared) => {
        if (other === index) return;
        const scale4 = (this.lambda[index] + (other < FLUID_COUNT ? this.lambda[other] : 0)) * gradientScale(distanceSquared) / this.restDensity;
        dx += scale4 * rx;
        dy += scale4 * ry;
        dz += scale4 * rz;
      });
      const length = Math.hypot(dx, dy, dz);
      const limit = length > FLUID_SPACING_M * 0.25 ? FLUID_SPACING_M * 0.25 / length : 1;
      this.corrections[offset] = dx * limit;
      this.corrections[offset + 1] = dy * limit;
      this.corrections[offset + 2] = dz * limit;
    }
    let boundaryHits = 0;
    for (let index = 0; index < FLUID_COUNT; index++) {
      const offset = index * 3;
      for (let axis = 0; axis < 3; axis++) {
        this.predicted[offset + axis] += this.corrections[offset + axis];
      }
      boundaryHits += confine(this.predicted, velocities, index);
      if (this.staticBox) {
        this.obstacleHits += confineStaticBox(this.predicted, velocities, index, this.staticBox);
      }
    }
    return boundaryHits;
  }
  step(positions, velocities) {
    let boundaryHits = 0;
    this.obstacleHits = 0;
    for (let index = 0; index < FLUID_COUNT; index++) {
      const offset = index * 3;
      velocities[offset + 1] += FLUID_STEP_SECONDS * FLUID_GRAVITY_MPS2[1];
      for (let axis = 0; axis < 3; axis++) {
        velocities[offset + axis] *= 0.998;
        this.predicted[offset + axis] = positions[offset + axis] + FLUID_STEP_SECONDS * velocities[offset + axis];
      }
      boundaryHits += confine(this.predicted, velocities, index);
      if (this.staticBox) {
        this.obstacleHits += confineStaticBox(this.predicted, velocities, index, this.staticBox);
      }
    }
    for (let iteration = 0; iteration < 3; iteration++) {
      boundaryHits += this.projectDensity(velocities);
    }
    for (let index = 0; index < FLUID_COUNT; index++) {
      const offset = index * 3;
      for (let axis = 0; axis < 3; axis++) {
        velocities[offset + axis] = (this.predicted[offset + axis] - positions[offset + axis]) / FLUID_STEP_SECONDS;
        positions[offset + axis] = this.predicted[offset + axis];
      }
    }
    if (this.smoothedVelocities) {
      blendVisualViscosity(
        positions,
        velocities,
        this.grid,
        this.smoothedVelocities,
        this.visualViscosityCoefficient
      );
    }
    for (let index = 0; index < FLUID_COUNT; index++) {
      stopOutwardVelocity(positions, velocities, index);
      if (this.staticBox) stopIntoStaticBox(positions, velocities, index, this.staticBox);
    }
    return { boundaryHits, obstacleHits: this.obstacleHits };
  }
};

// src/fluid/diagnostics.ts
var floor = floorSamples();
function fluidDiagnostics(positions, restDensity, boundaryHits) {
  const combined = new Float64Array(positions.length + floor.length);
  combined.set(positions);
  combined.set(floor, positions.length);
  const density = new Float64Array(FLUID_COUNT);
  densities(combined, new NeighborGrid(), density);
  let absoluteError = 0;
  const compressions = new Array(FLUID_COUNT);
  for (let index = 0; index < FLUID_COUNT; index++) {
    const difference = density[index] / restDensity - 1;
    absoluteError += Math.abs(difference);
    compressions[index] = Math.max(0, difference);
  }
  compressions.sort((a2, b2) => a2 - b2);
  return {
    meanAbsoluteDensityError: absoluteError / FLUID_COUNT,
    p95Compression: compressions[Math.ceil(0.95 * FLUID_COUNT) - 1],
    boundaryHits
  };
}

// src/domain/fluid.ts
function copyFluidCandidateOutput(id, candidate) {
  return { id, positionsM: candidate.positions.slice(), velocitiesMps: candidate.velocities.slice(), diagnostics: { ...candidate.diagnostics } };
}
function initializeFluid(fluid, staticData) {
  const copied = immutableCopy({ fluid, staticData }), f = copied.fluid, data2 = copied.staticData;
  invalid(["fluid-basin-visual-v1", "fluid-basin-xsph-visual-v1", "fluid-static-box-visual-v1"].includes(data2.profile), "Unsupported fluid profile");
  validateStatic(data2, f.staticColliderIds);
  invalid(f.massModel.kind === "visual-unit-weights" && f.particleRadiusM === FLUID_PARTICLE_RADIUS_M && f.smoothingRadiusM === FLUID_SMOOTHING_RADIUS_M, "Unsupported fluid mass or radii");
  const xsph = data2.profile === "fluid-basin-xsph-visual-v1", boxProfile = data2.profile === "fluid-static-box-visual-v1";
  invalid(xsph ? f.visualSmoothing.kind === "xsph" && f.visualSmoothing.coefficient === 0.15 : f.visualSmoothing.kind === "none", "Unsupported smoothing");
  invalid(data2.colliders.length === (boxProfile ? 2 : 1), "Unsupported static fluid collider population");
  const basin = data2.colliders.find((c) => c.geometry.kind === "box-interior");
  invalid(basin?.geometry.kind === "box-interior", "Fluid requires basin");
  const basinBody = data2.bodies.find((b2) => b2.id === basin.bodyId);
  invalid(basin.geometry.halfExtentsM.every((x, i) => x === FLUID_BASIN_M[i] / 2) && basinBody.initial.positionM.every((x, i) => x === FLUID_BASIN_M[i] / 2), "Unsupported basin");
  const positions = flat(f.initialPositionsM, 256), velocities = flat(f.initialVelocitiesMps, 256);
  invalid(velocities.every((x) => x === 0) && insideBasin(positions), "Invalid initial fluid state");
  const minimumSquared = FLUID_MIN_SPACING_M ** 2;
  for (let first = 0; first < 256; first++) for (let second = first + 1; second < 256; second++) {
    const dx = positions[first * 3] - positions[second * 3], dy = positions[first * 3 + 1] - positions[second * 3 + 1], dz = positions[first * 3 + 2] - positions[second * 3 + 2];
    invalid(dx * dx + dy * dy + dz * dz >= minimumSquared - 1e-12, "Initial particles must be at least 0.025 m apart");
  }
  let staticBox = null;
  if (boxProfile) {
    const collider = data2.colliders.find((c) => c.geometry.kind === "box");
    invalid(collider?.geometry.kind === "box", "Static fluid profile requires box");
    const body = data2.bodies.find((b2) => b2.id === collider.bodyId);
    staticBox = inflatedBoxBounds(body.initial.positionM, collider.geometry.halfExtentsM);
    invalid(staticBox.low.every((x, i) => x >= FLUID_PARTICLE_RADIUS_M && staticBox.high[i] <= FLUID_BASIN_M[i] - FLUID_PARTICLE_RADIUS_M), "Static box exceeds basin");
    invalid(!insideStaticBox(positions, staticBox), "Static box overlaps initial particles");
  }
  const restDensity = initialRestDensity(positions);
  const definition = immutableCopy({ ...copied, restDensity, staticBox });
  const diagnostics = { ...fluidDiagnostics(positions, restDensity, 0), obstacleHits: 0 };
  return { definition, initial: { positions, velocities, diagnostics } };
}
function prepareFluid(definition, accepted) {
  const positions = accepted.positions.slice(), velocities = accepted.velocities.slice();
  const coefficient = definition.fluid.visualSmoothing.kind === "xsph" ? definition.fluid.visualSmoothing.coefficient : 0;
  const solver = new PbfSolver(definition.restDensity, coefficient, definition.staticBox);
  const { boundaryHits, obstacleHits } = solver.step(positions, velocities);
  if (!insideBasin(positions) || !velocities.every((x) => Number.isFinite(x) && Math.abs(x) <= 1e3)) throw new PhysicsError6("NUMERIC_LIMIT", "Fluid candidate exceeded numeric bounds");
  const measured = fluidDiagnostics(positions, definition.restDensity, boundaryHits);
  if (!Number.isFinite(measured.meanAbsoluteDensityError) || !Number.isFinite(measured.p95Compression)) throw new PhysicsError6("NUMERIC_LIMIT", "Fluid candidate density is not finite");
  const candidate = { positions, velocities, diagnostics: { ...measured, obstacleHits } };
  const output = copyFluidCandidateOutput(definition.fluid.id, candidate);
  return { candidate, output };
}

// src/rotation-validation.ts
function validateRotationResult(result, dt) {
  if (result.angularVelocityRadps.some((value) => !Number.isFinite(value) || Math.abs(value) > 1e3) || !Number.isFinite(dt) || dt <= 0 || Math.hypot(...result.angularVelocityRadps) * dt > 10) {
    error("NUMERIC_LIMIT", "free rotation exceeded angular movement limit");
  }
  if (result.orientation.some((value) => !Number.isFinite(value)) || Math.abs(Math.hypot(...result.orientation) - 1) > 1e-12) {
    error("NUMERIC_LIMIT", "free rotation orientation exceeded tolerance");
  }
}

// src/rigid-free-rotation.ts
var exponents = Object.freeze([3, 5, 7]);
var roots = Object.freeze(exponents.map((exponent) => {
  return Math.pow(2, 1 / exponent);
}));
var a = Object.freeze(roots.map((root) => 1 / (2 - root)));
var b = Object.freeze(a.map((value) => 1 - 2 * value));
var expanded = [1];
for (let level = 0; level < 3; level++) {
  expanded = [
    ...expanded.map((value) => a[level] * value),
    ...expanded.map((value) => b[level] * value),
    ...expanded.map((value) => a[level] * value)
  ];
}
var triaxialFreeRotationCoefficients = Object.freeze({
  exponents,
  roots,
  a,
  b,
  weights: Object.freeze(expanded)
});
var ROUNDING_UNIT = 2 ** -52;
var unitVectorBound = (value) => value.every((component) => Number.isFinite(component) && Math.abs(component) <= 1);
var maximumComponent = (value) => Math.max(Math.abs(value[0]), Math.abs(value[1]), Math.abs(value[2]));
function field(p, diagonal) {
  return [
    (diagonal[2] - diagonal[1]) * p[1] * p[2],
    (diagonal[0] - diagonal[2]) * p[2] * p[0],
    (diagonal[1] - diagonal[0]) * p[0] * p[1]
  ];
}
function derivative(p, diagonal) {
  return [
    [0, (diagonal[2] - diagonal[1]) * p[2], (diagonal[2] - diagonal[1]) * p[1]],
    [(diagonal[0] - diagonal[2]) * p[2], 0, (diagonal[0] - diagonal[2]) * p[0]],
    [(diagonal[1] - diagonal[0]) * p[1], (diagonal[1] - diagonal[0]) * p[0], 0]
  ];
}
function linearSolve(matrix3, right) {
  const rows = matrix3.map((row, index) => [...row, right[index]]);
  for (let column = 0; column < 3; column++) {
    let selected2 = column;
    for (let row = column + 1; row < 3; row++) {
      if (Math.abs(rows[row][column]) > Math.abs(rows[selected2][column])) selected2 = row;
    }
    if (selected2 !== column) [rows[selected2], rows[column]] = [rows[column], rows[selected2]];
    const selectedPivot = rows[column][column];
    const pivotMagnitude = Math.abs(selectedPivot);
    if (!Number.isFinite(selectedPivot) || pivotMagnitude < 1 / 4) {
      error("NUMERIC_LIMIT", "triaxial midpoint pivot outside qualified bound");
    }
    for (let row = column + 1; row < 3; row++) {
      const multiplier = rows[row][column] / selectedPivot;
      rows[row][column] = 0;
      for (let entry = column + 1; entry < 4; entry++) rows[row][entry] -= multiplier * rows[column][entry];
    }
  }
  const result = [0, 0, 0];
  for (let row = 2; row >= 0; row--) {
    let total = rows[row][3];
    for (let column = row + 1; column < 3; column++) total -= rows[row][column] * result[column];
    result[row] = total / rows[row][row];
  }
  if (!result.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite triaxial midpoint correction");
  const residual = matrix3.map((row, index) => row.reduce((sum, value, column) => sum + value * result[column], 0) - right[index]);
  const matrixNorm = Math.max(...matrix3.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0)));
  const residualMaximum = maximumComponent(residual);
  const residualScale = Math.max(1, matrixNorm * maximumComponent(result) + maximumComponent(right));
  const residualBound = 64 * ROUNDING_UNIT * residualScale;
  if (!Number.isFinite(residualMaximum) || !Number.isFinite(residualBound) || residualMaximum > residualBound) {
    error("NUMERIC_LIMIT", "triaxial linear correction residual outside qualified bound");
  }
  return { value: result, residualMaximum, residualBound };
}
function midpoint(p0, diagonal, signedStep) {
  if (!Number.isFinite(signedStep) || !unitVectorBound(p0)) {
    error("NUMERIC_LIMIT", "triaxial midpoint initial iterate outside bound");
  }
  const initialField = field(p0, diagonal);
  let guess = p0.map((value, index) => value + signedStep * initialField[index]);
  if (!unitVectorBound(guess)) error("NUMERIC_LIMIT", "triaxial midpoint predictor outside bound");
  for (let update = 0; update < 4; update++) {
    const middle2 = p0.map((value, index) => (value + guess[index]) / 2);
    const velocity2 = field(middle2, diagonal);
    const residual2 = guess.map((value, index) => value - p0[index] - signedStep * velocity2[index]);
    const jacobianField = derivative(middle2, diagonal);
    const perturbation = maximumComponent(jacobianField.map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
    if (!unitVectorBound(middle2) || !Number.isFinite(perturbation) || perturbation > 1 / 4) {
      error("NUMERIC_LIMIT", "triaxial midpoint Jacobian outside qualified bound");
    }
    const jacobian = jacobianField.map((row, i) => row.map((value, j) => (i === j ? 1 : 0) - signedStep * value / 2));
    const linearResult = linearSolve(jacobian, residual2.map((value) => -value));
    const correction = linearResult.value;
    const linearResidualMaximum = linearResult.residualMaximum;
    const linearResidualBound = linearResult.residualBound;
    guess = guess.map((value, index) => value + correction[index]);
    if (!unitVectorBound(guess)) error("NUMERIC_LIMIT", "triaxial midpoint update outside bound");
  }
  const middle = p0.map((value, index) => (value + guess[index]) / 2);
  const velocity = field(middle, diagonal);
  const residual = guess.map((value, index) => value - p0[index] - signedStep * velocity[index]);
  const residualMaximum = maximumComponent(residual);
  const residualScale = Math.max(
    1,
    maximumComponent(p0),
    maximumComponent(guess),
    maximumComponent(velocity.map((value) => signedStep * value))
  );
  const residualBound = 64 * ROUNDING_UNIT * residualScale;
  const finalPerturbation = maximumComponent(derivative(middle, diagonal).map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
  if (!unitVectorBound(middle) || !Number.isFinite(residualMaximum) || !Number.isFinite(finalPerturbation) || finalPerturbation > 1 / 4 || residualMaximum > residualBound) {
    error("NUMERIC_LIMIT", "triaxial midpoint residual outside qualified bound");
  }
  return { p: guess, omegaMid: middle.map((value, index) => value * diagonal[index]) };
}
function prepareFreeRotation(body, dt) {
  if (body.kind !== "dynamic") return null;
  const moments = body.inertiaDiagonalKgM2 ?? [body.inertiaKgM2, body.inertiaKgM2, body.inertiaKgM2];
  if (!moments.every((value) => Number.isFinite(value) && value > 0) || !Number.isFinite(dt) || dt <= 0) {
    error("NUMERIC_LIMIT", "triaxial flow outside qualified time/inertia bounds");
  }
  if (moments[0] === moments[1] && moments[1] === moments[2]) return null;
  if (body.angularVelocityRadps.every((value) => value === 0)) {
    return { orientation: [...body.orientation], angularVelocityRadps: [...body.angularVelocityRadps] };
  }
  const magnitude2 = Math.hypot(...body.orientation);
  if (!Number.isFinite(magnitude2) || magnitude2 === 0) error("NUMERIC_LIMIT", "invalid triaxial orientation");
  let orientation = body.orientation.map((value) => value / magnitude2);
  const localOmega = rotate2(inverse(orientation), body.angularVelocityRadps);
  if (!localOmega.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite triaxial body spin");
  const momentum2 = localOmega.map((value, index) => moments[index] * value);
  const momentumNorm = Math.hypot(...momentum2);
  const momentumScale = 2 * momentumNorm;
  if (!momentum2.every(Number.isFinite) || !Number.isFinite(momentumScale) || momentumNorm === 0) {
    error("NUMERIC_LIMIT", "free rotation momentum outside finite range");
  }
  if (localOmega.filter((value) => value !== 0).length === 1) {
    return {
      orientation: advanceOrientation(orientation, body.angularVelocityRadps, dt),
      angularVelocityRadps: [...body.angularVelocityRadps]
    };
  }
  const diagonal = moments.map((value) => momentumScale / value);
  let p = momentum2.map((value) => value / momentumScale);
  if (!diagonal.every(Number.isFinite) || Math.hypot(...p) > 1 / 2 + 4 * ROUNDING_UNIT) {
    error("NUMERIC_LIMIT", "free rotation scaled momentum outside bound");
  }
  const maximumDifference = Math.max(
    Math.abs(diagonal[2] - diagonal[1]),
    Math.abs(diagonal[0] - diagonal[2]),
    Math.abs(diagonal[1] - diagonal[0])
  );
  const maximumWeight = Math.max(...triaxialFreeRotationCoefficients.weights.map(Math.abs));
  const subdivisions = Math.max(1, Math.ceil(4 * maximumWeight * dt * maximumDifference));
  if (!Number.isFinite(subdivisions) || subdivisions > 64) {
    error("NUMERIC_LIMIT", "free rotation exceeded internal subdivision limit");
  }
  for (let subdivision = 0; subdivision < subdivisions; subdivision++) {
    for (let stage = 0; stage < 27; stage++) {
      const weight = triaxialFreeRotationCoefficients.weights[stage];
      if (!Number.isFinite(weight) || Math.abs(weight) >= 3) error("NUMERIC_LIMIT", "invalid triaxial composition coefficient");
      const signedStep = weight * (dt / subdivisions);
      const prepared = midpoint(p, diagonal, signedStep);
      const vector3 = prepared.omegaMid.map((value) => signedStep * value / 2);
      const deltaNorm = Math.hypot(...vector3, 1);
      if (!Number.isFinite(deltaNorm) || deltaNorm === 0) error("NUMERIC_LIMIT", "invalid Cayley increment");
      const delta = [vector3[0] / deltaNorm, vector3[1] / deltaNorm, vector3[2] / deltaNorm, 1 / deltaNorm];
      const composed = multiplyQuaternion(orientation, delta);
      const composedNorm = Math.hypot(...composed);
      if (!Number.isFinite(composedNorm) || composedNorm === 0) error("NUMERIC_LIMIT", "nonfinite Cayley orientation");
      orientation = composed.map((value) => value / composedNorm);
      p = prepared.p;
    }
  }
  const angularVelocityRadps = rotate2(orientation, p.map((value, index) => value * diagonal[index]));
  return { orientation, angularVelocityRadps };
}

// src/rigid-forced-rotation.ts
function rotation(q) {
  const [x, y, z, w] = q;
  const n = x * x + y * y + z * z + w * w;
  if (!q.every(Number.isFinite) || !Number.isFinite(n) || n <= 0) {
    error("NUMERIC_LIMIT", "invalid forced stage quaternion");
  }
  return [
    [(w * w + x * x - y * y - z * z) / n, 2 * (x * y - z * w) / n, 2 * (x * z + y * w) / n],
    [2 * (x * y + z * w) / n, (w * w - x * x + y * y - z * z) / n, 2 * (y * z - x * w) / n],
    [2 * (x * z - y * w) / n, 2 * (y * z + x * w) / n, (w * w - x * x - y * y + z * z) / n]
  ];
}
function product(r, v, transpose = false) {
  return [0, 1, 2].map((i) => [0, 1, 2].reduce((s, j) => s + (transpose ? r[j][i] : r[i][j]) * v[j], 0));
}
function movement(omega, dt) {
  if (omega.some((x) => !Number.isFinite(x) || Math.abs(x) > 1e3) || Math.hypot(...omega) * dt > 10) {
    error("NUMERIC_LIMIT", "forced rotation exceeded angular movement limit");
  }
}
function prepareForcedRotation(body, dt, torque) {
  if (body.kind !== "dynamic" || torque.every((x) => x === 0)) return null;
  const moments = body.inertiaDiagonalKgM2 ?? [body.inertiaKgM2, body.inertiaKgM2, body.inertiaKgM2];
  if (!moments.every((x) => Number.isFinite(x) && x > 0) || !Number.isFinite(dt) || dt <= 0 || !torque.every(Number.isFinite)) {
    error("NUMERIC_LIMIT", "forced rotation outside finite time/inertia/load bounds");
  }
  movement(body.angularVelocityRadps, dt);
  const r0 = rotation(body.orientation);
  const localOmega = product(r0, body.angularVelocityRadps, true);
  const momentum2 = product(r0, localOmega.map((x, i) => x * moments[i]));
  if (!momentum2.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced initial momentum");
  const angularRateBound = (Math.hypot(...momentum2) + dt * Math.hypot(...torque)) / Math.min(...moments);
  const subdivisions = Math.max(1, Math.ceil(dt * angularRateBound / (1 / 8)));
  if (!Number.isFinite(subdivisions) || subdivisions > 64) {
    error("NUMERIC_LIMIT", "forced rotation exceeded internal subdivision limit");
  }
  const omegaAt = (q2, time) => {
    const r = rotation(q2);
    const stageL = momentum2.map((x, i) => x + torque[i] * time);
    if (!stageL.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced stage momentum");
    const localL = product(r, stageL, true);
    const omega = product(r, localL.map((x, i) => x / moments[i]));
    movement(omega, dt);
    return omega;
  };
  const rhs = (q2, time) => {
    const [a2, b2, c] = omegaAt(q2, time), [x, y, z, w] = q2;
    const rate = [
      (a2 * w + b2 * z - c * y) / 2,
      (-a2 * z + b2 * w + c * x) / 2,
      (a2 * y - b2 * x + c * w) / 2,
      (-a2 * x - b2 * y - c * z) / 2
    ];
    if (!rate.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced quaternion rate");
    return rate;
  };
  const offset = (q2, rate, h) => q2.map((x, i) => x + h * rate[i]);
  const levels = [2, 4, 6, 8];
  let q = [...body.orientation];
  const macroStep = dt / subdivisions;
  for (let macro = 0; macro < subdivisions; macro++) {
    const start = macro * macroStep;
    const table = [];
    for (let k = 0; k < levels.length; k++) {
      const count = levels[k], h = macroStep / count;
      let previous = q;
      let current = offset(q, rhs(q, start), h);
      for (let m = 1; m < count; m++) {
        const next2 = offset(previous, rhs(current, start + m * h), 2 * h);
        previous = current;
        current = next2;
      }
      const endpointRate = rhs(current, start + macroStep);
      const row = [current.map((x, i) => (x + previous[i] + h * endpointRate[i]) / 2)];
      for (let j = 1; j <= k; j++) {
        const denominator = (count / levels[k - j]) ** 2 - 1;
        row.push(row[j - 1].map((x, i) => x + (x - table[k - 1][j - 1][i]) / denominator));
      }
      table.push(row);
    }
    const next = table[3][3];
    const norm2 = Math.hypot(...next);
    if (!next.every(Number.isFinite) || !Number.isFinite(norm2) || norm2 <= 0) {
      error("NUMERIC_LIMIT", "nonfinite forced extrapolated orientation");
    }
    q = next.map((x) => x / norm2);
  }
  const angularVelocityRadps = omegaAt(q, dt);
  if (Math.abs(q.reduce((s, x) => s + x * x, 0) - 1) > 1e-12) {
    error("NUMERIC_LIMIT", "forced final quaternion exceeded norm limit");
  }
  return { orientation: q, angularVelocityRadps };
}

// src/stack/sat-feature.ts
var FEATURE_INPUT_MESSAGE = "private feature geometry requires two admitted boxes";
var DIAGNOSTIC_TIE_TOLERANCE_M = 1e-12;
function boxAxes2(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
}
function boxSupport2(body, direction2) {
  const axes = boxAxes2(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function featureAt(candidateIndex) {
  if (candidateIndex < 3) return { kind: "face-a", axisA: candidateIndex };
  if (candidateIndex < 6) return { kind: "face-b", axisB: candidateIndex - 3 };
  const crossIndex = candidateIndex - 6;
  return { kind: "edge-cross", axisA: Math.floor(crossIndex / 3), axisB: crossIndex % 3 };
}
function featureLabel(feature) {
  if (feature.kind === "face-a") return `A.face.${feature.axisA}`;
  if (feature.kind === "face-b") return `B.face.${feature.axisB}`;
  return `A.edge.${feature.axisA}xB.edge.${feature.axisB}`;
}
function selectBoxSATFeature(a2, b2) {
  if (a2.shape.kind !== "box" || b2.shape.kind !== "box") {
    error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE);
  }
  const axesA = boxAxes2(a2), axesB = boxAxes2(b2);
  const extentA = a2.shape.halfExtentsM, extentB = b2.shape.halfExtentsM;
  const delta = sub(b2.positionM, a2.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  let bestCandidateIndex = 0, bestRawLength = 0;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  const diagnostics = [];
  for (const [candidateIndex, candidate] of candidates.entries()) {
    const length = Math.hypot(...candidate);
    const feature2 = featureAt(candidateIndex);
    const diagnostic = {
      candidateIndex,
      label: featureLabel(feature2),
      feature: feature2,
      rawAxisLength: length,
      skippedByOriginalCutoff: length < 1e-12,
      signedDistanceM: null,
      overlapM: null
    };
    diagnostics.push(diagnostic);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis3, index) => sum + extentA[index] * Math.abs(dot(basis3, axis)), 0);
    const radiusB = axesB.reduce((sum, basis3, index) => sum + extentB[index] * Math.abs(dot(basis3, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    diagnostic.signedDistanceM = signedDistance;
    diagnostic.overlapM = overlap;
    if (overlap < -1e-12) return null;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
      bestCandidateIndex = candidateIndex;
      bestRawLength = length;
    }
  }
  const aPoint = boxSupport2(a2, bestAxis);
  const bPoint = boxSupport2(b2, scale(bestAxis, -1));
  const originalHit = {
    normal: bestAxis,
    penetration: Math.max(0, bestOverlap),
    pointM: scale(add(aPoint, bPoint), 0.5)
  };
  const feature = featureAt(bestCandidateIndex);
  return {
    hit: {
      normal: [...originalHit.normal],
      penetration: originalHit.penetration,
      pointM: [...originalHit.pointM]
    },
    feature,
    label: featureLabel(feature),
    candidateIndex: bestCandidateIndex,
    rawAxisLength: bestRawLength,
    candidates: diagnostics,
    ambiguity: {
      exactMinimumCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && candidate.overlapM === bestOverlap).map((candidate) => candidate.candidateIndex),
      withinDiagnosticTieToleranceCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && Math.abs(candidate.overlapM - bestOverlap) <= DIAGNOSTIC_TIE_TOLERANCE_M).map((candidate) => candidate.candidateIndex),
      skippedCandidateIndices: diagnostics.filter((candidate) => candidate.skippedByOriginalCutoff).map((candidate) => candidate.candidateIndex),
      diagnosticTieToleranceM: DIAGNOSTIC_TIE_TOLERANCE_M,
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// src/stack/witness.ts
var WITNESS_MESSAGE = "private feature contact requires valid box witnesses";
var WITNESS_TOLERANCE_M = 1e-12;
var DUPLICATE_TOLERANCE_M = 1e-12;
var basis2 = (b2) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((v) => rotate2(b2.orientation, v));
var extents = (b2) => b2.shape.halfExtentsM;
function unit(v) {
  const n = Math.hypot(...v);
  if (!Number.isFinite(n) || n < 1e-12) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return scale(v, 1 / n);
}
function point(key, a2, b2, n) {
  const gap = dot(sub(b2, a2), n);
  const result = {
    key,
    witnessAM: [...a2],
    witnessBM: [...b2],
    midpointM: scale(add(a2, b2), 0.5),
    normalGapM: gap,
    pointPenetrationM: Math.max(0, -gap)
  };
  if (![...a2, ...b2, ...result.midpointM, gap, result.pointPenetrationM].every(Number.isFinite) || gap > WITNESS_TOLERANCE_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return result;
}

// src/stack/strict-line.ts
var STRICT_LINE_LIMITS = Object.freeze({
  rationalOperations: 2e5,
  integerOperations: 2e6,
  integerBits: 16384,
  roundingSteps: 16
});
var StrictLineFailure = class extends Error {
  constructor(message) {
    super(message);
    this.name = "StrictLineFailure";
  }
};
var ZERO2 = { n: 0n, d: 1n };
var ieee = new DataView(new ArrayBuffer(8));
function nextAfterToward(value, target) {
  if (!Number.isFinite(value) || !Number.isFinite(target)) throw new StrictLineFailure("nonfinite nextafter");
  if (value === target) return value;
  if (value === 0) return target > 0 ? Number.MIN_VALUE : -Number.MIN_VALUE;
  ieee.setFloat64(0, value, false);
  let bits2 = ieee.getBigUint64(0, false);
  bits2 += target > value === value > 0 ? 1n : -1n;
  ieee.setBigUint64(0, bits2, false);
  const result = ieee.getFloat64(0, false);
  if (!Number.isFinite(result)) throw new StrictLineFailure("nextafter overflow");
  return result;
}
var Arithmetic = class {
  counters = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 };
  guardCached() {
    if (this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
    if (this.counters.peakIntegerBits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
  }
  tick(amount = 1) {
    this.counters.integerOperations += amount;
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
  }
  op() {
    if (++this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
  }
  checked(value) {
    const hex = (value < 0n ? -value : value).toString(16), first = hex.charCodeAt(0);
    const bits2 = 4 * (hex.length - 1) + (first <= 49 ? 1 : first <= 51 ? 2 : first <= 55 ? 3 : 4);
    this.counters.peakIntegerBits = Math.max(this.counters.peakIntegerBits, bits2);
    if (bits2 > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
    return value;
  }
  multiply(a2, b2) {
    this.tick();
    return this.checked(a2 * b2);
  }
  sum(a2, b2) {
    this.tick();
    return this.checked(a2 + b2);
  }
  shifted(value, bits2) {
    this.tick();
    return this.checked(value << BigInt(bits2));
  }
  make(n, d = 1n) {
    this.checked(n);
    this.checked(d);
    return this.normalizeChecked(n, d);
  }
  /** Both operands have already passed checked in this call's evaluation order. */
  normalizeChecked(n, d) {
    if (d === 0n) throw new StrictLineFailure("zero rational denominator");
    if (n === 0n) return ZERO2;
    if (d < 0n) {
      this.tick(2);
      n = -n;
      d = -d;
    }
    if (d === 1n) {
      this.guardCached();
      return { n, d };
    }
    let a2 = n < 0n ? -n : n, b2 = d;
    this.tick(2);
    if ((d & d - 1n) === 0n) {
      this.tick(2);
      const factor2 = a2 & -a2, divisor = factor2 < d ? factor2 : d;
      this.tick(2);
      return { n: n / divisor, d: d / divisor };
    }
    while (b2 !== 0n) {
      this.tick();
      const remainder = a2 % b2;
      a2 = b2;
      b2 = remainder;
    }
    this.tick(2);
    return { n: n / a2, d: d / a2 };
  }
  from(value) {
    this.op();
    if (!Number.isFinite(value)) throw new StrictLineFailure("nonfinite exact operand");
    ieee.setFloat64(0, value, false);
    const bits2 = ieee.getBigUint64(0, false), negative = bits2 >> 63n !== 0n;
    const exponent = Number(bits2 >> 52n & 2047n), fraction = bits2 & (1n << 52n) - 1n;
    const significand = exponent === 0 ? fraction : fraction + (1n << 52n);
    const power = exponent === 0 ? -1074 : exponent - 1023 - 52;
    const n = negative ? -significand : significand;
    return power >= 0 ? this.make(this.shifted(n, power)) : this.make(n, this.shifted(1n, -power));
  }
  add(a2, b2) {
    this.op();
    if (a2.d === b2.d) return this.make(this.sum(a2.n, b2.n), a2.d);
    if (a2.d > 0n && b2.d > 0n) {
      this.tick();
      if (a2.d % b2.d === 0n) {
        this.tick();
        const ratio4 = this.checked(a2.d / b2.d);
        return this.make(this.sum(a2.n, this.multiply(b2.n, ratio4)), a2.d);
      }
      this.tick();
      if (b2.d % a2.d === 0n) {
        this.tick();
        const ratio4 = this.checked(b2.d / a2.d);
        return this.make(this.sum(this.multiply(a2.n, ratio4), b2.n), b2.d);
      }
    }
    return this.normalizeChecked(this.sum(this.multiply(a2.n, b2.d), this.multiply(b2.n, a2.d)), this.multiply(a2.d, b2.d));
  }
  neg(a2) {
    this.op();
    this.tick();
    return { n: -a2.n, d: a2.d };
  }
  sub(a2, b2) {
    return this.add(a2, this.neg(b2));
  }
  mul(a2, b2) {
    this.op();
    return this.normalizeChecked(this.multiply(a2.n, b2.n), this.multiply(a2.d, b2.d));
  }
  sumSquare(a2, b2) {
    const sum = this.add(a2, b2);
    this.op();
    const n = this.multiply(sum.n, sum.n), d = this.multiply(sum.d, sum.d);
    if (n === 0n) return ZERO2;
    if (d === 1n) this.guardCached();
    return { n, d };
  }
  div(a2, b2) {
    this.op();
    if (a2.d > 0n && b2.d > 0n && b2.n !== 0n) {
      this.guardCached();
      if (a2.d === b2.d) return this.make(a2.n, b2.n);
      this.tick();
      if (a2.d % b2.d === 0n) {
        this.tick();
        const ratio4 = this.checked(a2.d / b2.d);
        return this.make(a2.n, this.multiply(ratio4, b2.n));
      }
      this.tick();
      if (b2.d % a2.d === 0n) {
        this.tick();
        const ratio4 = this.checked(b2.d / a2.d);
        return this.make(this.multiply(ratio4, a2.n), b2.n);
      }
    }
    return this.normalizeChecked(this.multiply(a2.n, b2.d), this.multiply(a2.d, b2.n));
  }
  compare(a2, b2) {
    this.op();
    const difference = this.sum(this.multiply(a2.n, b2.d), -this.multiply(b2.n, a2.d));
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
  }
  abs(a2) {
    return a2.n < 0n ? this.neg(a2) : a2;
  }
  vec(value, length = 3) {
    if (value.length !== length || !Array.from({ length }, (_, i) => i).every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    return value.map((x) => this.from(x));
  }
  dot(a2, b2) {
    return a2.reduce((value, x, i) => {
      const product2 = this.mul(x, b2[i]);
      return value === null && product2.n !== 0n && product2.d !== 1n ? product2 : this.add(value ?? ZERO2, product2);
    }, null) ?? ZERO2;
  }
  quotient(a2, b2) {
    this.tick();
    return this.checked(a2 / b2);
  }
  /** Called only after both original boxes have fully decoded and normalized. */
  prepareRotation(rotation2) {
    let denominator = 1n;
    for (const row of rotation2) for (const value of row) {
      if (value.d === 1n) continue;
      let a2 = denominator, b2 = value.d;
      while (b2 !== 0n) {
        this.tick();
        const remainder = a2 % b2;
        a2 = b2;
        b2 = remainder;
      }
      denominator = this.multiply(this.quotient(denominator, a2), value.d);
    }
    if (denominator === 1n) return { denominator, columns: [0, 1, 2].map((axis) => rotation2.map((row) => row[axis].n)) };
    const columns = [0, 1, 2].map((axis) => rotation2.map((row) => this.multiply(row[axis].n, this.quotient(denominator, row[axis].d))));
    return { denominator, columns };
  }
  /** Relative coordinates are owned dyadics from unchanged from/sub calls. */
  localProjection(rotation2, relative) {
    this.guardCached();
    let denominator = 1n;
    for (const value of relative) if (value.d > denominator) denominator = value.d;
    const scaled3 = relative.map((value) => this.multiply(value.n, this.quotient(denominator, value.d)));
    const divisor = this.multiply(rotation2.denominator, denominator);
    return rotation2.columns.map((column) => {
      this.op();
      let numerator = this.multiply(column[0], scaled3[0]);
      for (let i = 1; i < 3; i++) numerator = this.sum(numerator, this.multiply(column[i], scaled3[i]));
      return this.normalizeChecked(numerator, divisor);
    });
  }
  /** Correct nearest-even conversion, including subnormals; no Number(BigInt)/Number(BigInt). */
  number(value) {
    this.op();
    if (value.n === 0n) return 0;
    const negative = value.n < 0n, n = negative ? -value.n : value.n, d = value.d;
    let exponent = n.toString(2).length - d.toString(2).length;
    if (exponent >= 0 ? n < this.shifted(d, exponent) : this.shifted(n, -exponent) < d) exponent--;
    const unit2 = Math.max(-1074, exponent - 52);
    const numerator = unit2 < 0 ? this.shifted(n, -unit2) : n;
    const denominator = unit2 > 0 ? this.shifted(d, unit2) : d;
    this.tick(2);
    let quotient = numerator / denominator;
    const remainder = numerator % denominator;
    const twice = this.shifted(remainder, 1);
    if (twice > denominator || twice === denominator && (quotient & 1n) !== 0n) {
      this.tick();
      quotient++;
    }
    const result = Number(quotient) * Math.pow(2, unit2);
    if (!Number.isFinite(result)) throw new StrictLineFailure("rounded witness overflow");
    return negative ? -result : result;
  }
};
var StrictLineContext = class {
  m = new Arithmetic();
  boxes;
  integerRotations;
  normal;
  tolerance;
  normalSquared;
  fourToleranceSquared;
  directions = [void 0, void 0];
  lastMidpoint;
  constructor(a2, b2, normal) {
    this.normal = this.m.vec(normal);
    if (this.normal.every((x) => x.n === 0n)) throw new StrictLineFailure("zero line direction");
    this.tolerance = this.m.from(1e-12);
    this.normalSquared = this.m.dot(this.normal, this.normal);
    this.fourToleranceSquared = this.m.mul(this.m.from(4), this.m.mul(this.tolerance, this.tolerance));
    this.boxes = [this.box(a2), this.box(b2)];
    this.integerRotations = [this.m.prepareRotation(this.boxes[0].rotation), this.m.prepareRotation(this.boxes[1].rotation)];
  }
  stats() {
    return { ...this.m.counters };
  }
  box(body) {
    if (body.shape.kind !== "box") throw new StrictLineFailure("box required");
    const m = this.m, [x, y, z, w] = m.vec(body.orientation, 4), norm2 = m.dot([x, y, z, w], [x, y, z, w]);
    if (norm2.n === 0n) throw new StrictLineFailure("zero quaternion");
    const two = m.from(2), square = (q) => m.mul(q, q);
    const twice = (a2, b2) => m.mul(two, m.mul(a2, b2));
    const diagonal = (a2, b2) => m.div(m.sub(norm2, m.mul(two, m.add(square(a2), square(b2)))), norm2);
    const entry = (a2, b2, c, d, sign) => m.div(sign === 1 ? m.add(twice(a2, b2), twice(c, d)) : m.sub(twice(a2, b2), twice(c, d)), norm2);
    const rotation2 = [
      [diagonal(y, z), entry(x, y, z, w, -1), entry(x, z, y, w, 1)],
      [entry(x, y, z, w, 1), diagonal(x, z), entry(y, z, x, w, -1)],
      [entry(x, z, y, w, -1), entry(y, z, x, w, 1), diagonal(x, y)]
    ];
    const extent = m.vec(body.shape.halfExtentsM);
    if (extent.some((value) => value.n <= 0n)) throw new StrictLineFailure("positive extents required");
    return { centre: m.vec(body.positionM), extent, rotation: rotation2 };
  }
  local(box, world, direction2 = false) {
    const relative = direction2 ? world : world.map((value, i) => this.m.sub(value, box.centre[i]));
    return this.m.localProjection(this.integerRotations[box === this.boxes[0] ? 0 : 1], relative);
  }
  direction(which) {
    const cached = this.directions[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], this.normal, true);
    this.directions[which] = value;
    return value;
  }
  midpoint(value) {
    if (!Array.isArray(value) || value.length !== 3 || ![0, 1, 2].every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    const key = [value[0], value[1], value[2]], cached = this.lastMidpoint;
    if (key.every(Number.isFinite) && cached !== void 0 && key.every((v, i) => Object.is(v, cached.key[i]))) {
      this.m.guardCached();
      return cached;
    }
    const point2 = this.m.vec(key);
    const entry = { key, point: point2, local: [void 0, void 0], interval: [void 0, void 0] };
    this.lastMidpoint = entry;
    return entry;
  }
  localMidpoint(which, entry) {
    const cached = entry.local[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], entry.point);
    entry.local[which] = value;
    return value;
  }
  interval(which, entry) {
    const cached = entry.interval[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const result = this.computeInterval(which, entry);
    entry.interval[which] = result;
    return result;
  }
  computeInterval(which, entry) {
    const box = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which);
    let low = null, high = null;
    for (let i = 0; i < 3; i++) {
      if (d[i].n === 0n) {
        if (m.compare(m.abs(u[i]), box.extent[i]) > 0) return null;
        continue;
      }
      const first = m.div(m.sub(m.neg(box.extent[i]), u[i]), d[i]), second = m.div(m.sub(box.extent[i], u[i]), d[i]);
      const lower = m.compare(first, second) <= 0 ? first : second, upper = lower === first ? second : first;
      if (low === null || m.compare(lower, low) > 0) low = lower;
      if (high === null || m.compare(upper, high) < 0) high = upper;
      if (low !== null && high !== null && m.compare(low, high) > 0) return null;
    }
    if (low === null || high === null) throw new StrictLineFailure("unbounded box line interval");
    return { low, high };
  }
  /** Strict closed slabs and the actual A-exit/B-entry surface midpoint. */
  check(midpoint2) {
    const m = this.m, entry = this.midpoint(midpoint2), a2 = this.interval(0, entry);
    if (a2 === null) return false;
    const b2 = this.interval(1, entry);
    if (b2 === null) return false;
    const fourDistanceSquared = m.mul(m.sumSquare(a2.high, b2.low), this.normalSquared);
    return m.compare(fourDistanceSquared, this.fourToleranceSquared) <= 0;
  }
  faceIsBoundary(which, entry, plane, bound, exit) {
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    const box = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which), axis = plane.axis;
    if (d[axis].n === 0n) return false;
    const side2 = m.from(plane.side), outwardDirection = m.mul(side2, d[axis]);
    if (m.compare(outwardDirection, ZERO2) !== (exit ? 1 : -1)) return false;
    const parameter = m.div(m.sub(m.mul(side2, box.extent[axis]), u[axis]), d[axis]);
    return m.compare(parameter, bound) === 0;
  }
  /** Named faces must be actual line bounds; closed edge/corner ties remain valid. */
  selectedFaceBounds(midpoint2, faceA, faceB) {
    const entry = this.midpoint(midpoint2), a2 = this.interval(0, entry);
    if (a2 === null) return false;
    const b2 = this.interval(1, entry);
    return b2 !== null && this.faceIsBoundary(0, entry, faceA, a2.high, true) && this.faceIsBoundary(1, entry, faceB, b2.low, false);
  }
  onFace(which, plane, witness) {
    const m = this.m, box = this.boxes[which], local = this.local(box, m.vec(witness));
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    if (local.some((value, i) => m.compare(m.sub(m.abs(value), box.extent[i]), this.tolerance) > 0)) return false;
    return m.compare(m.abs(m.sub(local[plane.axis], m.mul(m.from(plane.side), box.extent[plane.axis]))), this.tolerance) <= 0;
  }
  movementWithin(original, moved) {
    const m = this.m, a2 = m.vec(original), b2 = m.vec(moved), delta = a2.map((value, i) => m.sub(b2[i], value));
    return m.compare(m.dot(delta, delta), m.mul(this.tolerance, this.tolerance)) <= 0;
  }
  projectedPair(seed, faceA, faceB) {
    const m = this.m, p = m.vec(seed);
    return [faceA, faceB].map((face, which) => {
      if (!Number.isInteger(face.axis) || face.axis < 0 || face.axis > 2 || Math.abs(face.side) !== 1) throw new StrictLineFailure("face selector");
      const box = this.boxes[which], u = this.local(box, p), d = this.direction(which), axis = face.axis;
      if (d[axis].n === 0n) throw new StrictLineFailure("line parallel to selected face");
      const t = m.div(m.sub(m.mul(m.from(face.side), box.extent[axis]), u[axis]), d[axis]);
      return p.map((value, i) => m.number(m.add(value, m.mul(this.normal[i], t))));
    });
  }
};

// src/stack/face-contact.ts
function clipFace(polygon, centre, axis, limit) {
  const out = [];
  for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i], q = polygon[(i + 1) % polygon.length];
    const dp = dot(sub(p, centre), axis) - limit, dq = dot(sub(q, centre), axis) - limit;
    if (dp <= 0) out.push([...p]);
    if (dp <= 0 !== dq <= 0) out.push(add(p, scale(sub(q, p), dp / (dp - dq))));
  }
  return out;
}
function faceContact(a2, b2, selection) {
  const f = selection.feature;
  if (f.kind === "edge-cross") error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const isA = f.kind === "face-a", ref = isA ? a2 : b2, inc = isA ? b2 : a2;
  const axis = f.kind === "face-a" ? f.axisA : f.axisB, ra = basis2(ref), ia = basis2(inc), re = extents(ref), ie = extents(inc);
  const outward = isA ? selection.hit.normal : scale(selection.hit.normal, -1);
  const side2 = dot(ra[axis], outward) < 0 ? -1 : 1, n = unit(scale(ra[axis], side2));
  const centre = add(ref.positionM, scale(ra[axis], side2 * re[axis]));
  let incidentAxis = 0, greatest = -Infinity;
  for (let i = 0; i < 3; i++) {
    const v = Math.abs(dot(ia[i], n));
    if (v > greatest) {
      greatest = v;
      incidentAxis = i;
    }
  }
  const incidentSide = dot(ia[incidentAxis], n) > 0 ? -1 : 1;
  const incidentCentre = add(inc.positionM, scale(ia[incidentAxis], incidentSide * ie[incidentAxis]));
  const it = [0, 1, 2].filter((i) => i !== incidentAxis), rt = [0, 1, 2].filter((i) => i !== axis);
  let poly = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => add(add(incidentCentre, scale(ia[it[0]], u * ie[it[0]])), scale(ia[it[1]], v * ie[it[1]])));
  for (const i of rt) {
    poly = clipFace(poly, centre, ra[i], re[i]);
    poly = clipFace(poly, centre, scale(ra[i], -1), re[i]);
  }
  const planeNormalAtoB = isA ? n : scale(n, -1);
  const candidates = poly.map((p) => {
    const separation = dot(sub(p, centre), n), r = sub(p, scale(n, separation));
    return { p, r, separation, u: dot(sub(r, centre), ra[rt[0]]), v: dot(sub(r, centre), ra[rt[1]]) };
  }).filter((p) => p.separation <= WITNESS_TOLERANCE_M);
  if (!candidates.length) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const selected2 = candidates.length <= 4 ? candidates : [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => candidates.reduce((best, p) => u * p.u + v * p.v > u * best.u + v * best.v ? p : best, candidates[0]));
  const unique = selected2.filter((p, i) => selected2.findIndex((q) => Math.hypot(...sub(p.r, q.r)) <= DUPLICATE_TOLERANCE_M) === i);
  unique.sort((p, q) => p.u - q.u || p.v - q.v);
  const prefix = `face:${ref.id}:${axis}:${side2}:${inc.id}:${incidentAxis}:${incidentSide}`;
  const referencePlane = { axis, side: side2 }, incidentPlane = { axis: incidentAxis, side: incidentSide };
  const faceA = isA ? referencePlane : incidentPlane, faceB = isA ? incidentPlane : referencePlane;
  const interior = scale(candidates.reduce((sum, p) => add(sum, scale(add(p.r, p.p), 0.5)), [0, 0, 0]), 1 / candidates.length);
  let movedPoints = 0, maximumSteps = 0;
  let exact3;
  let points;
  try {
    exact3 = new StrictLineContext(a2, b2, planeNormalAtoB);
    points = unique.map((p, i) => {
      const original = point(`${prefix}:${i}`, isA ? p.r : p.p, isA ? p.p : p.r, planeNormalAtoB);
      const certified = (candidate) => exact3.check(candidate.midpointM) && exact3.selectedFaceBounds(candidate.midpointM, faceA, faceB) && exact3.onFace(0, faceA, candidate.witnessAM) && exact3.onFace(1, faceB, candidate.witnessBM);
      if (certified(original)) return original;
      let seed = [...original.midpointM];
      for (let step = 1; step <= STRICT_LINE_LIMITS.roundingSteps; step++) {
        seed = seed.map((value, k) => nextAfterToward(value, interior[k]));
        const [witnessA, witnessB] = exact3.projectedPair(seed, faceA, faceB);
        const candidate = point(original.key, witnessA, witnessB, planeNormalAtoB);
        if (!exact3.movementWithin(original.witnessAM, candidate.witnessAM) || !exact3.movementWithin(original.witnessBM, candidate.witnessBM) || !exact3.movementWithin(original.midpointM, candidate.midpointM)) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
        if (certified(candidate)) {
          movedPoints++;
          maximumSteps = Math.max(maximumSteps, step);
          return candidate;
        }
      }
      error("NUMERIC_LIMIT", WITNESS_MESSAGE);
    });
  } catch (caught) {
    if (caught instanceof StrictLineFailure) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
    throw caught;
  }
  const exactWork = exact3.stats();
  return {
    selection: structuredClone(selection),
    family: "face",
    planeNormalAtoB,
    reference: { body: isA ? "a" : "b", axis, side: side2, incidentAxis, incidentSide },
    points,
    conditioning: {
      clippedVertices: poly.length,
      candidates: candidates.length,
      retainedPoints: points.length,
      rawAxisLength: selection.rawAxisLength,
      uniquePhysicalFeatureClaimed: false,
      strictLineCertified: true,
      boundaryRoundingMovedPoints: movedPoints,
      boundaryRoundingMaximumSteps: maximumSteps,
      exactRationalOperations: exactWork.rationalOperations,
      exactIntegerOperations: exactWork.integerOperations,
      exactPeakIntegerBits: exactWork.peakIntegerBits
    }
  };
}

// src/stack/edge-contact.ts
var clamp2 = (v) => Math.max(0, Math.min(1, v));
function closestSegments(p, p1, q, q1) {
  const u = sub(p1, p), v = sub(q1, q), r = sub(q, p), uu = dot(u, u), vv = dot(v, v), uv = dot(u, v), c = cross(u, v), den = dot(c, c);
  if (![...p, ...p1, ...q, ...q1, uu, vv, den].every(Number.isFinite) || uu <= 0 || vv <= 0) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const pairs = [
    { s: 0, t: clamp2(-dot(r, v) / vv) },
    { s: 1, t: clamp2((uv - dot(r, v)) / vv) },
    { s: clamp2(dot(r, u) / uu), t: 0 },
    { s: clamp2((dot(r, u) + uv) / uu), t: 1 }
  ];
  if (den > 0) {
    const s = dot(cross(r, v), c) / den, t = dot(cross(r, u), c) / den;
    if (Number.isFinite(s) && Number.isFinite(t) && s >= 0 && s <= 1 && t >= 0 && t <= 1) pairs.push({ s, t });
  }
  let best = pairs[0], bestDistance = Infinity;
  for (const pair of pairs) {
    const d = sub(add(p, scale(u, pair.s)), add(q, scale(v, pair.t))), ds = dot(d, d);
    if (ds < bestDistance) {
      best = pair;
      bestDistance = ds;
    }
  }
  return {
    a: add(p, scale(u, best.s)),
    b: add(q, scale(v, best.t)),
    parameterA: best.s,
    parameterB: best.t,
    crossSquared: den,
    distanceSquared: bestDistance,
    parallel: den === 0,
    boundary: best.s === 0 || best.s === 1 || best.t === 0 || best.t === 1
  };
}
function supportEdge(body, axis, direction2) {
  const axes = basis2(body), e = extents(body), sides = [0, 0, 0];
  let centre = [...body.positionM];
  for (let i = 0; i < 3; i++) if (i !== axis) {
    sides[i] = dot(axes[i], direction2) < 0 ? -1 : 1;
    centre = add(centre, scale(axes[i], sides[i] * e[i]));
  }
  return { lo: sub(centre, scale(axes[axis], e[axis])), hi: add(centre, scale(axes[axis], e[axis])), sides };
}
function edgeContact(a2, b2, selection) {
  const f = selection.feature;
  if (f.kind !== "edge-cross") error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const n = [...selection.hit.normal], ea = supportEdge(a2, f.axisA, n), eb = supportEdge(b2, f.axisB, scale(n, -1));
  const nearest = closestSegments(ea.lo, ea.hi, eb.lo, eb.hi);
  const difference = sub(nearest.b, nearest.a), gap = dot(difference, n), tangent = sub(difference, scale(n, gap));
  if (Math.hypot(...tangent) > WITNESS_TOLERANCE_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const key = `edge:${a2.id}:${f.axisA}:${ea.sides.join(",")}:${b2.id}:${f.axisB}:${eb.sides.join(",")}`;
  return {
    selection: structuredClone(selection),
    family: "edge",
    planeNormalAtoB: n,
    edges: { axisA: f.axisA, axisB: f.axisB, sidesA: ea.sides, sidesB: eb.sides, parameterA: nearest.parameterA, parameterB: nearest.parameterB },
    points: [point(key, nearest.a, nearest.b, n)],
    conditioning: {
      crossSquared: nearest.crossSquared,
      rawAxisLength: selection.rawAxisLength,
      parallel: nearest.parallel,
      boundary: nearest.boundary,
      tangentDistanceM: Math.hypot(...tangent),
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// src/stack/geometry.ts
function witnessInside(body, w) {
  const local = basis2(body).map((axis) => dot(sub(w, body.positionM), axis)), e = extents(body);
  return local.every((v, i) => Number.isFinite(v) && Math.abs(v) <= e[i] + WITNESS_TOLERANCE_M);
}
function denseVector(v, size2, min, max) {
  return Array.isArray(v) && v.length === size2 && Array.from({ length: size2 }, (_, i) => i).every((i) => Object.hasOwn(v, i) && Number.isFinite(v[i]) && v[i] >= min && v[i] <= max);
}
function admitted(b2) {
  return b2 !== null && typeof b2 === "object" && typeof b2.id === "string" && ID.test(b2.id) && ["dynamic", "static", "kinematic"].includes(b2.kind) && b2.shape?.kind === "box" && denseVector(b2.shape.halfExtentsM, 3, 1e-4, 1e3) && denseVector(b2.positionM, 3, -1e4, 1e4) && denseVector(b2.orientation, 4, -1, 1) && Math.abs(Math.hypot(...b2.orientation) - 1) <= 1e-9;
}
function featureContact(a2, b2) {
  if (!admitted(a2) || !admitted(b2) || a2.id === b2.id) error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE);
  const selection = selectBoxSATFeature(a2, b2);
  if (!selection) return null;
  if (selection.hit.penetration > MAX_STEP_DISPLACEMENT_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const geometry = selection.feature.kind === "edge-cross" ? edgeContact(a2, b2, selection) : faceContact(a2, b2, selection);
  if (!geometry.points.length || geometry.points.some((p) => !witnessInside(a2, p.witnessAM) || !witnessInside(b2, p.witnessBM))) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return geometry;
}

// src/stack/geometry-adapter.ts
var FEATURE_WITNESS_MESSAGE = "private feature contact requires valid box witnesses";
function adaptContactGeometry(a2, b2) {
  let geometry;
  try {
    geometry = featureContact(a2, b2);
  } catch (caught) {
    if (caught instanceof PhysicsError && (caught.code === "INVALID_CONFIG" || caught.code === "NUMERIC_LIMIT")) {
      error("NUMERIC_LIMIT", FEATURE_WITNESS_MESSAGE);
    }
    throw caught;
  }
  if (!geometry) return null;
  const points = geometry.points.map((point2) => ({
    id: point2.key,
    pointM: [...point2.midpointM],
    witnessAM: [...point2.witnessAM],
    witnessBM: [...point2.witnessBM],
    normalGapM: point2.normalGapM,
    pointPenetrationM: point2.pointPenetrationM
  }));
  const sum = points.reduce((value, point2) => add(value, point2.pointM), [0, 0, 0]);
  return {
    family: geometry.family,
    normal: [...geometry.planeNormalAtoB],
    satNormalAtoB: [...geometry.selection.hit.normal],
    satPenetrationM: geometry.selection.hit.penetration,
    points,
    meanPointM: sum.map((value) => value / points.length)
  };
}

// src/stack/stationary-normal.ts
var STATIONARY_LIMITS = Object.freeze({ rationalOperations: 2e5, integerOperations: 2e6, integerBits: 16384, triangleTrials: 32 });
var ZERO3 = { n: 0n, d: 1n };
var Stop = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "StationaryNormalFailure";
  }
};
function need(ok, status, message) {
  if (!ok) throw new Stop(status, message);
}
var Exact = class {
  stats = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0, triangleTrials: 0, interfacesProcessed: 0 };
  ieee = new DataView(new ArrayBuffer(8));
  op() {
    if (++this.stats.rationalOperations > STATIONARY_LIMITS.rationalOperations)
      throw new Stop("RESOURCE_LIMIT", "rational work limit");
  }
  tick() {
    if (++this.stats.integerOperations > STATIONARY_LIMITS.integerOperations)
      throw new Stop("RESOURCE_LIMIT", "integer work limit");
  }
  check(n) {
    const h = (n < 0n ? -n : n).toString(16), c = h.charCodeAt(0);
    const bits2 = 4 * (h.length - 1) + (c <= 49 ? 1 : c <= 51 ? 2 : c <= 55 ? 3 : 4);
    this.stats.peakIntegerBits = Math.max(this.stats.peakIntegerBits, bits2);
    need(bits2 <= STATIONARY_LIMITS.integerBits, "RESOURCE_LIMIT", "integer bit limit");
    return n;
  }
  addI(a2, b2) {
    this.tick();
    return this.check(a2 + b2);
  }
  mulI(a2, b2) {
    this.tick();
    return this.check(a2 * b2);
  }
  divI(a2, b2) {
    this.tick();
    need(b2 !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a2 / b2);
  }
  modI(a2, b2) {
    this.tick();
    need(b2 !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a2 % b2);
  }
  negI(a2) {
    this.tick();
    return this.check(-a2);
  }
  shift(a2, b2) {
    this.tick();
    return this.check(a2 << BigInt(b2));
  }
  normalized(n, d) {
    this.check(n);
    this.check(d);
    need(d !== 0n, "NUMERIC_LIMIT", "zero rational denominator");
    if (n === 0n) return ZERO3;
    if (d < 0n) {
      n = this.negI(n);
      d = this.negI(d);
    }
    let a2 = n < 0n ? this.negI(n) : n, b2 = d;
    while (b2 !== 0n) {
      const t = this.modI(a2, b2);
      a2 = b2;
      b2 = t;
    }
    return { n: this.divI(n, a2), d: this.divI(d, a2) };
  }
  make(n, d = 1n) {
    this.op();
    return this.normalized(n, d);
  }
  from(value) {
    this.op();
    need(Number.isFinite(value), "INVALID_INPUT", "nonfinite exact operand");
    this.ieee.setFloat64(0, value, false);
    const bits2 = this.ieee.getBigUint64(0, false), e = Number(bits2 >> 52n & 2047n);
    const f = bits2 & (1n << 52n) - 1n, s = e === 0 ? f : f + (1n << 52n);
    const p = e === 0 ? -1074 : e - 1075, n = bits2 >> 63n !== 0n ? -s : s;
    return p >= 0 ? this.normalized(this.shift(n, p), 1n) : this.normalized(n, this.shift(1n, -p));
  }
  add(a2, b2) {
    this.op();
    return this.normalized(this.addI(this.mulI(a2.n, b2.d), this.mulI(b2.n, a2.d)), this.mulI(a2.d, b2.d));
  }
  neg(a2) {
    this.op();
    return a2.n === 0n ? ZERO3 : { n: this.negI(a2.n), d: a2.d };
  }
  sub(a2, b2) {
    return this.add(a2, this.neg(b2));
  }
  mul(a2, b2) {
    this.op();
    return this.normalized(this.mulI(a2.n, b2.n), this.mulI(a2.d, b2.d));
  }
  div(a2, b2) {
    this.op();
    return this.normalized(this.mulI(a2.n, b2.d), this.mulI(a2.d, b2.n));
  }
  number(a2) {
    this.op();
    if (a2.n === 0n) return 0;
    const negative = a2.n < 0n, n = negative ? this.negI(a2.n) : a2.n, d = a2.d;
    let e = n.toString(2).length - d.toString(2).length;
    if (e >= 0 ? n < this.shift(d, e) : this.shift(n, -e) < d) e--;
    const unit2 = Math.max(-1074, e - 52);
    const nn = unit2 < 0 ? this.shift(n, -unit2) : n, dd = unit2 > 0 ? this.shift(d, unit2) : d;
    let q = this.divI(nn, dd);
    const rem = this.modI(nn, dd), twice = this.shift(rem, 1);
    if (twice > dd || twice === dd && (q & 1n) !== 0n) q = this.addI(q, 1n);
    const out = Number(q) * Math.pow(2, unit2);
    need(Number.isFinite(out), "NUMERIC_LIMIT", "rounded impulse overflow");
    return negative ? -out : out;
  }
};
var ratio3 = (q) => ({ n: q.n.toString(), d: q.d.toString() });
function word(n) {
  const d = new DataView(new ArrayBuffer(8));
  d.setFloat64(0, n, false);
  return d.getBigUint64(0, false).toString(16).padStart(16, "0");
}
function data(input, depth = 0, meter = { nodes: 0 }) {
  need(++meter.nodes <= 8192 && depth <= 12, "INVALID_INPUT", "input size or depth");
  if (input === null || typeof input === "string" || typeof input === "boolean" || typeof input === "number" && Number.isFinite(input)) return input;
  need(input && typeof input === "object", "INVALID_INPUT", "finite plain data required");
  const ds = Object.getOwnPropertyDescriptors(input), keys = Reflect.ownKeys(input), array2 = Array.isArray(input);
  need(Object.getPrototypeOf(input) === (array2 ? Array.prototype : Object.prototype), "INVALID_INPUT", "plain data required");
  if (array2) {
    need(input.length <= 64 && keys.length === input.length + 1, "INVALID_INPUT", "dense bounded array");
    return Array.from({ length: input.length }, (_, i) => {
      need(ds[i]?.enumerable && "value" in ds[i], "INVALID_INPUT", "dense data array");
      return data(ds[i].value, depth + 1, meter);
    });
  }
  need(keys.length <= 12 && keys.every((k) => typeof k === "string" && ds[k].enumerable && "value" in ds[k]), "INVALID_INPUT", "data fields required");
  return Object.fromEntries(keys.map((k) => [k, data(ds[k].value, depth + 1, meter)]));
}
function fields2(value, keys) {
  need(value !== null && typeof value === "object" && !Array.isArray(value), "INVALID_INPUT", "record required");
  const o = value;
  need(Object.keys(o).length === keys.length && keys.every((k) => Object.hasOwn(o, k)), "INVALID_INPUT", "exact fields required");
  return o;
}
function vec(value, n = 3, bound = 1e4) {
  need(Array.isArray(value) && value.length === n && value.every((x) => typeof x === "number" && Number.isFinite(x) && Math.abs(x) <= bound), "INVALID_INPUT", "finite bounded vector required");
  return value;
}
function coefficients(body, p, sign) {
  const r = p.pointM.map((x, i) => x - body.positionM[i]);
  need(r.every((x) => Number.isFinite(x) && Math.abs(x) <= 10), "UNSUPPORTED_PROFILE", "contact arm bound");
  const n = p.normalAtoB;
  const t = [r[1] * n[2] - r[2] * n[1], r[2] * n[0] - r[0] * n[2], r[0] * n[1] - r[1] * n[0]];
  return [...n.map((x) => sign * x), ...t.map((x) => sign * x)];
}
function det(m, c) {
  return m.add(
    m.sub(
      m.mul(c[0][0], m.sub(m.mul(c[1][1], c[2][2]), m.mul(c[1][2], c[2][1]))),
      m.mul(c[1][0], m.sub(m.mul(c[0][1], c[2][2]), m.mul(c[0][2], c[2][1])))
    ),
    m.mul(c[2][0], m.sub(m.mul(c[0][1], c[1][2]), m.mul(c[0][2], c[1][1])))
  );
}
function triangle(m, columns, rhs) {
  if (rhs.every((q) => q.n === 0n)) return [ZERO3, ZERO3, ZERO3, ZERO3];
  for (const ids of [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]]) {
    need(++m.stats.triangleTrials <= STATIONARY_LIMITS.triangleTrials, "RESOURCE_LIMIT", "triangle work limit");
    const c = ids.map((i) => columns[i]), d = det(m, c);
    if (d.n === 0n) continue;
    const values = c.map((_, j) => m.div(det(m, c.map((v, k) => k === j ? rhs : v)), d));
    if (values.some((v) => v.n < 0n)) continue;
    const out = [ZERO3, ZERO3, ZERO3, ZERO3];
    ids.forEach((id, j) => out[id] = values[j]);
    return out;
  }
  return null;
}
function solveCore(raw, count) {
  const m = new Exact();
  let input = null;
  try {
    const root = fields2(data(raw), ["bodies", "points"]);
    need(Array.isArray(root.bodies) && Array.isArray(root.points), "INVALID_INPUT", "body and point lists required");
    need(root.bodies.length === count + 1 && root.points.length === 4 * count, "UNSUPPORTED_PROFILE", "stationary population");
    input = root;
    const ids = /* @__PURE__ */ new Map();
    let floor2 = -1, dynamics = 0;
    for (const [i, b2] of input.bodies.entries()) {
      fields2(b2, ["id", "positionM", "velocityMps", "angularVelocityRadps", "inverseMass", "inverseInertiaWorld"]);
      need(typeof b2.id === "string" && /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/.test(b2.id) && !ids.has(b2.id), "INVALID_INPUT", "body identity");
      ids.set(b2.id, i);
      vec(b2.positionM);
      vec(b2.velocityMps, 3, 1e3);
      vec(b2.angularVelocityRadps, 3, 1e3);
      need(Array.isArray(b2.inverseInertiaWorld) && b2.inverseInertiaWorld.length === 3, "INVALID_INPUT", "inertia matrix");
      b2.inverseInertiaWorld.forEach((x) => vec(x, 3, 1e6));
      const fixed = b2.inverseMass === 0;
      need(fixed || b2.inverseMass === 1, "UNSUPPORTED_PROFILE", "unit dynamic mass");
      need(b2.inverseInertiaWorld.every((r, i2) => r.every((v2, j) => v2 === (fixed ? 0 : i2 === j ? 24 : 0))), "UNSUPPORTED_PROFILE", "isotropic24 inertia");
      need(b2.angularVelocityRadps.every((x) => x === 0) && b2.velocityMps[0] === 0 && b2.velocityMps[2] === 0 && b2.velocityMps[1] <= 0 && -b2.velocityMps[1] <= 1, "UNSUPPORTED_PROFILE", "stationary free motion");
      if (fixed) {
        need(floor2 === -1 && b2.velocityMps[1] === 0, "UNSUPPORTED_PROFILE", "one fixed floor");
        floor2 = i;
      } else dynamics++;
    }
    need(floor2 >= 0 && dynamics === count, "UNSUPPORTED_PROFILE", "one floor and complete dynamics");
    const seen = /* @__PURE__ */ new Set(), rows = [], edges = /* @__PURE__ */ new Map();
    for (const [index, p] of input.points.entries()) {
      fields2(p, ["id", "aId", "bId", "pointM", "normalAtoB"]);
      need(typeof p.id === "string" && p.id.length > 0 && p.id.length <= 4096 && !seen.has(p.id) && ids.has(p.aId) && ids.has(p.bId) && p.aId !== p.bId, "INVALID_INPUT", "point identity");
      seen.add(p.id);
      vec(p.pointM);
      vec(p.normalAtoB, 3, 1);
      need(p.normalAtoB[0] === 0 && p.normalAtoB[2] === 0 && Math.abs(p.normalAtoB[1]) === 1, "UNSUPPORTED_PROFILE", "exact vertical normal");
      const a2 = ids.get(p.aId), b2 = ids.get(p.bId);
      const ca = coefficients(input.bodies[a2], p, -1), cb = coefficients(input.bodies[b2], p, 1);
      need([ca, cb].every((c) => c[0] === 0 && c[2] === 0 && c[4] === 0), "UNSUPPORTED_PROFILE", "other Jacobian dofs must be zero");
      rows.push({ a: a2, b: b2, ca, cb, qa: ca.map((x) => m.from(x)), qb: cb.map((x) => m.from(x)) });
      const lower = ca[1] === -1 ? a2 : b2, upper = lower === a2 ? b2 : a2, key = lower + "\0" + upper;
      let edge = edges.get(key);
      if (!edge) {
        edge = { lower, upper, rows: [] };
        edges.set(key, edge);
      }
      edge.rows.push(index);
    }
    need(edges.size === count && [...edges.values()].every((e) => e.rows.length === 4), "UNSUPPORTED_PROFILE", "four points per chain interface");
    const above = /* @__PURE__ */ new Map(), below = /* @__PURE__ */ new Map();
    for (const e of edges.values()) {
      need(!above.has(e.lower) && !below.has(e.upper) && e.upper !== floor2, "UNSUPPORTED_PROFILE", "unbranched directed chain");
      above.set(e.lower, e);
      below.set(e.upper, e);
    }
    const chain = [floor2];
    while (above.has(chain[chain.length - 1])) {
      const next = above.get(chain[chain.length - 1]).upper;
      need(!chain.includes(next), "UNSUPPORTED_PROFILE", "acyclic chain");
      chain.push(next);
    }
    need(chain.length === count + 1, "UNSUPPORTED_PROFILE", "connected floor-to-top chain");
    const incoming = input.bodies.map(() => [ZERO3, ZERO3, ZERO3]), lambda = rows.map(() => ZERO3);
    for (let k = chain.length - 1; k > 0; k--) {
      const body = chain[k], edge = below.get(body);
      const rhs = [
        m.sub(m.neg(m.from(input.bodies[body].velocityMps[1])), incoming[body][0]),
        m.neg(incoming[body][1]),
        m.neg(incoming[body][2])
      ];
      const columns = edge.rows.map((i) => {
        const row = rows[i], c = row.a === body ? row.qa : row.qb;
        return [c[1], c[3], c[5]];
      });
      const chosen = triangle(m, columns, rhs);
      need(chosen, "NO_WITNESS", "greedy support triangle not found");
      for (let j = 0; j < 4; j++) {
        const index = edge.rows[j], row = rows[index], q = chosen[j], c = row.a === edge.lower ? row.qa : row.qb;
        lambda[index] = q;
        for (let d = 0; d < 3; d++) incoming[edge.lower][d] = m.add(incoming[edge.lower][d], m.mul(c[[1, 3, 5][d]], q));
      }
      m.stats.interfacesProcessed++;
    }
    const balances = input.bodies.map((b2) => [...b2.velocityMps.map((x) => m.from(x)), ZERO3, ZERO3, ZERO3]);
    for (let i = 0; i < rows.length; i++) {
      need(lambda[i].n >= 0n, "NUMERIC_LIMIT", "negative exact multiplier");
      for (const [body, c] of [[rows[i].a, rows[i].qa], [rows[i].b, rows[i].qb]]) {
        if (body === floor2) continue;
        for (let d = 0; d < 6; d++) balances[body][d] = m.add(balances[body][d], m.mul(c[d], lambda[i]));
      }
    }
    for (let i = 0; i < input.bodies.length; i++) {
      if (i !== floor2) need(balances[i].every((q) => q.n === 0n), "NUMERIC_LIMIT", "global exact stationarity failed");
    }
    for (const row of rows) {
      let primal = ZERO3;
      for (let d = 0; d < 6; d++) primal = m.add(primal, m.add(m.mul(row.qa[d], ZERO3), m.mul(row.qb[d], ZERO3)));
      need(primal.n === 0n, "NUMERIC_LIMIT", "global exact primal failed");
    }
    const rounded = lambda.map((q) => m.number(q));
    const bodies = input.bodies.map((b2, i) => ({
      ...b2,
      positionM: [...b2.positionM],
      velocityMps: i === floor2 ? [...b2.velocityMps] : [0, 0, 0],
      angularVelocityRadps: i === floor2 ? [...b2.angularVelocityRadps] : [0, 0, 0],
      inverseInertiaWorld: b2.inverseInertiaWorld.map((r) => [...r])
    }));
    const applied = input.bodies.map(() => [0, 0, 0, 0, 0, 0]);
    for (let i = 0; i < rows.length; i++) {
      for (const [body, c] of [[rows[i].a, rows[i].ca], [rows[i].b, rows[i].cb]]) {
        for (let d = 0; d < 6; d++) applied[body][d] += c[d] * rounded[i];
      }
    }
    let v = 0, w = 0, stationarity = 0;
    for (const [i, b2] of input.bodies.entries()) if (i !== floor2) {
      for (let d = 0; d < 3; d++) {
        const dv = b2.velocityMps[d] + applied[i][d], dw = 24 * applied[i][d + 3];
        v = Math.max(v, Math.abs(dv));
        w = Math.max(w, Math.abs(dw));
        stationarity = Math.max(stationarity, Math.abs(dv), Math.abs(dw) / Math.sqrt(24));
      }
    }
    need([v, w, stationarity, ...rounded].every(Number.isFinite), "NUMERIC_LIMIT", "nonfinite rounded diagnostic");
    return {
      ok: true,
      status: "SOLVED_STATIONARY_WITNESS",
      reason: null,
      bodies,
      normalImpulsesNs: rounded,
      exactApplied: {
        format: "STATIONARY_FLOAT_J_RATIOS_V1",
        points: input.points.map((p, i) => ({
          id: p.id,
          a: { bodyId: p.aId, coefficients: rows[i].ca, words: rows[i].ca.map(word) },
          b: { bodyId: p.bId, coefficients: rows[i].cb, words: rows[i].cb.map(word) },
          lambda: ratio3(lambda[i]),
          roundedWord: word(rounded[i])
        })),
        dynamicResiduals: input.bodies.flatMap((b2, i) => i === floor2 ? [] : [{ bodyId: b2.id, values: balances[i].map(ratio3) }]),
        allRowsPrimalZero: true,
        allRowsComplementarityZero: true,
        nonnegative: true
      },
      roundedReconstruction: { maxVelocityErrorMps: v, maxAngularVelocityErrorRadps: w, maxUnscaledMassWeightedResidualSqrtJ: stationarity },
      stats: { ...m.stats }
    };
  } catch (e) {
    if (!(e instanceof Stop)) throw e;
    return {
      ok: false,
      status: e.status,
      reason: e.message,
      bodies: input?.bodies ?? [],
      normalImpulsesNs: null,
      exactApplied: null,
      roundedReconstruction: null,
      stats: { ...m.stats }
    };
  }
}
function solveStationaryNormal(problem) {
  return solveCore(problem, 8);
}

// src/stack/normal-bridge.ts
var NormalPhaseFailure = class extends PhysicsError {
  problem;
  result;
  stationaryWitness;
  constructor(reason, problem, result, stationaryWitness) {
    super(reason.code, reason.message);
    this.problem = structuredClone(problem);
    this.result = structuredClone(result);
    this.stationaryWitness = structuredClone(stationaryWitness);
  }
};
function diagnoseStationaryNormal(problem, witness) {
  requireNormal(
    witness.ok && witness.status === "SOLVED_STATIONARY_WITNESS" && witness.exactApplied && witness.normalImpulsesNs && witness.roundedReconstruction,
    "exact stationary witness required"
  );
  requireNormal(witness.bodies.length === problem.bodies.length && witness.normalImpulsesNs.length === problem.points.length, "stationary result population");
  requireNormal(
    witness.roundedReconstruction.maxVelocityErrorMps <= 1e-10 && witness.roundedReconstruction.maxAngularVelocityErrorRadps <= 1e-10,
    "rounded impulse reconstruction exceeds1e-10"
  );
  const ids = new Map(problem.bodies.map((body, i) => [body.id, i]));
  const reaction = problem.bodies.map(() => [0, 0, 0, 0, 0, 0]);
  const root = Math.sqrt(24);
  for (let i = 0; i < problem.points.length; i++) {
    const point2 = problem.points[i], lambda = witness.normalImpulsesNs[i];
    requireNormal(Number.isFinite(lambda) && lambda >= 0, "rounded nonnegative impulse");
    for (const [id, sign] of [[point2.aId, -1], [point2.bId, 1]]) {
      const index = ids.get(id);
      requireNormal(index !== void 0, "stationary endpoint");
      const body = problem.bodies[index];
      if (body.inverseMass === 0) continue;
      const arm = point2.pointM.map((value, k) => value - body.positionM[k]);
      const n = point2.normalAtoB;
      const torque = [
        arm[1] * n[2] - arm[2] * n[1],
        arm[2] * n[0] - arm[0] * n[2],
        arm[0] * n[1] - arm[1] * n[0]
      ];
      for (let k = 0; k < 3; k++) {
        reaction[index][k] += sign * n[k] * lambda;
        let coefficient = 0;
        for (let j = 0; j < 3; j++) coefficient += torque[j] * (j === k ? root : 0);
        reaction[index][k + 3] += sign * coefficient * lambda;
      }
    }
  }
  let stationarity = 0;
  for (const [i, body] of problem.bodies.entries()) if (body.inverseMass !== 0) {
    for (let k = 0; k < 6; k++) {
      stationarity = Math.max(stationarity, Math.abs(-(k < 3 ? body.velocityMps[k] : 0) - reaction[i][k]));
    }
  }
  requireNormal(
    Number.isFinite(stationarity) && stationarity <= 1e-10,
    "rounded scaled stationarity exceeds1e-10"
  );
  const bodies = witness.bodies.map((body) => structuredClone(body));
  const byId = new Map(bodies.map((body) => [body.id, body]));
  const rowResiduals = problem.points.map((point2, i) => {
    const a2 = byId.get(point2.aId), b2 = byId.get(point2.bId);
    requireNormal(a2 && b2, "stationary result endpoints");
    const va = pointVelocity(a2, point2.pointM), vb = pointVelocity(b2, point2.pointM);
    const relative = vb.map((value, k) => value - va[k]);
    const vn = relative.reduce((sum, value, k) => sum + value * point2.normalAtoB[k], 0);
    const tangent = relative.map((value, k) => value - vn * point2.normalAtoB[k]);
    return {
      id: point2.id,
      normalSpeedMps: vn,
      negativeNormalImpulseNs: Math.max(0, -witness.normalImpulsesNs[i]),
      complementarityJ: Math.abs(witness.normalImpulsesNs[i] * vn),
      tangentSpeedMps: Math.hypot(...tangent)
    };
  });
  const certificate2 = {
    maxClosingNormalSpeedMps: Math.max(0, ...rowResiduals.map((row) => -row.normalSpeedMps)),
    maxNegativeNormalImpulseNs: Math.max(0, ...rowResiduals.map((row) => row.negativeNormalImpulseNs)),
    maxComplementarityJ: Math.max(0, ...rowResiduals.map((row) => row.complementarityJ)),
    maxStationaritySqrtJ: stationarity,
    maxLoadedTangentSpeedMps: Math.max(0, ...rowResiduals.filter((_, i) => witness.normalImpulsesNs[i] > 0).map((row) => row.tangentSpeedMps)),
    zeroTangentFeasible: false
  };
  certificate2.zeroTangentFeasible = certificate2.maxLoadedTangentSpeedMps <= 1e-10;
  requireNormal(Object.values(certificate2).every((value) => typeof value !== "number" || Number.isFinite(value) && value <= 1e-10), "finite rounded normal certificate");
  return {
    ok: true,
    status: "SOLVED_NORMAL_ONLY",
    bodies,
    normalImpulsesNs: [...witness.normalImpulsesNs],
    rowResiduals,
    certificate: certificate2,
    stats: { ...witness.stats },
    solver: "EXACT_STATIONARY_FLOAT_J_V1",
    reason: null
  };
}
function requireNormal(ok, message) {
  if (!ok) throw new PhysicsError("NUMERIC_LIMIT", "bounded stack normal: " + message);
}
function pointVelocity(body, point2) {
  const r = point2.map((value, i) => value - body.positionM[i]);
  const w = body.angularVelocityRadps;
  return [
    body.velocityMps[0] + w[1] * r[2] - w[2] * r[1],
    body.velocityMps[1] + w[2] * r[0] - w[0] * r[2],
    body.velocityMps[2] + w[0] * r[1] - w[1] * r[0]
  ];
}
function solveStackNormal(bodies, patches) {
  const inputBodies = bodies.map((body) => {
    const inverseInertiaWorld = body.kind === "dynamic" ? [[24, 0, 0], [0, 24, 0], [0, 0, 24]] : [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    return {
      id: body.id,
      positionM: [...body.positionM],
      velocityMps: [...body.velocityMps],
      angularVelocityRadps: [...body.angularVelocityRadps],
      inverseMass: body.inverseMass,
      inverseInertiaWorld
    };
  });
  const points = [];
  for (const patch of patches) {
    requireNormal(bodies[patch.aIndex]?.id === patch.aId && bodies[patch.bIndex]?.id === patch.bId && patch.pairKey === patch.aId + "\0" + patch.bId, "frozen patch identity");
    for (const point2 of patch.points) {
      points.push({
        id: JSON.stringify([patch.pairKey, point2.id]),
        aId: patch.aId,
        bId: patch.bId,
        pointM: [...point2.pointM],
        normalAtoB: [...patch.normal]
      });
    }
  }
  requireNormal(points.length <= 32, "more than32 actual points");
  const problem = { bodies: inputBodies, points };
  let result = null;
  let stationaryWitness = null;
  try {
    stationaryWitness = solveStationaryNormal(problem);
    if (!stationaryWitness.ok) throw new PhysicsError(
      stationaryWitness.status === "RESOURCE_LIMIT" ? "ITERATION_LIMIT" : "NUMERIC_LIMIT",
      "bounded stack stationary normal: " + stationaryWitness.status + ": " + stationaryWitness.reason
    );
    result = diagnoseStationaryNormal(problem, stationaryWitness);
    requireNormal(
      result.status === "SOLVED_NORMAL_ONLY" && result.normalImpulsesNs && result.rowResiduals && result.certificate && result.bodies.length === bodies.length && result.normalImpulsesNs.length === points.length && result.rowResiduals.length === points.length,
      "complete normal solution required"
    );
    requireNormal(result.certificate.zeroTangentFeasible && result.certificate.maxLoadedTangentSpeedMps <= 1e-10, "loaded tangent speed exceeds1e-10");
    const resultById = new Map(result.bodies.map((body) => [body.id, body]));
    for (let i = 0; i < points.length; i++) {
      const lambda = result.normalImpulsesNs[i], point2 = points[i];
      requireNormal(Number.isFinite(lambda) && lambda >= 0, "invalid normal impulse");
      if (lambda === 0) continue;
      const a2 = resultById.get(point2.aId), b2 = resultById.get(point2.bId);
      requireNormal(a2 && b2, "result endpoint missing");
      const va = pointVelocity(a2, point2.pointM), vb = pointVelocity(b2, point2.pointM);
      const relative = vb.map((value, k) => value - va[k]);
      const vn = relative.reduce((sum, value, k) => sum + value * point2.normalAtoB[k], 0);
      const tangent = relative.map((value, k) => value - vn * point2.normalAtoB[k]);
      requireNormal(
        Math.hypot(...tangent) <= 1e-10 && result.rowResiduals[i].tangentSpeedMps <= 1e-10,
        "independent loaded tangent speed exceeds1e-10"
      );
    }
    for (let i = 0; i < bodies.length; i++) {
      requireNormal(result.bodies[i].id === bodies[i].id && result.bodies[i].positionM.every((v, j) => v === bodies[i].positionM[j]), "body order or pose changed");
    }
    const pointLedger = [];
    const seen = /* @__PURE__ */ new Set();
    let index = 0;
    for (const patch of patches) for (const point2 of patch.points) {
      const key = patch.pairKey + "\0" + point2.id;
      requireNormal(!seen.has(key), "duplicate actual point key");
      seen.add(key);
      pointLedger.push({
        aId: patch.aId,
        bId: patch.bId,
        aIndex: patch.aIndex,
        bIndex: patch.bIndex,
        pairKey: patch.pairKey,
        pointId: point2.id,
        family: patch.family,
        pointM: [...point2.pointM],
        normal: [...patch.normal],
        aPositionM: [...bodies[patch.aIndex].positionM],
        bPositionM: [...bodies[patch.bIndex].positionM],
        warm: { normalNs: 0, tangentNs: [0, 0, 0] },
        final: { normalNs: result.normalImpulsesNs[index++], tangentNs: [0, 0, 0] }
      });
    }
    requireNormal(pointLedger.length === points.length, "complete point ledger");
    for (let i = 0; i < bodies.length; i++) {
      bodies[i].velocityMps = [...result.bodies[i].velocityMps];
      bodies[i].angularVelocityRadps = [...result.bodies[i].angularVelocityRadps];
    }
    return { problem, result, pointLedger, stationaryWitness };
  } catch (caught) {
    if (caught instanceof PhysicsError) throw new NormalPhaseFailure(caught, problem, result, stationaryWitness);
    throw caught;
  }
}

// src/stack/full-pair-input.mjs
var MESSAGES = Object.freeze({
  input: "full-pair position reference input is invalid",
  limit: "full-pair position reference admits at most nine bodies and thirty-six rows",
  empty: "full-pair position reference requires at least one body",
  ids: "full-pair position reference body IDs must be nonempty and unique",
  mass: "full-pair position reference inverse mass is invalid",
  endpoints: "full-pair position reference row endpoints are invalid",
  normal: "full-pair position reference normal must be finite and unit length",
  bound: "full-pair position reference bound must be finite and between minus ten and ten metres",
  result: "full-pair position reference result is invalid",
  workLimits: "full-pair position reference work limits are invalid"
});
var FullPairPositionReferenceError = class extends Error {
  constructor(code, message) {
    super(message);
    this.name = "FullPairPositionReferenceError";
    this.code = code;
  }
};
var DEFAULT_LIMITS = Object.freeze({
  iterations: 1024,
  activeChanges: 1024,
  rankChecks: 2048,
  linearSolves: 2048,
  constraintTests: 262144,
  exactIntegerOperations: 1e6,
  reducedRationalBits: 8192,
  intermediateIntegerBits: 16385
});
var COUNTER_KEYS = Object.freeze(["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "factorizations", "blockRightHandSides", "exactIntegerOperations", "exactPeakBits"]);
function zeroFullPairCounters() {
  return Object.fromEntries(COUNTER_KEYS.map((k) => [k, 0]));
}
function requireFull(condition, key = "input", code = "INVALID_INPUT") {
  if (!condition) throw new FullPairPositionReferenceError(code, MESSAGES[key]);
}
function dataRecord(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return null;
  const own = Reflect.ownKeys(value);
  if (own.length !== keys.length || own.some((k) => typeof k !== "string" || !keys.includes(k))) return null;
  const copy2 = {};
  for (const k of keys) {
    const d = Object.getOwnPropertyDescriptor(value, k);
    if (!d || !Object.hasOwn(d, "value")) return null;
    Object.defineProperty(copy2, k, { value: d.value, enumerable: true, writable: true, configurable: true });
  }
  return copy2;
}
function dataArray(value, size2) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) return null;
  const length = Object.getOwnPropertyDescriptor(value, "length");
  if (!length || !Object.hasOwn(length, "value") || !Number.isSafeInteger(length.value) || length.value < 0) return null;
  const n = length.value;
  if (size2 !== void 0 && n !== size2) return null;
  const own = Reflect.ownKeys(value);
  if (own.length !== n + 1) return null;
  const copy2 = [];
  for (let i = 0; i < n; i++) {
    const d = Object.getOwnPropertyDescriptor(value, String(i));
    if (!d || !Object.hasOwn(d, "value")) return null;
    copy2.push(d.value);
  }
  return copy2;
}
function dataFiniteVector(value, size2) {
  const a2 = dataArray(value, size2);
  return a2 && a2.every((v) => typeof v === "number" && Number.isFinite(v)) ? a2 : null;
}
function validateFullPairProblem(value) {
  const p = dataRecord(value, ["bodies", "rows"]);
  requireFull(p !== null);
  const bodies = dataArray(p.bodies), rows = dataArray(p.rows);
  requireFull(bodies !== null && rows !== null);
  requireFull(bodies.length <= 9 && rows.length <= 36, "limit", "PROFILE_LIMIT");
  requireFull(bodies.length > 0, "empty");
  const checkedBodies = [], ids = /* @__PURE__ */ new Set();
  for (const raw of bodies) {
    const b2 = dataRecord(raw, ["id", "inverseMass"]);
    requireFull(b2 !== null);
    requireFull(typeof b2.id === "string" && b2.id.length > 0 && !ids.has(b2.id), "ids");
    ids.add(b2.id);
    requireFull(typeof b2.inverseMass === "number" && Number.isFinite(b2.inverseMass) && (b2.inverseMass === 0 || b2.inverseMass >= 1e-6 && b2.inverseMass <= 1e6), "mass");
    checkedBodies.push({ id: b2.id, inverseMass: b2.inverseMass });
  }
  const checkedRows = [];
  for (const raw of rows) {
    const row = dataRecord(raw, ["aId", "bId", "normal", "boundM"]);
    requireFull(row !== null);
    requireFull(ids.has(row.aId) && ids.has(row.bId) && row.aId !== row.bId, "endpoints");
    const normal = dataFiniteVector(row.normal, 3);
    requireFull(normal !== null && Math.abs(Math.hypot(...normal) - 1) <= 1e-12, "normal");
    requireFull(typeof row.boundM === "number" && Number.isFinite(row.boundM) && row.boundM >= -10 && row.boundM <= 10, "bound");
    checkedRows.push({ aId: row.aId, bId: row.bId, normal: [...normal], boundM: row.boundM });
  }
  return { bodies: checkedBodies, rows: checkedRows };
}
function validateWorkLimits(value) {
  const limits = dataRecord(value, Object.keys(DEFAULT_LIMITS));
  requireFull(limits !== null, "workLimits");
  for (const k of Object.keys(DEFAULT_LIMITS)) requireFull(Number.isSafeInteger(limits[k]) && limits[k] >= 0 && limits[k] <= DEFAULT_LIMITS[k], "workLimits");
  return { ...limits };
}
var CoreStop = class extends Error {
  constructor(status, reason) {
    super(reason);
    this.name = "FullPairCoreStop";
    this.status = status;
    this.reason = reason;
  }
};
function unsafe(reason) {
  throw new CoreStop("NUMERIC_UNSAFE", reason);
}
function finite3(value) {
  if (!Number.isFinite(value)) unsafe("nonfinite");
  return value;
}
function createMeter(limits = DEFAULT_LIMITS) {
  const selected2 = validateWorkLimits(limits), counters = zeroFullPairCounters();
  return {
    limits: selected2,
    counters,
    take(key, amount = 1) {
      const next = counters[key] + amount;
      if (!Number.isSafeInteger(next) || next > selected2[key]) throw new CoreStop("WORK_LIMIT", "budget:" + key);
      counters[key] = next;
    },
    bits(value, reduced = false) {
      const size2 = value === 0n ? 0 : (value < 0n ? -value : value).toString(2).length;
      const key = reduced ? "reducedRationalBits" : "intermediateIntegerBits";
      if (size2 > selected2[key]) throw new CoreStop("WORK_LIMIT", "budget:" + key);
      counters.exactPeakBits = Math.max(counters.exactPeakBits, size2);
      return size2;
    },
    plannedBits(size2) {
      if (size2 > selected2.intermediateIntegerBits) throw new CoreStop("WORK_LIMIT", "budget:intermediateIntegerBits");
    }
  };
}

// src/stack/full-pair-linear.mjs
var EPS = 1e-12;
var PIVOT = 1e-14;
var normInfVector = (v) => Math.max(0, ...v.map(Math.abs));
var normInfMatrix = (m) => Math.max(0, ...m.map((row) => row.reduce((s, v) => finite3(s + Math.abs(v)), 0)));
function dot3(a2, b2) {
  let sum = 0;
  for (let i = 0; i < a2.length; i++) sum = finite3(sum + finite3(a2[i] * b2[i]));
  return sum;
}
function prepareModel(problem) {
  const offsets = [], D = [];
  for (const body of problem.bodies) {
    if (body.inverseMass === 0) offsets.push(null);
    else {
      offsets.push(D.length);
      D.push(body.inverseMass, body.inverseMass, body.inverseMass);
    }
  }
  const locations = new Map(problem.bodies.map((b3, i) => [b3.id, i]));
  const A = problem.rows.map((row) => {
    const a2 = Array(D.length).fill(0), ia = offsets[locations.get(row.aId)], ib = offsets[locations.get(row.bId)];
    for (let k = 0; k < 3; k++) {
      if (ia !== null) a2[ia + k] = -row.normal[k];
      if (ib !== null) a2[ib + k] = row.normal[k];
    }
    return a2;
  });
  const b2 = problem.rows.map((row) => row.boundM), G = A.map((left) => A.map((right) => {
    let sum = 0;
    for (let k = 0; k < D.length; k++) sum = finite3(sum + finite3(finite3(left[k] * D[k]) * right[k]));
    return sum;
  }));
  return { problem, A, b: b2, D, G, offsets, dynamicDof: D.length };
}
function reconstruct(model2, lambda) {
  return model2.D.map((inverseMass, k) => {
    let sum = 0;
    for (let i = 0; i < model2.A.length; i++) sum = finite3(sum + finite3(model2.A[i][k] * lambda[i]));
    return finite3(inverseMass * sum);
  });
}
function margins(model2, u, meter) {
  return model2.A.map((row, i) => {
    meter?.take("constraintTests");
    return finite3(dot3(row, u) - model2.b[i]);
  });
}
function translations(model2, u) {
  return model2.problem.bodies.map((body, i) => ({ id: body.id, u: model2.offsets[i] === null ? [0, 0, 0] : u.slice(model2.offsets[i], model2.offsets[i] + 3) }));
}
function fullCertificate(model2, u, lambda, meter) {
  const primalMarginsM = margins(model2, u, meter);
  let stationarityKgM = 0;
  for (let k = 0; k < u.length; k++) {
    let sum = 0;
    for (let i = 0; i < lambda.length; i++) sum = finite3(sum + finite3(model2.A[i][k] * lambda[i]));
    stationarityKgM = Math.max(stationarityKgM, Math.abs(finite3(u[k] / model2.D[k] - sum)));
  }
  const certificate2 = {
    primalViolationM: Math.max(0, ...primalMarginsM.map((v) => -v)),
    negativeMultiplierKgM: Math.max(0, ...lambda.map((v) => -v)),
    complementarityKgM2: Math.max(0, ...lambda.map((v, i) => Math.abs(finite3(v * primalMarginsM[i])))),
    stationarityKgM
  };
  let objectiveKgM2 = 0;
  for (let i = 0; i < model2.problem.bodies.length; i++) {
    const start = model2.offsets[i];
    if (start === null) continue;
    let square = 0;
    for (let k = 0; k < 3; k++) square = finite3(square + finite3(u[start + k] * u[start + k]));
    objectiveKgM2 = finite3(objectiveKgM2 + finite3(square / model2.problem.bodies[i].inverseMass / 2));
  }
  return { primalMarginsM, certificate: certificate2, objectiveKgM2 };
}
function checkIterate(model2, u, lambda, W, pending, meter) {
  if (u.some((v) => !Number.isFinite(v)) || lambda.some((v) => !Number.isFinite(v))) unsafe("nonfinite");
  if (lambda.some((v) => v < 0)) unsafe("negative-multiplier");
  const allowed = new Set(W);
  if (pending !== null) allowed.add(pending);
  if (lambda.some((v, i) => v !== 0 && !allowed.has(i))) unsafe("iterate-certificate");
  for (const i of W) {
    meter.take("constraintTests");
    if (Math.abs(finite3(dot3(model2.A[i], u) - model2.b[i])) > EPS) unsafe("iterate-certificate");
  }
  for (let k = 0; k < u.length; k++) {
    let sum = 0;
    for (let i = 0; i < lambda.length; i++) sum = finite3(sum + finite3(model2.A[i][k] * lambda[i]));
    if (Math.abs(finite3(u[k] / model2.D[k] - sum)) > EPS) unsafe("iterate-certificate");
  }
}
function solveBasis(matrix3, rhs, meter) {
  const n = rhs.length;
  if (n === 0) return { r: [], inverse: [], condition: null };
  meter.take("linearSolves");
  meter.counters.factorizations++;
  meter.counters.blockRightHandSides += 1 + n;
  const scale4 = Math.max(1, ...matrix3.flat().map(Math.abs)), aug = matrix3.map((row, i) => [...row, rhs[i], ...Array.from({ length: n }, (_, j) => i === j ? 1 : 0)]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let row = col + 1; row < n; row++) if (Math.abs(aug[row][col]) > Math.abs(aug[pivot][col])) pivot = row;
    if (!Number.isFinite(aug[pivot][col])) unsafe("nonfinite");
    if (Math.abs(aug[pivot][col]) <= PIVOT * scale4) unsafe("pivot");
    [aug[pivot], aug[col]] = [aug[col], aug[pivot]];
    for (let row = col + 1; row < n; row++) {
      const ratio4 = finite3(aug[row][col] / aug[col][col]);
      for (let k = col; k < 2 * n + 1; k++) aug[row][k] = finite3(aug[row][k] - finite3(ratio4 * aug[col][k]));
    }
  }
  const solved = Array.from({ length: n }, () => Array(n + 1).fill(0));
  for (let row = n - 1; row >= 0; row--) for (let k = 0; k < n + 1; k++) {
    let value = aug[row][n + k];
    for (let col = row + 1; col < n; col++) value = finite3(value - finite3(aug[row][col] * solved[col][k]));
    solved[row][k] = finite3(value / aug[row][row]);
  }
  const r = solved.map((row) => row[0]), inverse2 = solved.map((row) => row.slice(1));
  const normG = normInfMatrix(matrix3), condition = finite3(normG * normInfMatrix(inverse2));
  if (condition > 1e12) unsafe("condition");
  const residual = normInfVector(matrix3.map((row, i) => finite3(dot3(row, r) - rhs[i]))), denominator = finite3(Math.max(1, finite3(normG * normInfVector(r)) + normInfVector(rhs)));
  if (finite3(residual / denominator) > EPS) unsafe("factor-residual");
  const product2 = matrix3.map((row, i) => Array.from({ length: n }, (_, j) => finite3(dot3(row, inverse2.map((x) => x[j])) - (i === j ? 1 : 0))));
  if (normInfMatrix(product2) > EPS) unsafe("factor-residual");
  return { r, inverse: inverse2, condition };
}
function direction(model2, W, p, r, meter) {
  const z = model2.D.map((inv, k) => {
    let projection = 0;
    for (let j = 0; j < W.length; j++) projection = finite3(projection + finite3(model2.A[W[j]][k] * r[j]));
    return finite3(inv * finite3(model2.A[p][k] - projection));
  });
  meter.take("rankChecks");
  const delta = dot3(model2.A[p], z), scale4 = Math.max(1, model2.G[p][p]);
  let zMz = 0;
  for (let k = 0; k < z.length; k++) zMz = finite3(zMz + finite3(finite3(z[k] * z[k]) / model2.D[k]));
  const orthogonal = normInfVector(W.map((i) => dot3(model2.A[i], z))), orthScale = Math.max(1, ...W.map((i) => Math.abs(model2.G[i][p])), ...W.map((i) => {
    let sum = 0;
    for (let j = 0; j < W.length; j++) sum = finite3(sum + Math.abs(finite3(model2.G[i][W[j]] * r[j])));
    return sum;
  }));
  if (finite3(orthogonal / orthScale) > EPS || finite3(Math.abs(finite3(delta - zMz)) / Math.max(1, Math.abs(delta), Math.abs(zMz), Math.abs(model2.G[p][p]))) > EPS) unsafe("direction-residual");
  if (delta < -PIVOT * scale4) unsafe("direction-residual");
  return { z, delta, near: Math.abs(delta) <= PIVOT * scale4 || W.length + 1 > model2.dynamicDof };
}

// src/stack/full-pair-exact.mjs
var ZERO4 = Object.freeze({ n: 0n, d: 1n });
var ONE2 = Object.freeze({ n: 1n, d: 1n });
var bits = (x) => x === 0n ? 0 : (x < 0n ? -x : x).toString(2).length;
function operation(meter, estimate, fn) {
  meter.plannedBits(estimate);
  meter.take("exactIntegerOperations");
  const x = fn();
  meter.bits(x);
  return x;
}
var addI = (a2, b2, m) => operation(m, Math.max(bits(a2), bits(b2)) + 1, () => a2 + b2);
var subI = (a2, b2, m) => operation(m, Math.max(bits(a2), bits(b2)) + 1, () => a2 - b2);
var mulI = (a2, b2, m) => operation(m, bits(a2) + bits(b2), () => a2 * b2);
var divI = (a2, b2, m) => operation(m, bits(a2), () => a2 / b2);
var remI = (a2, b2, m) => operation(m, bits(a2), () => a2 % b2);
var shiftI = (a2, k, m) => operation(m, bits(a2) + k, () => a2 << BigInt(k));
function absI(a2, m) {
  return a2 < 0n ? subI(0n, a2, m) : a2;
}
function gcd(a2, b2, m) {
  a2 = absI(a2, m);
  b2 = absI(b2, m);
  while (b2 !== 0n) {
    const next = remI(a2, b2, m);
    a2 = b2;
    b2 = next;
  }
  return a2;
}
function checked2(q, m) {
  m.bits(q.n, true);
  m.bits(q.d, true);
  return q;
}
function rational(n, d, m) {
  if (d === 0n) unsafe("uncertified-infeasibility");
  if (d < 0n) {
    n = subI(0n, n, m);
    d = subI(0n, d, m);
  }
  if (n === 0n) return checked2(ZERO4, m);
  const g = gcd(n, d, m);
  return checked2({ n: divI(n, g, m), d: divI(d, g, m) }, m);
}
function addQ(a2, b2, m) {
  if (a2.n === 0n) return checked2(b2, m);
  if (b2.n === 0n) return checked2(a2, m);
  return rational(addI(mulI(a2.n, b2.d, m), mulI(b2.n, a2.d, m), m), mulI(a2.d, b2.d, m), m);
}
function negQ(a2, m) {
  return a2.n === 0n ? checked2(ZERO4, m) : checked2({ n: subI(0n, a2.n, m), d: a2.d }, m);
}
function subQ(a2, b2, m) {
  return addQ(a2, negQ(b2, m), m);
}
function mulQ(a2, b2, m) {
  if (a2.n === 0n || b2.n === 0n) return checked2(ZERO4, m);
  return rational(mulI(a2.n, b2.n, m), mulI(a2.d, b2.d, m), m);
}
function divQ(a2, b2, m) {
  if (b2.n === 0n) unsafe("uncertified-infeasibility");
  if (a2.n === 0n) return checked2(ZERO4, m);
  return rational(mulI(a2.n, b2.d, m), mulI(a2.d, b2.n, m), m);
}
var text2 = (q) => `${q.n}/${q.d}`;
function fromNumber(value, m) {
  if (!Number.isFinite(value)) unsafe("nonfinite");
  if (value === 0) return checked2(ZERO4, m);
  const view = new DataView(new ArrayBuffer(8));
  view.setFloat64(0, value, false);
  const raw = view.getBigUint64(0, false);
  const sign = raw >> 63n, exponent = Number(raw >> 52n & 2047n), fraction = raw & (1n << 52n) - 1n;
  let n = exponent === 0 ? fraction : addI(1n << 52n, fraction, m), d = 1n;
  const shift = exponent === 0 ? -1074 : exponent - 1023 - 52;
  if (shift >= 0) n = shiftI(n, shift, m);
  else d = shiftI(d, -shift, m);
  if (sign) n = subI(0n, n, m);
  return rational(n, d, m);
}
function toNumber(q, m) {
  if (q.n === 0n) return 0;
  const negative = q.n < 0n, n = absI(q.n, m), d = q.d;
  let exponent = bits(n) - bits(d);
  if (exponent >= 0) {
    if (n < shiftI(d, exponent, m)) exponent--;
  } else if (shiftI(n, -exponent, m) < d) exponent--;
  if (exponent > 1023) unsafe("dependency-conversion");
  const quantum = Math.max(exponent - 52, -1074), numerator = quantum < 0 ? shiftI(n, -quantum, m) : n, denominator = quantum > 0 ? shiftI(d, quantum, m) : d;
  let significand = divI(numerator, denominator, m);
  const remainder = remI(numerator, denominator, m), twice = mulI(remainder, 2n, m);
  if (twice > denominator || twice === denominator && remI(significand, 2n, m) !== 0n) significand = addI(significand, 1n, m);
  const result = (negative ? -1 : 1) * Number(significand) * 2 ** quantum;
  if (!Number.isFinite(result) || result === 0 || result < 0 !== negative) unsafe("dependency-conversion");
  return result;
}
function makeExactSystem(model2, meter) {
  const A = model2.A.map((row) => row.map((x) => fromNumber(x, meter))), D = model2.D.map((x) => fromNumber(x, meter)), b2 = model2.b.map((x) => fromNumber(x, meter)), cache = /* @__PURE__ */ new Map();
  return { A, D, b: b2, gram(i, j) {
    const key = i + ":" + j;
    if (cache.has(key)) return cache.get(key);
    let sum = checked2(ZERO4, meter);
    for (let k = 0; k < D.length; k++) if (A[i][k].n !== 0n && A[j][k].n !== 0n) sum = addQ(sum, mulQ(mulQ(A[i][k], D[k], meter), A[j][k], meter), meter);
    cache.set(key, sum);
    return sum;
  } };
}
function solveExact(matrix3, rhs, m) {
  const n = rhs.length;
  if (n === 0) return [];
  m.take("linearSolves");
  m.counters.factorizations++;
  m.counters.blockRightHandSides++;
  const a2 = matrix3.map((row, i) => [...row, rhs[i]]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    while (pivot < n && a2[pivot][col].n === 0n) pivot++;
    if (pivot === n) unsafe("dependent-basis");
    [a2[col], a2[pivot]] = [a2[pivot], a2[col]];
    for (let row = col + 1; row < n; row++) {
      if (a2[row][col].n === 0n) continue;
      const ratio4 = divQ(a2[row][col], a2[col][col], m);
      for (let k = col; k <= n; k++) a2[row][k] = subQ(a2[row][k], mulQ(ratio4, a2[col][k], m), m);
    }
  }
  const x = Array(n).fill(ZERO4);
  for (let row = n - 1; row >= 0; row--) {
    let value = a2[row][n];
    for (let col = row + 1; col < n; col++) value = subQ(value, mulQ(a2[row][col], x[col], m), m);
    x[row] = divQ(value, a2[row][row], m);
  }
  return x;
}
function exactDependency(system, W, p, meter) {
  const rExact = solveExact(W.map((i) => W.map((j) => system.gram(i, j))), W.map((i) => system.gram(i, p)), meter);
  for (let k = 0; k < system.D.length; k++) {
    let projection = checked2(ZERO4, meter);
    for (let j = 0; j < W.length; j++) projection = addQ(projection, mulQ(system.A[W[j]][k], rExact[j], meter), meter);
    if (subQ(system.A[p][k], projection, meter).n !== 0n) return { dependent: false, rExact: [], r: [] };
  }
  return { dependent: true, rExact };
}
function dependencyNumbers(rExact, meter) {
  return rExact.map((x) => toNumber(x, meter));
}
function verifyWeights(system, weights, meter) {
  if (weights.length !== system.b.length || weights.some((w) => w.n < 0n)) return null;
  let sum = checked2(ZERO4, meter);
  for (const w of weights) sum = addQ(sum, w, meter);
  if (sum.n !== sum.d) return null;
  const dynamicDot = [];
  for (let k = 0; k < system.D.length; k++) {
    let dot7 = checked2(ZERO4, meter);
    for (let i = 0; i < weights.length; i++) dot7 = addQ(dot7, mulQ(system.A[i][k], weights[i], meter), meter);
    if (dot7.n !== 0n) return null;
    dynamicDot.push(text2(dot7));
  }
  let boundDot = checked2(ZERO4, meter);
  for (let i = 0; i < weights.length; i++) boundDot = addQ(boundDot, mulQ(system.b[i], weights[i], meter), meter);
  if (boundDot.n <= 0n) return null;
  return { weights: weights.map(text2), sumWeights: "1/1", dynamicDot, boundDotM: text2(boundDot) };
}
function makeInfeasibilityCertificate(system, W, p, rExact, meter) {
  const weights = Array(system.b.length).fill(ZERO4);
  weights[p] = checked2(ONE2, meter);
  for (let j = 0; j < W.length; j++) weights[W[j]] = negQ(rExact[j], meter);
  if (weights.some((w) => w.n < 0n)) unsafe("uncertified-infeasibility");
  let sum = checked2(ZERO4, meter);
  for (const w of weights) sum = addQ(sum, w, meter);
  if (sum.n <= 0n) unsafe("uncertified-infeasibility");
  const normalized = weights.map((w) => divQ(w, sum, meter)), proof = verifyWeights(system, normalized, meter);
  if (proof === null) unsafe("uncertified-infeasibility");
  return proof;
}
function parseCanonical(value, meter) {
  if (typeof value !== "string" || value.length > 4937 || !/^(?:0|-?[1-9][0-9]*)\/[1-9][0-9]*$/.test(value)) return null;
  const [ns, ds] = value.split("/");
  if (ns.replace("-", "").length > 2467 || ds.length > 2467) return null;
  meter.take("exactIntegerOperations");
  const n = BigInt(ns);
  meter.bits(n, true);
  meter.take("exactIntegerOperations");
  const d = BigInt(ds);
  meter.bits(d, true);
  const q = rational(n, d, meter);
  return text2(q) === value ? q : null;
}
function verifyInfeasibilityCertificate(problem, certificate2, meter = createMeter()) {
  const model2 = prepareModel(problem), system = makeExactSystem(model2, meter), weights = [];
  for (const value of certificate2.weights) {
    const q = parseCanonical(value, meter);
    if (q === null) return false;
    weights.push(q);
  }
  const checkedProof = verifyWeights(system, weights, meter);
  if (checkedProof === null) return false;
  return certificate2.sumWeights === "1/1" && certificate2.boundDotM === checkedProof.boundDotM && certificate2.dynamicDot.length === checkedProof.dynamicDot.length && certificate2.dynamicDot.every((x, i) => x === checkedProof.dynamicDot[i]);
}

// src/stack/full-pair-core.mjs
var copySafe = (s) => ({ uDynamic: [...s.u], lambdaKgM: [...s.lambda], pendingRow: s.pending, pendingLambdaKgM: s.pending === null ? 0 : s.lambda[s.pending], basisRows: [...s.W] });
function ieeeState(s) {
  const view = new DataView(new ArrayBuffer(8));
  const encode = (x) => {
    view.setFloat64(0, x, false);
    return view.getBigUint64(0, false).toString(16);
  };
  return s.W.join(",") + "|" + String(s.pending) + "|" + s.u.map(encode).join(",") + "|" + s.lambda.map(encode).join(",");
}
function context(state, meter) {
  return { iteration: meter.counters.iterations, enteringRow: state.pending, basisBefore: [...state.W], basisAfter: [...state.W], blocker: null, stepKgM: null, schurInverseKg: null, condition: null, exactDependent: null };
}
function traceEntry(ctx, action, state) {
  return { ...ctx, basisBefore: [...ctx.basisBefore], basisAfter: [...state.W], action };
}
function runFullPairCore(rawProblem, limits = DEFAULT_LIMITS) {
  const problem = validateFullPairProblem(rawProblem), meter = createMeter(limits), model2 = prepareModel(problem), n = problem.rows.length;
  let state = { u: Array(model2.dynamicDof).fill(0), lambda: Array(n).fill(0), W: [], pending: null }, ctx = context(state, meter), exact3 = null;
  const trace = [], seen = /* @__PURE__ */ new Set();
  const getExact = () => exact3 ?? (exact3 = makeExactSystem(model2, meter));
  const common = () => ({ basisRows: [...state.W], basisRank: state.W.length, dynamicDof: model2.dynamicDof, counters: { ...meter.counters }, trace: trace.map((x) => ({ ...x, basisBefore: [...x.basisBefore], basisAfter: [...x.basisAfter] })), lastSafeIterate: copySafe(state), worldStepped: false });
  const refused = (status, reason, proof = null) => ({ ok: false, status, ...common(), translations: null, lambdaKgM: null, primalMarginsM: null, objectiveKgM2: null, certificate: null, infeasibilityCertificate: proof, reason });
  try {
    for (let i = 0; i < n; i++) {
      meter.take("constraintTests");
      if (model2.A[i].every((x) => x === 0) && model2.b[i] > 0) {
        const proof = makeInfeasibilityCertificate(getExact(), [], i, [], meter);
        ctx.exactDependent = true;
        trace.push(traceEntry(ctx, "infeasible", state));
        return refused("INFEASIBLE", null, proof);
      }
    }
    while (true) {
      if (state.pending === null) {
        ctx = context(state, meter);
        const allMargins = margins(model2, state.u, meter);
        if (state.W.some((i) => Math.abs(allMargins[i]) > EPS)) unsafe("iterate-certificate");
        const p2 = allMargins.findIndex((v, i) => v < -EPS && !state.W.includes(i));
        if (p2 < 0) {
          const u2 = reconstruct(model2, state.lambda), checked3 = fullCertificate(model2, u2, state.lambda, meter), bodyTranslations = translations(model2, u2);
          if (Object.values(checked3.certificate).some((v) => !Number.isFinite(v) || v > EPS) || checked3.objectiveKgM2 < 0) unsafe("result-certificate");
          if (bodyTranslations.some((t) => Math.hypot(...t.u) > 10)) unsafe("translation-bound");
          state = { ...state, u: u2 };
          return { ok: true, status: "SOLVED", ...common(), translations: bodyTranslations, lambdaKgM: [...state.lambda], primalMarginsM: [...checked3.primalMarginsM], objectiveKgM2: checked3.objectiveKgM2, certificate: { ...checked3.certificate }, infeasibilityCertificate: null, reason: null };
        }
        state = { ...state, pending: p2 };
      }
      ctx = context(state, meter);
      meter.take("iterations");
      ctx.iteration = meter.counters.iterations;
      const key = ieeeState(state);
      if (seen.has(key)) throw new CoreStop("WORK_LIMIT", "cycle");
      seen.add(key);
      const p = state.pending, W = state.W, solved = solveBasis(W.map((i) => W.map((j) => model2.G[i][j])), W.map((i) => model2.G[i][p]), meter);
      ctx.condition = solved.condition;
      let r = solved.r;
      const projected = direction(model2, W, p, r, meter);
      ctx.schurInverseKg = projected.delta;
      let dependent = false;
      if (projected.near) {
        meter.take("rankChecks");
        const relation = exactDependency(getExact(), W, p, meter);
        ctx.exactDependent = relation.dependent;
        if (!relation.dependent) unsafe("near-dependent-independent");
        dependent = true;
        if (!relation.rExact.some((x) => x.n > 0n)) {
          const proof = makeInfeasibilityCertificate(getExact(), W, p, relation.rExact, meter);
          trace.push(traceEntry(ctx, "infeasible", state));
          return refused("INFEASIBLE", null, proof);
        }
        r = dependencyNumbers(relation.rExact, meter);
      }
      let dualStep = Infinity, blocker = null;
      for (let j = 0; j < W.length; j++) if (r[j] > 0) {
        const step2 = finite3(state.lambda[W[j]] / r[j]);
        if (step2 < 0) unsafe("negative-step");
        if (step2 < dualStep || step2 === dualStep && (blocker === null || W[j] < blocker)) {
          dualStep = step2;
          blocker = W[j];
        }
      }
      let primalStep = Infinity;
      if (!dependent) {
        meter.take("constraintTests");
        const deficit = finite3(model2.b[p] - dot3(model2.A[p], state.u));
        primalStep = finite3(deficit / projected.delta);
        if (primalStep < 0) unsafe("negative-step");
      }
      const drop = dualStep <= primalStep, step = drop ? dualStep : primalStep;
      if (!Number.isFinite(step)) unsafe("uncertified-infeasibility");
      ctx.stepKgM = step;
      ctx.blocker = drop ? blocker : null;
      if (drop && blocker === null) unsafe("uncertified-infeasibility");
      const lambda = [...state.lambda];
      for (let j = 0; j < W.length; j++) lambda[W[j]] = finite3(lambda[W[j]] - finite3(step * r[j]));
      lambda[p] = finite3(lambda[p] + step);
      if (drop) lambda[blocker] = 0;
      const nextW = drop ? W.filter((i) => i !== blocker) : [...W, p].sort((a2, b2) => a2 - b2), pending = drop ? p : null, u = reconstruct(model2, lambda);
      checkIterate(model2, u, lambda, nextW, pending, meter);
      meter.take("activeChanges");
      state = { u, lambda, W: nextW, pending };
      trace.push(traceEntry(ctx, drop ? dependent ? "dependent-drop" : "drop" : "add", state));
    }
  } catch (error2) {
    if (!(error2 instanceof CoreStop)) throw error2;
    ctx.iteration = meter.counters.iterations;
    trace.push(traceEntry(ctx, error2.status === "WORK_LIMIT" ? "work-limit" : "unsafe", state));
    return refused(error2.status, error2.reason);
  }
}

// src/stack/full-pair-solver.mjs
var RESULT_KEYS = ["ok", "status", "basisRows", "basisRank", "dynamicDof", "counters", "trace", "lastSafeIterate", "translations", "lambdaKgM", "primalMarginsM", "objectiveKgM2", "certificate", "infeasibilityCertificate", "reason", "worldStepped"];
var CERT_KEYS = ["primalViolationM", "negativeMultiplierKgM", "complementarityKgM2", "stationarityKgM"];
var TRACE_KEYS = ["iteration", "enteringRow", "basisBefore", "basisAfter", "action", "blocker", "stepKgM", "schurInverseKg", "condition", "exactDependent"];
var UNSAFE_REASONS = ["nonfinite", "negative-step", "negative-multiplier", "pivot", "condition", "factor-residual", "direction-residual", "near-dependent-independent", "dependent-basis", "dependency-conversion", "uncertified-infeasibility", "iterate-certificate", "result-certificate", "translation-bound"];
var WORK_REASONS = [...Object.keys(DEFAULT_LIMITS).map((k) => "budget:" + k), "cycle"];
var fail2 = (condition) => requireFull(condition, "result", "NUMERIC_LIMIT");
var finiteNumber = (x) => typeof x === "number" && Number.isFinite(x);
var integer = (x) => Number.isSafeInteger(x) && x >= 0;
var sameVector = (a2, b2) => a2.length === b2.length && a2.every((v, i) => Object.is(v, b2[i]));
function checkedArithmetic(fn) {
  try {
    return fn();
  } catch (error2) {
    if (error2 instanceof CoreStop) requireFull(false, "result", "NUMERIC_LIMIT");
    throw error2;
  }
}
function indices(raw, n, d) {
  const a2 = dataArray(raw);
  fail2(a2 !== null && a2.length <= d && a2.every((v, i) => integer(v) && v < n && (i === 0 || v > a2[i - 1])));
  return a2;
}
function numberVector(raw, size2) {
  const a2 = dataFiniteVector(raw, size2);
  fail2(a2 !== null);
  return a2;
}
function indexOrNull(value, n) {
  fail2(value === null || integer(value) && value < n);
  return value;
}
function checkedCounters(raw, d, n) {
  const c = dataRecord(raw, COUNTER_KEYS);
  fail2(c !== null && COUNTER_KEYS.every((k) => integer(c[k])));
  for (const k of ["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "exactIntegerOperations"]) fail2(c[k] <= DEFAULT_LIMITS[k]);
  fail2(c.exactPeakBits <= DEFAULT_LIMITS.intermediateIntegerBits && c.activeChanges <= c.iterations && c.rankChecks <= 2 * c.iterations && c.linearSolves <= 2 * c.iterations);
  fail2(c.factorizations <= c.linearSolves && c.blockRightHandSides >= c.factorizations && c.blockRightHandSides <= (Math.min(d, n) + 1) * c.factorizations);
  if (n === 0) fail2(["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "factorizations", "blockRightHandSides", "exactIntegerOperations", "exactPeakBits"].every((k) => c[k] === 0));
  return { ...c };
}
function checkedTrace(raw, n, d, counters, basisRows) {
  const entries = dataArray(raw);
  fail2(entries !== null && entries.length <= counters.iterations + 1);
  const trace = [];
  let previous = [], iteration = 0, changes = 0;
  for (const rawEntry of entries) {
    const e = dataRecord(rawEntry, TRACE_KEYS);
    fail2(e !== null && integer(e.iteration) && e.iteration >= iteration && e.iteration <= counters.iterations);
    const before = indices(e.basisBefore, n, d), after = indices(e.basisAfter, n, d);
    fail2(sameVector(before, previous));
    const enteringRow = indexOrNull(e.enteringRow, n), blocker = indexOrNull(e.blocker, n);
    fail2(["add", "drop", "dependent-drop", "infeasible", "unsafe", "work-limit"].includes(e.action) && (e.exactDependent === null || typeof e.exactDependent === "boolean"));
    fail2(e.stepKgM === null || finiteNumber(e.stepKgM) && e.stepKgM >= 0);
    fail2(e.schurInverseKg === null || finiteNumber(e.schurInverseKg));
    fail2(e.condition === null || finiteNumber(e.condition) && e.condition >= 0);
    if (e.action === "add") {
      fail2(e.iteration > 0 && enteringRow !== null && !before.includes(enteringRow) && blocker === null && e.stepKgM !== null && e.exactDependent !== true);
      fail2(sameVector(after, [...before, enteringRow].sort((a2, b2) => a2 - b2)));
      changes++;
    } else if (e.action === "drop" || e.action === "dependent-drop") {
      fail2(e.iteration > 0 && enteringRow !== null && !before.includes(enteringRow) && blocker !== null && before.includes(blocker) && e.stepKgM !== null);
      fail2((e.action === "dependent-drop" ? e.exactDependent === true : e.exactDependent !== true) && sameVector(after, before.filter((i) => i !== blocker)));
      changes++;
    } else fail2(sameVector(before, after));
    trace.push({ ...e, basisBefore: [...before], basisAfter: [...after] });
    previous = after;
    iteration = e.iteration;
  }
  fail2(changes === counters.activeChanges && sameVector(previous, basisRows));
  return trace;
}
function checkedSafe(raw, model2, basisRows) {
  const s = dataRecord(raw, ["uDynamic", "lambdaKgM", "pendingRow", "pendingLambdaKgM", "basisRows"]);
  fail2(s !== null);
  const u = numberVector(s.uDynamic, model2.dynamicDof), lambda = numberVector(s.lambdaKgM, model2.A.length), basis3 = indices(s.basisRows, model2.A.length, model2.dynamicDof), pending = indexOrNull(s.pendingRow, model2.A.length);
  fail2(sameVector(basis3, basisRows) && finiteNumber(s.pendingLambdaKgM) && s.pendingLambdaKgM >= 0 && lambda.every((v) => v >= 0));
  fail2(pending === null ? s.pendingLambdaKgM === 0 : !basis3.includes(pending) && Object.is(s.pendingLambdaKgM, lambda[pending]));
  const expected = checkedArithmetic(() => reconstruct(model2, lambda));
  fail2(u.every((v, k) => Math.abs(v - expected[k]) <= EPS));
  checkedArithmetic(() => checkIterate(model2, u, lambda, basis3, pending, createMeter()));
  return { uDynamic: [...u], lambdaKgM: [...lambda], pendingRow: pending, pendingLambdaKgM: s.pendingLambdaKgM, basisRows: [...basis3] };
}
function checkedInfeasibility(problem, model2, raw) {
  const proof = dataRecord(raw, ["weights", "sumWeights", "dynamicDot", "boundDotM"]);
  fail2(proof !== null);
  const weights = dataArray(proof.weights, problem.rows.length), dynamicDot = dataArray(proof.dynamicDot, model2.dynamicDof);
  fail2(weights !== null && weights.every((v) => typeof v === "string") && dynamicDot !== null && dynamicDot.every((v) => v === "0/1") && proof.sumWeights === "1/1" && typeof proof.boundDotM === "string");
  const copied = { weights: [...weights], sumWeights: "1/1", dynamicDot: [...dynamicDot], boundDotM: proof.boundDotM };
  fail2(checkedArithmetic(() => verifyInfeasibilityCertificate(problem, copied, createMeter())));
  return copied;
}
function validateFullPairResult(rawProblem, rawResult) {
  const problem = validateFullPairProblem(rawProblem);
  try {
    const model2 = checkedArithmetic(() => prepareModel(problem)), r = dataRecord(rawResult, RESULT_KEYS);
    fail2(r !== null);
    fail2(typeof r.ok === "boolean" && ["SOLVED", "INFEASIBLE", "NUMERIC_UNSAFE", "WORK_LIMIT"].includes(r.status) && r.worldStepped === false);
    const basisRows = indices(r.basisRows, problem.rows.length, model2.dynamicDof);
    fail2(integer(r.basisRank) && r.basisRank === basisRows.length && r.dynamicDof === model2.dynamicDof);
    const counters = checkedCounters(r.counters, model2.dynamicDof, problem.rows.length), trace = checkedTrace(r.trace, problem.rows.length, model2.dynamicDof, counters, basisRows), lastSafeIterate = checkedSafe(r.lastSafeIterate, model2, basisRows);
    const common = { basisRows: [...basisRows], basisRank: basisRows.length, dynamicDof: model2.dynamicDof, counters, trace, lastSafeIterate, worldStepped: false };
    if (r.status === "SOLVED") {
      fail2(r.ok === true && r.reason === null && r.infeasibilityCertificate === null && lastSafeIterate.pendingRow === null);
      const ts = dataArray(r.translations, problem.bodies.length);
      fail2(ts !== null);
      const translations2 = [];
      for (let i = 0; i < ts.length; i++) {
        const t = dataRecord(ts[i], ["id", "u"]);
        fail2(t !== null && t.id === problem.bodies[i].id);
        const u2 = numberVector(t.u, 3);
        fail2(Math.hypot(...u2) <= 10);
        if (problem.bodies[i].inverseMass === 0) fail2(u2.every((v) => Object.is(v, 0)));
        translations2.push({ id: t.id, u: [...u2] });
      }
      const lambdaKgM = numberVector(r.lambdaKgM, problem.rows.length), primalMarginsM = numberVector(r.primalMarginsM, problem.rows.length), certificate2 = dataRecord(r.certificate, CERT_KEYS);
      fail2(certificate2 !== null && CERT_KEYS.every((k) => finiteNumber(certificate2[k]) && certificate2[k] >= 0 && certificate2[k] <= EPS) && finiteNumber(r.objectiveKgM2) && r.objectiveKgM2 >= 0);
      fail2(sameVector(lambdaKgM, lastSafeIterate.lambdaKgM));
      const u = translations2.flatMap((t, i) => model2.offsets[i] === null ? [] : t.u);
      fail2(sameVector(u, lastSafeIterate.uDynamic));
      const actual = checkedArithmetic(() => fullCertificate(model2, u, lambdaKgM, createMeter()));
      fail2(actual.primalMarginsM.every((v, i) => v >= -EPS && Math.abs(v - primalMarginsM[i]) <= EPS) && Math.abs(actual.objectiveKgM2 - r.objectiveKgM2) <= EPS);
      fail2(CERT_KEYS.every((k) => actual.certificate[k] <= EPS && Math.abs(actual.certificate[k] - certificate2[k]) <= EPS));
      return { ok: true, status: "SOLVED", ...common, translations: translations2, lambdaKgM: [...lambdaKgM], primalMarginsM: [...primalMarginsM], objectiveKgM2: r.objectiveKgM2, certificate: { ...certificate2 }, infeasibilityCertificate: null, reason: null };
    }
    fail2(r.ok === false && ["translations", "lambdaKgM", "primalMarginsM", "objectiveKgM2", "certificate"].every((k) => r[k] === null));
    let infeasibilityCertificate = null;
    if (r.status === "INFEASIBLE") {
      fail2(r.reason === null);
      infeasibilityCertificate = checkedInfeasibility(problem, model2, r.infeasibilityCertificate);
    } else {
      fail2(r.infeasibilityCertificate === null);
      fail2((r.status === "NUMERIC_UNSAFE" ? UNSAFE_REASONS : WORK_REASONS).includes(r.reason));
    }
    return { ok: false, status: r.status, ...common, translations: null, lambdaKgM: null, primalMarginsM: null, objectiveKgM2: null, certificate: null, infeasibilityCertificate, reason: r.reason };
  } catch (error2) {
    throw error2;
  }
}
function solveFullPairPosition(problem) {
  return validateFullPairResult(problem, runFullPairCore(problem, DEFAULT_LIMITS));
}

// src/stack/signed-sat.ts
var FEATURE_INPUT_MESSAGE2 = "signed position reference requires admitted raw boxes";
var AXIS_MESSAGE = "signed position reference requires a fresh supported pre-SAT axis";
var DIAGNOSTIC_TIE_TOLERANCE_M2 = 1e-12;
function denseFinite(value, size2, bound) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === size2 && Reflect.ownKeys(value).length === size2 + 1 && Array.from({ length: size2 }, (_, i) => i).every((i) => Object.hasOwn(value, i) && typeof value[i] === "number" && Number.isFinite(value[i]) && Math.abs(value[i]) <= bound);
}
function admittedRawBox(body) {
  return body !== null && typeof body === "object" && typeof body.id === "string" && ID.test(body.id) && (body.kind === "dynamic" || body.kind === "static") && body.shape?.kind === "box" && denseFinite(body.shape.halfExtentsM, 3, 1e3) && body.shape.halfExtentsM.every((v) => v >= 1e-4) && denseFinite(body.positionM, 3, 1e4) && denseFinite(body.velocityMps, 3, 1e3) && denseFinite(body.angularVelocityRadps, 3, 1e3) && denseFinite(body.orientation, 4, 1) && Math.abs(Math.hypot(...body.orientation) - 1) <= 1e-9 && typeof body.inverseMass === "number" && Number.isFinite(body.inverseMass) && (body.kind === "static" ? body.inverseMass === 0 : body.inverseMass >= 1e-6 && body.inverseMass <= 1e6);
}
function boxAxes3(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
}
function boxSupport3(body, direction2) {
  const axes = boxAxes3(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function featureAt2(candidateIndex) {
  if (candidateIndex < 3) return { kind: "face-a", axisA: candidateIndex };
  if (candidateIndex < 6) return { kind: "face-b", axisB: candidateIndex - 3 };
  const crossIndex = candidateIndex - 6;
  return { kind: "edge-cross", axisA: Math.floor(crossIndex / 3), axisB: crossIndex % 3 };
}
function featureLabel2(feature) {
  if (feature.kind === "face-a") return `A.face.${feature.axisA}`;
  if (feature.kind === "face-b") return `B.face.${feature.axisB}`;
  return `A.edge.${feature.axisA}xB.edge.${feature.axisB}`;
}
function inspectSignedBoxSAT(a2, b2) {
  if (!admittedRawBox(a2) || !admittedRawBox(b2)) {
    error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE2);
  }
  const axesA = boxAxes3(a2), axesB = boxAxes3(b2);
  const extentA = a2.shape.halfExtentsM, extentB = b2.shape.halfExtentsM;
  const delta = sub(b2.positionM, a2.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  let bestCandidateIndex = 0, bestRawLength = 0;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  const diagnostics = [];
  for (const [candidateIndex, candidate] of candidates.entries()) {
    const length = Math.hypot(...candidate);
    const feature2 = featureAt2(candidateIndex);
    const diagnostic = {
      candidateIndex,
      label: featureLabel2(feature2),
      feature: feature2,
      rawAxisLength: length,
      skippedByOriginalCutoff: length < 1e-12,
      signedDistanceM: null,
      overlapM: null,
      axis: null,
      orientedNormal: null,
      radiusAM: null,
      radiusBM: null
    };
    diagnostics.push(diagnostic);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis3, index) => sum + extentA[index] * Math.abs(dot(basis3, axis)), 0);
    const radiusB = axesB.reduce((sum, basis3, index) => sum + extentB[index] * Math.abs(dot(basis3, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    diagnostic.signedDistanceM = signedDistance;
    diagnostic.overlapM = overlap;
    diagnostic.axis = [...axis];
    diagnostic.orientedNormal = scale(axis, signedDistance < 0 ? -1 : 1);
    diagnostic.radiusAM = radiusA;
    diagnostic.radiusBM = radiusB;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
      bestCandidateIndex = candidateIndex;
      bestRawLength = length;
    }
  }
  if (!Number.isFinite(bestOverlap) || !Number.isFinite(bestRawLength) || bestRawLength < 1e-12) error("NUMERIC_LIMIT", AXIS_MESSAGE);
  const aPoint = boxSupport3(a2, bestAxis);
  const bPoint = boxSupport3(b2, scale(bestAxis, -1));
  const pointM = scale(add(aPoint, bPoint), 0.5);
  const feature = featureAt2(bestCandidateIndex);
  return {
    normal: [...bestAxis],
    boundM: bestOverlap,
    pointM: [...pointM],
    feature,
    label: featureLabel2(feature),
    candidateIndex: bestCandidateIndex,
    rawAxisLength: bestRawLength,
    candidates: diagnostics,
    ambiguity: {
      exactMinimumCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && candidate.overlapM === bestOverlap).map((candidate) => candidate.candidateIndex),
      withinDiagnosticTieToleranceCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && Math.abs(candidate.overlapM - bestOverlap) <= DIAGNOSTIC_TIE_TOLERANCE_M2).map((candidate) => candidate.candidateIndex),
      skippedCandidateIndices: diagnostics.filter((candidate) => candidate.skippedByOriginalCutoff).map((candidate) => candidate.candidateIndex),
      diagnosticTieToleranceM: DIAGNOSTIC_TIE_TOLERANCE_M2,
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// src/stack/full-pair-rows.ts
var FULL_PAIR_ERRORS = {
  INPUT: "private full-pair position input is invalid",
  PROFILE: "private full-pair position profile is unsupported",
  RANGE: "private full-pair position signed bound exceeds the admitted range",
  GEOMETRY: "private full-pair position requires fresh matching box geometry",
  INFEASIBLE: "private full-pair position constraints are infeasible",
  NUMERIC_UNSAFE: "private full-pair position solve is numerically unsafe",
  WORK_LIMIT: "private full-pair position solve exceeded its work limit",
  RESULT: "private full-pair position result is invalid",
  NONPENETRATION: "private full-pair position result left an overlapping pair"
};
function refuse2(key) {
  throw new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS[key]);
}
function mapFullPairError(error2) {
  try {
    if (error2 instanceof FullPairPositionReferenceError) {
      if (error2.code === "PROFILE_LIMIT" && error2.message === MESSAGES.limit) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.PROFILE);
      }
      if (error2.code === "INVALID_INPUT" && [
        MESSAGES.input,
        MESSAGES.empty,
        MESSAGES.ids,
        MESSAGES.mass,
        MESSAGES.endpoints,
        MESSAGES.normal,
        MESSAGES.bound,
        MESSAGES.workLimits
      ].includes(error2.message)) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.INPUT);
      }
      if (error2.code === "NUMERIC_LIMIT" && error2.message === MESSAGES.result) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.RESULT);
      }
    }
    if (error2 instanceof PhysicsError && (error2.code === "INVALID_CONFIG" && error2.message === FEATURE_INPUT_MESSAGE2 || error2.code === "NUMERIC_LIMIT" && error2.message === AXIS_MESSAGE)) {
      return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.GEOMETRY);
    }
  } catch {
  }
  return error2;
}
function ordinaryDense(value, size2) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && (size2 === void 0 || value.length === size2) && Reflect.ownKeys(value).length === value.length + 1 && Array.from({ length: value.length }, (_, i) => i).every((i) => {
    const descriptor = Object.getOwnPropertyDescriptor(value, i);
    return descriptor !== void 0 && "value" in descriptor;
  });
}
function finiteVector(value, size2, bound = Infinity) {
  return ordinaryDense(value, size2) && value.every((v) => typeof v === "number" && Number.isFinite(v) && Math.abs(v) <= bound);
}
function record2(value) {
  return value !== null && typeof value === "object";
}
function checkedFullPairInputs(bodies, pairs) {
  if (!ordinaryDense(bodies) || !ordinaryDense(pairs) || bodies.length === 0) refuse2("INPUT");
  if (bodies.length > 9 || pairs.length > 36) refuse2("PROFILE");
  const ids = /* @__PURE__ */ new Set();
  for (const body of bodies) {
    if (!record2(body) || typeof body.id !== "string" || !ID.test(body.id) || ids.has(body.id) || !finiteVector(body.positionM, 3) || !finiteVector(body.velocityMps, 3) || !finiteVector(body.orientation, 4) || !finiteVector(body.angularVelocityRadps, 3) || typeof body.inverseMass !== "number" || !Number.isFinite(body.inverseMass)) refuse2("INPUT");
    ids.add(body.id);
    if (body.kind !== "dynamic" && body.kind !== "static" || body.shape?.kind !== "box" || body.sensor || body.ccd || body.collisionFilter || !finiteVector(body.shape.halfExtentsM, 3, 1e3) || body.shape.halfExtentsM.some((v) => v < 1e-4) || body.restitution !== 0 || !finiteVector(body.inverseInertiaLocal, 3) || body.inverseInertiaLocal.some((v) => v < 0) || (body.kind === "static" ? body.inverseMass !== 0 : body.inverseMass < 1e-6 || body.inverseMass > 1e6)) {
      refuse2("PROFILE");
    }
  }
  validateResult(bodies, []);
  const expected = [];
  for (let a2 = 0; a2 < bodies.length; a2++) for (let b2 = a2 + 1; b2 < bodies.length; b2++) {
    if (bodies[a2].inverseMass !== 0 || bodies[b2].inverseMass !== 0) {
      expected.push(bodies[a2].id < bodies[b2].id ? [a2, b2] : [b2, a2]);
    }
  }
  expected.sort((l, r) => bodies[l[0]].id < bodies[r[0]].id ? -1 : bodies[l[0]].id > bodies[r[0]].id ? 1 : bodies[l[1]].id < bodies[r[1]].id ? -1 : 1);
  if (pairs.length !== expected.length || pairs.some((p, i) => !ordinaryDense(p, 2) || p[0] !== expected[i][0] || p[1] !== expected[i][1])) refuse2("INPUT");
}
function pairKey(bodies, a2, b2) {
  return `${bodies[a2].id}\0${bodies[b2].id}`;
}
function compactSelection(full) {
  return {
    normal: [...full.normal],
    boundM: full.boundM,
    candidateIndex: full.candidateIndex,
    pointM: [...full.pointM],
    rawAxisLength: full.rawAxisLength,
    label: full.label,
    feature: { ...full.feature }
  };
}
function freshSelection(a2, b2) {
  return compactSelection(inspectSignedBoxSAT(a2, b2));
}
function buildFullPairProblem(bodies, pairs, capture) {
  checkedFullPairInputs(bodies, pairs);
  const result = capture ?? {
    problem: { bodies: bodies.map((b2) => ({ id: b2.id, inverseMass: b2.inverseMass })), rows: [] },
    rowSources: [],
    initialDetections: [],
    pairObservations: [],
    tests: 0,
    hits: 0,
    signedPreQueries: 0
  };
  for (const [aIndex, bIndex] of pairs) {
    const a2 = bodies[aIndex], b2 = bodies[bIndex], key = pairKey(bodies, aIndex, bIndex);
    result.tests++;
    const hit = detect(a2, b2);
    result.initialDetections.push({ pairKey: key, aIndex, bIndex, hit: hit ? structuredClone(hit) : null });
    if (hit !== null) result.hits++;
    result.signedPreQueries++;
    const selection = freshSelection(a2, b2);
    result.pairObservations.push({ pairKey: key, aIndex, bIndex, selection });
    if (hit !== null && (!hit.normal.every((v, d) => v === selection.normal[d]) || Math.max(0, selection.boundM) !== hit.penetration)) refuse2("GEOMETRY");
    result.rowSources.push({
      rowIndex: result.problem.rows.length,
      pairKey: key,
      aIndex,
      bIndex,
      selection: structuredClone(selection)
    });
    result.problem.rows.push({
      aId: a2.id,
      bId: b2.id,
      normal: [...selection.normal],
      boundM: selection.boundM
    });
  }
  if (result.pairObservations.some((p) => p.selection.boundM < -10 || p.selection.boundM > 10)) refuse2("RANGE");
  return result;
}
function inspectFullPairHypothesis(bodies, pairs, capture = [], progress) {
  for (const [aIndex, bIndex] of pairs) {
    if (progress) progress.postPairTests++;
    capture.push({
      pairKey: pairKey(bodies, aIndex, bIndex),
      aIndex,
      bIndex,
      selection: freshSelection(bodies[aIndex], bodies[bIndex])
    });
  }
  return capture;
}

// src/stack/full-pair-apply.ts
function same3(a2, b2) {
  if (a2 === null || b2 === null || typeof a2 !== "object" || typeof b2 !== "object") return Object.is(a2, b2);
  const ka = Reflect.ownKeys(a2), kb = Reflect.ownKeys(b2);
  return ka.length === kb.length && ka.every((k) => kb.includes(k) && same3(Reflect.get(a2, k), Reflect.get(b2, k)));
}
function vector2(value, size2) {
  return ordinaryDense(value, size2) && value.every((x) => typeof x === "number" && Number.isFinite(x));
}
function applyFullPairTranslationsOnce(preBodies, problem, result) {
  try {
    const checked3 = validateFullPairResult(problem, result);
    if (checked3.status !== "SOLVED" || checked3.ok !== true || !ordinaryDense(preBodies) || preBodies.length < 1 || preBodies.length > 9 || problem.bodies.length !== preBodies.length) refuse2("RESULT");
    for (let i = 0; i < preBodies.length; i++) {
      const body = preBodies[i];
      if (!body || body.id !== problem.bodies[i].id || body.inverseMass !== problem.bodies[i].inverseMass || !vector2(body.positionM, 3) || !vector2(body.velocityMps, 3) || !vector2(body.orientation, 4) || !vector2(body.angularVelocityRadps, 3)) refuse2("RESULT");
    }
    validateResult(preBodies, []);
    const bodies = preBodies.map(copyBody), rounding = [];
    for (let i = 0; i < preBodies.length; i++) {
      const before = preBodies[i], body = bodies[i], u = checked3.translations[i].u;
      if (Math.hypot(...u) > 10 || before.inverseMass === 0 && !u.every((v) => v === 0)) refuse2("RESULT");
      const roundedFinalM = before.inverseMass === 0 ? [...before.positionM] : before.positionM.map((v, j) => v + u[j]);
      if (!roundedFinalM.every(Number.isFinite)) refuse2("RESULT");
      body.positionM = roundedFinalM;
      const actualDeltaM = body.positionM.map((v, j) => v - before.positionM[j]);
      if (before.inverseMass === 0 && (!u.every((v) => v === 0) || !same3(body, before))) refuse2("RESULT");
      if (!same3({ ...body, positionM: before.positionM }, before)) refuse2("RESULT");
      rounding.push({
        id: body.id,
        nominalTranslationM: [...u],
        roundedFinalM: [...roundedFinalM],
        actualDeltaM,
        nominalActualDeltaDifferenceM: actualDeltaM.map((v, j) => v - u[j]),
        exactRoundedFinalMatch: true,
        staticPositionAdditionPerformed: false,
        dynamicPositionAdditionPerformed: before.inverseMass > 0
      });
    }
    validateResult(bodies, []);
    return {
      bodies: bodies.map(copyBody),
      rounding: structuredClone(rounding),
      applications: 1,
      worldCreated: false,
      worldStepped: false
    };
  } catch (error2) {
    throw mapFullPairError(error2);
  }
}

// src/stack/full-pair-phase.ts
var PositionPhaseFailure = class extends PhysicsError {
  stats;
  attempt;
  constructor(reason, stats2, attempt) {
    super(reason.code, reason.message);
    this.stats = structuredClone(stats2);
    this.attempt = structuredClone(attempt);
  }
};
function zeroFullPairPositionStats() {
  return {
    tests: 0,
    hits: 0,
    rows: 0,
    signedPreQueries: 0,
    solverCalls: 0,
    postPairTests: 0,
    maxTranslationM: 0,
    workingApplicationCount: 0,
    solverCounters: {
      iterations: 0,
      activeChanges: 0,
      rankChecks: 0,
      linearSolves: 0,
      constraintTests: 0,
      factorizations: 0,
      blockRightHandSides: 0,
      exactIntegerOperations: 0,
      exactPeakBits: 0
    },
    certificate: null
  };
}
function errorRecord(error2) {
  let result = {
    kind: "unexpected-error",
    name: "ThrownValue",
    message: "Unexpected non-Error exception"
  };
  try {
    if (error2 instanceof Error) result = { kind: "unexpected-error", name: error2.name, message: error2.message };
    if (error2 instanceof PhysicsError) {
      result = { kind: "typed-refusal", name: error2.name, code: error2.code, message: error2.message };
    }
  } catch {
  }
  return result;
}
function runFullPairPositionPhase(workingBodies, sortedPairs2) {
  const stats2 = zeroFullPairPositionStats();
  const attempt = {
    preBodies: [],
    pairs: [],
    initialDetections: [],
    pairObservations: [],
    problem: null,
    rowSources: [],
    result: null,
    hypotheticalBodies: null,
    rounding: null,
    finalPairObservations: [],
    failurePair: null,
    workingApplicationCount: 0,
    error: null
  };
  const capture = {
    problem: { bodies: [], rows: [] },
    rowSources: attempt.rowSources,
    initialDetections: attempt.initialDetections,
    pairObservations: attempt.pairObservations,
    tests: 0,
    hits: 0,
    signedPreQueries: 0
  };
  const updatePreStats = () => {
    stats2.tests = capture.tests;
    stats2.hits = capture.hits;
    stats2.rows = capture.problem.rows.length;
    stats2.signedPreQueries = capture.signedPreQueries;
  };
  try {
    checkedFullPairInputs(workingBodies, sortedPairs2);
    attempt.preBodies = workingBodies.map(copyBody);
    attempt.pairs = sortedPairs2.map(([a2, b2]) => [a2, b2]);
    capture.problem.bodies = attempt.preBodies.map((b2) => ({ id: b2.id, inverseMass: b2.inverseMass }));
    attempt.problem = capture.problem;
    buildFullPairProblem(attempt.preBodies, attempt.pairs, capture);
    updatePreStats();
    const problem = validateFullPairProblem(capture.problem);
    stats2.solverCalls++;
    const raw = solveFullPairPosition(structuredClone(problem));
    const checked3 = validateFullPairResult(problem, raw);
    attempt.result = checked3;
    stats2.solverCounters = structuredClone(checked3.counters);
    if (checked3.status === "INFEASIBLE") refuse2("INFEASIBLE");
    if (checked3.status === "NUMERIC_UNSAFE") refuse2("NUMERIC_UNSAFE");
    if (checked3.status === "WORK_LIMIT") refuse2("WORK_LIMIT");
    if (checked3.status !== "SOLVED" || checked3.ok !== true) refuse2("RESULT");
    stats2.maxTranslationM = Math.max(0, ...checked3.translations.map((t) => Math.hypot(...t.u)));
    stats2.certificate = structuredClone(checked3.certificate);
    const applied = applyFullPairTranslationsOnce(attempt.preBodies, problem, checked3);
    attempt.hypotheticalBodies = applied.bodies;
    attempt.rounding = applied.rounding;
    inspectFullPairHypothesis(applied.bodies, attempt.pairs, attempt.finalPairObservations, stats2);
    attempt.failurePair = attempt.finalPairObservations.find((p) => p.selection.boundM > 1e-12)?.pairKey ?? null;
    if (attempt.failurePair !== null) refuse2("NONPENETRATION");
  } catch (caught) {
    updatePreStats();
    const error2 = mapFullPairError(caught);
    const record5 = errorRecord(error2);
    if (attempt.failurePair === null && record5.kind === "typed-refusal" && record5.code === "NUMERIC_LIMIT" && record5.message === FULL_PAIR_ERRORS.RANGE) {
      attempt.failurePair = attempt.pairObservations.find((p) => p.selection.boundM < -10 || p.selection.boundM > 10)?.pairKey ?? null;
    }
    attempt.error = record5;
    if (error2 instanceof PhysicsError) throw new PositionPhaseFailure(error2, stats2, attempt);
    throw error2;
  }
  for (let i = 0; i < workingBodies.length; i++) if (workingBodies[i].inverseMass > 0) {
    workingBodies[i].positionM = [...attempt.hypotheticalBodies[i].positionM];
  }
  attempt.workingApplicationCount = 1;
  stats2.workingApplicationCount = 1;
  return { stats: structuredClone(stats2), attempt: structuredClone(attempt) };
}

// src/stack/prepare-step.ts
var StackStepFailure = class extends PhysicsError {
  diagnostics;
  constructor(reason, diagnostics) {
    super(reason.code, reason.message);
    this.diagnostics = structuredClone(diagnostics);
  }
};
function requireStack(ok, message) {
  if (!ok) throw new PhysicsError("NUMERIC_LIMIT", "bounded stack profile: " + message);
}
function equal2(a2, b2) {
  return a2.length === b2.length && a2.every((v, i) => v === b2[i]);
}
function finiteVector2(value, size2, bound) {
  return Array.isArray(value) && value.length === size2 && Array.from({ length: size2 }, (_, i) => i).every((i) => Object.hasOwn(value, i) && typeof value[i] === "number" && Number.isFinite(value[i]) && Math.abs(value[i]) <= bound);
}
function admitted2(bodies, dt, gravity) {
  requireStack(dt === 1 / 120 && finiteVector2(gravity, 3, 1e3), "dt or gravity");
  requireStack(Array.isArray(bodies) && bodies.length === 9 && bodies.every((body) => body !== null && typeof body === "object") && bodies.filter((body) => body.kind === "dynamic").length === 8 && bodies.filter((body) => body.kind === "static").length === 1, "eight cubes and one floor");
  const ids = /* @__PURE__ */ new Set();
  for (const body of bodies) {
    requireStack(
      finiteVector2(body.positionM, 3, 1e4) && finiteVector2(body.velocityMps, 3, 1e3) && finiteVector2(body.angularVelocityRadps, 3, 1e3) && finiteVector2(body.orientation, 4, 1) && finiteVector2(body.inverseInertiaLocal, 3, 1e6) && Number.isFinite(body.inverseMass),
      "finite represented body state"
    );
    requireStack(typeof body.id === "string" && ID.test(body.id) && !ids.has(body.id), "unique opaque IDs");
    ids.add(body.id);
    requireStack(
      body.shape && body.shape.kind === "box" && finiteVector2(body.shape.halfExtentsM, 3, 1e3) && !body.sensor && !body.ccd && !body.collisionFilter && !body.sleeping && body.restitution === 0 && body.frictionStatic === 1 && body.frictionDynamic === 0.7,
      "unfiltered unsensed unforced original box material"
    );
    if (body.kind === "dynamic") {
      requireStack(body.inverseMass === 1 && equal2(body.shape.halfExtentsM, [0.25, 0.25, 0.25]) && equal2(body.inverseInertiaLocal, [24, 24, 24]), "unit-mass half-quarter isotropic cube");
    } else {
      requireStack(body.kind === "static" && body.inverseMass === 0 && equal2(body.inverseInertiaLocal, [0, 0, 0]) && equal2(body.velocityMps, [0, 0, 0]) && equal2(body.angularVelocityRadps, [0, 0, 0]) && equal2(body.shape.halfExtentsM, [2, 0.1, 2]) && equal2(body.positionM, [0, -0.1, 0]) && equal2(body.orientation, [0, 0, 0, 1]), "fixed original floor");
    }
  }
  validateResult(bodies, []);
  requireStack(
    equal2(gravity, [0, -9.81, 0]) && bodies.every((body) => body.velocityMps.every((value) => value === 0) && body.angularVelocityRadps.every((value) => value === 0)),
    "stationary profile requires original gravity and zero before motion"
  );
}
function sortedPairs(bodies) {
  const pairs = [];
  for (let a2 = 0; a2 < bodies.length; a2++) for (let b2 = a2 + 1; b2 < bodies.length; b2++) {
    if (bodies[a2].inverseMass !== 0 || bodies[b2].inverseMass !== 0) {
      pairs.push(bodies[a2].id < bodies[b2].id ? [a2, b2] : [b2, a2]);
    }
  }
  pairs.sort((left, right) => bodies[left[0]].id < bodies[right[0]].id ? -1 : bodies[left[0]].id > bodies[right[0]].id ? 1 : bodies[left[1]].id < bodies[right[1]].id ? -1 : 1);
  requireStack(pairs.length === 36, "complete all-pair population");
  return pairs;
}
function prepareStackStep(bodies, dt, gravity) {
  admitted2(bodies, dt, gravity);
  const next = bodies.map(copyBody);
  const diagnostics = {
    beforeBodies: bodies.map(copyBody),
    freeBodies: null,
    velocityBodies: null,
    geometryPatches: [],
    pointLedger: [],
    normalProblem: null,
    normalResult: null,
    stationaryNormalWitness: null,
    positionAttempt: null,
    positionStats: null
  };
  try {
    for (const body of next) if (body.kind === "dynamic") {
      body.angularVelocityRadps = add(
        body.angularVelocityRadps,
        inverseInertia(body, add([0, 0, 0], scale([0, 0, 0], dt)))
      );
    }
    for (const body of next) if (body.kind === "dynamic") {
      requireStack(body.angularVelocityRadps.every((v) => Number.isFinite(v) && Math.abs(v) <= 1e3) && Math.hypot(...body.angularVelocityRadps) * dt <= 10, "angular movement bound");
      body.orientation = advanceOrientation(body.orientation, body.angularVelocityRadps, dt);
      for (let i = 0; i < 3; i++) {
        body.velocityMps[i] += 0 * body.inverseMass;
        body.velocityMps[i] += (gravity[i] + 0 * body.inverseMass) * dt;
      }
      requireStack(Math.hypot(...body.velocityMps) * dt <= MAX_STEP_DISPLACEMENT_M, "step displacement");
      for (let i = 0; i < 3; i++) body.positionM[i] += body.velocityMps[i] * dt;
    }
    validateResult(next, []);
    diagnostics.freeBodies = next.map(copyBody);
    const pairs = sortedPairs(next);
    for (const [aIndex, bIndex] of pairs) {
      const a2 = next[aIndex], b2 = next[bIndex], hit = detect(a2, b2);
      if (!hit) continue;
      requireStack(hit.penetration <= MAX_STEP_DISPLACEMENT_M, "contact penetration");
      const geometry = adaptContactGeometry(a2, b2);
      requireStack(geometry, "strict native contact geometry");
      diagnostics.geometryPatches.push({
        aIndex,
        bIndex,
        aId: a2.id,
        bId: b2.id,
        pairKey: a2.id + "\0" + b2.id,
        family: geometry.family,
        normal: [...geometry.normal],
        points: geometry.points
      });
    }
    const normal = solveStackNormal(next, diagnostics.geometryPatches);
    diagnostics.normalProblem = normal.problem;
    diagnostics.normalResult = normal.result;
    diagnostics.stationaryNormalWitness = normal.stationaryWitness;
    diagnostics.pointLedger = normal.pointLedger;
    diagnostics.velocityBodies = next.map(copyBody);
    const position = runFullPairPositionPhase(next, pairs);
    diagnostics.positionAttempt = position.attempt;
    diagnostics.positionStats = position.stats;
    validateResult(next, []);
    return { candidateBodies: next.map(copyBody), diagnostics: structuredClone(diagnostics) };
  } catch (caught) {
    if (caught instanceof NormalPhaseFailure) {
      diagnostics.normalProblem = caught.problem;
      diagnostics.normalResult = caught.result;
      diagnostics.stationaryNormalWitness = caught.stationaryWitness;
    }
    if (caught instanceof PositionPhaseFailure) {
      diagnostics.positionAttempt = caught.attempt;
      diagnostics.positionStats = caught.stats;
    }
    if (caught instanceof PhysicsError) throw new StackStepFailure(caught, diagnostics);
    throw caught;
  }
}

// src/stack/public-output.ts
function requireOutput(value, message) {
  if (!value) error("NUMERIC_LIMIT", "stationary public output: " + message);
}
function prepareStationaryOutput(prepared, previous) {
  const { freeBodies, geometryPatches, pointLedger } = prepared.diagnostics;
  requireOutput(freeBodies && freeBodies.length <= 9 && geometryPatches.length <= 8 && pointLedger.length <= 32, "bounded reached free geometry");
  const points = new Map(pointLedger.map((row) => [JSON.stringify([row.pairKey, row.pointId]), row]));
  requireOutput(points.size === pointLedger.length, "unique actual point IDs");
  const used = /* @__PURE__ */ new Set(), pairs = /* @__PURE__ */ new Set(), contacts = [];
  for (const patch of geometryPatches) {
    const a2 = freeBodies[patch.aIndex], b2 = freeBodies[patch.bIndex];
    requireOutput(
      a2 && b2 && a2.id === patch.aId && b2.id === patch.bId && a2.id < b2.id && patch.pairKey === a2.id + "\0" + b2.id && !pairs.has(patch.pairKey) && patch.points.length === 4,
      "frozen pair and four-point identity"
    );
    pairs.add(patch.pairKey);
    const hit = detect(a2, b2);
    requireOutput(hit && Number.isFinite(hit.penetration) && hit.penetration >= 0, "actual free-pose SAT hit");
    const mean = [0, 0, 0];
    let impulse = 0;
    for (const point2 of patch.points) {
      const key = JSON.stringify([patch.pairKey, point2.id]), row = points.get(key);
      requireOutput(row && !used.has(key) && row.aId === a2.id && row.bId === b2.id && row.aIndex === patch.aIndex && row.bIndex === patch.bIndex && point2.pointM.every((value, index) => Number.isFinite(value) && Object.is(value, row.pointM[index])) && patch.normal.every((value, index) => Number.isFinite(value) && Object.is(value, row.normal[index])) && Number.isFinite(row.final.normalNs) && row.final.normalNs >= 0 && row.final.tangentNs.every((value) => value === 0), "actual point-ledger summary");
      used.add(key);
      for (let axis = 0; axis < 3; axis++) mean[axis] += point2.pointM[axis];
      impulse += row.final.normalNs;
    }
    for (let axis = 0; axis < 3; axis++) mean[axis] /= 4;
    requireOutput(mean.every(Number.isFinite) && Number.isFinite(impulse), "finite retained-order mean and RNE sum");
    contacts.push({
      aId: a2.id,
      bId: b2.id,
      normalAtoB: [...patch.normal],
      pointM: mean,
      penetrationM: hit.penetration,
      impulseNs: impulse,
      tangentImpulseNs: [0, 0, 0]
    });
  }
  requireOutput(used.size === pointLedger.length, "all actual points summarized exactly once");
  contacts.sort((a2, b2) => a2.aId < b2.aId ? -1 : a2.aId > b2.aId ? 1 : a2.bId < b2.bId ? -1 : a2.bId > b2.bId ? 1 : 0);
  const activePairs = /* @__PURE__ */ new Map();
  for (const contact of contacts) activePairs.set(contact.aId + "\0" + contact.bId, { aId: contact.aId, bId: contact.bId, kind: "contact" });
  const events = [.../* @__PURE__ */ new Set([...previous.keys(), ...activePairs.keys()])].sort().map((key) => {
    const current = activePairs.get(key), prior = previous.get(key);
    return { ...current ?? prior, phase: current ? prior ? "stay" : "begin" : "end" };
  });
  let eligiblePairs = 0;
  for (let a2 = 0; a2 < freeBodies.length; a2++) for (let b2 = a2 + 1; b2 < freeBodies.length; b2++)
    if (freeBodies[a2].inverseMass !== 0 || freeBodies[b2].inverseMass !== 0) eligiblePairs++;
  return { contacts, events, activePairs, pairStats: { eligiblePairs, candidatePairs: eligiblePairs, aabbTests: 0 } };
}

// src/stack/normal-solver.ts
var NORMAL_CANDIDATE_GATES = Object.freeze({
  normal: 1e-10,
  complementarity: 1e-10,
  stationarity: 1e-10,
  tangent: 1e-10,
  rank: 1e-12
});
var NORMAL_CANDIDATE_BUDGET = Object.freeze({
  outerIterations: 64,
  blockQrFactorizations: 64,
  activeChanges: 64,
  rankTests: 2048,
  dotProducts: 4e5,
  dotScalarProducts: 32e6,
  vectorUpdates: 1e7,
  triangularTerms: 4e4,
  constraintTests: 4096
});
var Stop2 = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
function numeric(message) {
  throw new Stop2("NUMERIC", message);
}
function need2(value, message) {
  if (!value) numeric(message);
}
function finite4(x) {
  if (!Number.isFinite(x)) numeric("nonfinite arithmetic");
  return x;
}
function stats() {
  return {
    outerIterations: 0,
    blockQrFactorizations: 0,
    activeChanges: 0,
    qrRank: 0,
    finalActiveRows: 0,
    dynamicDof: 0,
    rankTests: 0,
    dotProducts: 0,
    dotScalarProducts: 0,
    vectorUpdates: 0,
    triangularTerms: 0,
    constraintTests: 0
  };
}
function take(s, key, amount = 1) {
  if (s[key] + amount > NORMAL_CANDIDATE_BUDGET[key]) throw new Stop2("ITERATION_LIMIT", "budget:" + key);
  s[key] += amount;
}
function dot4(a2, b2, s) {
  take(s, "dotProducts");
  take(s, "dotScalarProducts", a2.length);
  let value = 0;
  for (let i = 0; i < a2.length; i++) value = finite4(value + finite4(a2[i] * b2[i]));
  return value;
}
function axpy(target, source, amount, s) {
  take(s, "vectorUpdates", target.length);
  for (let i = 0; i < target.length; i++) target[i] = finite4(target[i] + finite4(amount * source[i]));
}
function cross2(a2, b2) {
  return [finite4(a2[1] * b2[2] - a2[2] * b2[1]), finite4(a2[2] * b2[0] - a2[0] * b2[2]), finite4(a2[0] * b2[1] - a2[1] * b2[0])];
}
function subtract(a2, b2) {
  return [finite4(a2[0] - b2[0]), finite4(a2[1] - b2[1]), finite4(a2[2] - b2[2])];
}
function validVector(v, limit) {
  return Array.isArray(v) && v.length === 3 && Array.from({ length: 3 }, (_, i) => i).every((i) => Object.hasOwn(v, i) && typeof v[i] === "number" && Number.isFinite(v[i]) && Math.abs(v[i]) <= limit);
}
function copyBody2(body) {
  return {
    id: body.id,
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inverseMass: body.inverseMass,
    inverseInertiaWorld: body.inverseInertiaWorld.map((row) => [...row])
  };
}
function read(value) {
  need2(value && Array.isArray(value.bodies) && value.bodies.length >= 1 && value.bodies.length <= 9 && Array.isArray(value.points) && value.points.length <= 32, "body/point bound");
  const ids = /* @__PURE__ */ new Set();
  let dynamic = 0;
  for (const body of value.bodies) {
    need2(body && typeof body.id === "string" && body.id.length > 0 && body.id.length <= 1024 && !ids.has(body.id), "body id");
    ids.add(body.id);
    need2(validVector(body.positionM, 1e4) && validVector(body.velocityMps, 1e3) && validVector(body.angularVelocityRadps, 1e3), "body vectors");
    need2(typeof body.inverseMass === "number" && Number.isFinite(body.inverseMass) && (body.inverseMass === 0 || body.inverseMass >= 1e-6 && body.inverseMass <= 1e6), "inverse mass");
    need2(Array.isArray(body.inverseInertiaWorld) && body.inverseInertiaWorld.length === 3 && body.inverseInertiaWorld.every((row) => validVector(row, 1e6)), "inverse inertia");
    if (body.inverseMass === 0) {
      need2(
        [...body.velocityMps, ...body.angularVelocityRadps, ...body.inverseInertiaWorld.flat()].every((x) => x === 0),
        "static input must have zero motion and inertia"
      );
    } else dynamic++;
  }
  need2(dynamic >= 1 && dynamic <= 8, "dynamic body bound");
  const pointIds = /* @__PURE__ */ new Set();
  for (const point2 of value.points) {
    need2(point2 && typeof point2.id === "string" && point2.id.length > 0 && point2.id.length <= 4096 && !pointIds.has(point2.id), "point id");
    pointIds.add(point2.id);
    need2(ids.has(point2.aId) && ids.has(point2.bId) && point2.aId !== point2.bId, "point endpoints");
    need2(validVector(point2.pointM, 1e4) && validVector(point2.normalAtoB, 1 + 1e-12), "point vectors");
    need2(Math.abs(Math.hypot(...point2.normalAtoB) - 1) <= 1e-12, "unit normal");
  }
  return { bodies: value.bodies.map(copyBody2), points: value.points.map((p) => ({
    ...p,
    pointM: [...p.pointM],
    normalAtoB: [...p.normalAtoB]
  })) };
}
function cholesky(matrix3, s) {
  const scale4 = Math.max(1, ...matrix3.flat().map(Math.abs));
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) need2(matrix3[i][j] === matrix3[j][i], "symmetric inertia required");
  const lower = Array.from({ length: 3 }, () => [0, 0, 0]);
  for (let i = 0; i < 3; i++) for (let j = 0; j <= i; j++) {
    let entry = matrix3[i][j];
    for (let k = 0; k < j; k++) {
      take(s, "triangularTerms");
      entry = finite4(entry - finite4(lower[i][k] * lower[j][k]));
    }
    if (i === j) {
      need2(entry > 1e-12 * scale4, "positive definite well-scaled inertia required");
      lower[i][j] = Math.sqrt(entry);
    } else lower[i][j] = finite4(entry / lower[j][j]);
  }
  return lower;
}
function model(input, s) {
  const blocks = [], free = [];
  for (const body of input.bodies) {
    if (body.inverseMass === 0) {
      blocks.push({ offset: null, rootMass: 0, angular: [] });
      continue;
    }
    const angular = cholesky(body.inverseInertiaWorld, s), rootMass = Math.sqrt(body.inverseMass), offset = free.length;
    for (const value of body.velocityMps) free.push(finite4(value / rootMass));
    const local = [0, 0, 0];
    for (let i = 0; i < 3; i++) {
      let value = body.angularVelocityRadps[i];
      for (let j = 0; j < i; j++) {
        take(s, "triangularTerms");
        value = finite4(value - finite4(angular[i][j] * local[j]));
      }
      local[i] = finite4(value / angular[i][i]);
    }
    free.push(...local);
    blocks.push({ offset, rootMass, angular });
  }
  s.dynamicDof = free.length;
  const ids = new Map(input.bodies.map((body, i) => [body.id, i]));
  const a2 = input.points.map((point2) => {
    const row = Array(free.length).fill(0);
    let dynamicEndpoint = false;
    for (const [id, sign] of [[point2.aId, -1], [point2.bId, 1]]) {
      const index = ids.get(id), body = input.bodies[index], block = blocks[index];
      const arm = subtract(point2.pointM, body.positionM);
      need2(arm.every((x) => Math.abs(x) <= 10), "contact arm bound");
      if (block.offset === null) continue;
      dynamicEndpoint = true;
      const torque = cross2(arm, point2.normalAtoB);
      for (let k = 0; k < 3; k++) {
        row[block.offset + k] = finite4(sign * point2.normalAtoB[k] * block.rootMass);
        row[block.offset + 3 + k] = finite4(sign * dot4(torque, block.angular.map((r) => r[k]), s));
      }
    }
    need2(dynamicEndpoint, "static/static contact unsupported");
    return row;
  });
  return { input, blocks, a: a2, free };
}
function factor(a2, candidates, s) {
  take(s, "blockQrFactorizations");
  const residual = new Map(candidates.map((i) => [i, [...a2[i]]]));
  const remaining = [...candidates], rows = [], q = [];
  const scale4 = Math.max(1, ...candidates.map((i) => Math.sqrt(dot4(a2[i], a2[i], s))));
  while (remaining.length) {
    let pivot = remaining[0], square = -1;
    for (const index of remaining) {
      const value = dot4(residual.get(index), residual.get(index), s);
      if (value > square || value === square && index < pivot) {
        pivot = index;
        square = value;
      }
    }
    take(s, "rankTests");
    if (Math.sqrt(Math.max(0, square)) <= NORMAL_CANDIDATE_GATES.rank * scale4) break;
    const direction2 = [...a2[pivot]];
    for (let pass = 0; pass < 2; pass++) for (const basis4 of q) axpy(direction2, basis4, -dot4(direction2, basis4, s), s);
    const length = Math.sqrt(dot4(direction2, direction2, s));
    need2(length > NORMAL_CANDIDATE_GATES.rank * scale4, "inconsistent rank decision");
    const basis3 = direction2.map((value) => finite4(value / length));
    for (const prior of q) need2(Math.abs(dot4(basis3, prior, s)) <= 1e-12, "orthogonality");
    q.push(basis3);
    rows.push(pivot);
    remaining.splice(remaining.indexOf(pivot), 1);
    for (const index of remaining) for (let pass = 0; pass < 2; pass++) {
      const target = residual.get(index);
      axpy(target, basis3, -dot4(target, basis3, s), s);
    }
  }
  const lower = rows.map((index, i) => q.slice(0, i + 1).map((basis3) => dot4(a2[index], basis3, s)));
  return { rows, q, lower };
}
function equality(m, qr, s) {
  const c = qr.q.map((row) => dot4(row, m.free, s)), target = [...m.free];
  for (let i = 0; i < qr.q.length; i++) axpy(target, qr.q[i], -c[i], s);
  const lambda = Array(qr.rows.length).fill(0);
  for (let i = lambda.length - 1; i >= 0; i--) {
    let value = -c[i];
    for (let j = i + 1; j < lambda.length; j++) {
      take(s, "triangularTerms");
      value = finite4(value - finite4(qr.lower[j][i] * lambda[j]));
    }
    lambda[i] = finite4(value / qr.lower[i][i]);
  }
  return { target, lambda };
}
function outputBodies(m, x, s) {
  return m.input.bodies.map((body, index) => {
    const result = copyBody2(body), block = m.blocks[index];
    if (block.offset !== null) {
      result.velocityMps = [0, 1, 2].map((k) => finite4(block.rootMass * x[block.offset + k]));
      result.angularVelocityRadps = block.angular.map((row) => dot4(row, x.slice(block.offset + 3, block.offset + 6), s));
    }
    return result;
  });
}
function finish2(m, x, active, multipliers, s) {
  const lambda = Array(m.a.length).fill(0);
  active.forEach((index, i) => {
    need2(multipliers[i] >= -1e-10, "negative active multiplier");
    lambda[index] = Math.max(0, multipliers[i]);
  });
  const bodies = outputBodies(m, x, s), ids = new Map(bodies.map((body, i) => [body.id, i]));
  const rowResiduals = m.input.points.map((point2, i) => {
    take(s, "constraintTests");
    const velocities = [point2.aId, point2.bId].map((id) => {
      const body = bodies[ids.get(id)], spin = cross2(body.angularVelocityRadps, subtract(point2.pointM, body.positionM));
      return body.velocityMps.map((v, k) => finite4(v + spin[k]));
    });
    const relative = subtract(velocities[1], velocities[0]), vn = dot4(relative, point2.normalAtoB, s);
    const tangent = relative.map((value, k) => finite4(value - point2.normalAtoB[k] * vn));
    return {
      id: point2.id,
      normalSpeedMps: vn,
      negativeNormalImpulseNs: Math.max(0, -lambda[i]),
      complementarityJ: Math.abs(finite4(lambda[i] * vn)),
      tangentSpeedMps: Math.hypot(...tangent)
    };
  });
  let stationarity = 0;
  for (let k = 0; k < x.length; k++) {
    const reaction = dot4(m.a.map((row) => row[k]), lambda, s);
    stationarity = Math.max(stationarity, Math.abs(finite4(x[k] - m.free[k] - reaction)));
  }
  const certificate2 = {
    maxClosingNormalSpeedMps: Math.max(0, ...rowResiduals.map((row) => -row.normalSpeedMps)),
    maxNegativeNormalImpulseNs: Math.max(0, ...rowResiduals.map((row) => row.negativeNormalImpulseNs)),
    maxComplementarityJ: Math.max(0, ...rowResiduals.map((row) => row.complementarityJ)),
    maxStationaritySqrtJ: stationarity,
    maxLoadedTangentSpeedMps: Math.max(0, ...rowResiduals.filter((_, i) => lambda[i] > 0).map((row) => row.tangentSpeedMps)),
    zeroTangentFeasible: false
  };
  certificate2.zeroTangentFeasible = certificate2.maxLoadedTangentSpeedMps <= 1e-10;
  need2(certificate2.maxClosingNormalSpeedMps <= 1e-10 && certificate2.maxNegativeNormalImpulseNs <= 1e-10 && certificate2.maxComplementarityJ <= 1e-10 && certificate2.maxStationaritySqrtJ <= 1e-10, "final certificate");
  s.finalActiveRows = active.length;
  return {
    ok: true,
    status: "SOLVED_NORMAL_ONLY",
    bodies,
    normalImpulsesNs: [...lambda],
    rowResiduals,
    certificate: certificate2,
    stats: { ...s },
    reason: null
  };
}
function solveNormalContacts(problem) {
  const s = stats();
  let input = null;
  try {
    input = read(problem);
    const m = model(input, s);
    let current = Array(m.free.length).fill(0), active = null;
    for (; ; ) {
      take(s, "outerIterations");
      const qr = factor(m.a, active ?? m.a.map((_, i) => i), s);
      if (active === null) s.qrRank = qr.rows.length;
      else need2(qr.rows.length === active.length, "dependent working basis");
      active = [...qr.rows];
      const solved = equality(m, qr, s), direction2 = solved.target.map((value, i) => finite4(value - current[i]));
      const directionNorm = Math.sqrt(dot4(direction2, direction2, s));
      let alpha = 1, blocker = null;
      if (directionNorm > 1e-12 * Math.max(1, Math.sqrt(dot4(m.free, m.free, s)))) {
        for (let i = 0; i < m.a.length; i++) {
          take(s, "constraintTests");
          if (active.includes(i)) continue;
          const margin = dot4(m.a[i], current, s), slope = dot4(m.a[i], direction2, s);
          need2(margin >= -1e-10, "lost feasible iterate");
          if (slope < -1e-12) {
            const step = finite4(Math.max(0, margin) / -slope);
            if (step < alpha || step === alpha && step < 1 && (blocker === null || i < blocker)) {
              alpha = step;
              blocker = i;
            }
          }
        }
      }
      if (blocker !== null && alpha < 1) {
        axpy(current, direction2, alpha, s);
        take(s, "activeChanges");
        active.push(blocker);
        continue;
      }
      current = solved.target;
      let leaving = null;
      for (let i = 0; i < active.length; i++) if (solved.lambda[i] < -1e-10 && (leaving === null || active[i] < active[leaving])) leaving = i;
      if (leaving !== null) {
        take(s, "activeChanges");
        active.splice(leaving, 1);
        continue;
      }
      return finish2(m, current, active, solved.lambda, s);
    }
  } catch (error2) {
    if (!(error2 instanceof Stop2)) throw error2;
    return {
      ok: false,
      status: error2.status,
      bodies: input?.bodies.map(copyBody2) ?? [],
      normalImpulsesNs: null,
      rowResiduals: null,
      certificate: null,
      stats: { ...s },
      reason: error2.message
    };
  }
}

// src/stack/frictionless-island.ts
var FrictionlessIslandFailure = class extends PhysicsError {
  diagnostics;
  constructor(reason, diagnostics) {
    super(reason.code, reason.message);
    this.diagnostics = structuredClone(diagnostics);
  }
};
var SI = 1e-10;
function need3(ok, message) {
  if (!ok) throw new PhysicsError("NUMERIC_LIMIT", "frictionless island: " + message);
}
function finite5(value) {
  need3(Number.isFinite(value), "finite validation arithmetic");
  return value;
}
function maximum(values) {
  return values.reduce((value, next) => Math.max(value, Math.abs(finite5(next))), 0);
}
function pairKey2(a2, b2) {
  return a2.id + "\0" + b2.id;
}
function velocityAt(body, point2) {
  return add(body.velocityMps, cross(body.angularVelocityRadps, sub(point2, body.positionM)));
}
function worldInverse(body) {
  if (body.inverseMass === 0) return [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  const local = body.inverseInertiaLocal;
  if (local[0] === local[1] && local[1] === local[2]) {
    const c = local[0];
    return [[c, 0, 0], [0, c, 0], [0, 0, c]];
  }
  const columns = [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => inverseInertia(body, axis));
  return [
    [columns[0][0], columns[1][0], columns[2][0]],
    [columns[0][1], columns[1][1], columns[2][1]],
    [columns[0][2], columns[1][2], columns[2][2]]
  ];
}
function normalBody(body) {
  return {
    id: body.id,
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inverseMass: body.inverseMass,
    inverseInertiaWorld: worldInverse(body)
  };
}
function validationFactor(matrix3) {
  const lower = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  const magnitude2 = Math.max(1, ...matrix3.flat().map(Math.abs));
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++)
    need3(matrix3[i][j] === matrix3[j][i], "actual inverse inertia symmetry");
  for (let i = 0; i < 3; i++) for (let j = 0; j <= i; j++) {
    let value = matrix3[i][j];
    for (let k = 0; k < j; k++) value = finite5(value - finite5(lower[i][k] * lower[j][k]));
    if (i === j) {
      need3(value > 1e-12 * magnitude2, "actual inverse inertia positive definite");
      lower[i][j] = Math.sqrt(value);
    } else lower[i][j] = finite5(value / lower[j][j]);
  }
  return lower;
}
function whiten(factor2, angularVelocity) {
  const out = [];
  for (let i = 0; i < 3; i++) {
    let value = angularVelocity[i];
    for (let j = 0; j < i; j++) value = finite5(value - finite5(factor2[i][j] * out[j]));
    out.push(finite5(value / factor2[i][i]));
  }
  return out;
}
function validateApplied(free, applied, problem, solved, applications) {
  need3(solved.ok && solved.normalImpulsesNs && solved.bodies.length === free.length, "complete normal solve");
  const result = {
    maxClosingNormalSpeedMps: 0,
    maxComplementarityJ: 0,
    maxStationaritySqrtJ: 0,
    maxSolverVelocityDifference: 0,
    maxLinearMomentumResidualNs: 0,
    maxAngularMomentumResidualNms: 0,
    postValidationCholeskyFactorizations: 0
  };
  const linear = free.map(() => [0, 0, 0]), angular = free.map(() => [0, 0, 0]);
  for (const entry of applications) {
    const application = entry.contribution.applications[0];
    need3(application && entry.contribution.applications.length === 1, "one actual point application");
    for (const [index, side2] of [[entry.aIndex, application.onA], [entry.bIndex, application.onB]]) {
      linear[index] = add(linear[index], side2.linearImpulseNs);
      angular[index] = add(angular[index], side2.armTorqueNms);
    }
  }
  const ids = new Map(free.map((body, index) => [body.id, index]));
  for (let i = 0; i < free.length; i++) {
    need3(applied[i].id === free[i].id && solved.bodies[i].id === free[i].id, "body order retained");
    if (free[i].inverseMass === 0) continue;
    const factor2 = validationFactor(problem.bodies[i].inverseInertiaWorld);
    result.postValidationCholeskyFactorizations++;
    const rootMass = Math.sqrt(free[i].inverseMass);
    const oldAngular = whiten(factor2, free[i].angularVelocityRadps);
    const newAngular = whiten(factor2, applied[i].angularVelocityRadps);
    const reaction = [0, 0, 0, 0, 0, 0];
    for (let p = 0; p < problem.points.length; p++) {
      const point2 = problem.points[p], lambda = solved.normalImpulsesNs[p];
      const sign = point2.aId === free[i].id ? -1 : point2.bId === free[i].id ? 1 : 0;
      if (!sign) continue;
      const n = [...point2.normalAtoB];
      const torque = cross(sub([...point2.pointM], free[i].positionM), n);
      for (let k = 0; k < 3; k++) {
        reaction[k] = finite5(reaction[k] + finite5(finite5(sign * n[k] * rootMass) * lambda));
        let coefficient = 0;
        for (let j = 0; j < 3; j++) coefficient = finite5(coefficient + finite5(torque[j] * factor2[j][k]));
        reaction[k + 3] = finite5(reaction[k + 3] + finite5(finite5(sign * coefficient) * lambda));
      }
    }
    const residual = [0, 1, 2].map((k) => finite5(applied[i].velocityMps[k] / rootMass - free[i].velocityMps[k] / rootMass - reaction[k]));
    for (let k = 0; k < 3; k++) residual.push(finite5(newAngular[k] - oldAngular[k] - reaction[k + 3]));
    result.maxStationaritySqrtJ = Math.max(result.maxStationaritySqrtJ, maximum(residual));
    result.maxSolverVelocityDifference = Math.max(
      result.maxSolverVelocityDifference,
      maximum(sub(applied[i].velocityMps, [...solved.bodies[i].velocityMps])),
      maximum(sub(applied[i].angularVelocityRadps, [...solved.bodies[i].angularVelocityRadps]))
    );
    result.maxLinearMomentumResidualNs = Math.max(
      result.maxLinearMomentumResidualNs,
      maximum(sub(scale(sub(applied[i].velocityMps, free[i].velocityMps), 1 / free[i].inverseMass), linear[i]))
    );
    result.maxAngularMomentumResidualNms = Math.max(
      result.maxAngularMomentumResidualNms,
      maximum(sub(inertia(free[i], sub(applied[i].angularVelocityRadps, free[i].angularVelocityRadps)), angular[i]))
    );
  }
  for (let p = 0; p < problem.points.length; p++) {
    const point2 = problem.points[p], a2 = ids.get(point2.aId), b2 = ids.get(point2.bId);
    need3(a2 !== void 0 && b2 !== void 0, "normal endpoints retained");
    const relative = sub(velocityAt(applied[b2], [...point2.pointM]), velocityAt(applied[a2], [...point2.pointM]));
    const speed = finite5(dot(relative, [...point2.normalAtoB]));
    result.maxClosingNormalSpeedMps = Math.max(result.maxClosingNormalSpeedMps, -speed);
    result.maxComplementarityJ = Math.max(result.maxComplementarityJ, Math.abs(finite5(speed * solved.normalImpulsesNs[p])));
  }
  for (const key of [
    "maxClosingNormalSpeedMps",
    "maxComplementarityJ",
    "maxStationaritySqrtJ",
    "maxSolverVelocityDifference",
    "maxLinearMomentumResidualNs",
    "maxAngularMomentumResidualNms"
  ])
    need3(Number.isFinite(result[key]) && result[key] <= SI, "actual applied normal certificate: " + key);
  return result;
}
function representative(a2, b2, geometry) {
  const mean = scale(geometry.points.reduce((sum, point2) => add(sum, point2.midpointM), [0, 0, 0]), 1 / geometry.points.length);
  const exact3 = new StrictLineContext(a2, b2, geometry.planeNormalAtoB);
  need3(exact3.check(mean), "post representative strict line");
  if (geometry.family === "face") {
    const reference = geometry.reference;
    need3(reference, "post face selectors");
    const ref = { axis: reference.axis, side: reference.side };
    const inc = { axis: reference.incidentAxis, side: reference.incidentSide };
    const faceA = reference.body === "a" ? ref : inc, faceB = reference.body === "a" ? inc : ref;
    need3(
      exact3.selectedFaceBounds(mean, faceA, faceB) && exact3.onFace(0, faceA, mean) && exact3.onFace(1, faceB, mean),
      "post representative finite boundary faces"
    );
  }
  return mean;
}
function prepareFrictionlessIsland(freeBodies, pairs, context2) {
  const diagnostics = {
    freeBodies: [],
    pairs: [],
    freeGeometry: [],
    normalProblem: null,
    normalResult: null,
    applications: [],
    velocityBodies: null,
    appliedNormalCertificate: null,
    positionAttempt: null,
    positionStats: null,
    postGeometry: [],
    pairContributions: [],
    normalSolverCalls: 0,
    positionPhaseCalls: 0,
    positionSolverCalls: 0
  };
  try {
    need3(context2 && context2.jointCount === 0, "no joints");
    need3(Array.isArray(freeBodies) && freeBodies.length >= 1 && freeBodies.length <= 4 && freeBodies.every((body) => body !== null && typeof body === "object") && freeBodies.some((body) => body.kind === "dynamic"), "existing persistent body bound");
    checkedFullPairInputs(freeBodies, pairs);
    for (const body of freeBodies) need3(
      body.frictionStatic === 0 && body.frictionDynamic === 0 && body.restitution === 0 && !body.sleeping && !body.sensor && !body.ccd && !body.collisionFilter,
      "zero-friction zero-restitution unfiltered awake boxes"
    );
    for (const body of freeBodies) if (body.kind === "static")
      need3(body.inverseInertiaLocal.every((value) => value === 0), "prescribed static inverse inertia");
    const working = freeBodies.map(copyBody);
    diagnostics.freeBodies = working.map(copyBody);
    diagnostics.pairs = pairs.map(([a2, b2]) => [a2, b2]);
    const points = [];
    for (const [aIndex, bIndex] of pairs) {
      const a2 = working[aIndex], b2 = working[bIndex], hit = detect(a2, b2);
      if (!hit) continue;
      const geometry = featureContact(a2, b2);
      need3(geometry && geometry.points.length > 0, "actual free contact geometry");
      const key = pairKey2(a2, b2);
      diagnostics.freeGeometry.push({
        aIndex,
        bIndex,
        aId: a2.id,
        bId: b2.id,
        pairKey: key,
        hit: structuredClone(hit),
        geometry
      });
      for (const point2 of geometry.points) points.push({
        id: JSON.stringify([key, point2.key]),
        aId: a2.id,
        bId: b2.id,
        pointM: [...point2.midpointM],
        normalAtoB: [...geometry.planeNormalAtoB]
      });
    }
    need3(points.length <= 32, "existing normal point bound");
    const problem = { bodies: working.map(normalBody), points };
    diagnostics.normalProblem = problem;
    diagnostics.normalSolverCalls++;
    const solved = solveNormalContacts(problem);
    diagnostics.normalResult = solved;
    if (!solved.ok) throw new PhysicsError(
      solved.status === "ITERATION_LIMIT" ? "ITERATION_LIMIT" : "NUMERIC_LIMIT",
      "frictionless island normal: " + solved.reason
    );
    need3(
      solved.status === "SOLVED_NORMAL_ONLY" && solved.normalImpulsesNs && solved.normalImpulsesNs.length === points.length,
      "complete global normal solve"
    );
    const totals = new ContactPairAccumulator(), byId = new Map(working.map((body, index) => [body.id, index]));
    let pointIndex = 0;
    for (const patch of diagnostics.freeGeometry) for (const point2 of patch.geometry.points) {
      const a2 = working[patch.aIndex], b2 = working[patch.bIndex], lambda = solved.normalImpulsesNs[pointIndex];
      need3(
        Number.isFinite(lambda) && lambda >= 0 && problem.points[pointIndex].id === JSON.stringify([patch.pairKey, point2.key]),
        "nonnegative actual point impulse/link"
      );
      const n = [...patch.geometry.planeNormalAtoB];
      const pointM = [...point2.midpointM], onB = scale(n, lambda);
      const armA = sub(pointM, a2.positionM), armB = sub(pointM, b2.positionM);
      const contribution = contactApplication(a2.positionM, b2.positionM, armA, armB, onB);
      const actual = contribution.applications[0];
      diagnostics.applications.push({
        id: problem.points[pointIndex].id,
        aIndex: patch.aIndex,
        bIndex: patch.bIndex,
        pairKey: patch.pairKey,
        pointKey: point2.key,
        pointM,
        normalAtoB: n,
        normalImpulseNs: lambda,
        contribution
      });
      totals.add(a2.id, b2.id, contribution);
      if (lambda !== 0) {
        for (const [body, side2] of [[a2, actual.onA], [b2, actual.onB]]) if (body.inverseMass !== 0) {
          body.velocityMps = add(body.velocityMps, scale(side2.linearImpulseNs, body.inverseMass));
          body.angularVelocityRadps = add(body.angularVelocityRadps, inverseInertia(body, side2.armTorqueNms));
        }
      }
      pointIndex++;
    }
    need3(pointIndex === points.length, "every normal point applied exactly once");
    diagnostics.pairContributions = totals.finish();
    diagnostics.velocityBodies = working.map(copyBody);
    validateResult(working, []);
    diagnostics.appliedNormalCertificate = validateApplied(diagnostics.freeBodies, working, problem, solved, diagnostics.applications);
    diagnostics.positionPhaseCalls++;
    diagnostics.positionSolverCalls = null;
    try {
      const position = runFullPairPositionPhase(working, pairs);
      diagnostics.positionAttempt = position.attempt;
      diagnostics.positionStats = position.stats;
      diagnostics.positionSolverCalls = position.stats.solverCalls;
    } catch (error2) {
      if (error2 instanceof PositionPhaseFailure) {
        diagnostics.positionAttempt = error2.attempt;
        diagnostics.positionStats = error2.stats;
        diagnostics.positionSolverCalls = error2.stats.solverCalls;
      }
      throw error2;
    }
    const impulseTotals = /* @__PURE__ */ new Map();
    for (const application of diagnostics.applications)
      impulseTotals.set(application.pairKey, finite5((impulseTotals.get(application.pairKey) ?? 0) + application.normalImpulseNs));
    const freePenetrations = new Map(diagnostics.freeGeometry.map((patch) => [patch.pairKey, patch.hit?.penetration ?? 0]));
    const contacts = [], retained = /* @__PURE__ */ new Set();
    for (const [aIndex, bIndex] of pairs) {
      const a2 = working[aIndex], b2 = working[bIndex], key = pairKey2(a2, b2);
      const geometry = featureContact(a2, b2);
      if (!geometry) {
        need3((impulseTotals.get(key) ?? 0) === 0, "applied pair needs fresh post witness");
        continue;
      }
      diagnostics.postGeometry.push({
        aIndex,
        bIndex,
        aId: a2.id,
        bId: b2.id,
        pairKey: key,
        hit: detect(a2, b2),
        geometry
      });
      for (const point2 of geometry.points) {
        const speed = finite5(dot(sub(velocityAt(b2, point2.midpointM), velocityAt(a2, point2.midpointM)), geometry.planeNormalAtoB));
        need3(speed >= -SI, "fresh post contact normal feasibility");
      }
      const mean = representative(a2, b2, geometry);
      contacts.push({
        aId: a2.id,
        bId: b2.id,
        normalAtoB: [...geometry.planeNormalAtoB],
        pointM: mean,
        penetrationM: freePenetrations.get(key) ?? 0,
        impulseNs: impulseTotals.get(key) ?? 0,
        tangentImpulseNs: [0, 0, 0]
      });
      retained.add(key);
    }
    for (const [key, impulse] of impulseTotals) need3(impulse === 0 || retained.has(key), "all applied pair summaries retained");
    need3(byId.size === working.length, "body identity retained");
    validateResult(working, contacts);
    return {
      candidateBodies: working.map(copyBody),
      contacts,
      pairStats: {
        eligiblePairs: pairs.length,
        candidatePairs: pairs.length,
        aabbTests: 0
      },
      pairContributions: structuredClone(diagnostics.pairContributions),
      diagnostics: structuredClone(diagnostics)
    };
  } catch (caught) {
    if (caught instanceof StrictLineFailure) throw new FrictionlessIslandFailure(
      new PhysicsError("NUMERIC_LIMIT", "frictionless island post representative strict-line refusal"),
      diagnostics
    );
    if (caught instanceof PhysicsError) throw new FrictionlessIslandFailure(caught, diagnostics);
    throw caught;
  }
}

// src/world.ts
function publicState(bodies, contacts, events, joints, ccdHits, pairStats, stepIndex, dt, identity2, colliderIds) {
  return {
    identity: { ...identity2 },
    stepIndex,
    timeSeconds: stepIndex * dt,
    bodies: bodies.map((body) => ({
      id: body.id,
      kind: body.kind,
      positionM: [...body.positionM],
      orientationXYZW: [...body.orientation],
      velocityMps: [...body.velocityMps],
      angularVelocityRadps: [...body.angularVelocityRadps],
      sleeping: body.sleeping ?? false
    })),
    contacts: contacts.map((contact) => ({
      colliderAId: colliderIds.get(contact.aId),
      colliderBId: colliderIds.get(contact.bId),
      bodyAId: contact.aId,
      bodyBId: contact.bId,
      normalAtoB: [...contact.normalAtoB],
      pointM: [...contact.pointM],
      penetrationM: contact.penetrationM,
      normalImpulseNs: contact.impulseNs,
      tangentImpulseOnBNs: [...contact.tangentImpulseNs]
    })),
    events: events.map((event) => ({
      colliderAId: colliderIds.get(event.aId),
      colliderBId: colliderIds.get(event.bId),
      kind: event.kind,
      phase: event.phase
    })),
    joints: joints.map((joint) => ({
      id: joint.id,
      bodyAId: joint.aId,
      bodyBId: joint.bId,
      linearImpulseOnBNs: [...joint.linearImpulseNs],
      angularImpulseOnBNms: [...joint.angularImpulseNms],
      angleRad: joint.angleRad ?? null,
      motorImpulseNms: joint.motorImpulseNms ?? null
    })),
    ccdHits: ccdHits.map((hit) => ({
      bodyId: hit.bodyId,
      colliderId: colliderIds.get(hit.fixtureId),
      toiFraction: hit.toiFraction,
      normalFixtureToBody: [...hit.normalFixtureToBody]
    })),
    cloths: [],
    fluids: [],
    pairStats: { ...pairStats }
  };
}
function publicDomainState(runtime, model2, identity2, stepIndex, dt, prepared) {
  const bodies = model2.bodies.map((body) => ({
    id: body.id,
    kind: body.kind,
    positionM: [...body.initial.positionM],
    orientationXYZW: [...body.initial.orientationXYZW],
    velocityMps: [0, 0, 0],
    angularVelocityRadps: [0, 0, 0],
    sleeping: false
  }));
  const state = {
    identity: { ...identity2 },
    stepIndex,
    timeSeconds: stepIndex * dt,
    bodies,
    joints: [],
    contacts: [],
    events: [],
    ccdHits: [],
    cloths: [],
    fluids: [],
    pairStats: { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 }
  };
  if (runtime.kind === "cloth") {
    const output2 = prepared ?? {
      id: runtime.definition.cloth.id,
      positionsM: runtime.accepted.positions.slice(),
      velocitiesMps: runtime.accepted.velocities.slice(),
      diagnostics: { ...runtime.accepted.diagnostics }
    };
    return { ...state, cloths: [output2] };
  }
  const output = prepared ?? {
    id: runtime.definition.fluid.id,
    positionsM: runtime.accepted.positions.slice(),
    velocitiesMps: runtime.accepted.velocities.slice(),
    diagnostics: { ...runtime.accepted.diagnostics }
  };
  return { ...state, fluids: [output] };
}
function createPhysicsWorld(model2, options) {
  const admitted3 = admitModel(model2, options);
  const islandMode = admitted3.options.profile === "rigid-persistent-box-v1" && admitted3.joints.length === 0 && admitted3.bodies.some((body) => body.kind === "dynamic") && admitted3.bodies.every((body) => (body.kind === "dynamic" || body.kind === "static") && body.shape.kind === "box" && !body.sleeping && !body.sensor && !body.ccd && !body.collisionFilter && body.restitution === 0 && body.frictionStatic === 0 && body.frictionDynamic === 0);
  if (islandMode && admitted3.options.broadPhase !== "direct") {
    error("INVALID_CONFIG", "frictionless island requires direct broadPhase");
  }
  const dt = admitted3.options.fixedStepSeconds;
  const domainKind = admitted3.domain?.kind ?? null;
  const domainId = admitted3.domain?.data.id ?? null;
  const stationaryMode = admitted3.stationary;
  const stepLimit = stationaryMode ? STATIONARY_MAX_STEPS : domainKind === "cloth" ? CLOTH_MAX_STEPS : domainKind === "fluid" ? FLUID_MAX_STEPS : MAX_STEPS;
  let domainState = null;
  if (admitted3.domain?.kind === "cloth") {
    const initialized = initializeCloth(admitted3.domain.data, admitted3.domain.staticData);
    domainState = { kind: "cloth", definition: initialized.definition, accepted: initialized.initial };
  } else if (admitted3.domain?.kind === "fluid") {
    const initialized = initializeFluid(admitted3.domain.data, admitted3.domain.staticData);
    domainState = { kind: "fluid", definition: initialized.definition, accepted: initialized.initial };
  }
  const gravity = [...admitted3.model.gravityMps2];
  const useAabb = admitted3.options.broadPhase === "aabb";
  const usePersistentBox = admitted3.options.profile === "rigid-persistent-box-v1";
  const largeMode = admitted3.options.profile === "rigid-large-v1";
  let bodies = admitted3.bodies;
  let joints = admitted3.joints;
  let disjointHinges = admitted3.disjointHinges;
  let modelCopy = admitted3.model;
  let optionsCopy = admitted3.options;
  const colliderIds = new Map(admitted3.model.colliders.map((collider) => [collider.bodyId, collider.id]));
  const identity2 = {
    modelRevision: admitted3.model.revision,
    modelDigest: digest(admitted3.model),
    configurationDigest: digest(admitted3.options),
    providerDigest: digest(providerManifest),
    profile: admitted3.options.profile,
    frameId: admitted3.model.frame.id,
    fixedStepSeconds: dt
  };
  let dynamicHinge = joints.find((joint) => joint.kind === "hinge" && bodies[joint.aIndex].kind === "dynamic");
  if (dynamicHinge && !disjointHinges) admitDynamicHingeScene(dynamicHinge, bodies, gravity);
  let ccd = domainKind ? { kind: "none" } : admitCcd(bodies, joints.length, gravity);
  if (ccd.kind === "box-pair" && usePersistentBox) {
    error("INVALID_CONFIG", "box CCD excludes persistent-box-v1");
  }
  const disabledPairs = new Set(joints.map((joint) => [bodies[joint.aIndex].id, bodies[joint.bIndex].id].sort().join("\0")));
  const pairs = [];
  for (let a2 = 0; a2 < bodies.length; a2++) for (let b2 = a2 + 1; b2 < bodies.length; b2++) {
    if ((bodies[a2].inverseMass !== 0 || bodies[b2].inverseMass !== 0) && (!largeMode || filterAllowsPair(bodies[a2], bodies[b2]))) {
      if (disabledPairs.has([bodies[a2].id, bodies[b2].id].sort().join("\0"))) continue;
      pairs.push(bodies[a2].id < bodies[b2].id ? [a2, b2] : [b2, a2]);
    }
  }
  pairs.sort((left, right) => bodies[left[0]].id < bodies[right[0]].id ? -1 : bodies[left[0]].id > bodies[right[0]].id ? 1 : bodies[left[1]].id < bodies[right[1]].id ? -1 : 1);
  let contacts = [];
  let events = [];
  let ccdHits = [];
  let pairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
  let jointStates = joints.map((joint) => ({
    id: joint.id,
    kind: joint.kind,
    aId: bodies[joint.aIndex].id,
    bId: bodies[joint.bIndex].id,
    linearImpulseNs: [0, 0, 0],
    angularImpulseNms: [0, 0, 0],
    ...joint.kind === "hinge" ? { angleRad: 0 } : {},
    ...joint.motor ? { motorImpulseNms: 0 } : {}
  }));
  let activePairs = /* @__PURE__ */ new Map();
  let persistentPoints = /* @__PURE__ */ new Map();
  let sleepFrames = bodies.map(() => 0);
  let stepIndex = 0;
  let disposed = false;
  let owner = null;
  let advancingOwner = null;
  const ensureActive = () => {
    if (disposed) error("DISPOSED", "world is disposed");
  };
  const world = {
    getModel() {
      ensureActive();
      return copyData(modelCopy);
    },
    getState() {
      ensureActive();
      return domainState ? publicDomainState(domainState, modelCopy, identity2, stepIndex, dt) : publicState(bodies, contacts, events, jointStates, ccdHits, pairStats, stepIndex, dt, identity2, colliderIds);
    },
    step(commands = []) {
      ensureActive();
      if (owner !== advancingOwner) error("WORLD_OWNED", "World has an exclusive recorder");
      if (stepIndex >= stepLimit) error("WORLD_LIMIT", "world step limit reached");
      if (owner && (owner.recording.frames.length >= 512 || Array.isArray(commands) && owner.commandCount + commands.length > 4096)) {
        error("WORLD_LIMIT", "recording frame or command limit reached");
      }
      let admittedCommands;
      try {
        admittedCommands = copyData(commands);
      } catch (failure) {
        if (failure instanceof PhysicsError7 && failure.code === "INVALID_CONFIG") error("INVALID_COMMAND", failure.message);
        throw failure;
      }
      if (owner && Array.isArray(admittedCommands) && owner.commandCount + admittedCommands.length > 4096) {
        error("WORLD_LIMIT", "recording command limit reached");
      }
      const actions = parseCommands(admittedCommands, bodies);
      if (stationaryMode) {
        admitStationaryCommands(admittedCommands);
        let phase = "prepare-output";
        try {
          const preparedFrames = owner ? owner.prepareFrames(admittedCommands, stepIndex + 1) : null;
          phase = "candidate";
          const prepared = prepareStackStep(bodies, dt, gravity);
          phase = "prepare-output";
          const output = prepareStationaryOutput(prepared, activePairs);
          const next = prepared.candidateBodies;
          phase = "validation";
          validateResult(next, output.contacts);
          phase = "prepare-output";
          const nextJoints = [], nextCcdHits = [];
          const nextPersistentPoints = /* @__PURE__ */ new Map(), nextSleepFrames = next.map(() => 0);
          const state = publicState(
            next,
            output.contacts,
            output.events,
            nextJoints,
            nextCcdHits,
            output.pairStats,
            stepIndex + 1,
            dt,
            identity2,
            colliderIds
          );
          const preparedRecording = owner ? owner.prepare(preparedFrames, state) : null;
          const preparedCommandCount = owner ? owner.commandCount + admittedCommands.length : 0;
          bodies = next;
          contacts = output.contacts;
          events = output.events;
          jointStates = nextJoints;
          ccdHits = nextCcdHits;
          pairStats = output.pairStats;
          activePairs = output.activePairs;
          persistentPoints = nextPersistentPoints;
          sleepFrames = nextSleepFrames;
          stepIndex++;
          if (owner) {
            owner.recording = preparedRecording;
            owner.commandCount = preparedCommandCount;
          }
          return state;
        } catch (failure) {
          if (!(failure instanceof PhysicsError7)) throw failure;
          const enriched = new PhysicsError7(failure.code, failure.message, {
            operation: owner ? "record" : "step",
            phase: failure.code === "WORLD_LIMIT" ? "budget" : phase,
            domain: "rigid",
            entityIds: [...failure.details.entityIds],
            accepted: { stepIndex, timeSeconds: stepIndex * dt }
          });
          enriched.stack = failure.stack;
          throw enriched;
        }
      }
      if (domainState) {
        if (admittedCommands.length !== 0) error("INVALID_COMMAND", "visual domain commands are unsupported");
        const preparedFrames = owner ? owner.prepareFrames(admittedCommands, stepIndex + 1) : null;
        let nextDomain;
        let output;
        if (domainState.kind === "cloth") {
          const prepared = prepareCloth(domainState.definition, domainState.accepted);
          nextDomain = { kind: "cloth", definition: domainState.definition, accepted: prepared.candidate };
          output = prepared.output;
        } else {
          const prepared = prepareFluid(domainState.definition, domainState.accepted);
          nextDomain = { kind: "fluid", definition: domainState.definition, accepted: prepared.candidate };
          output = prepared.output;
        }
        const state = publicDomainState(nextDomain, modelCopy, identity2, stepIndex + 1, dt, output);
        const preparedRecording = owner ? owner.prepare(preparedFrames, state) : null;
        const preparedCommandCount = owner ? owner.commandCount + admittedCommands.length : 0;
        domainState = nextDomain;
        stepIndex++;
        if (owner) {
          owner.recording = preparedRecording;
          owner.commandCount = preparedCommandCount;
        }
        return state;
      }
      if (disjointHinges) admitDisjointHingeCommands(disjointHinges, bodies, actions, admittedCommands.length);
      else if (dynamicHinge) admitDynamicHingeCommands(dynamicHinge, bodies, actions);
      if (ccd.kind === "box-pair") rejectAngularBoxCommand(actions.get(bodies[ccd.boxIndex].id));
      let preparationPhase = "prepare-output";
      try {
        const preparedFrames = owner ? owner.prepareFrames(admittedCommands, stepIndex + 1) : null;
        preparationPhase = "candidate";
        let next = bodies.map(copyBody);
        const motorImpulses = joints.map(() => 0);
        const nextSleepFrames = sleepFrames.slice();
        if (largeMode) wakeForActions(next, contacts, actions, nextSleepFrames);
        for (const body of next) {
          if (body.kind !== "dynamic" || largeMode && body.sleeping) continue;
          const action = actions.get(body.id);
          body.angularVelocityRadps = add(
            body.angularVelocityRadps,
            inverseInertia(body, action?.angularImpulseNms ?? [0, 0, 0])
          );
        }
        if (disjointHinges) driveDisjointHingeMotors(disjointHinges, next, jointStates, motorImpulses);
        else for (let index = 0; index < joints.length; index++) {
          const joint = joints[index];
          if (!joint.motor) continue;
          motorImpulses[index] = next[joint.aIndex].kind === "dynamic" ? driveDynamicHingeMotor(
            joint,
            next[joint.aIndex],
            next[joint.bIndex],
            jointStates[index].angleRad
          ) : driveHingeMotor(joint, next[joint.bIndex], jointStates[index].angleRad);
        }
        for (let bodyIndex = 0; bodyIndex < next.length; bodyIndex++) {
          const body = next[bodyIndex];
          const action = actions.get(body.id);
          if (body.kind === "kinematic") {
            const target = action?.positionM ?? body.positionM;
            const delta = target.map((value, index) => value - body.positionM[index]);
            if (Math.hypot(...delta) > MAX_STEP_DISPLACEMENT_M || delta.some((value) => Math.abs(value / dt) > 1e3)) {
              error("NUMERIC_LIMIT", `${body.id} exceeded kinematic movement limit`);
            }
            body.velocityMps = delta.map((value) => value / dt);
            body.positionM = [...target];
          } else if (body.kind === "dynamic") {
            if (largeMode && body.sleeping) continue;
            if (body.angularVelocityRadps.some((value) => !Number.isFinite(value) || Math.abs(value) > 1e3) || Math.hypot(...body.angularVelocityRadps) * dt > 10) {
              error("NUMERIC_LIMIT", `${body.id} exceeded angular movement limit`);
            }
            const preparedRotation = prepareForcedRotation(body, dt, action?.torqueNm ?? [0, 0, 0]) ?? prepareFreeRotation(body, dt) ?? {
              orientation: advanceOrientation(body.orientation, body.angularVelocityRadps, dt),
              angularVelocityRadps: [...body.angularVelocityRadps]
            };
            validateRotationResult(preparedRotation, dt);
            body.angularVelocityRadps = preparedRotation.angularVelocityRadps;
            body.orientation = preparedRotation.orientation;
            for (let i = 0; i < 3; i++) {
              body.velocityMps[i] += (action?.impulseNs?.[i] ?? 0) * body.inverseMass;
              body.velocityMps[i] += (gravity[i] + (action?.forceN?.[i] ?? 0) * body.inverseMass) * dt;
            }
            if (Math.hypot(...body.velocityMps) * dt > MAX_STEP_DISPLACEMENT_M) {
              error("NUMERIC_LIMIT", `${body.id} exceeded step displacement limit`);
            }
            for (let i = 0; i < 3; i++) body.positionM[i] += body.velocityMps[i] * dt;
          }
        }
        const hit = ccd.kind === "static-boxes" ? sweepSphere(bodies[ccd.sphereIndex], next[ccd.sphereIndex], ccd.fixtures) : ccd.kind === "sphere-pair" ? sweepSpherePair(
          bodies[ccd.sphereIndex],
          next[ccd.sphereIndex],
          bodies[ccd.otherIndex],
          next[ccd.otherIndex]
        ) : ccd.kind === "box-pair" ? sweepDynamicBox(
          bodies[ccd.boxIndex],
          next[ccd.boxIndex],
          next[ccd.fixtureIndex]
        ) : null;
        const nextCcdHits = hit ? [hit] : [];
        const nextPairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
        const found = /* @__PURE__ */ new Map();
        const contactContributions = new ContactPairAccumulator();
        const nextPersistentPoints = /* @__PURE__ */ new Map();
        const persistentNormalTargets = /* @__PURE__ */ new Map();
        const sensed = /* @__PURE__ */ new Map();
        const nextJoints = jointStates.map((joint, index) => ({
          ...joint,
          linearImpulseNs: [0, 0, 0],
          angularImpulseNms: [0, 0, 0],
          ...joint.motorImpulseNms === void 0 ? {} : { motorImpulseNms: motorImpulses[index] }
        }));
        let islandContributions = [];
        if (islandMode) {
          const prepared = prepareFrictionlessIsland(next, pairs, { jointCount: joints.length });
if (globalThis.__coupledPublicControlsFault) { const exampleFault = globalThis.__coupledPublicControlsFault; globalThis.__coupledPublicControlsFault = null; exampleFault.seen++; throw exampleFault.value; }

          next = prepared.candidateBodies;
          preparationPhase = "prepare-output";
          nextPairStats.eligiblePairs = prepared.pairStats.eligiblePairs;
          nextPairStats.candidatePairs = prepared.pairStats.candidatePairs;
          nextPairStats.aabbTests = prepared.pairStats.aabbTests;
          for (const contact of prepared.contacts) found.set(`${contact.aId}\0${contact.bId}`, contact);
          islandContributions = prepared.pairContributions;
        } else {
          const bounds = useAabb ? next.map(bodyBounds) : null;
          for (let pass = 0; pass < SOLVER_PASSES; pass++) {
            if (bounds && pass > 0) for (let index = 0; index < next.length; index++) {
              if (next[index].kind !== "static") bounds[index] = bodyBounds(next[index]);
            }
            for (const [aIndex, bIndex] of pairs) {
              nextPairStats.eligiblePairs++;
              if (largeMode && pass > 0 && dormantPair(next[aIndex], next[bIndex])) continue;
              if (bounds) {
                nextPairStats.aabbTests++;
                if (!boundsOverlap(bounds[aIndex], bounds[bIndex])) continue;
              }
              nextPairStats.candidatePairs++;
              const a2 = next[aIndex], b2 = next[bIndex];
              const hit2 = detect(a2, b2);
              if (!hit2) continue;
              if (hit2.penetration > MAX_STEP_DISPLACEMENT_M) error("NUMERIC_LIMIT", "contact penetration exceeded limit");
              const key = `${a2.id}\0${b2.id}`;
              if (a2.sensor || b2.sensor) {
                sensed.set(key, { aId: a2.id, bId: b2.id, kind: "sensor" });
                continue;
              }
              if (largeMode) wakeOnContact(a2, b2, nextSleepFrames, aIndex, bIndex);
              let contact = found.get(key);
              if (!contact) {
                contact = {
                  aId: a2.id,
                  bId: b2.id,
                  normalAtoB: [...hit2.normal],
                  pointM: [...hit2.pointM],
                  penetrationM: 0,
                  impulseNs: 0,
                  tangentImpulseNs: [0, 0, 0]
                };
                found.set(key, contact);
              }
              const manifold = usePersistentBox ? boxFaceManifold(a2, b2, hit2) : null;
              const points = manifold?.map((entry) => entry.pointM) ?? [hit2.pointM];
              contact.pointM = points.reduce((sum, point2) => add(sum, point2), [0, 0, 0]).map((value) => value / points.length);
              contact.penetrationM = Math.max(contact.penetrationM, hit2.penetration);
              if (largeMode && dormantPair(a2, b2)) continue;
              if (manifold) {
                const restitution = Math.min(a2.restitution, b2.restitution);
                for (const point2 of manifold) {
                  const pointKey = `${key}\0${point2.id}`;
                  if (persistentNormalTargets.has(pointKey)) continue;
                  let target = 0;
                  if (restitution !== 0) {
                    const velocityA = add(
                      a2.velocityMps,
                      cross(a2.angularVelocityRadps, sub(point2.pointM, a2.positionM))
                    );
                    const velocityB = add(
                      b2.velocityMps,
                      cross(b2.angularVelocityRadps, sub(point2.pointM, b2.positionM))
                    );
                    const speed = dot(hit2.normal, sub(velocityB, velocityA));
                    if (-speed > 0.5) target = -speed * restitution;
                  }
                  persistentNormalTargets.set(pointKey, target);
                }
                for (const point2 of manifold) {
                  const pointKey = `${key}\0${point2.id}`;
                  let impulse = nextPersistentPoints.get(pointKey);
                  if (!impulse) {
                    const prior = persistentPoints.get(pointKey);
                    impulse = prior ? { normalNs: prior.normalNs, tangentNs: [...prior.tangentNs] } : { normalNs: 0, tangentNs: [0, 0, 0] };
                    nextPersistentPoints.set(pointKey, impulse);
                    if (prior) contactContributions.add(
                      a2.id,
                      b2.id,
                      warmStartPoint(a2, b2, point2.pointM, hit2.normal, impulse)
                    );
                  }
                }
                for (let iteration = 0; iteration < 8; iteration++) {
                  const order = iteration % 2 ? [...manifold].reverse() : manifold;
                  for (const point2 of order) {
                    const pointKey = `${key}\0${point2.id}`;
                    const impulse = nextPersistentPoints.get(pointKey);
                    contactContributions.add(
                      a2.id,
                      b2.id,
                      solvePersistentPoint(
                        a2,
                        b2,
                        point2.pointM,
                        hit2.normal,
                        impulse,
                        persistentNormalTargets.get(pointKey)
                      )
                    );
                  }
                }
                correctPersistentPair(a2, b2, hit2.normal, hit2.penetration);
                contact.impulseNs = 0;
                contact.tangentImpulseNs = [0, 0, 0];
                for (const point2 of manifold) {
                  const impulse = nextPersistentPoints.get(`${key}\0${point2.id}`);
                  contact.impulseNs += impulse.normalNs;
                  contact.tangentImpulseNs = add(contact.tangentImpulseNs, impulse.tangentNs);
                }
              } else {
                const resolved = solve(a2, b2, hit2);
                contactContributions.add(a2.id, b2.id, resolved.contribution);
                contact.impulseNs += resolved.normalImpulseNs;
                contact.tangentImpulseNs = add(contact.tangentImpulseNs, resolved.tangentImpulseNs);
              }
              if (bounds) {
                bounds[aIndex] = bodyBounds(a2);
                bounds[bIndex] = bodyBounds(b2);
              }
            }
            if (!disjointHinges) for (let index = 0; index < joints.length; index++) {
              const reaction = projectJoint(joints[index], next, bodies, dt);
              nextJoints[index].linearImpulseNs = add(nextJoints[index].linearImpulseNs, reaction.linearImpulseNs);
              nextJoints[index].angularImpulseNms = add(nextJoints[index].angularImpulseNms, reaction.angularImpulseNms);
              if (reaction.angleRad !== void 0) nextJoints[index].angleRad = reaction.angleRad;
            }
          }
        }
        preparationPhase = "prepare-output";
        if (disjointHinges) {
          if (found.size !== 0 || sensed.size !== 0) {
            error("NUMERIC_LIMIT", "disjoint hinge contact profile is unsupported");
          }
          applyDisjointHingePostContact(disjointHinges, next, nextJoints, motorImpulses, stepIndex, stepIndex * dt);
        }
        const nextContacts = [...found.values()];
        if (largeMode) updateSleeping(next, nextContacts, nextSleepFrames);
        const nextActive = new Map(sensed);
        for (const contact of nextContacts) {
          nextActive.set(
            `${contact.aId}\0${contact.bId}`,
            { aId: contact.aId, bId: contact.bId, kind: "contact" }
          );
        }
        const nextEvents = [.../* @__PURE__ */ new Set([...activePairs.keys(), ...nextActive.keys()])].sort().map((key) => {
          const current = nextActive.get(key);
          const previous = activePairs.get(key);
          return { ...current ?? previous, phase: current ? previous ? "stay" : "begin" : "end" };
        });
        preparationPhase = "validation";
        validateResult(next, nextContacts);
        if (ccd.kind === "box-pair" && !axisAlignedBox(next[ccd.boxIndex])) {
          error("NUMERIC_LIMIT", "box CCD contact rotated outside the admitted profile");
        }
        if (nextJoints.some((joint) => [...joint.linearImpulseNs, ...joint.angularImpulseNms].some((value) => !Number.isFinite(value)) || joint.angleRad !== void 0 && !Number.isFinite(joint.angleRad))) {
          error("NUMERIC_LIMIT", "unsafe joint reaction");
        }
        for (let index = 0; index < joints.length; index++) {
          const motor = joints[index].motor;
          if (motor && Math.hypot(...nextJoints[index].angularImpulseNms) > motor.maxReactionNms) {
            error("NUMERIC_LIMIT", `${joints[index].id} exceeded motor reaction limit`);
          }
        }
        if (!islandMode) contactContributions.finish();
        else for (const pair of islandContributions) {
          if (!next.some((body) => body.id === pair.aId) || !next.some((body) => body.id === pair.bId) || [pair.onA, pair.onB].some((side2) => [side2.linearImpulseNs, side2.angularImpulseAboutWorldOriginNms].some((vector3) => vector3.length !== 3 || vector3.some((value) => !Number.isFinite(value))))) {
            error("NUMERIC_LIMIT", "unsafe completed island contribution");
          }
        }
        preparationPhase = "prepare-output";
        const state = publicState(next, nextContacts, nextEvents, nextJoints, nextCcdHits, nextPairStats, stepIndex + 1, dt, identity2, colliderIds);
        const preparedRecording = owner ? owner.prepare(preparedFrames, state) : null;
        const preparedCommandCount = owner ? owner.commandCount + admittedCommands.length : 0;
        bodies = next;
        contacts = nextContacts;
        events = nextEvents;
        jointStates = nextJoints;
        ccdHits = nextCcdHits;
        pairStats = nextPairStats;
        activePairs = nextActive;
        persistentPoints = nextPersistentPoints;
        sleepFrames = nextSleepFrames;
        stepIndex++;
        if (owner) {
          owner.recording = preparedRecording;
          owner.commandCount = preparedCommandCount;
        }
        return state;
      } catch (failure) {
        if (!islandMode || !(failure instanceof PhysicsError7)) throw failure;
        const enriched = new PhysicsError7(failure.code, failure.message, {
          operation: owner ? "record" : "step",
          phase: failure.code === "WORLD_LIMIT" ? "budget" : preparationPhase,
          domain: "rigid",
          entityIds: [...failure.details.entityIds],
          accepted: { stepIndex, timeSeconds: stepIndex * dt }
        });
        enriched.stack = failure.stack;
        throw enriched;
      }
    },
    query(input) {
      ensureActive();
      const data2 = queryRecord(input, ["kind", "includeSensors"], ["centerM", "radiusM", "originM", "direction", "maxDistanceM"]);
      const sensors = includeSensors(data2);
      if (data2.kind === "overlap-sphere") {
        const query3 = queryRecord(data2, ["kind", "centerM", "radiusM", "includeSensors"], []);
        const center = queryVector(query3.centerM, 1e4, "centerM");
        const radius = queryNumber(query3.radiusM, 1e-4, 1e3, "radiusM");
        if (domainState) error("INVALID_QUERY", "visual domain queries are unsupported");
        return { kind: "overlap-sphere", colliderIds: bodies.filter((body) => (sensors || !body.sensor) && sphereOverlaps(center, radius, body)).map((body) => body.id).sort().map((id) => colliderIds.get(id)) };
      }
      if (data2.kind !== "raycast") error("INVALID_QUERY", "unsupported query kind");
      const query2 = queryRecord(data2, ["kind", "originM", "direction", "maxDistanceM", "includeSensors"], []);
      const origin = queryVector(query2.originM, 1e4, "originM");
      const direction2 = queryVector(query2.direction, 1 + 1e-9, "direction");
      if (Math.abs(Math.hypot(...direction2) - 1) > 1e-9) error("INVALID_QUERY", "direction must be a unit 3-vector");
      const limit = queryNumber(query2.maxDistanceM, 1e-4, 1e4, "maxDistanceM");
      if (domainState) error("INVALID_QUERY", "visual domain queries are unsupported");
      let best = null;
      for (const body of bodies) {
        if (!sensors && body.sensor) continue;
        const distance = rayDistance(origin, direction2, body);
        if (distance === null || distance > limit) continue;
        if (best === null || distance < best.distanceM || distance === best.distanceM && body.id < best.bodyId) best = { bodyId: body.id, distanceM: distance };
      }
      return { kind: "raycast", hit: best === null ? null : { ...best, colliderId: colliderIds.get(best.bodyId) } };
    },
    dispose() {
      disposed = true;
      if (owner) {
        owner.recording = null;
        owner.commandCount = 0;
        owner = null;
      }
      optionsCopy = null;
      domainState = null;
      advancingOwner = null;
      bodies = [];
      contacts = [];
      events = [];
      ccdHits = [];
      activePairs.clear();
      persistentPoints.clear();
      sleepFrames = [];
      jointStates = [];
      joints = [];
      dynamicHinge = void 0;
      disjointHinges = null;
      ccd = { kind: "none" };
      pairs.length = 0;
      colliderIds.clear();
      modelCopy = null;
    }
  };
  let running = false;
  function guarded(operation2, action) {
    if (disposed) throw new PhysicsError7("DISPOSED", "world is disposed", {
      operation: operation2,
      phase: "lifecycle",
      domain: "world",
      entityIds: [],
      accepted: { stepIndex, timeSeconds: stepIndex * dt }
    });
    if (running) throw new PhysicsError7("REENTRANT_CALL", "World call is reentrant", {
      operation: operation2,
      phase: "lifecycle",
      domain: "world",
      entityIds: [],
      accepted: { stepIndex, timeSeconds: stepIndex * dt }
    });
    running = true;
    try {
      return action();
    } catch (failure) {
      if (!(failure instanceof PhysicsError7)) throw failure;
      const enriched = new PhysicsError7(failure.code, failure.message, {
        operation: operation2,
        phase: (stationaryMode || islandMode) && ["candidate", "validation", "prepare-output", "budget"].includes(failure.details.phase) && failure.details.accepted !== null ? failure.details.phase : ["DISPOSED", "WORLD_OWNED", "REENTRANT_CALL"].includes(failure.code) ? "lifecycle" : failure.code === "WORLD_LIMIT" ? "budget" : failure.code === "NUMERIC_LIMIT" ? "validation" : "admission",
        domain: domainKind ?? "rigid",
        entityIds: domainId && failure.details.entityIds.length === 0 ? [domainId] : failure.details.entityIds,
        accepted: { stepIndex, timeSeconds: stepIndex * dt }
      });
      enriched.stack = failure.stack;
      throw enriched;
    } finally {
      running = false;
    }
  }
  const getModel = world.getModel;
  const getState = world.getState;
  const step = world.step;
  const query = world.query;
  const dispose = world.dispose;
  world.getModel = () => guarded("read", getModel);
  world.getState = () => guarded("read", getState);
  world.step = (commands) => guarded("step", () => step(commands));
  world.query = (input) => guarded("query", () => query(input));
  world.dispose = () => {
    if (!disposed) guarded("read", dispose);
  };
  recordingWorlds.set(world, {
    attach: (prepare) => guarded("record", () => {
      if (owner) error("WORLD_OWNED", "World has an exclusive recorder");
      if (stepIndex !== 0) error("INVALID_SNAPSHOT", "recording must attach at step zero");
      const prepared = prepare({ model: copyData(modelCopy), options: copyData(optionsCopy), state: getState() });
      owner = prepared;
      return prepared;
    }),
    detach: (current) => {
      if (!disposed) guarded("record", () => {
        if (owner === current) owner = null;
        current.recording = null;
        current.commandCount = 0;
      });
    },
    read: (current) => guarded("record", () => {
      if (owner !== current) error("DISPOSED", "recorder is detached");
      return getState();
    }),
    step: (current, commands) => guarded("record", () => {
      if (owner !== current) error("DISPOSED", "recorder is detached");
      advancingOwner = current;
      try {
        return step(commands);
      } finally {
        advancingOwner = null;
      }
    })
  });
  return world;
}

// src/capsule-query-error.ts
import { PhysicsError as PhysicsError8 } from "./types.js";

// src/capsule-query/profile.ts
var PROFILE = "upright-capsule-box-v1";
var RADIUS_M = 0.15;
var HALF_LENGTH_M = 0.35;
var TIE_FRACTION = 1e-9;
var BOX_CAPACITY = 32;

// src/capsule-query/admission.ts
function refuse3(code, message) {
  throw new PhysicsError8(code, message);
}
function metadata(code, action) {
  try {
    return action();
  } catch {
    throw new PhysicsError8(code, "Input reflection failed");
  }
}
function record3(value, keys, code) {
  if (!value || typeof value !== "object" || metadata(code, () => Object.getPrototypeOf(value)) !== Object.prototype) {
    refuse3(code, "Expected an ordinary record");
  }
  const own = metadata(code, () => Reflect.ownKeys(value));
  if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) {
    refuse3(code, "Unexpected record fields");
  }
  const copied = {};
  for (const key of keys) {
    const descriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, key));
    if (!descriptor || !("value" in descriptor)) refuse3(code, "Accessor fields are not admitted");
    copied[key] = descriptor.value;
  }
  return copied;
}
function dense2(value, limit, code, exact3) {
  if (!metadata(code, () => Array.isArray(value)) || metadata(code, () => Object.getPrototypeOf(value)) !== Array.prototype) {
    refuse3(code, "Expected an ordinary dense array");
  }
  const lengthDescriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, "length"));
  if (!lengthDescriptor || !("value" in lengthDescriptor)) refuse3(code, "Expected array length");
  const length = lengthDescriptor.value;
  if (typeof length !== "number" || !Number.isInteger(length) || length < 0 || length > limit || exact3 !== void 0 && length !== exact3 || metadata(code, () => Reflect.ownKeys(value)).length !== length + 1) {
    refuse3(code, "Invalid array length or fields");
  }
  const values = [];
  for (let index = 0; index < length; index++) {
    const descriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, String(index)));
    if (!descriptor || !("value" in descriptor)) refuse3(code, "Sparse or accessor array");
    values.push(descriptor.value);
  }
  return values;
}
function tuple(value, count, bound, code) {
  return dense2(value, count, code, count).map((component) => {
    if (typeof component !== "number" || !Number.isFinite(component) || Math.abs(component) > bound) {
      refuse3(code, "Invalid tuple component");
    }
    return component;
  });
}
function identity(value, code) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_][A-Za-z0-9_.:-]{0,63}$/.test(value)) {
    refuse3(code, "Invalid identity");
  }
  return value;
}
function admitScene(input) {
  const scene = record3(input, ["version", "profile", "revision", "boxes"], "INVALID_CONFIG");
  if (scene.version !== 1 || scene.profile !== PROFILE) refuse3("INVALID_CONFIG", "Unsupported capsule query profile");
  const revision = identity(scene.revision, "INVALID_CONFIG");
  const boxes = dense2(scene.boxes, BOX_CAPACITY, "INVALID_CONFIG").map((value) => {
    const box = record3(value, ["id", "centerM", "halfExtentsM", "orientationXYZW"], "INVALID_CONFIG");
    const id = identity(box.id, "INVALID_CONFIG");
    const centerM = tuple(box.centerM, 3, 10, "INVALID_CONFIG");
    const halfExtentsM = tuple(box.halfExtentsM, 3, 5, "INVALID_CONFIG");
    const orientationXYZW = tuple(box.orientationXYZW, 4, 1, "INVALID_CONFIG");
    if (halfExtentsM.some((value2) => value2 < 1e-4) || Math.abs(Math.hypot(...orientationXYZW) - 1) > 1e-12) {
      refuse3("INVALID_CONFIG", "Invalid box extents or quaternion");
    }
    return { id, centerM, halfExtentsM, orientationXYZW };
  });
  if (new Set(boxes.map((box) => box.id)).size !== boxes.length) refuse3("INVALID_CONFIG", "Duplicate box ID");
  return { version: 1, profile: PROFILE, revision, boxes };
}
function admitSweep(input, scene) {
  const query = record3(input, ["revision", "centerM", "displacementM", "excludeId"], "INVALID_QUERY");
  const revision = identity(query.revision, "INVALID_QUERY");
  const centerM = tuple(query.centerM, 3, 5, "INVALID_QUERY");
  const displacementM = tuple(query.displacementM, 3, 2, "INVALID_QUERY");
  if (Math.hypot(...displacementM) > 2) refuse3("INVALID_QUERY", "Displacement exceeds 2 metres");
  const excludeId = query.excludeId === null ? null : identity(query.excludeId, "INVALID_QUERY");
  if (revision !== scene.revision) throw new PhysicsError8("STALE_SNAPSHOT", "Revision mismatch");
  if (excludeId !== null && !scene.boxes.some((box) => box.id === excludeId)) refuse3("INVALID_QUERY", "Unknown excluded ID");
  return { revision, centerM, displacementM, excludeId };
}

// src/capsule-query/geometry.ts
function matrix2(q) {
  const [x, y, z, w] = q, factor2 = 2 / (x * x + y * y + z * z + w * w);
  return [
    [1 - factor2 * (y * y + z * z), factor2 * (x * y - z * w), factor2 * (x * z + y * w)],
    [factor2 * (x * y + z * w), 1 - factor2 * (x * x + z * z), factor2 * (y * z - x * w)],
    [factor2 * (x * z - y * w), factor2 * (y * z + x * w), 1 - factor2 * (x * x + y * y)]
  ];
}
var dot5 = (a2, b2) => a2[0] * b2[0] + a2[1] * b2[1] + a2[2] * b2[2];
function closestCandidate(center, box) {
  const m = matrix2(box.orientationXYZW), h = box.halfExtentsM;
  const toLocal = (p) => [0, 1, 2].map((j) => m[0][j] * (p[0] - box.centerM[0]) + m[1][j] * (p[1] - box.centerM[1]) + m[2][j] * (p[2] - box.centerM[2]));
  const toWorld = (p) => m.map((row, i) => dot5(row, p) + box.centerM[i]);
  const a2 = toLocal([center[0], center[1] - HALF_LENGTH_M, center[2]]);
  const b2 = toLocal([center[0], center[1] + HALF_LENGTH_M, center[2]]);
  const d = b2.map((value, i) => value - a2[i]);
  function squared(t) {
    let sum = 0;
    for (let i = 0; i < 3; i++) {
      const delta = Math.max(0, Math.abs(a2[i] + t * d[i]) - h[i]);
      sum += delta * delta;
    }
    return sum;
  }
  let lo = 0, hi = 1;
  for (let pass = 0; pass < 100; pass++) {
    const t1 = (2 * lo + hi) / 3, t2 = (lo + 2 * hi) / 3;
    if (squared(t1) <= squared(t2)) hi = t2;
    else lo = t1;
  }
  let u = 0, best = squared(0);
  for (const t of [1, (lo + hi) / 2]) {
    const value = squared(t);
    if (value < best) {
      best = value;
      u = t;
    }
  }
  const segmentLocal = a2.map((value, i) => value + u * d[i]);
  const pointLocal = segmentLocal.map((value, i) => Math.max(-h[i], Math.min(h[i], value)));
  const difference = segmentLocal.map((value, i) => value - pointLocal[i]);
  const distanceM = Math.sqrt(best);
  const normalM = distanceM > 0 ? m.map((row) => dot5(row, difference) / distanceM) : null;
  return { distanceM, normalM, pointM: toWorld(pointLocal), segmentM: toWorld(segmentLocal) };
}

// src/capsule-query/sweep.ts
function sweepBox2(center, displacement, box) {
  let fraction = 0;
  for (let iteration = 0; iteration < 64; iteration++) {
    const at = center.map((value, i) => value + fraction * displacement[i]);
    const closest = closestCandidate(at, box), gap = closest.distanceM - RADIUS_M;
    if (!Number.isFinite(gap)) throw new PhysicsError8("NUMERIC_LIMIT", "Nonfinite distance");
    if (iteration === 0 && gap < -1e-12) throw new PhysicsError8("INITIAL_OVERLAP", "Initial capsule overlaps a box");
    if (!closest.normalM) throw new PhysicsError8("NUMERIC_LIMIT", "No distance normal");
    if (iteration === 0 && Math.abs(gap) <= 1e-12 || gap <= 1e-14) {
      if (gap < -1e-12) throw new PhysicsError8("NUMERIC_LIMIT", "Advancement crossed contact");
      return {
        bodyId: box.id,
        toiFraction: fraction,
        normalFixtureToCapsule: closest.normalM.slice(),
        pointM: closest.pointM.slice(),
        segmentPointM: closest.segmentM.slice(),
        iterations: iteration + 1
      };
    }
    const closing = -dot5(closest.normalM, displacement);
    if (closing <= 0) return null;
    const next = fraction + gap / closing;
    if (!Number.isFinite(next)) throw new PhysicsError8("NUMERIC_LIMIT", "Nonfinite advancement");
    if (next > 1) return null;
    if (next <= fraction) throw new PhysicsError8("ITERATION_LIMIT", "Advancement cannot make progress");
    fraction = next;
  }
  throw new PhysicsError8("ITERATION_LIMIT", "Fixed advancement cap exhausted");
}

// src/capsule-query/snapshot.ts
function copyBox(box) {
  return { id: box.id, centerM: [...box.centerM], halfExtentsM: [...box.halfExtentsM], orientationXYZW: [...box.orientationXYZW] };
}
function geometryKey(box) {
  const values = [...box.centerM, ...box.halfExtentsM, ...box.orientationXYZW];
  const bytes = new Uint8Array(80), view = new DataView(bytes.buffer);
  values.forEach((value, index) => view.setFloat64(index * 8, value, true));
  return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
}
function groupBoxes(boxes) {
  const groups = /* @__PURE__ */ new Map();
  for (const box of boxes) {
    const key = geometryKey(box), group = groups.get(key);
    if (group) group.ids.push(box.id);
    else groups.set(key, { representative: copyBox(box), ids: [box.id] });
  }
  return Array.from(groups.values());
}
function createUprightCapsuleQuery(input) {
  const scene = admitScene(input), groups = groupBoxes(scene.boxes);
  let disposed = false;
  function live() {
    if (disposed) throw new PhysicsError8("DISPOSED", "Capsule query is disposed");
  }
  return {
    sweep(input2) {
      live();
      const query = admitSweep(input2, scene), hits = [];
      for (const group of groups) {
        let selectedId = null;
        for (const id of group.ids) if (id !== query.excludeId && (selectedId === null || id < selectedId)) selectedId = id;
        if (selectedId === null) continue;
        const hit = sweepBox2(query.centerM, query.displacementM, group.representative);
        if (hit) hits.push({ ...hit, bodyId: selectedId });
      }
      if (!hits.length) return null;
      const minimum2 = Math.min(...hits.map((hit) => hit.toiFraction));
      return hits.filter((hit) => hit.toiFraction <= minimum2 + TIE_FRACTION).sort((a2, b2) => a2.bodyId < b2.bodyId ? -1 : a2.bodyId > b2.bodyId ? 1 : 0)[0];
    },
    getSnapshot() {
      live();
      return { version: 1, profile: scene.profile, revision: scene.revision, boxes: scene.boxes.map(copyBox) };
    },
    dispose() {
      disposed = true;
    }
  };
}

// src/character/profile.ts
var PROFILE2 = "upright-capsule-controller-v1";
var DT = 1 / 120;
var STEPS = 240;
var GRAVITY = -9.81;
var SKIN = 2e-3;
var SNAP = 0.02;
var STEP_HEIGHT = 0.1;
var PREVIEW = 0.152;
var STEP_DOWN = 0.12;
var ASSIST_CAP = 20;
var SLIDE_CAP = 4;
var QUERY_CAP = 32;
var LOOKAHEAD = 0.02;
var WALKABLE = Math.cos(10 * Math.PI / 180);

// src/character/admission.ts
function refuse4(code, message) {
  throw new PhysicsError8(code, message);
}
function metadata2(code, action) {
  try {
    return action();
  } catch {
    throw new PhysicsError8(code, "Controller input reflection failed");
  }
}
function record4(value, keys, code) {
  if (!value || typeof value !== "object" || metadata2(code, () => Object.getPrototypeOf(value)) !== Object.prototype) {
    refuse4(code, "Expected an ordinary controller record");
  }
  const own = metadata2(code, () => Reflect.ownKeys(value));
  if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) {
    refuse4(code, "Unexpected controller fields");
  }
  const copy2 = {};
  for (const key of keys) {
    const descriptor = metadata2(code, () => Object.getOwnPropertyDescriptor(value, key));
    if (!descriptor || !("value" in descriptor)) refuse4(code, "Controller accessors are not admitted");
    copy2[key] = descriptor.value;
  }
  return copy2;
}
function tuple2(value, bound, code) {
  if (!metadata2(code, () => Array.isArray(value)) || metadata2(code, () => Object.getPrototypeOf(value)) !== Array.prototype) {
    refuse4(code, "Expected an ordinary controller tuple");
  }
  const length = metadata2(code, () => Object.getOwnPropertyDescriptor(value, "length"));
  if (!length || !("value" in length) || length.value !== 3 || metadata2(code, () => Reflect.ownKeys(value)).length !== 4) {
    refuse4(code, "Invalid controller tuple length or fields");
  }
  const copy2 = [];
  for (let index = 0; index < 3; index++) {
    const descriptor = metadata2(code, () => Object.getOwnPropertyDescriptor(value, String(index)));
    if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "number" || !Number.isFinite(descriptor.value) || Math.abs(descriptor.value) > bound) {
      refuse4(code, "Invalid controller tuple component");
    }
    copy2.push(descriptor.value);
  }
  return copy2;
}
function admitConfig(input) {
  const config = record4(input, ["version", "profile", "scene", "positionM"], "INVALID_CONFIG");
  if (config.version !== 1 || config.profile !== PROFILE2) refuse4("INVALID_CONFIG", "Unsupported controller profile");
  const positionM = tuple2(config.positionM, 5, "INVALID_CONFIG");
  return { scene: config.scene, positionM };
}
function admitCommand(input) {
  const command = record4(input, ["dtSeconds", "sceneRevision", "desiredVelocityMps"], "INVALID_COMMAND");
  if (typeof command.dtSeconds !== "number" || !Number.isFinite(command.dtSeconds)) refuse4("INVALID_COMMAND", "Invalid controller time");
  if (typeof command.sceneRevision !== "string" || !/^[A-Za-z0-9_][A-Za-z0-9_.:-]{0,63}$/.test(command.sceneRevision)) {
    refuse4("INVALID_COMMAND", "Invalid controller revision");
  }
  const desiredVelocityMps = tuple2(command.desiredVelocityMps, 1, "INVALID_COMMAND");
  if (desiredVelocityMps[1] !== 0 || Math.hypot(desiredVelocityMps[0], desiredVelocityMps[2]) > 1) {
    refuse4("INVALID_COMMAND", "Controller horizontal request exceeds its bound");
  }
  return { dtSeconds: command.dtSeconds, sceneRevision: command.sceneRevision, desiredVelocityMps };
}
function admitCoreCommand(dt, velocity, revision, stateRevision, stepIndex) {
  const command = admitCommand({ dtSeconds: dt, sceneRevision: revision, desiredVelocityMps: velocity });
  if (command.dtSeconds !== DT) throw new PhysicsError8("INVALID_STEP", "Controller requires exactly 1/120 second");
  if (command.sceneRevision !== stateRevision) throw new PhysicsError8("STALE_SNAPSHOT", "Controller revision mismatch");
  if (stepIndex >= STEPS) throw new PhysicsError8("WORLD_LIMIT", "Controller step limit exhausted");
  return command.desiredVelocityMps;
}

// src/character/math.ts
var dot6 = (a2, b2) => a2.reduce((sum, value, index) => sum + value * b2[index], 0);
var add2 = (a2, b2) => a2.map((value, index) => value + b2[index]);
var scale3 = (a2, factor2) => a2.map((value) => value * factor2);
var norm = (a2) => Math.hypot(...a2);
function clone(value) {
  if (Array.isArray(value)) return value.map((item) => clone(item));
  if (value !== null && typeof value === "object") {
    const result = {};
    for (const key of Object.keys(value)) result[key] = clone(value[key]);
    return result;
  }
  return value;
}

// src/character/state.ts
function initialState(positionM, sceneRevision) {
  return {
    stepIndex: 0,
    timeSeconds: 0,
    positionM: [...positionM],
    velocityMps: [0, 0, 0],
    fallVelocityYMps: 0,
    orientationXYZW: [0, 0, 0, 1],
    grounded: false,
    support: null,
    blocked: false,
    assist: null,
    sceneRevision,
    queryCount: 0,
    lastQueries: [],
    lastSegments: [],
    gravityPrediction: null
  };
}
function projectState(state) {
  return {
    version: 1,
    profile: PROFILE2,
    sceneRevision: state.sceneRevision,
    stepIndex: state.stepIndex,
    timeSeconds: state.timeSeconds,
    positionM: [...state.positionM],
    velocityMps: [...state.velocityMps],
    orientationXYZW: [...state.orientationXYZW],
    fallVelocityYMps: state.fallVelocityYMps,
    grounded: state.grounded,
    support: clone(state.support),
    blocked: state.blocked,
    assist: clone(state.assist),
    queryCount: state.queryCount
  };
}
function validateState(position, velocity, request, previous) {
  if (position.some((value) => !Number.isFinite(value) || Math.abs(value) > 5) || velocity.some((value) => !Number.isFinite(value)) || norm(velocity) > 20) {
    throw new PhysicsError8("NUMERIC_LIMIT", "Controller state exceeds its bound");
  }
  const actual = position.map((value, index) => value - previous.positionM[index]);
  const horizontal = Math.hypot(actual[0], actual[2]), allowed = Math.hypot(request[0], request[2]) * DT;
  if (horizontal > allowed + 1e-9 || Math.abs(actual[1]) > 0.1 + 1e-6) {
    throw new PhysicsError8("NUMERIC_LIMIT", "Controller movement exceeds its bound");
  }
}
function errorRecord2(error2) {
  const value = error2;
  return { name: value.name ?? "Error", code: value.code, message: value.message ?? String(error2) };
}

// src/character/query.ts
function queryContext(query, candidate, diagnostic, capture) {
  function raw(position, delta, kind, preview, excludeId = null) {
    if (candidate.queryCount >= (diagnostic.queryBudget ?? QUERY_CAP)) {
      throw new PhysicsError8("WORLD_LIMIT", "Controller per-step query limit exhausted");
    }
    const input = {
      revision: candidate.sceneRevision,
      centerM: [...position],
      displacementM: [...delta],
      excludeId
    };
    const index = candidate.queryCount;
    candidate.queryCount++;
    let hit;
    try {
      hit = query.sweep(input);
    } catch (error2) {
      if (capture) candidate.lastQueries.push({ kind, preview, input: clone(input), hit: null, error: errorRecord2(error2) });
      throw error2;
    }
    if (capture) candidate.lastQueries.push({ kind, preview, input: clone(input), hit: clone(hit), error: null });
    return { hit, indices: [index] };
  }
  function sweep(position, delta, kind, preview = false) {
    const first = raw(position, delta, kind, preview);
    if (first.hit?.toiFraction === 0 && dot6(first.hit.normalFixtureToCapsule, delta) >= -1e-12) {
      const second = raw(position, delta, kind + "-fresh-touch-departure", preview, first.hit.bodyId);
      if (second.hit?.toiFraction === 0) throw new PhysicsError8("INVALID_COMMAND", "Controller second fresh touch is unresolved");
      return { hit: second.hit, indices: [...first.indices, ...second.indices] };
    }
    return first;
  }
  function commit(position, delta, kind, indices2) {
    const target = position.map((value, index) => value + delta[index]);
    if (capture) candidate.lastSegments.push({
      kind,
      fromM: [...position],
      displacementM: [...delta],
      toM: [...target],
      queryIndices: [...indices2]
    });
    return target;
  }
  return { sweep, commit };
}

// src/character/step-assist.ts
function tryStep(position, remaining, candidate, context2) {
  const horizontal = [remaining[0], 0, remaining[2]], length = norm(horizontal);
  if (length <= 1e-12 || !candidate.grounded) return null;
  const direction2 = scale3(horizontal, 1 / length);
  const up = context2.sweep(position, [0, STEP_HEIGHT, 0], "step-up-probe", true);
  if (up.hit) return null;
  const raised = add2(position, [0, STEP_HEIGHT, 0]);
  const forward = context2.sweep(raised, scale3(direction2, PREVIEW), "step-ahead-probe", true);
  if (forward.hit) return null;
  const preview = add2(raised, scale3(direction2, PREVIEW));
  const down = context2.sweep(preview, [0, -STEP_DOWN, 0], "step-down-probe", true);
  if (!down.hit || down.hit.normalFixtureToCapsule[1] < WALKABLE) return null;
  const targetY = raised[1] - STEP_DOWN * down.hit.toiFraction + SKIN / down.hit.normalFixtureToCapsule[1];
  const rise = targetY - position[1];
  if (rise <= 1e-9 || rise > STEP_HEIGHT + 1e-6) return null;
  const actualRaised = add2(position, [0, rise, 0]);
  const actual = context2.sweep(actualRaised, horizontal, "step-actual-forward", false);
  if (actual.hit) return null;
  let moved = context2.commit(position, [0, rise, 0], "step-up", up.indices);
  moved = context2.commit(moved, horizontal, "step-forward", actual.indices);
  candidate.assist = { bodyId: down.hit.bodyId, heightM: targetY, directionXZ: [direction2[0], direction2[2]], frames: 0 };
  candidate.fallVelocityYMps = 0;
  candidate.grounded = false;
  candidate.support = null;
  return moved;
}
function validateAssist(position, candidate, context2, diagnostic) {
  if (!candidate.assist) return;
  const direction2 = [candidate.assist.directionXZ[0], 0, candidate.assist.directionXZ[1]];
  const ahead = context2.sweep(position, scale3(direction2, PREVIEW), "assist-ahead", true);
  if (ahead.hit) throw new PhysicsError8("INVALID_COMMAND", "Controller assist forward path is blocked");
  const down = context2.sweep(add2(position, scale3(direction2, PREVIEW)), [0, -STEP_DOWN, 0], "assist-support", true);
  const hit = down.hit;
  const target = hit ? position[1] - STEP_DOWN * hit.toiFraction + SKIN / hit.normalFixtureToCapsule[1] : NaN;
  if (!hit || hit.normalFixtureToCapsule[1] < WALKABLE || hit.bodyId !== candidate.assist.bodyId || Math.abs(target - candidate.assist.heightM) > 1e-6) {
    throw new PhysicsError8("INVALID_COMMAND", "Controller assist support is unresolved");
  }
  candidate.assist.frames++;
  if (candidate.assist.frames > (diagnostic.assistCap ?? ASSIST_CAP)) {
    throw new PhysicsError8("WORLD_LIMIT", "Controller assist duration limit exhausted");
  }
}

// src/character/slide.ts
function move(position, delta, candidate, context2, diagnostic) {
  let p = [...position], remaining = [...delta];
  for (let pass = 0; pass < (diagnostic.slideBudget ?? SLIDE_CAP); pass++) {
    if (norm(remaining) <= 1e-12) return p;
    const length = norm(remaining), direction2 = scale3(remaining, 1 / length), probeLength = length + LOOKAHEAD;
    const result = context2.sweep(p, scale3(direction2, probeLength), "slide-lookahead", true), hit = result.hit;
    if (!hit) return context2.commit(p, remaining, "travel", result.indices);
    const normal = hit.normalFixtureToCapsule, closingUnit = -dot6(normal, direction2);
    if (closingUnit <= 1e-12) throw new PhysicsError8("INVALID_COMMAND", "Controller lookahead closing normal is unresolved");
    const contactDistance = probeLength * hit.toiFraction;
    const safeDistance = Math.max(0, contactDistance - SKIN / closingUnit);
    const fraction = Math.min(1, safeDistance / length);
    const travel = scale3(remaining, fraction);
    if (norm(travel) > 0) p = context2.commit(p, travel, "travel", result.indices);
    if (fraction === 1) return p;
    remaining = scale3(remaining, 1 - fraction);
    if (normal[1] < WALKABLE) {
      const stepped = tryStep(p, remaining, candidate, context2);
      if (stepped) return stepped;
      candidate.blocked = true;
      const horizontalNormal = [normal[0], 0, normal[2]], size2 = norm(horizontalNormal);
      if (size2 > 1e-12) {
        const unit2 = scale3(horizontalNormal, 1 / size2), into = dot6(remaining, unit2);
        if (into < 0) remaining = add2(remaining, scale3(unit2, -into));
      }
      if (normal[1] > 1e-12 && remaining[1] < 0) {
        remaining[1] = 0;
        candidate.fallVelocityYMps = 0;
      } else if (normal[1] < -1e-12 && remaining[1] > 0) remaining[1] = 0;
    } else {
      const into = dot6(remaining, normal);
      if (into < 0) remaining = add2(remaining, scale3(normal, -into));
      candidate.fallVelocityYMps = 0;
    }
  }
  if (norm(remaining) > 1e-12) throw new PhysicsError8("WORLD_LIMIT", "Controller slide limit exhausted");
  return p;
}

// src/character/ground.ts
function snap(position, candidate, context2) {
  const down = context2.sweep(position, [0, -SNAP, 0], "ground-probe", true), hit = down.hit;
  if (!hit || hit.normalFixtureToCapsule[1] < WALKABLE) {
    candidate.grounded = false;
    candidate.support = null;
    return position;
  }
  const targetY = position[1] - SNAP * hit.toiFraction + SKIN / hit.normalFixtureToCapsule[1];
  const delta = [0, targetY - position[1], 0];
  let proof = down.indices;
  if (delta[1] > 0) {
    const up = context2.sweep(position, delta, "positive-snap-validation");
    if (up.hit) throw new PhysicsError8("INVALID_COMMAND", "Controller positive snap is blocked");
    proof = up.indices;
  }
  const p = context2.commit(position, delta, "ground-snap", proof);
  candidate.grounded = true;
  candidate.support = { bodyId: hit.bodyId, normal: [...hit.normalFixtureToCapsule] };
  candidate.fallVelocityYMps = 0;
  candidate.assist = null;
  return p;
}

// src/character/core.ts
function createCharacterCore(scene, positionM, diagnostic = {}, options = {}) {
  const admitted3 = admitConfig({ version: 1, profile: PROFILE2, scene, positionM });
  const query = createUprightCapsuleQuery(admitted3.scene);
  let state;
  try {
    const snapshot = query.getSnapshot();
    query.sweep({ revision: snapshot.revision, centerM: [...admitted3.positionM], displacementM: [0, 0, 0], excludeId: null });
    state = initialState(admitted3.positionM, snapshot.revision);
  } catch (error2) {
    query.dispose();
    throw error2;
  }
  const capture = options.capture ?? true;
  let lastRejected = null, disposed = false;
  function live() {
    if (disposed) throw new PhysicsError8("DISPOSED", "Capsule controller is disposed");
  }
  return {
    getState() {
      live();
      return clone(state);
    },
    getLastRejected() {
      return clone(lastRejected);
    },
    step(dt, velocity, revision = state.sceneRevision) {
      live();
      let attempted = null;
      try {
        const request = admitCoreCommand(dt, velocity, revision, state.sceneRevision, state.stepIndex);
        const next = clone(state);
        attempted = next;
        next.queryCount = 0;
        next.lastQueries = [];
        next.lastSegments = [];
        next.blocked = false;
        const assisted = !!state.assist, speed = Math.hypot(request[0], request[2]);
        if (assisted && (speed === 0 || Math.abs(request[0] / speed - state.assist.directionXZ[0]) > 1e-12 || Math.abs(request[2] / speed - state.assist.directionXZ[1]) > 1e-12)) {
          throw new PhysicsError8("INVALID_COMMAND", "Controller assist request changed");
        }
        const predicted = state.grounded || assisted ? 0 : state.fallVelocityYMps + GRAVITY * DT;
        next.fallVelocityYMps = predicted;
        next.gravityPrediction = capture ? {
          previousFallVelocityYMps: state.fallVelocityYMps,
          previousGrounded: state.grounded,
          previousAssisted: assisted,
          predictedFallVelocityYMps: predicted,
          predictedDeltaYM: predicted * DT
        } : null;
        const context2 = queryContext(query, next, diagnostic, capture);
        const delta = [request[0] * DT, predicted * DT, request[2] * DT];
        let p = move(state.positionM, delta, next, context2, diagnostic);
        p = snap(p, next, context2);
        validateAssist(p, next, context2, diagnostic);
        if (diagnostic.numericFault) throw new PhysicsError8("NUMERIC_LIMIT", "Internal controller numeric fault");
        const actualVelocity = p.map((value, index) => (value - state.positionM[index]) / DT);
        validateState(p, actualVelocity, request, state);
        next.positionM = p;
        next.velocityMps = actualVelocity;
        next.stepIndex++;
        next.timeSeconds = next.stepIndex * DT;
        state = next;
        lastRejected = null;
        return clone(state);
      } catch (error2) {
        if (capture) lastRejected = { acceptedState: clone(state), attemptedState: clone(attempted), error: errorRecord2(error2) };
        throw error2;
      }
    },
    dispose() {
      if (!disposed) {
        disposed = true;
        query.dispose();
      }
    }
  };
}

// src/character-controller.ts
function createUprightCapsuleController(config) {
  const admitted3 = admitConfig(config);
  const core = createCharacterCore(admitted3.scene, admitted3.positionM, {}, { capture: false });
  let disposed = false;
  function live() {
    if (disposed) throw new PhysicsError8("DISPOSED", "Capsule controller is disposed");
  }
  return {
    getSnapshot() {
      live();
      return projectState(core.getState());
    },
    step(input) {
      live();
      const command = admitCommand(input);
      return projectState(core.step(command.dtSeconds, command.desiredVelocityMps, command.sceneRevision));
    },
    dispose() {
      if (!disposed) {
        disposed = true;
        core.dispose();
      }
    }
  };
}
export {
  createPhysicsWorld,
  createUprightCapsuleController,
  createUprightCapsuleQuery
};
