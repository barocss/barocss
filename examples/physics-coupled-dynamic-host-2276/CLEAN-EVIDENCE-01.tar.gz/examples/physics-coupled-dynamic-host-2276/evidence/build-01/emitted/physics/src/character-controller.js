"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUprightCapsuleController = createUprightCapsuleController;
const admission_js_1 = require("./character/admission.js");
const core_js_1 = require("./character/core.js");
const state_js_1 = require("./character/state.js");
const capsule_query_error_js_1 = require("./capsule-query-error.js");
/** Fixed upright capsule gameplay movement against an immutable bounded box scene. */
function createUprightCapsuleController(config) {
    const admitted = (0, admission_js_1.admitConfig)(config);
    const core = (0, core_js_1.createCharacterCore)(admitted.scene, admitted.positionM, {}, { capture: false });
    let disposed = false;
    function live() { if (disposed)
        throw new capsule_query_error_js_1.PhysicsError('DISPOSED', 'Capsule controller is disposed'); }
    return {
        getSnapshot() { live(); return (0, state_js_1.projectState)(core.getState()); },
        step(input) {
            live();
            const command = (0, admission_js_1.admitCommand)(input);
            return (0, state_js_1.projectState)(core.step(command.dtSeconds, command.desiredVelocityMps, command.sceneRevision));
        },
        dispose() { if (!disposed) {
            disposed = true;
            core.dispose();
        } },
    };
}
