export type Vec = [number, number, number];
export interface Box {
    id: string;
    positionM: Vec;
    orientationXYZW: [number, number, number, number];
    halfExtentsM: Vec;
}
export interface Pair {
    id: string;
    a: Box;
    b: Box;
}
export declare function quantizedContact(pair: Pair): unknown;
export declare function representedNativeLine(pair: Pair, anchorM: Vec, normal: Vec): {
    pointOnAM: Vec;
    pointOnBM: Vec;
    signedGapM: number;
};
