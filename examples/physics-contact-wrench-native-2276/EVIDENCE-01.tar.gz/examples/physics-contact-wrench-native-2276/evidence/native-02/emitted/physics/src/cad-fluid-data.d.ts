/** Optional CAD-to-public-DATA admission. No World, initializer or clock. */
import type { PhysicsModel, WorldOptions } from './types.js';
import type { CadSurfaceProxy, CadSurfaceProxyRequest } from './cad-proxy-types.js';
export declare function admitCadFluidStaticData(basinModel: PhysicsModel, targetOptions: WorldOptions, sourceText: string, request: CadSurfaceProxyRequest): {
    model: PhysicsModel;
    proxy: CadSurfaceProxy;
};
