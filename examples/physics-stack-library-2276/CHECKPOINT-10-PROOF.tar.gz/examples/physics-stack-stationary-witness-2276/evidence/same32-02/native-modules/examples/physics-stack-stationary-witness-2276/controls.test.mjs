import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { solveStationaryNormal, STATIONARY_LIMITS } from '../../packages/barocss-physics/src/stack/stationary-normal.js';
import { unitCore, UnitExact, unitTriangle } from './unit-source.js';
import { verifierView } from './adapter.js';
import { verifyNormalSolution } from '../physics-stack-solver-2276/verification.js';
const receipts = [], q = (n, d = 1n) => ({ n, d }), zero = q(0n);
function body(id, y, fixed = false, x = 0, z = 0) { return { id, positionM: [x, y, z], velocityMps: [0, fixed ? 0 : -.5, 0], angularVelocityRadps: [0, 0, 0], inverseMass: fixed ? 0 : 1, inverseInertiaWorld: [[fixed ? 0 : 24, 0, 0], [0, fixed ? 0 : 24, 0], [0, 0, fixed ? 0 : 24]] }; }
function problem(count) { const bodies = [body('floor', 0, true), body('one', 1), ...(count === 2 ? [body('two', 2)] : [])], points = []; for (let k = 0; k < count; k++)
    for (const [j, [x, z]] of [[-1, -1], [1, -1], [1, 1], [-1, 1]].entries())
        points.push({ id: 'row-' + k + '-' + j, aId: bodies[k].id, bId: bodies[k + 1].id, pointM: [x, k + .5, z], normalAtoB: [0, 1, 0] }); return { bodies, points }; }
function successful(p, count) { const before = structuredClone(p), result = unitCore(p, count); assert.equal(result.ok, true, JSON.stringify(result)); assert.deepEqual(p, before); assert.ok(result.exactApplied); assert.equal(result.exactApplied.points.length, 4 * count); assert.equal(result.stats.interfacesProcessed, count); assert.ok(result.stats.triangleTrials <= 4 * count); assert.ok(result.bodies.filter(b => b.inverseMass === 1).every(b => [...b.velocityMps, ...b.angularVelocityRadps].every(v => Object.is(v, 0)))); receipts.push({ problem: p, result, unitDynamicCount: count }); return result; }
function changed(f, status) { const p = problem(1); f(p); const before = structuredClone(p), r = unitCore(p, 1); assert.equal(r.status, status, r.reason ?? ''); assert.equal(r.ok, false); assert.equal(r.exactApplied, null); assert.equal(r.normalImpulsesNs, null); assert.deepEqual(p, before); }
test('01 centered literal quarter loads retain four rows', () => { const r = successful(problem(1), 1); assert.deepEqual(r.exactApplied.points.map(p => p.lambda), [{ n: '1', d: '4' }, { n: '0', d: '1' }, { n: '1', d: '4' }, { n: '0', d: '1' }]); });
test('02 offset COM literal eighth eighth quarter loads', () => { const p = problem(1); p.bodies[1].positionM = [.5, 1, 0]; assert.deepEqual(successful(p, 1).exactApplied.points.map(p => p.lambda), [{ n: '1', d: '8' }, { n: '1', d: '8' }, { n: '1', d: '4' }, { n: '0', d: '1' }]); });
test('03 vertex retains exact zero weights', () => { const p = problem(1); p.bodies[1].positionM = [-1, 1, -1]; assert.deepEqual(successful(p, 1).exactApplied.points.map(p => p.lambda), [{ n: '1', d: '2' }, { n: '0', d: '1' }, { n: '0', d: '1' }, { n: '0', d: '1' }]); });
test('04 edge retains zero complementarity rows', () => { const p = problem(1); p.bodies[1].positionM = [0, 1, -1]; assert.deepEqual(successful(p, 1).exactApplied.points.map(p => p.lambda), [{ n: '1', d: '4' }, { n: '1', d: '4' }, { n: '0', d: '1' }, { n: '0', d: '1' }]); });
test('05 outside polygon is NO_WITNESS never infeasible', () => changed(p => p.bodies[1].positionM = [2, 1, 0], 'NO_WITNESS'));
test('06 reversed endpoint order retains directed load', () => { const p = problem(1); for (const point of p.points) {
    [point.aId, point.bId] = [point.bId, point.aId];
    point.normalAtoB = [0, -1, 0];
} successful(p, 1); });
test('07 two-body incoming load propagates exact ratios', () => { const r = successful(problem(2), 2); assert.deepEqual(r.exactApplied.points.map(p => p.lambda), [{ n: '1', d: '2' }, { n: '0', d: '1' }, { n: '1', d: '2' }, { n: '0', d: '1' }, { n: '1', d: '4' }, { n: '0', d: '1' }, { n: '1', d: '4' }, { n: '0', d: '1' }]); });
test('08 body array ordering and opaque IDs do not define chain', () => { const p = problem(2); p.bodies = [p.bodies[2], p.bodies[0], p.bodies[1]]; successful(p, 2); });
test('09 point permutation retains original row identities', () => { const p = problem(1); p.points = [p.points[3], p.points[1], p.points[0], p.points[2]]; const r = successful(p, 1); assert.deepEqual(r.exactApplied.points.map(x => x.id), p.points.map(x => x.id)); });
test('10 zero load and signed-zero static metadata retain exact words', () => { const p = problem(1); p.bodies[1].velocityMps = [0, 0, 0]; p.bodies[0].positionM = [-0, 0, -0]; p.bodies[0].velocityMps = [-0, 0, -0]; p.bodies[0].angularVelocityRadps = [0, -0, 0]; p.bodies[0].inverseInertiaWorld = [[-0, 0, 0], [0, -0, 0], [0, 0, -0]]; const result = successful(p, 1); assert.ok(result.exactApplied.points.every(p => p.lambda.n === '0' && p.lambda.d === '1')); assert.ok(Object.is(result.bodies[0].velocityMps[0], -0)); assert.ok(Object.is(result.bodies[0].angularVelocityRadps[1], -0)); assert.ok(Object.is(result.bodies[0].positionM[2], -0)); assert.ok(Object.is(result.bodies[0].inverseInertiaWorld[0][0], -0)); });
test('11 branch profile refuses without solving', () => { const p = problem(2); for (const point of p.points.slice(4))
    point.aId = 'floor'; assert.equal(unitCore(p, 2).status, 'UNSUPPORTED_PROFILE'); });
test('12 cycle disconnected from floor refuses', () => { const p = problem(2); for (const point of p.points.slice(0, 4))
    point.aId = 'two'; assert.equal(unitCore(p, 2).status, 'UNSUPPORTED_PROFILE'); });
test('13 nonzero subnormal horizontal normal is not snapped', () => changed(p => p.points[0].normalAtoB = [Number.MIN_VALUE, 1, 0], 'UNSUPPORTED_PROFILE'));
test('14 near-unit vertical normal is not normalized', () => changed(p => p.points[0].normalAtoB = [0, 1 - Number.EPSILON, 0], 'UNSUPPORTED_PROFILE'));
test('15 nonzero horizontal free motion refuses', () => changed(p => p.bodies[1].velocityMps = [Number.MIN_VALUE, -.5, 0], 'UNSUPPORTED_PROFILE'));
test('16 nonzero spin refuses', () => changed(p => p.bodies[1].angularVelocityRadps = [Number.MIN_VALUE, 0, 0], 'UNSUPPORTED_PROFILE'));
test('17 positive free vertical motion refuses', () => changed(p => p.bodies[1].velocityMps = [0, Number.MIN_VALUE, 0], 'UNSUPPORTED_PROFILE'));
test('18 nonunit inverse mass refuses', () => changed(p => p.bodies[1].inverseMass = .5, 'UNSUPPORTED_PROFILE'));
test('19 duplicate identity invalid', () => changed(p => p.bodies[1].id = 'floor', 'INVALID_INPUT'));
test('20 unresolved endpoint invalid', () => changed(p => p.points[0].aId = 'missing', 'INVALID_INPUT'));
test('21 accessor invalid without invoking getter', () => { const p = problem(1); let calls = 0; Object.defineProperty(p.bodies[1], 'inverseMass', { enumerable: true, get() { calls++; return 1; } }); assert.equal(unitCore(p, 1).status, 'INVALID_INPUT'); assert.equal(calls, 0); });
test('22 sole production entry never admits unit-core population', () => { assert.equal(solveStationaryNormal(problem(1)).status, 'UNSUPPORTED_PROFILE'); assert.equal(solveStationaryNormal(problem(2)).status, 'UNSUPPORTED_PROFILE'); });
test('23 literal algebraic greedy trap is not global infeasibility', () => { const m = new UnitExact(), upper = [[q(1n), q(1n), q(-1n)], [q(1n), q(1n), q(1n)], [q(1n), q(-1n), q(1n)], [q(1n), q(-1n), q(-1n)]], eps = q(1n, 1n << 53n), lower = [[q(1n), zero, q(-1n)], [q(1n), eps, q(-1n)], [q(1n), zero, q(1n)], [q(1n), eps, q(1n)]]; assert.deepEqual(unitTriangle(m, upper, [q(1n), zero, zero]), [q(1n, 2n), zero, q(1n, 2n), zero]); assert.equal(unitTriangle(m, lower, [q(2n), q(-1n, 1n << 54n), zero]), null); assert.ok(unitTriangle(m, lower, [q(2n), zero, zero])); /* Alternate upper diagonal1/3 has zero perturbed transfer: a known global alternative. This synthetic matrix seam is not a physical-admission fixture. */ });
test('24 negative required support never yields negative multiplier success', () => { const m = new UnitExact(), c = [[q(1n), zero, zero], [q(1n), q(1n), zero], [q(1n), zero, q(1n)], [q(1n), q(1n), q(1n)]]; assert.equal(unitTriangle(m, c, [q(-1n), zero, zero]), null); assert.equal(m.stats.triangleTrials, 4); });
test('25 exact singular triangles do not use epsilon pivot', () => { const m = new UnitExact(); assert.equal(unitTriangle(m, Array.from({ length: 4 }, () => [q(1n), zero, zero]), [q(1n), q(1n), zero]), null); assert.equal(m.stats.triangleTrials, 4); });
test('26 independent RNE and signed subnormal literal words', () => { const m = new UnitExact(), D = 1n << 53n, word = (n) => { const b = Buffer.alloc(8); b.writeDoubleBE(n); return b.toString('hex'); }; for (const [n, d, w] of [[D + 1n, D, '3ff0000000000000'], [D + 3n, D, '3ff0000000000002'], [1n, 1n << 1074n, '0000000000000001'], [-1n, 1n << 1075n, '8000000000000000'], [1n, 1n << 1075n, '0000000000000000']])
    assert.equal(word(m.number(m.make(n, d))), w); });
test('27 actual oversized integer refuses before normalization', () => { const m = new UnitExact(); assert.throws(() => m.make(1n << 16384n), /integer bit limit/); assert.equal(m.stats.peakIntegerBits, 16385); });
test('28 actual rational exhaustion without counter writes', () => { const m = new UnitExact(); for (let i = 0; i < 200000; i++)
    m.neg(zero); assert.throws(() => m.neg(zero), /rational work limit/); assert.equal(m.stats.rationalOperations, 200001); });
test('29 actual integer exhaustion without counter writes', () => { const m = new UnitExact(); for (let i = 0; i < 2000000; i++)
    m.addI(0n, 0n); assert.throws(() => m.addI(0n, 0n), /integer work limit/); assert.equal(m.stats.integerOperations, 2000001); });
test('30 asymmetric rounded endpoint levers propagate independently', () => { const p = problem(2); p.bodies[1].positionM = [.4, 1, 0]; p.bodies[2].positionM = [.2, 2, 0]; for (const point of p.points)
    point.pointM = [point.pointM[0] < 0 ? .1 : 1.1, point.pointM[1], point.pointM[2]]; const r = successful(p, 2), edge = r.exactApplied.points[4]; assert.notEqual(edge.a.coefficients[5] + edge.b.coefficients[5], .4 - .2); });
let actual = null, fixture;
test('31 identical authenticated original ALIGNED32 and old independent oracle', () => { assert.ok(process.env.STATIONARY_FIXTURE); const bytes = readFileSync(process.env.STATIONARY_FIXTURE); assert.equal(createHash('sha256').update(bytes).digest('hex'), 'da088aeff200bdcfe27927f11286e8a9f6a63f772c6f5558ae11feb2e9d769eb'); fixture = JSON.parse(bytes.toString()); const before = structuredClone(fixture.problem); actual = solveStationaryNormal(fixture.problem); assert.equal(actual.ok, true, JSON.stringify(actual)); assert.deepEqual(fixture.problem, before); const verification = verifyNormalSolution(fixture.problem, verifierView(fixture.problem, actual), fixture.oracle); assert.equal(verification.passed, true, JSON.stringify(verification)); assert.equal(actual.normalImpulsesNs.length, 32); receipts.push({ problem: fixture.problem, result: actual, originalVerification: verification }); });
test('32 actual original32 deterministic repeated result and unchanged fixed caps', () => { assert.ok(actual); assert.deepEqual(solveStationaryNormal(fixture.problem), actual); assert.deepEqual(STATIONARY_LIMITS, { rationalOperations: 200000, integerOperations: 2000000, integerBits: 16384, triangleTrials: 32 }); });
function numericWords(value) { const words = []; function walk(v) { if (typeof v === 'number') {
    assert.ok(Number.isFinite(v));
    const b = Buffer.alloc(8);
    b.writeDoubleLE(v);
    words.push(b);
}
else if (Array.isArray(v))
    v.forEach(walk);
else if (v && typeof v === 'object')
    Object.values(v).forEach(walk); } walk(value); assert.ok(words.length <= 16384); return Buffer.concat(words).toString('hex'); }
after(() => { assert.ok(process.env.STATIONARY_RECEIPTS); const rows = receipts.map(x => { const r = x; return { ...r, problemWordsF64leHex: numericWords(r.problem), resultWordsF64leHex: numericWords(r.result) }; }); const text = rows.map(x => JSON.stringify(x) + '\n').join(''); assert.ok(Buffer.byteLength(text) <= 2 ** 21); writeFileSync(process.env.STATIONARY_RECEIPTS, text, { flag: 'wx' }); });
