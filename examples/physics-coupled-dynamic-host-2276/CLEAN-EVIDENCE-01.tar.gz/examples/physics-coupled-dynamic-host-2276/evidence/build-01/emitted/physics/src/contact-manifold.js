"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.boxFaceManifold = boxFaceManifold;
const math_js_1 = require("./math.js");
const basis = (body) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    .map((axis) => (0, math_js_1.rotate)(body.orientation, axis));
function referenceFace(body, axes, normal) {
    for (let axis = 0; axis < 3; axis++) {
        const alignment = (0, math_js_1.dot)(axes[axis], normal);
        if (Math.abs(alignment) >= 1 - 1e-6) {
            return { body, axes, extents: body.shape.halfExtentsM,
                axis, side: Math.sign(alignment) };
        }
    }
    return null;
}
function clip(polygon, centre, axis, limit) {
    const result = [];
    for (let index = 0; index < polygon.length; index++) {
        const current = polygon[index], next = polygon[(index + 1) % polygon.length];
        // Classify and intersect against the *same* tolerance-shifted plane.
        // Using a 1e-9 inside test with an unshifted intersection plane can
        // extrapolate outside the edge when one endpoint lies inside the
        // tolerance band and the other lies outside, on the same side of the true plane.
        const a = (0, math_js_1.dot)((0, math_js_1.sub)(current, centre), axis) - limit - 1e-9;
        const b = (0, math_js_1.dot)((0, math_js_1.sub)(next, centre), axis) - limit - 1e-9;
        const insideA = a <= 0, insideB = b <= 0;
        if (insideA)
            result.push(current);
        if (insideA !== insideB)
            result.push((0, math_js_1.add)(current, (0, math_js_1.scale)((0, math_js_1.sub)(next, current), a / (a - b))));
    }
    return result;
}
function faceVertices(face) {
    const tangents = [0, 1, 2].filter((axis) => axis !== face.axis);
    const centre = (0, math_js_1.add)(face.body.positionM, (0, math_js_1.scale)(face.axes[face.axis], face.side * face.extents[face.axis]));
    return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => (0, math_js_1.add)((0, math_js_1.add)(centre, (0, math_js_1.scale)(face.axes[tangents[0]], u * face.extents[tangents[0]])), (0, math_js_1.scale)(face.axes[tangents[1]], v * face.extents[tangents[1]])));
}
/** Clip an incident box face against a reference box face. Edge axes keep the one-point path. */
function boxFaceManifold(a, b, hit) {
    if (a.shape.kind !== 'box' || b.shape.kind !== 'box')
        return null;
    const axesA = basis(a), axesB = basis(b);
    const faceA = referenceFace(a, axesA, hit.normal);
    const faceB = referenceFace(b, axesB, (0, math_js_1.scale)(hit.normal, -1));
    const reference = faceA ?? faceB;
    if (!reference)
        return null;
    const incidentBody = reference.body === a ? b : a;
    const incidentAxes = reference.body === a ? axesB : axesA;
    const normal = reference.body === a ? hit.normal : (0, math_js_1.scale)(hit.normal, -1);
    let incidentAxis = 0, greatest = -Infinity;
    for (let axis = 0; axis < 3; axis++) {
        const alignment = Math.abs((0, math_js_1.dot)(incidentAxes[axis], normal));
        if (alignment > greatest) {
            greatest = alignment;
            incidentAxis = axis;
        }
    }
    const incident = { body: incidentBody, axes: incidentAxes,
        extents: incidentBody.shape.halfExtentsM, axis: incidentAxis,
        side: (0, math_js_1.dot)(incidentAxes[incidentAxis], normal) > 0 ? -1 : 1 };
    const centre = (0, math_js_1.add)(reference.body.positionM, (0, math_js_1.scale)(reference.axes[reference.axis], reference.side * reference.extents[reference.axis]));
    const tangents = [0, 1, 2].filter((axis) => axis !== reference.axis);
    let polygon = faceVertices(incident);
    for (const axis of tangents) {
        polygon = clip(polygon, centre, reference.axes[axis], reference.extents[axis]);
        polygon = clip(polygon, centre, (0, math_js_1.scale)(reference.axes[axis], -1), reference.extents[axis]);
    }
    const candidates = polygon.map((point) => {
        const separation = (0, math_js_1.dot)((0, math_js_1.sub)(point, centre), normal);
        const midpoint = (0, math_js_1.sub)(point, (0, math_js_1.scale)(normal, separation / 2));
        return { pointM: midpoint, separation,
            u: (0, math_js_1.dot)((0, math_js_1.sub)(midpoint, centre), reference.axes[tangents[0]]),
            v: (0, math_js_1.dot)((0, math_js_1.sub)(midpoint, centre), reference.axes[tangents[1]]) };
    }).filter((point) => point.separation <= 1e-6);
    if (!candidates.length)
        return null;
    const selected = candidates.length <= 4 ? candidates :
        [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => candidates.reduce((best, point) => u * point.u + v * point.v > u * best.u + v * best.v
            ? point : best, candidates[0]));
    const unique = selected.filter((point, index) => selected.findIndex((other) => Math.hypot(...(0, math_js_1.sub)(point.pointM, other.pointM)) <= 1e-9) === index);
    unique.sort((first, second) => first.u - second.u || first.v - second.v);
    return unique.map((point, index) => ({ id: `${reference.body.id}:${reference.axis}:`
            + `${reference.side}:${index}`, pointM: point.pointM }));
}
