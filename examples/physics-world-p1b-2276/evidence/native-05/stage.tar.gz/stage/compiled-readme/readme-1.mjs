import { createPhysicsWorld } from '@barocss/physics';
const dt = 1 / 120;
const model = {
    format: 'barocss-physics-model', version: 1, revision: 'example1',
    frame: { id: 'world', basis: 'right-handed-xyz', rotation: 'local-to-world-xyzw' },
    units: { length: 'm', mass: 'kg', time: 's', angle: 'rad' }, gravityMps2: [0, -9.81, 0],
    bodies: [
        { id: 'part:ball', kind: 'dynamic', massKg: 1,
            inertia: { kind: 'primitive-com', about: 'com', frame: 'body-local' },
            initial: { positionM: [0, 2, 0], orientationXYZW: [0, 0, 0, 1],
                velocityMps: [0, 0, 0], angularVelocityRadps: [0, 0, 0] } },
        { id: 'fixture:floor', kind: 'static',
            initial: { positionM: [0, 0.2, 0], orientationXYZW: [0, 0, 0, 1] } },
    ],
    colliders: [
        { id: 'ball.shape', bodyId: 'part:ball', geometry: { kind: 'sphere', radiusM: 0.15 },
            local: { positionM: [0, 0, 0], orientationXYZW: [0, 0, 0, 1] },
            material: { restitution: 0.25, friction: { static: 0, dynamic: 0 } },
            sensor: false, ccd: false, filter: { categoryBits: 1, maskBits: 65535 } },
        { id: 'floor.shape', bodyId: 'fixture:floor', geometry: { kind: 'box', halfExtentsM: [1, 0.2, 1] },
            local: { positionM: [0, 0, 0], orientationXYZW: [0, 0, 0, 1] },
            material: { restitution: 0.25, friction: { static: 0, dynamic: 0 } },
            sensor: false, ccd: false, filter: { categoryBits: 1, maskBits: 65535 } },
    ], joints: [], cloths: [], fluids: [], sourceBindings: [],
};
const world = createPhysicsWorld(model, { profile: 'rigid-discrete-v1', fixedStepSeconds: dt, broadPhase: 'direct' });
const state = world.step(); // Exactly one configured step, with no hidden clock.
console.log(state.bodies, state.contacts, state.identity);
world.step([{ kind: 'force', bodyId: 'part:ball', forceN: [0, 2, 0] }]);
world.step([{ kind: 'impulse', bodyId: 'part:ball', impulseNs: [0, 0.5, 0] }]);
world.dispose();
