import test from 'node:test';
import assert from 'node:assert/strict';
import { emptyDoc } from '@barocss/cad-model/engine/doc';
import { openImportedFile } from '../src/files/importedFile';

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(r => { resolve = r; });
  return { promise, resolve };
}
/** Real import routing with deferred file and worker transports; no browser or kernel proof. */
function harness() {
  let current = true;
  const events: string[] = [];
  const worker = {
    engine: {
      async stepMeshes() { events.push('stepMeshes'); return null; },
      async diagnose() { events.push('diagnose'); return { error: 'bad mesh' }; },
      async part() { events.push('part'); return { ok: false, error: { detail: 'bad STEP' } }; },
    },
    nextRevision() { return 1; },
  };
  const options = {
    doc: emptyDoc(), worker,
    ownership: { isCurrent: () => current },
    mesh: { setStage(value: unknown) { events.push(`stage:${value}`); }, setMeshAsk() { events.push('meshAsk'); }, setRepairAsk() { events.push('repairAsk'); } },
    changes: { onOpened() { events.push('opened'); }, commitDirect() { events.push('commit'); return false; }, fitLater() { events.push('fit'); } },
    onNotice() { events.push('notice'); },
  };
  return { events, worker, options: options as unknown as Parameters<typeof openImportedFile>[1], invalidate() { current = false; } };
}

test('STL read completion cannot show a question or error after a newer intent', async () => {
  const h = harness(), bytes = deferred<ArrayBuffer>();
  const file = { name: 'old.stl', arrayBuffer: () => bytes.promise } as File;
  const pending = openImportedFile(file, h.options);
  h.invalidate(); bytes.resolve(new ArrayBuffer(0)); await pending;
  assert.deepEqual(h.events, []);
});

test('DWG header completion cannot replace a newer notice', async () => {
  const h = harness(), bytes = deferred<ArrayBuffer>();
  const file = { name: 'old.dwg', slice: () => ({ arrayBuffer: () => bytes.promise }) } as File;
  const pending = openImportedFile(file, h.options);
  h.invalidate(); bytes.resolve(new TextEncoder().encode('AC1027').buffer); await pending;
  assert.deepEqual(h.events, []);
});

test('STEP file read cannot start a worker after Stop or a newer intent', async () => {
  const h = harness(), text = deferred<string>();
  const pending = openImportedFile({ name: 'old.step', text: () => text.promise } as File, h.options);
  h.invalidate(); text.resolve('ISO-10303-21;'); await pending;
  assert.deepEqual(h.events, []);
});

test('STEP mesh reply cannot clear a newer stage or start a part read', async () => {
  const h = harness(), meshes = deferred<null>();
  h.worker.engine.stepMeshes = () => meshes.promise;
  const pending = openImportedFile({ name: 'old.step', text: async () => 'ISO-10303-21;' } as File, h.options);
  await Promise.resolve();
  assert.deepEqual(h.events, ['stage:reading the file']);
  h.invalidate(); meshes.resolve(null); await pending;
  assert.deepEqual(h.events, ['stage:reading the file']);
});

test('STEP part failure cannot replace a newer notice', async () => {
  const h = harness(), read = deferred<{ ok: false; error: { detail: string } }>();
  const entered = deferred<void>();
  h.worker.engine.part = () => { entered.resolve(); return read.promise; };
  const pending = openImportedFile({ name: 'old.step', text: async () => 'ISO-10303-21;' } as File, h.options);
  await entered.promise;
  const before = [...h.events]; h.invalidate();
  read.resolve({ ok: false, error: { detail: 'old failure' } }); await pending;
  assert.deepEqual(h.events, before);
});
