"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cadProxyPose = cadProxyPose;
const math_js_1 = require("./math.js");
const cad_proxy_validation_js_1 = require("./cad-proxy-validation.js");
const cad_proxy_admission_js_1 = require("./cad-proxy-admission.js");
function cadProxyPose(proxy, body, currentSource, currentRevision) {
    (0, cad_proxy_admission_js_1.assertCadProxyCurrent)(proxy, currentSource, currentRevision);
    if (!body || body.id !== proxy.bodyId || !Array.isArray(body.positionM) || body.positionM.length !== 3 ||
        body.positionM.some((value) => !Number.isFinite(value) || Math.abs(value) > 10000) ||
        !Array.isArray(body.orientationXYZW) || body.orientationXYZW.length !== 4 ||
        body.orientationXYZW.some((value) => !Number.isFinite(value)) ||
        Math.abs(Math.hypot(...body.orientationXYZW) - 1) > 1e-9) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'Physics body pose differs from CAD proxy binding');
    }
    const positionMM = body.positionM.map((value) => value * 1000);
    const translation = (0, math_js_1.sub)(positionMM, (0, math_js_1.rotate)([body.orientationXYZW[0], body.orientationXYZW[1], body.orientationXYZW[2], body.orientationXYZW[3]], proxy.sourceCenterMM));
    if (translation.some((value) => !Number.isFinite(value)))
        (0, cad_proxy_validation_js_1.proxyError)('NUMERIC_LIMIT', 'unsafe CAD proxy pose');
    return { targetId: proxy.bodyId, translation, rotation: [...body.orientationXYZW] };
}
