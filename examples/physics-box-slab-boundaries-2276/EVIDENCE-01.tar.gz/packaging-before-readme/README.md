# Finite axis-aligned box CCD boundaries

This is an authored, unexecuted 20-case qualification of the existing public box/static-box CCD path. The frozen contract preserves current admission, the strict event interval, inward bias and all tolerances. It adds analytic primitive-box cases to the earlier CAD-derived thin-box probe without repeating that trajectory.

The reference generator enumerates exact Fraction face events and tests the six physical halfspaces. It imports no production code. It creates `BANK-01.json` before the API runner can import a World. The baseline negative identity quaternion cases record current `INVALID_CONFIG` admission; Hamilton rotation by either identity sign is physically the same. A later admission repair requires a separate explicit amendment. Do not alter the baseline bank or provider pins.

Root review and freeze order, each through the existing heavy gate and 180-second command wrapper:

```sh
python3 -B examples/physics-box-slab-boundaries-2276/reference.py
node examples/physics-box-slab-boundaries-2276/freeze.mjs
node examples/physics-box-slab-boundaries-2276/run.mjs baseline-01
```

The first two commands write new files exclusively. The runner uses a fresh receipt directory. It authenticates `FREEZE-01.json`, the independent bank, harness and all qualified1779 Source/Native inputs before any numerical import. It does not rebuild, regenerate a bank or refresh pins. The original provider is pinned separately in `PROVIDER-PINS-01.json`; source or dist drift stops the run.

`run.mjs` accepts an optional explicit freeze path as its second argument for a later reviewed amendment. That manifest must use format `physics-box-slab-freeze`, version 1, and contain hashed `sourceModule`, `nativeModule`, `replayModule`, `caseFile` and `bankFile` entries plus the complete `files` map. An amendment is a new file; it does not replace the original freeze or evidence. The root owns the separate build script and any production edit. No renderer is authored before the repaired API gate passes.

Per graph, the intended counts are 20 cases, 22 constructor attempts, 18 successful Worlds, 4 creation refusals, 22 accepted steps and 2 command refusals. Hard caps are 24 Worlds, 28 accepted steps and 16 MiB evidence. Angular commands are refused after an accepted recorded impact; state, clock and log must remain unchanged, and retry must match a separate control World. Full inputs and raw binary64 states are saved before checks. The first failure ends dependent execution.

Expected gates are 1e-12 SI for TOI, geometry, normal, spin and tangent impulse; 1e-10 for velocity, momentum and energy. Event branches use no epsilon. Source/Native states and recording data must match exactly after provider identity normalization. These finite centered cases do not qualify tilted/off-center boxes, simultaneous edge/corner events, arbitrary scales, persistent geometry, full G2, P4, general mechanisms or equipment.

Authoring status: no build, bank generation, numerical import, World call or browser run has occurred in this task. Existing HOLDs and deployment limits remain.
