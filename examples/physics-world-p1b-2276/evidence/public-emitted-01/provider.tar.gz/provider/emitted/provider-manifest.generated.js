// Generated from the actual emitted provider graph. Do not edit.
export const providerManifest = {
  "format": "barocss-physics-provider",
  "version": 1,
  "graph": "emitted",
  "entries": [
    "index.js",
    "replay.js"
  ],
  "files": {
    "identity.js": "7f7243fcc617a32f77d517d029cb90bd99584f518ece49a7d7a4e35ae54d7791",
    "index.js": "39bf18e89255b0308fdc902bcc900d80222fd44d5db0b4de37966eed84a78548",
    "replay-compare.js": "46e92b237a3b74725e1f973bc195f3fb3c7d182ea4978f5092608706d1400875",
    "replay-json.js": "24359e390571cf591108d2a35769bc9b7c67677f0e1979a6a80aae66d1ce6d06",
    "replay-scene.js": "189dd152199f102cea5a437c81c814753179b772462c2f338273e4f105d829b7",
    "replay-session.js": "ff350e3d02099a4acca468968d0c85c1effa5e30b478df583c558074cc91ae54",
    "replay.js": "3d03d9441ff03f2fa100c52b646dbc93e3cd5c769e7a2326cfde215e18713c00",
    "types.js": "65a4905c6bda0d4e7a5fc7ea105a1362c8cae1345070b5d17fd524a8790e1f8b"
  }
};
