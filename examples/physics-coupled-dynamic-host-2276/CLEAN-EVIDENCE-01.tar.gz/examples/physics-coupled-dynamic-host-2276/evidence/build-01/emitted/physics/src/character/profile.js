"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WALKABLE = exports.LOOKAHEAD = exports.QUERY_CAP = exports.SLIDE_CAP = exports.ASSIST_CAP = exports.STEP_DOWN = exports.PREVIEW = exports.STEP_HEIGHT = exports.SNAP = exports.SKIN = exports.GRAVITY = exports.STEPS = exports.DT = exports.PROFILE = void 0;
exports.PROFILE = 'upright-capsule-controller-v1';
exports.DT = 1 / 120, exports.STEPS = 240, exports.GRAVITY = -9.81;
exports.SKIN = .002, exports.SNAP = .02, exports.STEP_HEIGHT = .1, exports.PREVIEW = .152, exports.STEP_DOWN = .12;
exports.ASSIST_CAP = 20, exports.SLIDE_CAP = 4, exports.QUERY_CAP = 32, exports.LOOKAHEAD = .02;
exports.WALKABLE = Math.cos(10 * Math.PI / 180);
