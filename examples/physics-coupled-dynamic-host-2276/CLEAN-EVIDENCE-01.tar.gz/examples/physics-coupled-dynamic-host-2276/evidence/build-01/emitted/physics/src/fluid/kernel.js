"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.densityKernel = densityKernel;
exports.gradientScale = gradientScale;
exports.densities = densities;
exports.initialRestDensity = initialRestDensity;
const constants_js_1 = require("./constants.js");
const neighbors_js_1 = require("./neighbors.js");
const radiusSquared = constants_js_1.FLUID_SMOOTHING_RADIUS_M ** 2;
function densityKernel(distanceSquared) {
    const q = 1 - distanceSquared / radiusSquared;
    return q > 0 ? q * q * q : 0;
}
function gradientScale(distanceSquared) {
    const q = 1 - distanceSquared / radiusSquared;
    return q > 0 ? -6 * q * q / radiusSquared : 0;
}
function densities(positions, grid, output) {
    grid.rebuild(positions);
    for (let index = 0; index < output.length; index++) {
        let density = 0;
        grid.each(index, (_other, _x, _y, _z, distanceSquared) => {
            density += densityKernel(distanceSquared);
        });
        output[index] = density;
    }
}
function initialRestDensity(positions) {
    const count = positions.length / 3;
    const result = new Float64Array(count);
    densities(positions, new neighbors_js_1.NeighborGrid(), result);
    return result.reduce((sum, density) => sum + density, 0) / count;
}
