"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectCoupledHinge = projectCoupledHinge;
const validation_js_1 = require("../validation.js");
const collision_js_1 = require("../collision.js");
const math_js_1 = require("../math.js");
const measure_js_1 = require("./measure.js");
const errors_js_1 = require("./errors.js");
function finiteData(value) { if (typeof value === 'number')
    return Number.isFinite(value); if (typeof value === 'string' || typeof value === 'boolean')
    return true; if (Array.isArray(value))
    return value.every(finiteData); if (value && typeof value === 'object')
    return Object.values(value).every(finiteData); return false; }
/** ONE declared pose-only law; v/omega are never assigned or compensated. */
function projectCoupledHinge(input) {
    const before = input.bodies.map(validation_js_1.copyBody), bodies = input.bodies.map(validation_js_1.copyBody), joint = input.pair.joint;
    const origin = [...input.pair.originM], beforeMetric = (0, measure_js_1.measurePose)(before, joint, origin);
    const targetAngleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], beforeMetric.relativeAngleRad)), excess = beforeMetric.relativeAngleRad - targetAngleRad;
    const a = bodies[joint.aIndex], b = bodies[joint.bIndex], axis = joint.axisWorld, inverseA = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(a, axis)), inverseB = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(b, axis)), inverseSum = inverseA + inverseB;
    const angleCorrectionsRad = [excess * inverseA / inverseSum, -excess * inverseB / inverseSum];
    a.orientation = (0, math_js_1.advanceOrientation)(a.orientation, (0, math_js_1.scale)(axis, angleCorrectionsRad[0]), 1);
    b.orientation = (0, math_js_1.advanceOrientation)(b.orientation, (0, math_js_1.scale)(axis, angleCorrectionsRad[1]), 1);
    // Orientations are now held; no angular anchor feedback or repeated clamp.
    const massA = 1 / a.inverseMass, massB = 1 / b.inverseMass, totalMass = massA + massB;
    const center = (0, math_js_1.scale)((0, math_js_1.add)((0, math_js_1.scale)(before[joint.aIndex].positionM, massA), (0, math_js_1.scale)(before[joint.bIndex].positionM, massB)), 1 / totalMass);
    const offset = (0, math_js_1.sub)((0, math_js_1.rotate)(b.orientation, joint.anchorBLocalM), (0, math_js_1.rotate)(a.orientation, joint.anchorALocalM));
    a.positionM = (0, math_js_1.add)(center, (0, math_js_1.scale)(offset, massB / totalMass));
    b.positionM = (0, math_js_1.sub)(center, (0, math_js_1.scale)(offset, massA / totalMass));
    // Original output bounds/errors remain original; no correction is repaired.
    (0, collision_js_1.validateResult)(bodies, []);
    const afterMetric = (0, measure_js_1.measurePose)(bodies, joint, origin), velocityBitsUnchanged = bodies.every((body, i) => body.velocityMps.every((v, k) => Object.is(v, before[i].velocityMps[k]))), angularVelocityBitsUnchanged = bodies.every((body, i) => body.angularVelocityRadps.every((v, k) => Object.is(v, before[i].angularVelocityRadps[k])));
    const poseReport = { jointId: joint.id, finalAngleRad: afterMetric.relativeAngleRad, targetAngleRad };
    const diagnostics = { before: beforeMetric, after: afterMetric, targetAngleRad, angleCorrectionsRad, translationCorrectionsM: bodies.map((body, i) => (0, math_js_1.sub)(body.positionM, before[i].positionM)), sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds, velocityBitsUnchanged, angularVelocityBitsUnchanged, lawEvaluations: 1 };
    if (!finiteData(poseReport) || !finiteData(diagnostics) || !velocityBitsUnchanged || !angularVelocityBitsUnchanged)
        (0, errors_js_1.fail)('result');
    return { bodies: bodies.map(validation_js_1.copyBody), poseReport: structuredClone(poseReport), diagnostics: structuredClone(diagnostics) };
}
