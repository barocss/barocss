/** Private physical admission. No scene IDs, solver options or expected state. */
import type { PhysicsCommand, PhysicsModel, WorldOptions } from '../types.js';
import type { Body } from '../internal-types.js';
export declare const STATIONARY_PROFILE: "rigid-stationary-cube-stack-v1";
export declare const STATIONARY_MAX_STEPS = 1200;
/** Call after generic copied model/schema/ID/reference and primitive-parser validation. */
export declare function admitStationaryProfile(model: PhysicsModel, options: WorldOptions, bodies: readonly Body[]): void;
/** Generic command parsing still owns malformed-command precedence. */
export declare function admitStationaryCommands(commands: readonly PhysicsCommand[]): void;
