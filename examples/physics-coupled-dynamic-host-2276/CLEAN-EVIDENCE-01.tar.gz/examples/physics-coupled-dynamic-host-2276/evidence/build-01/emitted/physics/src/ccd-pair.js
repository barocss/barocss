"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sweepSpherePair = sweepSpherePair;
const math_js_1 = require("./math.js");
const ccd_sphere_pair_exact_js_1 = require("./ccd-sphere-pair-exact.js");
/** Stop two linearly swept dynamic spheres at their first relative entry. */
function sweepSpherePair(markedStart, markedEnd, otherStart, otherEnd) {
    if (markedStart.shape.kind !== 'sphere' || otherStart.shape.kind !== 'sphere')
        return null;
    const hit = (0, ccd_sphere_pair_exact_js_1.sweepSpherePairExact)(markedStart.positionM, markedEnd.positionM, otherStart.positionM, otherEnd.positionM, markedStart.shape.radiusM, otherStart.shape.radiusM);
    if (!hit)
        return null;
    const markedTravel = (0, math_js_1.sub)(markedEnd.positionM, markedStart.positionM);
    const otherTravel = (0, math_js_1.sub)(otherEnd.positionM, otherStart.positionM);
    const { fraction, normal: normalFixtureToBody } = hit;
    const markedAtHit = (0, math_js_1.add)(markedStart.positionM, (0, math_js_1.scale)(markedTravel, fraction));
    const otherAtHit = (0, math_js_1.add)(otherStart.positionM, (0, math_js_1.scale)(otherTravel, fraction));
    markedEnd.positionM = (0, math_js_1.sub)(markedAtHit, (0, math_js_1.scale)(normalFixtureToBody, 5e-10));
    otherEnd.positionM = (0, math_js_1.add)(otherAtHit, (0, math_js_1.scale)(normalFixtureToBody, 5e-10));
    return { bodyId: markedStart.id, fixtureId: otherStart.id, toiFraction: fraction,
        normalFixtureToBody };
}
