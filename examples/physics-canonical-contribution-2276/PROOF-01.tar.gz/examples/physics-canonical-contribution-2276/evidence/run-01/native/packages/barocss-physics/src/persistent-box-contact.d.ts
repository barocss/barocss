import type { Body, Vec3 } from './internal-types.js';
import type { ContactContribution } from './contact-contribution.js';
export interface PointImpulse {
    normalNs: number;
    tangentNs: Vec3;
}
export declare function warmStartPoint(a: Body, b: Body, pointM: Vec3, normal: Vec3, impulse: PointImpulse): ContactContribution;
export declare function solvePersistentPoint(a: Body, b: Body, pointM: Vec3, normal: Vec3, impulse: PointImpulse, normalTargetMps: number): ContactContribution;
export declare function correctPersistentPair(a: Body, b: Body, normal: Vec3, penetration: number): void;
