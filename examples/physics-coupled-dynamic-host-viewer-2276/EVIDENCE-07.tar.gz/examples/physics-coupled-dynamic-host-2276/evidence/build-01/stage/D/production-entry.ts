export {coupledContactTarget} from './candidate.js';
export {coupledStaticTarget} from '../C/candidate.js';
export type {CoupledInput,CoupledResult,DynamicCertificate,DynamicCounts,RootCertificate} from './types.js';
