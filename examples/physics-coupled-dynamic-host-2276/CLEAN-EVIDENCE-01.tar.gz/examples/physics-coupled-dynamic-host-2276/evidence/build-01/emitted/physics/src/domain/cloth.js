"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeCloth = initializeCloth;
exports.prepareCloth = prepareCloth;
const types_js_1 = require("../types.js");
const solver_js_1 = require("../cloth/solver.js");
const metrics_js_1 = require("../cloth/metrics.js");
const profile_js_1 = require("../cloth/profile.js");
const types_js_2 = require("./types.js");
function sheet(definition, positions) {
    const c = definition.cloth;
    return { positions, restPositions: (0, types_js_2.flat)(c.restPositionsM, 289),
        inverseMasses: Float64Array.from(c.vertexMassesKg, (mass, index) => c.pinnedVertexIndices.includes(index) ? 0 : 1 / mass),
        pins: [...c.pinnedVertexIndices], triangles: Uint16Array.from(c.triangles.flat()),
        constraints: c.constraints.map(e => ({ a: e.a, b: e.b, kind: e.kind, rest: e.restLengthM, lambda: 0 })),
        totalMassKg: c.vertexMassesKg.reduce((sum, mass) => sum + mass, 0) };
}
function copyClothCandidateOutput(id, candidate) {
    return { id, positionsM: candidate.positions.slice(), velocitiesMps: candidate.velocities.slice(),
        diagnostics: { ...candidate.diagnostics } };
}
function initializeCloth(cloth, staticData) {
    const definition = (0, types_js_2.immutableCopy)({ cloth, staticData });
    const c = definition.cloth, data = definition.staticData;
    (0, types_js_2.invalid)(data.profile === 'cloth-pinned-sphere-visual-v1', 'Unsupported cloth profile');
    (0, types_js_2.validateStatic)(data, c.staticColliderIds);
    (0, types_js_2.invalid)(c.staticColliderIds.length === 1, 'Cloth requires one fixed sphere');
    const collider = data.colliders[0], body = data.bodies[0];
    (0, types_js_2.invalid)(collider.geometry.kind === 'sphere' && collider.geometry.radiusM === profile_js_1.CLOTH_PROFILE.sphereRadiusM
        && body.initial.positionM.every((x, i) => x === profile_js_1.CLOTH_PROFILE.sphereCentreM[i]), 'Unsupported cloth sphere');
    (0, types_js_2.invalid)(c.vertexMassesKg.length === 289 && c.vertexMassesKg.every(m => Number.isFinite(m) && m > 0), 'Invalid cloth masses');
    (0, types_js_2.invalid)(c.triangles.length === 512 && c.triangles.every(t => t.length === 3 && t.every(i => Number.isInteger(i) && i >= 0 && i < 289)), 'Invalid cloth triangles');
    (0, types_js_2.invalid)(c.pinnedVertexIndices.length === 2 && c.pinnedVertexIndices[0] === 0 && c.pinnedVertexIndices[1] === 16, 'Unsupported pins');
    (0, types_js_2.invalid)(c.constraints.length === 1566 && c.constraints.every(e => Number.isInteger(e.a) && e.a >= 0 && e.a < 289
        && Number.isInteger(e.b) && e.b >= 0 && e.b < 289 && e.a !== e.b && Number.isFinite(e.restLengthM) && e.restLengthM > 0
        && ['stretch', 'shear', 'bend-distance'].includes(e.kind)
        && e.complianceMPerN === (e.kind === 'bend-distance' ? profile_js_1.CLOTH_PROFILE.bendComplianceMPerN : profile_js_1.CLOTH_PROFILE.stretchComplianceMPerN)), 'Unsupported cloth constraints');
    const positions = (0, types_js_2.flat)(c.initialPositionsM, 289), velocities = (0, types_js_2.flat)(c.initialVelocitiesMps, 289);
    (0, types_js_2.invalid)(velocities.every(x => x === 0), 'Unsupported initial cloth velocities');
    const initialSheet = sheet(definition, positions);
    (0, types_js_2.invalid)(positions.every((x, i) => Object.is(x, initialSheet.restPositions[i])), 'Initial cloth must match rest data');
    const diagnostics = (0, metrics_js_1.clothDiagnostics)(initialSheet);
    (0, types_js_2.invalid)((0, metrics_js_1.withinClothBounds)(positions, velocities, diagnostics), 'Invalid initial cloth state');
    return { definition, initial: { positions, velocities, constraints: initialSheet.constraints, diagnostics } };
}
function prepareCloth(definition, accepted) {
    const positions = accepted.positions.slice(), velocities = accepted.velocities.slice();
    const candidateSheet = sheet(definition, positions);
    const solver = new solver_js_1.ClothSolver();
    solver.step(candidateSheet, positions, velocities);
    const diagnostics = (0, metrics_js_1.clothDiagnostics)(candidateSheet);
    if (!(0, metrics_js_1.withinClothBounds)(positions, velocities, diagnostics))
        throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'Cloth candidate exceeded the fixed profile bounds');
    const candidate = { positions, velocities, constraints: candidateSheet.constraints, diagnostics };
    const output = copyClothCandidateOutput(definition.cloth.id, candidate);
    return { candidate, output };
}
