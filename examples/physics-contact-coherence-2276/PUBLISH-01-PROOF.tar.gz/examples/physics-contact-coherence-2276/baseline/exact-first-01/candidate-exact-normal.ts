/** Example-only exact normal certificate and aggregate physical wrench. No World or fixture imports. */
import type { Body, Vec3 } from '../../packages/barocss-physics/src/internal-types.js';
import type { NormalBody, NormalProblem } from '../../packages/barocss-physics/src/stack/normal-solver.js';
export const STRICT_LINE_LIMITS = Object.freeze({ rationalOperations: 200000, integerOperations: 2000000,
  integerBits: 16384, roundingSteps: 16 });
class StrictLineFailure extends Error {}
interface Rational { n: bigint; d: bigint }
type RVec = [Rational, Rational, Rational];
interface IntegerRotation { denominator: bigint; columns: [bigint[], bigint[], bigint[]] }
interface StrictLineStats { rationalOperations: number; integerOperations: number; peakIntegerBits: number }
const ZERO: Rational = { n: 0n, d: 1n };
const ieee = new DataView(new ArrayBuffer(8));

class Arithmetic {
  readonly counters: StrictLineStats = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 };
  guardCached(): void {
    if (this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure('rational work limit');
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure('integer work limit');
    if (this.counters.peakIntegerBits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure('integer bit limit');
  }
  tick(amount = 1): void {
    this.counters.integerOperations += amount;
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure('integer work limit');
  }
  op(): void {
    if (++this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure('rational work limit');
  }
  checked(value: bigint): bigint {
    const hex = (value < 0n ? -value : value).toString(16), first = hex.charCodeAt(0);
    const bits = 4*(hex.length-1) + (first <= 49 ? 1 : first <= 51 ? 2 : first <= 55 ? 3 : 4);
    this.counters.peakIntegerBits = Math.max(this.counters.peakIntegerBits, bits);
    if (bits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure('integer bit limit');
    return value;
  }
  multiply(a: bigint, b: bigint): bigint { this.tick(); return this.checked(a*b); }
  sum(a: bigint, b: bigint): bigint { this.tick(); return this.checked(a+b); }
  shifted(value: bigint, bits: number): bigint { this.tick(); return this.checked(value << BigInt(bits)); }
  make(n: bigint, d = 1n): Rational {
    this.checked(n); this.checked(d);
    return this.normalizeChecked(n, d);
  }
  /** Both operands have already passed checked in this call's evaluation order. */
  private normalizeChecked(n: bigint, d: bigint): Rational {
    if (d === 0n) throw new StrictLineFailure('zero rational denominator');
    if (n === 0n) return ZERO;
    if (d < 0n) { this.tick(2); n = -n; d = -d; }
    if (d === 1n) { this.guardCached(); return { n, d }; }
    let a = n < 0n ? -n : n, b = d;
    this.tick(2);
    if ((d & (d-1n)) === 0n) {
      this.tick(2); const factor = a & -a, divisor = factor < d ? factor : d;
      this.tick(2); return { n: n/divisor, d: d/divisor };
    }
    while (b !== 0n) { this.tick(); const remainder = a % b; a = b; b = remainder; }
    this.tick(2); return { n: n/a, d: d/a };
  }
  from(value: number): Rational {
    this.op();
    if (!Number.isFinite(value)) throw new StrictLineFailure('nonfinite exact operand');
    ieee.setFloat64(0, value, false);
    const bits = ieee.getBigUint64(0, false), negative = (bits >> 63n) !== 0n;
    const exponent = Number((bits >> 52n) & 2047n), fraction = bits & ((1n << 52n)-1n);
    const significand = exponent === 0 ? fraction : fraction+(1n << 52n);
    const power = exponent === 0 ? -1074 : exponent-1023-52;
    const n = negative ? -significand : significand;
    return power >= 0 ? this.make(this.shifted(n, power)) : this.make(n, this.shifted(1n, -power));
  }
  add(a: Rational, b: Rational): Rational {
    this.op();
    if (a.d === b.d) return this.make(this.sum(a.n,b.n),a.d);
    if (a.d > 0n && b.d > 0n) {
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d/b.d);
        return this.make(this.sum(a.n,this.multiply(b.n,ratio)),a.d);
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d/a.d);
        return this.make(this.sum(this.multiply(a.n,ratio),b.n),b.d);
      }
    }
    return this.normalizeChecked(this.sum(this.multiply(a.n,b.d),this.multiply(b.n,a.d)),this.multiply(a.d,b.d));
  }
  neg(a: Rational): Rational { this.op(); this.tick(); return { n: -a.n, d: a.d }; }
  sub(a: Rational, b: Rational): Rational { return this.add(a,this.neg(b)); }
  mul(a: Rational, b: Rational): Rational { this.op(); return this.normalizeChecked(this.multiply(a.n,b.n),this.multiply(a.d,b.d)); }
  sumSquare(a: Rational, b: Rational): Rational {
    // Own the normalization: even raw input pairs produce a reduced sum.
    // Its numerator and denominator squares are therefore already coprime.
    const sum = this.add(a,b);
    this.op();
    const n = this.multiply(sum.n,sum.n), d = this.multiply(sum.d,sum.d);
    if (n === 0n) return ZERO;
    if (d === 1n) this.guardCached();
    return { n, d };
  }
  div(a: Rational, b: Rational): Rational {
    this.op();
    if (a.d > 0n && b.d > 0n && b.n !== 0n) {
      this.guardCached();
      if (a.d === b.d) return this.make(a.n,b.n);
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d/b.d);
        return this.make(a.n,this.multiply(ratio,b.n));
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d/a.d);
        return this.make(this.multiply(ratio,a.n),b.n);
      }
    }
    return this.normalizeChecked(this.multiply(a.n,b.d),this.multiply(a.d,b.n));
  }
  compare(a: Rational, b: Rational): number {
    this.op(); const difference = this.sum(this.multiply(a.n,b.d),-this.multiply(b.n,a.d));
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
  }
  abs(a: Rational): Rational { return a.n < 0n ? this.neg(a) : a; }
  vec(value: readonly number[], length = 3): Rational[] {
    if (value.length !== length || !Array.from({ length },(_,i)=>i).every(i=>Object.hasOwn(value,i))) throw new StrictLineFailure('dense exact vector required');
    return value.map(x=>this.from(x));
  }
  dot(a: Rational[], b: Rational[]): Rational {
    return a.reduce<Rational|null>((value,x,i)=>{
      const product = this.mul(x,b[i]);
      return value === null && product.n !== 0n && product.d !== 1n ? product : this.add(value ?? ZERO,product);
    },null) ?? ZERO;
  }
  private quotient(a: bigint, b: bigint): bigint { this.tick(); return this.checked(a/b); }
  /** Called only after both original boxes have fully decoded and normalized. */
  prepareRotation(rotation: Rational[][]): IntegerRotation {
    let denominator = 1n;
    for (const row of rotation) for (const value of row) {
      if (value.d === 1n) continue;
      let a = denominator, b = value.d;
      while (b !== 0n) { this.tick(); const remainder = a%b; a = b; b = remainder; }
      denominator = this.multiply(this.quotient(denominator,a),value.d);
    }
    // The already checked unit-denominator numerators need no new arithmetic.
    if (denominator === 1n) return { denominator, columns: [0,1,2].map(axis=>rotation.map(row=>row[axis].n)) as [bigint[],bigint[],bigint[]] };
    const columns = [0,1,2].map(axis=>rotation.map(row=>
      this.multiply(row[axis].n,this.quotient(denominator,row[axis].d)))) as [bigint[],bigint[],bigint[]];
    return { denominator, columns };
  }
  /** Relative coordinates are owned dyadics from unchanged from/sub calls. */
  localProjection(rotation: IntegerRotation, relative: Rational[]): RVec {
    this.guardCached();
    let denominator = 1n;
    for (const value of relative) if (value.d > denominator) denominator = value.d;
    const scaled = relative.map(value=>this.multiply(value.n,this.quotient(denominator,value.d)));
    const divisor = this.multiply(rotation.denominator,denominator);
    return rotation.columns.map(column=>{
      this.op();
      let numerator = this.multiply(column[0],scaled[0]);
      for (let i=1;i<3;i++) numerator = this.sum(numerator,this.multiply(column[i],scaled[i]));
      return this.normalizeChecked(numerator,divisor);
    }) as RVec;
  }
  /** Correct nearest-even conversion, including subnormals; no Number(BigInt)/Number(BigInt). */
  number(value: Rational): number {
    this.op();
    if (value.n === 0n) return 0;
    const negative = value.n < 0n, n = negative ? -value.n : value.n, d = value.d;
    let exponent = n.toString(2).length-d.toString(2).length;
    if (exponent >= 0 ? n < this.shifted(d,exponent) : this.shifted(n,-exponent) < d) exponent--;
    const unit = Math.max(-1074,exponent-52);
    const numerator = unit < 0 ? this.shifted(n,-unit) : n;
    const denominator = unit > 0 ? this.shifted(d,unit) : d;
    this.tick(2); let quotient = numerator/denominator; const remainder = numerator%denominator;
    const twice = this.shifted(remainder,1);
    if (twice > denominator || twice === denominator && (quotient & 1n) !== 0n) { this.tick(); quotient++; }
    const result = Number(quotient)*Math.pow(2,unit);
    if (!Number.isFinite(result)) throw new StrictLineFailure('rounded witness overflow');
    return negative ? -result : result;
  }
}

export interface ExactRatio { n: string; d: string }
export interface ExactSide {
  comM: ExactRatio[]; armM: ExactRatio[]; linearImpulseNs: ExactRatio[]; armTorqueNms: ExactRatio[];
}
export interface ExactPointApplication {
  id: string; aIndex: number; bIndex: number; pointM: ExactRatio[]; normalAtoB: ExactRatio[];
  lambdaNs: ExactRatio; onA: ExactSide; onB: ExactSide;
}
export interface ExactBodyAggregate {
  id: string; linearImpulseNs: ExactRatio[]; armTorqueNms: ExactRatio[];
  linearActionMps: ExactRatio[]; angularActionRadps: ExactRatio[];
  velocityMps: ExactRatio[]; angularVelocityRadps: ExactRatio[];
}
export interface ExactNormalResult {
  ok: true; status: 'EXACT_KKT_PHYSICAL_AGGREGATE'; representedRows: number[][];
  lambdaNs: ExactRatio[]; qpVelocity: ExactRatio[]; marginsMps: ExactRatio[];
  exactApplications: ExactPointApplication[]; bodyAggregates: ExactBodyAggregate[];
  appliedBodies: Body[];
  roundedReporting: { semantics: 'ROUNDED_REPORT_ONLY_NOT_BODY_MUTATION';
    normalImpulsesNs: number[]; qpBodies: NormalBody[] };
  certificate: { supportRows: number[]; exactRank: number; exactKkt: true;
    maxPhysicalTensorDifference: number; maxPhysicalQpVelocityDifference: number;
    maxRoundedPhysicalClosingMps: number; maxRoundedComplementarityJ: number };
  stats: StrictLineStats;
}
export class ExactNormalFailure extends Error {
  readonly code = 'NUMERIC_LIMIT';
  constructor(message: string, readonly stats: StrictLineStats) {
    super('exact normal: ' + message); this.name = 'ExactNormalFailure';
  }
}

/** The QR output proposes support only. Every accepted result has its own exact KKT proof. */
export function refineExactNormal(problem: NormalProblem, physicalBodies: readonly Body[],
  proposedImpulsesNs: readonly number[]): ExactNormalResult {
  const m = new Arithmetic();
  const refuse = (reason: string): never => { throw new ExactNormalFailure(reason, { ...m.counters }); };
  const need = (condition: unknown, reason: string): void => { if (!condition) refuse(reason); };
  const finite = (value: number): number => { need(Number.isFinite(value), 'finite represented arithmetic'); return value; };
  const add = (a: Rational[], b: Rational[]): Rational[] => a.map((x, i) => m.add(x, b[i]));
  const sub = (a: Rational[], b: Rational[]): Rational[] => a.map((x, i) => m.sub(x, b[i]));
  const scale = (a: Rational[], b: Rational): Rational[] => a.map(x => m.mul(x, b));
  const mv = (matrix: Rational[][], value: Rational[]): Rational[] => matrix.map(row => m.dot(row, value));
  const cross = (a: Rational[], b: Rational[]): Rational[] => [m.sub(m.mul(a[1], b[2]), m.mul(a[2], b[1])),
    m.sub(m.mul(a[2], b[0]), m.mul(a[0], b[2])), m.sub(m.mul(a[0], b[1]), m.mul(a[1], b[0]))];
  const crossFloat = (a: number[], b: readonly number[]): number[] => [finite(finite(a[1]*b[2])-finite(a[2]*b[1])),
    finite(finite(a[2]*b[0])-finite(a[0]*b[2])), finite(finite(a[0]*b[1])-finite(a[1]*b[0]))];
  let ratioBytes = 0;
  const encode = (value: Rational): ExactRatio => {
    m.guardCached(); const n = value.n.toString(), d = value.d.toString(); ratioBytes += n.length+d.length+20;
    need(ratioBytes <= 512*1024, 'exact ratio report admission'); return { n, d };
  };
  const encodeVec = (value: Rational[]): ExactRatio[] => value.map(encode);
  const tolerance = m.from(1e-10);
  const difference = (a: Rational, b: Rational): number => m.number(m.abs(m.sub(a, b)));
  const within = (value: Rational, reason: string): void => need(m.compare(m.abs(value), tolerance) <= 0, reason);
  try {
    need(Array.isArray(problem.bodies) && problem.bodies.length >= 1 && problem.bodies.length <= 4 &&
      Array.isArray(physicalBodies) && physicalBodies.length === problem.bodies.length &&
      Array.isArray(problem.points) && problem.points.length <= 32 &&
      Array.isArray(proposedImpulsesNs) && proposedImpulsesNs.length === problem.points.length, 'bounded populations');
    const ids = new Map<string, number>(), offsets = new Map<number, number>();
    const local: Rational[][] = [], orientations: Rational[][] = [], centers: Rational[][] = [];
    const free: Rational[] = [], metric: Rational[][] = [];
    let dof = 0;
    for (let i = 0; i < problem.bodies.length; i++) {
      const body = problem.bodies[i], actual = physicalBodies[i];
      need(body.id === actual.id && !ids.has(body.id), 'actual unique body order'); ids.set(body.id, i);
      for (const key of ['positionM', 'velocityMps', 'angularVelocityRadps'] as const)
        need(body[key].length === 3 && body[key].every((value, k) => Object.is(value, actual[key][k])), 'actual normal body words');
      need(Object.is(body.inverseMass, actual.inverseMass), 'actual inverse mass word');
      centers.push(m.vec(actual.positionM)); orientations.push(m.vec(actual.orientation, 4));
      local.push(m.vec(actual.inverseInertiaLocal));
      need(m.dot(orientations[i], orientations[i]).n > 0n, 'nonzero physical quaternion');
      need(body.inverseMass === 0 || body.inverseMass >= 1e-6 && body.inverseMass <= 1e6, 'inverse mass bound');
      need(body.inverseInertiaWorld.length === 3 && body.inverseInertiaWorld.every(row => row.length === 3 && row.every(Number.isFinite)), 'world tensor shape');
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
        need(Object.is(body.inverseInertiaWorld[r][c], body.inverseInertiaWorld[c][r]) ||
          body.inverseInertiaWorld[r][c] === body.inverseInertiaWorld[c][r], 'exact matrix symmetry');
      if (body.inverseMass === 0) {
        need([...body.velocityMps, ...body.angularVelocityRadps, ...body.inverseInertiaWorld.flat(), ...actual.inverseInertiaLocal].every(x => x === 0), 'prescribed static');
      } else {
        need(local[i].every(x => x.n > 0n), 'positive local physical inertia');
        offsets.set(i, dof); dof += 6; free.push(...m.vec(body.velocityMps), ...m.vec(body.angularVelocityRadps));
      }
    }
    need(dof > 0 && dof <= 24, 'dynamic degree bound');
    for (let i = 0; i < dof; i++) metric.push(Array<Rational>(dof).fill(ZERO));
    for (const [index, offset] of offsets) {
      const body = problem.bodies[index], tensor = body.inverseInertiaWorld.map(row => m.vec(row));
      const minor2 = m.sub(m.mul(tensor[0][0], tensor[1][1]), m.mul(tensor[0][1], tensor[0][1]));
      const determinant = m.dot(tensor[0], cross(tensor[1], tensor[2]));
      need(tensor[0][0].n > 0n && minor2.n > 0n && determinant.n > 0n, 'exact positive metric');
      for (let k = 0; k < 3; k++) {
        metric[offset+k][offset+k] = m.from(body.inverseMass);
        for (let j = 0; j < 3; j++) metric[offset+3+k][offset+3+j] = tensor[k][j];
      }
    }
    const pointIds = new Set<string>(), representedRows: number[][] = [];
    const rows = problem.points.map(point => {
      need(!pointIds.has(point.id) && ids.has(point.aId) && ids.has(point.bId) && point.aId !== point.bId, 'unique actual point links'); pointIds.add(point.id);
      need(point.pointM.length === 3 && point.normalAtoB.length === 3 &&
        [...point.pointM, ...point.normalAtoB].every(Number.isFinite), 'finite point operands');
      const row = Array<number>(dof).fill(0);
      let dynamic = false;
      for (const [id, sign] of [[point.aId, -1], [point.bId, 1]] as const) {
        const index = ids.get(id)!, offset = offsets.get(index), body = problem.bodies[index];
        const arm = point.pointM.map((value, k) => finite(value-body.positionM[k]));
        need(arm.every(value => Math.abs(value) <= 10), 'existing arm bound');
        if (offset === undefined) continue;
        dynamic = true;
        const torque = crossFloat(arm, point.normalAtoB);
        for (let k = 0; k < 3; k++) { row[offset+k] = finite(sign*point.normalAtoB[k]); row[offset+3+k] = finite(sign*torque[k]); }
      }
      need(dynamic, 'dynamic contact endpoint'); representedRows.push(row); return m.vec(row, dof);
    });
    const proposed = proposedImpulsesNs.map(value => { need(Number.isFinite(value) && value >= 0, 'nonnegative proposed support'); return m.from(value); });
    const support = proposed.flatMap((value, i) => value.n > 0n ? [i] : []);
    const gradients = rows.map(row => mv(metric, row));
    const marginsFree = rows.map(row => m.dot(row, free));
    const system = support.map(i => [...support.map(j => m.dot(rows[i], gradients[j])), m.neg(marginsFree[i])]);
    const pivots: number[] = [];
    let pivotRow = 0;
    for (let column = 0; column < support.length; column++) {
      const selected = system.findIndex((row, i) => i >= pivotRow && row[column].n !== 0n);
      if (selected < 0) continue;
      [system[pivotRow], system[selected]] = [system[selected], system[pivotRow]];
      const divisor = system[pivotRow][column]; system[pivotRow] = system[pivotRow].map(value => m.div(value, divisor));
      for (let row = 0; row < system.length; row++) if (row !== pivotRow && system[row][column].n !== 0n) {
        const factor = system[row][column]; system[row] = sub(system[row], scale(system[pivotRow], factor));
      }
      pivots.push(column); pivotRow++;
    }
    need(!system.some(row => row.slice(0, -1).every(value => value.n === 0n) && row.at(-1)!.n !== 0n), 'EXACT_KKT_NOT_PROVEN inconsistent support');
    const selectedDual = support.map(i => proposed[i]);
    for (let k = 0; k < pivots.length; k++) {
      let value = system[k].at(-1)!;
      for (let j = 0; j < support.length; j++) if (!pivots.includes(j)) value = m.sub(value, m.mul(system[k][j], selectedDual[j]));
      selectedDual[pivots[k]] = value;
    }
    const lambda = rows.map(() => ZERO); support.forEach((row, k) => { lambda[row] = selectedDual[k]; });
    need(lambda.every(value => value.n >= 0n), 'EXACT_KKT_NOT_PROVEN negative dual');
    let qpVelocity = [...free];
    for (let i = 0; i < rows.length; i++) if (lambda[i].n !== 0n) qpVelocity = add(qpVelocity, scale(gradients[i], lambda[i]));
    const margins = rows.map(row => m.dot(row, qpVelocity));
    need(margins.every((value, i) => value.n >= 0n && m.mul(value, lambda[i]).n === 0n), 'EXACT_KKT_NOT_PROVEN primal/complementarity');
    const rotate = (index: number, value: Rational[], backwards = false): Rational[] => {
      const [x, y, z, w] = orientations[index], norm = m.dot(orientations[index], orientations[index]);
      const twice = m.from(2), u = [x, y, z];
      // Quaternion action: ((w²-u·u)v + 2u(u·v) ± 2w(u×v))/||q||².
      const diagonal = m.sub(m.mul(w, w), m.dot(u, u));
      const axial = scale(u, m.mul(twice, m.dot(u, value)));
      const twist = scale(cross(u, value), m.mul(twice, backwards ? m.neg(w) : w));
      return add(add(scale(value, diagonal), axial), twist).map(entry => m.div(entry, norm));
    };
    const physicalAction = (index: number, value: Rational[]): Rational[] => {
      const diagonal = local[index];
      if (diagonal.every(entry => m.compare(entry, diagonal[0]) === 0)) return scale(value, diagonal[0]);
      return rotate(index, rotate(index, value, true).map((entry, k) => m.mul(entry, diagonal[k])));
    };
    const linear = physicalBodies.map(() => [ZERO, ZERO, ZERO]), angular = physicalBodies.map(() => [ZERO, ZERO, ZERO]);
    const exactApplications: ExactPointApplication[] = [];
    for (let p = 0; p < problem.points.length; p++) {
      const point = problem.points[p], ai = ids.get(point.aId)!, bi = ids.get(point.bId)!;
      const location = m.vec(point.pointM), normal = m.vec(point.normalAtoB), force = scale(normal, lambda[p]);
      const side = (index: number, sign: 1 | -1): ExactSide => {
        const arm = sub(location, centers[index]), impulse = sign === 1 ? force : force.map(value => m.neg(value));
        const torque = cross(arm, impulse);
        linear[index] = add(linear[index], impulse); angular[index] = add(angular[index], torque);
        return { comM: encodeVec(centers[index]), armM: encodeVec(arm), linearImpulseNs: encodeVec(impulse), armTorqueNms: encodeVec(torque) };
      };
      exactApplications.push({ id: point.id, aIndex: ai, bIndex: bi, pointM: encodeVec(location), normalAtoB: encodeVec(normal),
        lambdaNs: encode(lambda[p]), onA: side(ai, -1), onB: side(bi, 1) });
    }
    let maxTensor = 0, maxDifference = 0;
    const appliedBodies = physicalBodies.map(body => structuredClone(body)), aggregates: ExactBodyAggregate[] = [];
    const qpBodies: NormalBody[] = problem.bodies.map((body): NormalBody => ({ ...body, positionM: [...body.positionM], velocityMps: [...body.velocityMps],
      angularVelocityRadps: [...body.angularVelocityRadps], inverseInertiaWorld: body.inverseInertiaWorld.map(row => [...row]) as unknown as NormalBody['inverseInertiaWorld'] }));
    for (const [index, offset] of offsets) {
      for (let k = 0; k < 3; k++) {
        const basis = [ZERO, ZERO, ZERO]; basis[k] = m.from(1);
        const physicalColumn = physicalAction(index, basis);
        for (let j = 0; j < 3; j++) {
          const delta = m.sub(physicalColumn[j], metric[offset+3+j][offset+3+k]);
          within(delta, 'physical tensor versus represented tensor'); maxTensor = Math.max(maxTensor, m.number(m.abs(delta)));
        }
      }
      const body = physicalBodies[index], dv = scale(linear[index], m.from(body.inverseMass)), dw = physicalAction(index, angular[index]);
      const v = add(m.vec(body.velocityMps), dv), w = add(m.vec(body.angularVelocityRadps), dw);
      const round = (old: number, value: Rational, action: Rational): number => action.n === 0n ? old : m.number(value);
      appliedBodies[index].velocityMps = v.map((value, k) => round(body.velocityMps[k], value, dv[k])) as Vec3;
      appliedBodies[index].angularVelocityRadps = w.map((value, k) => round(body.angularVelocityRadps[k], value, dw[k])) as Vec3;
      qpBodies[index].velocityMps = qpVelocity.slice(offset, offset+3).map(value => m.number(value)) as Vec3;
      qpBodies[index].angularVelocityRadps = qpVelocity.slice(offset+3, offset+6).map(value => m.number(value)) as Vec3;
      for (let k = 0; k < 6; k++) {
        const delta = m.sub([...v, ...w][k], qpVelocity[offset+k]);
        within(delta, 'physical aggregate versus exact QP motion'); maxDifference = Math.max(maxDifference, difference([...v, ...w][k], qpVelocity[offset+k]));
      }
      aggregates.push({ id: body.id, linearImpulseNs: encodeVec(linear[index]), armTorqueNms: encodeVec(angular[index]),
        linearActionMps: encodeVec(dv), angularActionRadps: encodeVec(dw), velocityMps: encodeVec(v), angularVelocityRadps: encodeVec(w) });
    }
    let maxClosing = 0, maxComplementarity = 0;
    for (let p = 0; p < problem.points.length; p++) {
      const point = problem.points[p];
      const at = (id: string): Rational[] => {
        const index = ids.get(id)!, body = appliedBodies[index];
        return add(m.vec(body.velocityMps), cross(m.vec(body.angularVelocityRadps), sub(m.vec(point.pointM), centers[index])));
      };
      const speed = m.dot(sub(at(point.bId), at(point.aId)), m.vec(point.normalAtoB));
      need(m.compare(speed, m.neg(tolerance)) >= 0, 'rounded physical point closing');
      const complementarity = m.mul(speed, lambda[p]); within(complementarity, 'rounded physical complementarity');
      maxClosing = Math.max(maxClosing, speed.n < 0n ? m.number(m.neg(speed)) : 0);
      maxComplementarity = Math.max(maxComplementarity, m.number(m.abs(complementarity)));
    }
    const result: ExactNormalResult = { ok: true, status: 'EXACT_KKT_PHYSICAL_AGGREGATE', representedRows,
      lambdaNs: encodeVec(lambda), qpVelocity: encodeVec(qpVelocity), marginsMps: encodeVec(margins),
      exactApplications, bodyAggregates: aggregates, appliedBodies,
      roundedReporting: { semantics: 'ROUNDED_REPORT_ONLY_NOT_BODY_MUTATION', normalImpulsesNs: lambda.map(value => m.number(value)), qpBodies },
      certificate: { supportRows: support, exactRank: pivots.length, exactKkt: true, maxPhysicalTensorDifference: maxTensor,
        maxPhysicalQpVelocityDifference: maxDifference, maxRoundedPhysicalClosingMps: maxClosing, maxRoundedComplementarityJ: maxComplementarity },
      stats: { ...m.counters } };
    m.guardCached(); return result;
  } catch (error) {
    if (error instanceof StrictLineFailure) refuse(error.message);
    throw error;
  }
}

