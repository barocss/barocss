"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhysicsError = void 0;
var types_js_1 = require("./types.js");
Object.defineProperty(exports, "PhysicsError", { enumerable: true, get: function () { return types_js_1.PhysicsError; } });
