"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkedPhaseHit = checkedPhaseHit;
exports.isPhaseHit = isPhaseHit;
const types_js_1 = require("./types.js");
function record(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function vector(value) {
    return Array.isArray(value) && value.length === 3 && value.every(x => typeof x === 'number' && Number.isFinite(x));
}
function stringVector(value) {
    return Array.isArray(value) && value.length === 3 && value.every(x => typeof x === 'string');
}
function point(value) {
    return record(value) && typeof value.id === 'string' && vector(value.pointM) && vector(value.aPointM) && vector(value.bPointM) &&
        record(value.exact) && stringVector(value.exact.a) && stringVector(value.exact.b) && stringVector(value.exact.midpoint);
}
function box(value) {
    return record(value) && typeof value.id === 'string' && vector(value.positionM) && vector(value.halfExtentsM) &&
        Array.isArray(value.orientationXYZW) && value.orientationXYZW.length === 4 &&
        value.orientationXYZW.every(x => typeof x === 'number' && Number.isFinite(x));
}
function pair(value) {
    return record(value) && typeof value.id === 'string' && box(value.a) && box(value.b);
}
function hitResult(value) {
    return record(value) && value.status === 'HIT' && vector(value.normal) &&
        record(value.feature) && (value.feature.kind === 'FACE' || value.feature.kind === 'EDGE') &&
        Array.isArray(value.points) && value.points.length >= 1 && value.points.length <= 4 && value.points.every(point);
}
/** Validate the real unknown geometry boundary; return the same data objects. */
function checkedPhaseHit(normal, penetration, pointM, queryId, result, queryPair) {
    if (!vector(normal) || typeof penetration !== 'number' || !Number.isFinite(penetration) || penetration < 0 ||
        !vector(pointM) || typeof queryId !== 'number' || !Number.isSafeInteger(queryId) || queryId <= 0 ||
        !hitResult(result) || !pair(queryPair)) {
        throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'invalid typed private geometry-hit boundary');
    }
    return { normal, penetration, pointM, _phase: { queryId, result, pair: queryPair } };
}
function isPhaseHit(hit) {
    return '_phase' in hit && record(hit._phase) && hitResult(hit._phase.result) && pair(hit._phase.pair) &&
        typeof hit._phase.queryId === 'number' && Number.isSafeInteger(hit._phase.queryId) && hit._phase.queryId > 0;
}
