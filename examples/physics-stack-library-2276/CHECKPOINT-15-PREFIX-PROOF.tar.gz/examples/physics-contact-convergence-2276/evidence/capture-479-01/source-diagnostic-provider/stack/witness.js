import { add, sub, dot, scale, rotate } from '../math.js';
import { error } from '../validation.js';
export const WITNESS_MESSAGE = 'private feature contact requires valid box witnesses';
export const WITNESS_TOLERANCE_M = 1e-12;
export const DUPLICATE_TOLERANCE_M = 1e-12;
export const basis = (b) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map(v => rotate(b.orientation, v));
export const extents = (b) => b.shape.halfExtentsM;
export function unit(v) {
    const n = Math.hypot(...v);
    if (!Number.isFinite(n) || n < 1e-12)
        error('NUMERIC_LIMIT', WITNESS_MESSAGE);
    return scale(v, 1 / n);
}
export function point(key, a, b, n) {
    const gap = dot(sub(b, a), n);
    const result = { key, witnessAM: [...a], witnessBM: [...b],
        midpointM: scale(add(a, b), .5), normalGapM: gap, pointPenetrationM: Math.max(0, -gap) };
    if (globalThis.__contactWitness479?.armed) globalThis.__contactWitness479.lastPoint={key,a,b,normal:n,gap,result};
    if (![...a, ...b, ...result.midpointM, gap, result.pointPenetrationM].every(Number.isFinite)
        || gap > WITNESS_TOLERANCE_M) {
        if (globalThis.__contactWitness479?.armed) globalThis.__contactWitness479.pointFailure={site:'POINT_GAP_OR_NONFINITE',key,a,b,normal:n,gap,result};
        error('NUMERIC_LIMIT', WITNESS_MESSAGE);
    }
    return result;
}
