"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.snap = snap;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
function snap(position, candidate, context) {
    const down = context.sweep(position, [0, -profile_js_1.SNAP, 0], 'ground-probe', true), hit = down.hit;
    if (!hit || hit.normalFixtureToCapsule[1] < profile_js_1.WALKABLE) {
        candidate.grounded = false;
        candidate.support = null;
        return position;
    }
    const targetY = position[1] - profile_js_1.SNAP * hit.toiFraction + profile_js_1.SKIN / hit.normalFixtureToCapsule[1];
    const delta = [0, targetY - position[1], 0];
    let proof = down.indices;
    if (delta[1] > 0) {
        const up = context.sweep(position, delta, 'positive-snap-validation');
        if (up.hit)
            throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller positive snap is blocked');
        proof = up.indices;
    }
    const p = context.commit(position, delta, 'ground-snap', proof);
    candidate.grounded = true;
    candidate.support = { bodyId: hit.bodyId, normal: [...hit.normalFixtureToCapsule] };
    candidate.fallVelocityYMps = 0;
    candidate.assist = null;
    return p;
}
