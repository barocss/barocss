export { coupledContactTarget } from './candidate.js';
export { coupledStaticTarget } from '../C/candidate.js';
