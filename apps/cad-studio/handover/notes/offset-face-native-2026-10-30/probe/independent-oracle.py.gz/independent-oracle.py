# Prepared only; run after the source-bound baseline grant. No CAD imports.
import json, math
from fractions import Fraction as F
from pathlib import Path
P=Path('/tmp/d342-probe')
def q(x): return F.from_float(x) if isinstance(x,float) else F(x)
def emit(x): return {'numerator':str(x.numerator),'denominator':str(x.denominator),'value':float(x)}
def bounds(brep):
    points=[[q(x) for x in v['point']] for v in brep['vertices']]
    return [min(p[k] for p in points) for k in range(3)],[max(p[k] for p in points) for k in range(3)]
reports=[]
for case in json.loads((P/'results.json').read_text()):
    row={'name':case['name'],'status':case['status'],'inputRecipeUnchanged':case['inputRecipeUnchanged']}
    originals=case.get('inputNative',[]); outputs=case.get('outputNative',[])
    if case['expectedInput']['kind']=='right-box' and len(originals)==1:
        lo,hi=bounds(originals[0]['brep']); size=[hi[k]-lo[k] for k in range(3)]; end=hi[2]+q(case['expectedInput']['distance'])
        volume=size[0]*size[1]*(end-lo[2]); centroid=[(lo[0]+hi[0])/2,(lo[1]+hi[1])/2,(lo[2]+end)/2]
        row.update(originalNativeMin=list(map(emit,lo)),originalNativeMax=list(map(emit,hi)),originalExactDimensions=list(map(emit,size)),intendedVolume=emit(volume),intendedCentroid=list(map(emit,centroid)),intendedNewTop=emit(end))
        if len(outputs)==1:
            result=outputs[0]; actual=result.get('mass',{}).get('volume')
            row['actualNativeVolume']=actual
            if actual is not None: row['actualMinusIntendedVolume']=emit(q(actual)-volume)
            # Every boundary face of a right box, including split provenance patches, must lie on
            # one expected native support. Read topology vertices; no mesh fitting or production checks.
            expected=[(0,lo[0]),(0,hi[0]),(1,lo[1]),(1,hi[1]),(2,lo[2]),(2,end)]
            b=result['brep']; vertices={v['id']:[q(x) for x in v['point']] for v in b['vertices']}; edges={e['id']:e for e in b['edges']}; coedges={c['id']:c for c in b['coedges']}; loops={l['id']:l for l in b['loops']}
            supports=[]
            for face in b['faces']:
                ids=set()
                for lid in face['loops']:
                    for cid in loops[lid]['coedges']: ids.update(edges[coedges[cid]['edge']]['vertices'])
                points=[vertices[i] for i in ids]
                residuals=[max((abs(p[k]-value) for p in points),default=F(0)) for k,value in expected]
                best=min(residuals) if residuals else None
                supports.append({'name':face.get('name'),'id':face['id'],'vertexCount':len(points),'minimumExpectedSupportResidual':None if best is None else emit(best),'matchesOldTopExactly':bool(points) and all(p[2]==hi[2] for p in points)})
            row['outputFaceSupportResiduals']=supports
            row['allOutputFacesOnIntendedSupportWithinOriginal1eMinus7']=all(x['minimumExpectedSupportResidual'] and F(int(x['minimumExpectedSupportResidual']['numerator']),int(x['minimumExpectedSupportResidual']['denominator']))<=q(1e-7) for x in supports)
    elif case['expectedInput']['kind']=='cylinder-control':
        row['analyticRoundedVolumeGuide']=math.pi*case['expectedInput']['radius']**2*(case['expectedInput']['height']+case['expectedInput']['distance'])
        row['guideScope']='Analytic pi rounded by host; not exact rational circle certification'
    elif case['expectedInput']['kind']=='drafted-control' and len(originals)==1:
        b=originals[0]['brep']; points=[[q(x) for x in v['point']] for v in b['vertices']]; z0=min(p[2] for p in points); z1=max(p[2] for p in points)
        lower=[p for p in points if p[2]==z0]; upper=[p for p in points if p[2]==z1]
        lo0=[min(p[k] for p in lower) for k in range(2)]; hi0=[max(p[k] for p in lower) for k in range(2)]
        lo1=[min(p[k] for p in upper) for k in range(2)]; hi1=[max(p[k] for p in upper) for k in range(2)]
        slopesLo=[(lo1[k]-lo0[k])/(z1-z0) for k in range(2)]; slopesHi=[(hi1[k]-hi0[k])/(z1-z0) for k in range(2)]
        H=z1-z0+q(case['expectedInput']['distance']); widths=[hi0[k]-lo0[k] for k in range(2)]; slopes=[slopesHi[k]-slopesLo[k] for k in range(2)]
        # Exact integration of two linearly continued native side intervals, no trigonometry.
        a=widths[0]*widths[1]; bq=widths[0]*slopes[1]+widths[1]*slopes[0]; c=slopes[0]*slopes[1]
        volume=a*H+bq*H**2/2+c*H**3/3; zMoment=z0*volume+a*H**2/2+bq*H**3/3+c*H**4/4
        row.update(scope='Continuation of actual stored straight rectangular frustum side planes; not generic drafted-solid certification',intendedContinuedSideVolume=emit(volume),intendedNormalCentroid=emit(zMoment/volume),intendedNewTop=q(case['expectedInput']['distance'])+z1)
        row['intendedNewTop']=emit(row['intendedNewTop'])
        row['intendedNewTopMin']=[emit(lo0[k]+slopesLo[k]*H) for k in range(2)]; row['intendedNewTopMax']=[emit(hi0[k]+slopesHi[k]*H) for k in range(2)]
        if len(outputs)==1:
            actual=outputs[0]['mass'].get('volume'); row['actualNativeVolume']=actual
            if actual is not None: row['actualMinusContinuedSideVolume']=emit(q(actual)-volume)
            top=z0+H; resultPoints=[[q(x) for x in v['point']] for v in outputs[0]['brep']['vertices'] if q(v['point'][2])==top]
            row['actualTopVertices']=[[emit(x) for x in p] for p in resultPoints]
            row['actualTopVertexNearestContinuedSideResidual']=[emit(min(abs(p[k]-(lo0[k]+slopesLo[k]*H)) for k in range(2)) if not resultPoints else min([abs(p[k]-(lo0[k]+slopesLo[k]*H)) for k in range(2)]+[abs(p[k]-(hi0[k]+slopesHi[k]*H)) for k in range(2)])) for p in resultPoints]
    else: row['scope']='Missing native baseline input/output; no inferred pass' 
    reports.append(row)
(P/'independent-oracle.json').write_text(json.dumps(reports,indent=2)+'\n')
