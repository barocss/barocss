/** Private exact stationary-chain candidate. Not adopted by the normal bridge. */
import type { NormalBody, NormalProblem } from '../../packages/barocss-physics/src/stack/normal-solver.js';
type Q = {
    n: bigint;
    d: bigint;
};
type V = [Q, Q, Q];
type Six = [number, number, number, number, number, number];
export declare const STATIONARY_LIMITS: Readonly<{
    rationalOperations: 200000;
    integerOperations: 2000000;
    integerBits: 16384;
    triangleTrials: 32;
}>;
export type StationaryStatus = 'SOLVED_STATIONARY_WITNESS' | 'INVALID_INPUT' | 'UNSUPPORTED_PROFILE' | 'NO_WITNESS' | 'RESOURCE_LIMIT' | 'NUMERIC_LIMIT';
export interface StationaryStats {
    rationalOperations: number;
    integerOperations: number;
    peakIntegerBits: number;
    triangleTrials: number;
    interfacesProcessed: number;
}
export interface Ratio {
    n: string;
    d: string;
}
interface Endpoint {
    bodyId: string;
    coefficients: Six;
    words: string[];
}
export interface StationaryResult {
    ok: boolean;
    status: StationaryStatus;
    reason: string | null;
    bodies: readonly NormalBody[];
    normalImpulsesNs: number[] | null;
    exactApplied: null | {
        format: 'STATIONARY_FLOAT_J_RATIOS_V1';
        points: {
            id: string;
            a: Endpoint;
            b: Endpoint;
            lambda: Ratio;
            roundedWord: string;
        }[];
        dynamicResiduals: {
            bodyId: string;
            values: Ratio[];
        }[];
        allRowsPrimalZero: true;
        allRowsComplementarityZero: true;
        nonnegative: true;
    };
    roundedReconstruction: null | {
        maxVelocityErrorMps: number;
        maxAngularVelocityErrorRadps: number;
        maxUnscaledMassWeightedResidualSqrtJ: number;
    };
    stats: StationaryStats;
}
declare class Exact {
    readonly stats: StationaryStats;
    private ieee;
    op(): void;
    tick(): void;
    check(n: bigint): bigint;
    addI(a: bigint, b: bigint): bigint;
    mulI(a: bigint, b: bigint): bigint;
    divI(a: bigint, b: bigint): bigint;
    modI(a: bigint, b: bigint): bigint;
    negI(a: bigint): bigint;
    shift(a: bigint, b: number): bigint;
    private normalized;
    make(n: bigint, d?: bigint): Q;
    from(value: number): Q;
    add(a: Q, b: Q): Q;
    neg(a: Q): Q;
    sub(a: Q, b: Q): Q;
    mul(a: Q, b: Q): Q;
    div(a: Q, b: Q): Q;
    number(a: Q): number;
}
declare function triangle(m: Exact, columns: V[], rhs: V): Q[] | null;
declare function solveCore(raw: NormalProblem, count: 1 | 2 | 8): StationaryResult;
/** Sole production entry: no bridge or public World imports this candidate yet. */
export declare function solveStationaryNormal(problem: NormalProblem): StationaryResult;
export { solveCore as unitCore, Exact as UnitExact, triangle as unitTriangle };
