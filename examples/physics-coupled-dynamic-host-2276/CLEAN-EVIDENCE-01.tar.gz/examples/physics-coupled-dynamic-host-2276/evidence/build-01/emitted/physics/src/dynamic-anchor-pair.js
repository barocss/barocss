"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.solvePairMatrix = solvePairMatrix;
exports.applyPairAngle = applyPairAngle;
exports.projectDynamicPairAnchors = projectDynamicPairAnchors;
const limits_js_1 = require("./limits.js");
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
function solvePairMatrix(columns, target) {
    const rows = [0, 1, 2].map((row) => [columns[0][row], columns[1][row],
        columns[2][row], target[row]]);
    for (let column = 0; column < 3; column++) {
        let pivot = column;
        for (let row = column + 1; row < 3; row++) {
            if (Math.abs(rows[row][column]) > Math.abs(rows[pivot][column]))
                pivot = row;
        }
        if (!Number.isFinite(rows[pivot][column]) || Math.abs(rows[pivot][column]) < 1e-12) {
            (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic pair effective mass is singular');
        }
        [rows[column], rows[pivot]] = [rows[pivot], rows[column]];
        const divisor = rows[column][column];
        for (let index = column; index < 4; index++)
            rows[column][index] /= divisor;
        for (let row = 0; row < 3; row++) {
            if (row === column)
                continue;
            const factor = rows[row][column];
            for (let index = column; index < 4; index++)
                rows[row][index] -= factor * rows[column][index];
        }
    }
    const result = rows.map((row) => row[3]);
    if (result.some((value) => !Number.isFinite(value))) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic pair correction is not finite');
    }
    return result;
}
function applyPairAngle(body, angle, dt) {
    if (Math.hypot(...angle) > 1)
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic pair angular correction exceeds limit');
    body.orientation = (0, math_js_1.advanceOrientation)(body.orientation, angle, 1);
    body.angularVelocityRadps = (0, math_js_1.add)(body.angularVelocityRadps, (0, math_js_1.scale)(angle, 1 / dt));
}
/** Move two dynamic anchors together with equal and opposite generalized impulses. */
function projectDynamicPairAnchors(a, b, anchorA, anchorB, dt) {
    const armA = (0, math_js_1.rotate)(a.orientation, anchorA);
    const armB = (0, math_js_1.rotate)(b.orientation, anchorB);
    const separation = (0, math_js_1.sub)((0, math_js_1.worldPoint)(b, anchorB), (0, math_js_1.worldPoint)(a, anchorA));
    if (Math.hypot(...separation) > limits_js_1.MAX_STEP_DISPLACEMENT_M) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic pair anchor separation exceeds limit');
    }
    const basis = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    const columns = basis.map((axis) => (0, math_js_1.add)((0, math_js_1.scale)(axis, a.inverseMass + b.inverseMass), (0, math_js_1.add)((0, math_js_1.cross)((0, math_js_1.inverseInertia)(a, (0, math_js_1.cross)(armA, axis)), armA), (0, math_js_1.cross)((0, math_js_1.inverseInertia)(b, (0, math_js_1.cross)(armB, axis)), armB))));
    const correction = solvePairMatrix(columns, (0, math_js_1.scale)(separation, -1));
    const moveA = (0, math_js_1.scale)(correction, -a.inverseMass);
    const moveB = (0, math_js_1.scale)(correction, b.inverseMass);
    a.positionM = (0, math_js_1.add)(a.positionM, moveA);
    b.positionM = (0, math_js_1.add)(b.positionM, moveB);
    a.velocityMps = (0, math_js_1.add)(a.velocityMps, (0, math_js_1.scale)(moveA, 1 / dt));
    b.velocityMps = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.scale)(moveB, 1 / dt));
    applyPairAngle(a, (0, math_js_1.scale)((0, math_js_1.inverseInertia)(a, (0, math_js_1.cross)(armA, correction)), -1), dt);
    applyPairAngle(b, (0, math_js_1.inverseInertia)(b, (0, math_js_1.cross)(armB, correction)), dt);
}
