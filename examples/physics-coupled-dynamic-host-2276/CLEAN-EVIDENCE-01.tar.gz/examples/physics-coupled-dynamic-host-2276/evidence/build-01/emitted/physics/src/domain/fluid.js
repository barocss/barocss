"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeFluid = initializeFluid;
exports.prepareFluid = prepareFluid;
const types_js_1 = require("../types.js");
const pbf_js_1 = require("../fluid/pbf.js");
const kernel_js_1 = require("../fluid/kernel.js");
const diagnostics_js_1 = require("../fluid/diagnostics.js");
const boundary_js_1 = require("../fluid/boundary.js");
const static_box_js_1 = require("../fluid/static-box.js");
const constants_js_1 = require("../fluid/constants.js");
const types_js_2 = require("./types.js");
function copyFluidCandidateOutput(id, candidate) {
    return { id, positionsM: candidate.positions.slice(), velocitiesMps: candidate.velocities.slice(), diagnostics: { ...candidate.diagnostics } };
}
function initializeFluid(fluid, staticData) {
    const copied = (0, types_js_2.immutableCopy)({ fluid, staticData }), f = copied.fluid, data = copied.staticData;
    (0, types_js_2.invalid)(['fluid-basin-visual-v1', 'fluid-basin-xsph-visual-v1', 'fluid-static-box-visual-v1'].includes(data.profile), 'Unsupported fluid profile');
    (0, types_js_2.validateStatic)(data, f.staticColliderIds);
    (0, types_js_2.invalid)(f.massModel.kind === 'visual-unit-weights' && f.particleRadiusM === constants_js_1.FLUID_PARTICLE_RADIUS_M
        && f.smoothingRadiusM === constants_js_1.FLUID_SMOOTHING_RADIUS_M, 'Unsupported fluid mass or radii');
    const xsph = data.profile === 'fluid-basin-xsph-visual-v1', boxProfile = data.profile === 'fluid-static-box-visual-v1';
    (0, types_js_2.invalid)(xsph ? f.visualSmoothing.kind === 'xsph' && f.visualSmoothing.coefficient === 0.15 : f.visualSmoothing.kind === 'none', 'Unsupported smoothing');
    (0, types_js_2.invalid)(data.colliders.length === (boxProfile ? 2 : 1), 'Unsupported static fluid collider population');
    const basin = data.colliders.find(c => c.geometry.kind === 'box-interior');
    (0, types_js_2.invalid)(basin?.geometry.kind === 'box-interior', 'Fluid requires basin');
    const basinBody = data.bodies.find(b => b.id === basin.bodyId);
    (0, types_js_2.invalid)(basin.geometry.halfExtentsM.every((x, i) => x === constants_js_1.FLUID_BASIN_M[i] / 2)
        && basinBody.initial.positionM.every((x, i) => x === constants_js_1.FLUID_BASIN_M[i] / 2), 'Unsupported basin');
    const positions = (0, types_js_2.flat)(f.initialPositionsM, 256), velocities = (0, types_js_2.flat)(f.initialVelocitiesMps, 256);
    (0, types_js_2.invalid)(velocities.every(x => x === 0) && (0, boundary_js_1.insideBasin)(positions), 'Invalid initial fluid state');
    const minimumSquared = constants_js_1.FLUID_MIN_SPACING_M ** 2;
    for (let first = 0; first < 256; first++)
        for (let second = first + 1; second < 256; second++) {
            const dx = positions[first * 3] - positions[second * 3], dy = positions[first * 3 + 1] - positions[second * 3 + 1], dz = positions[first * 3 + 2] - positions[second * 3 + 2];
            (0, types_js_2.invalid)(dx * dx + dy * dy + dz * dz >= minimumSquared - 1e-12, 'Initial particles must be at least 0.025 m apart');
        }
    let staticBox = null;
    if (boxProfile) {
        const collider = data.colliders.find(c => c.geometry.kind === 'box');
        (0, types_js_2.invalid)(collider?.geometry.kind === 'box', 'Static fluid profile requires box');
        const body = data.bodies.find(b => b.id === collider.bodyId);
        staticBox = (0, static_box_js_1.inflatedBoxBounds)(body.initial.positionM, collider.geometry.halfExtentsM);
        (0, types_js_2.invalid)(staticBox.low.every((x, i) => x >= constants_js_1.FLUID_PARTICLE_RADIUS_M && staticBox.high[i] <= constants_js_1.FLUID_BASIN_M[i] - constants_js_1.FLUID_PARTICLE_RADIUS_M), 'Static box exceeds basin');
        (0, types_js_2.invalid)(!(0, static_box_js_1.insideStaticBox)(positions, staticBox), 'Static box overlaps initial particles');
    }
    const restDensity = (0, kernel_js_1.initialRestDensity)(positions);
    const definition = (0, types_js_2.immutableCopy)({ ...copied, restDensity, staticBox });
    const diagnostics = { ...(0, diagnostics_js_1.fluidDiagnostics)(positions, restDensity, 0), obstacleHits: 0 };
    return { definition, initial: { positions, velocities, diagnostics } };
}
function prepareFluid(definition, accepted) {
    const positions = accepted.positions.slice(), velocities = accepted.velocities.slice();
    const coefficient = definition.fluid.visualSmoothing.kind === 'xsph' ? definition.fluid.visualSmoothing.coefficient : 0;
    const solver = new pbf_js_1.PbfSolver(definition.restDensity, coefficient, definition.staticBox);
    const { boundaryHits, obstacleHits } = solver.step(positions, velocities);
    if (!(0, boundary_js_1.insideBasin)(positions) || !velocities.every(x => Number.isFinite(x) && Math.abs(x) <= 1000))
        throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'Fluid candidate exceeded numeric bounds');
    const measured = (0, diagnostics_js_1.fluidDiagnostics)(positions, definition.restDensity, boundaryHits);
    if (!Number.isFinite(measured.meanAbsoluteDensityError) || !Number.isFinite(measured.p95Compression))
        throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'Fluid candidate density is not finite');
    const candidate = { positions, velocities, diagnostics: { ...measured, obstacleHits } };
    const output = copyFluidCandidateOutput(definition.fluid.id, candidate);
    return { candidate, output };
}
