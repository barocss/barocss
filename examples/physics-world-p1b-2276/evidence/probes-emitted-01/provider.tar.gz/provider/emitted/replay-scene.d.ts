import type { PhysicsModel, WorldOptions } from './types.js';
import type { PhysicsSceneV1 } from './replay-types.js';
export declare function admitPhysicsScene(value: unknown): PhysicsSceneV1;
export declare function createPhysicsScene(model: PhysicsModel, options: WorldOptions, revisions: {
    revision: string;
    sourceRevision: string | null;
}): PhysicsSceneV1;
