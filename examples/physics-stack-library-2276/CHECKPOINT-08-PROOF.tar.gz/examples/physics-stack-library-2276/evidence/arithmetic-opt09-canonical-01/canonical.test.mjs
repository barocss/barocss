// Fixed32 independent dot controls; actual Arithmetic, no counters/prototypes changed.
import assert from 'node:assert/strict';
import test from 'node:test';
import { pathToFileURL } from 'node:url';
import { parseBody } from 'file:///Users/user/Documents/ChatGPT/barocss-physics-motion-2276/examples/physics-stack-library-2276/evidence/canonical-opt09-01/canonical-provider/dist/validation.js';
import { StrictLineContext, StrictLineFailure, STRICT_LINE_LIMITS } from 'file:///Users/user/Documents/ChatGPT/barocss-physics-motion-2276/examples/physics-stack-library-2276/evidence/canonical-opt09-01/canonical-provider/dist/stack/strict-line.js';
const current = { StrictLineContext, StrictLineFailure, STRICT_LINE_LIMITS }, ZERO = { n: 0n, d: 1n }, r = (n, d = 1n) => ({ n, d });
async function baseline() { assert.ok(process.env.STRICT_LINE_BASELINE_MODULE); return import(pathToFileURL(process.env.STRICT_LINE_BASELINE_MODULE).href); }
function box(id) { return parseBody({ id, kind: 'dynamic', shape: { kind: 'box', halfExtentsM: [1, 1, 1] }, positionM: [0, 0, 0], orientation: [0, 0, 0, 1], velocityMps: [0, 0, 0], massKg: 1, restitution: 0 }); }
function context(api) { return new api.StrictLineContext(box('a'), box('b'), [0, 1, 0]); }
function arithmetic(api) { const seed = context(api).m, Constructor = Object.getPrototypeOf(seed).constructor, m = new Constructor(); assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 }); return m; }
function refusal(api, call, message) { assert.throws(call, (e) => e instanceof api.StrictLineFailure && e.message === message); }
function outcome(call) { try {
    return { value: call() };
}
catch (e) {
    return { error: { name: e.name, message: e.message } };
} }
function word(v) { const b = Buffer.alloc(8); b.writeDoubleBE(v); return b.toString('hex'); }
async function exact(a, b, n, d, savedInteger, savedRational = savedInteger ? 1 : 0) { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api), before = structuredClone([a, b]);
    assert.deepEqual(m.dot(a, b), { n, d });
    assert.deepEqual([a, b], before);
    receipts.push({ ...m.counters });
} assert.equal(receipts[1].rationalOperations - receipts[0].rationalOperations, savedRational); assert.equal(receipts[1].integerOperations - receipts[0].integerOperations, savedInteger); assert.equal(receipts[0].peakIntegerBits, receipts[1].peakIntegerBits); return receipts; }
test('01 empty array ignores even null second input', async () => { const old = await baseline(); for (const api of [current, old]) {
    const m = arithmetic(api);
    assert.deepEqual(m.dot([], null), ZERO);
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 });
} });
test('02 all holes preserve empty native reduce behavior', async () => { const old = await baseline(); for (const api of [current, old]) {
    const m = arithmetic(api);
    assert.deepEqual(m.dot(Array(4), null), ZERO);
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 });
} });
test('03 leading holes use first present index not index zero', async () => { const a = Array(4), b = Array(4); a[2] = r(2n, 3n); b[2] = r(3n, 5n); const receipts = await exact(a, b, 2n, 5n, 12); assert.deepEqual(receipts[0], { rationalOperations: 1, integerOperations: 9, peakIntegerBits: 4 }); });
for (const [name, a, b, n, d, newTicks, oldTicks, peak] of [
    ['04 zero product retains old initial add', r(0n, -2n), r(3n, 5n), 0n, 1n, 3, 3, 4],
    ['05 integer product retains old initial add', r(2n), r(3n), 6n, 1n, 3, 3, 3],
    ['06 negative integer retains old initial add', r(-2n), r(3n), -6n, 1n, 3, 3, 3],
    ['07 dyadic first product skips only redundant normalization', r(1n, 2n), r(1n, 2n), 1n, 4n, 8, 19, 3],
    ['08 negative dyadic first product', r(-1n, 2n), r(1n, 2n), -1n, 4n, 8, 19, 3],
    ['09 nonbinary first product', r(2n, 3n), r(3n, 5n), 2n, 5n, 9, 21, 4],
    ['10 nonreduced inputs normalized by actual mul', r(6n, 8n), r(10n, 15n), 1n, 2n, 8, 19, 7],
    ['11 both raw denominators negative', r(2n, -3n), r(3n, -5n), 2n, 5n, 9, 21, 4],
    ['12 one raw denominator negative', r(2n, 3n), r(3n, -5n), -2n, 5n, 11, 23, 4]
])
    test(name, async () => { const receipts = await exact([a], [b], n, d, oldTicks - newTicks); assert.equal(receipts[0].integerOperations, newTicks); assert.equal(receipts[1].integerOperations, oldTicks); assert.equal(receipts[0].rationalOperations, newTicks === oldTicks ? 2 : 1); assert.equal(receipts[1].rationalOperations, 2); assert.equal(receipts[0].peakIntegerBits, peak); });
test('13 exact three-term cancellation keeps later add order', async () => { await exact([r(1n, 2n), r(1n, 3n), r(1n, 6n)], [r(1n), r(1n), r(-5n)], 0n, 1n, 11); });
test('14 independent four-term fraction', async () => { await exact([r(1n, 2n), r(1n, 3n), r(1n, 4n), r(1n, 5n)], [r(1n), r(2n), r(3n), r(4n)], 163n, 60n, 11); });
test('15 zero first term does not skip later nonunit add', async () => { const receipts = await exact([r(0n), r(1n, 3n)], [r(1n), r(1n)], 1n, 3n, 0); assert.deepEqual(receipts[0], receipts[1]); });
test('16 integer first term does not skip later nonunit add', async () => { const receipts = await exact([r(2n), r(1n, 3n)], [r(3n), r(1n)], 19n, 3n, 0); assert.deepEqual(receipts[0], receipts[1]); });
test('17 interior and trailing holes retain original index pairing', async () => { const a = Array(8), b = Array(8); a[3] = r(2n, 3n); b[3] = r(3n, 5n); a[6] = r(1n, 2n); b[6] = r(1n); await exact(a, b, 9n, 10n, 12); });
test('18 original identity fixture constructor stats stay exactly old', async () => { const old = await baseline(), a = context(current), b = context(old); assert.deepEqual(a.stats(), b.stats()); assert.deepEqual(a.check([0, 0, 0]), b.check([0, 0, 0])); });
test('19 null left input fails before any rational work', async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api), result = outcome(() => m.dot(null, []));
    assert.equal(result.error?.name, 'TypeError');
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 });
    receipts.push(result);
} assert.deepEqual(receipts[0], receipts[1]); });
for (const [name, a, b] of [['20 null first term', [null], [r(1n)]], ['21 missing second operand', [r(1n)], []]])
    test(name, async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
        const m = arithmetic(api), result = outcome(() => m.dot(a, b));
        assert.equal(result.error?.name, 'TypeError');
        assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 0, peakIntegerBits: 0 });
        receipts.push(result);
    } assert.deepEqual(receipts[0], receipts[1]); });
test('22 zero denominator refuses inside first product before any add', async () => { const old = await baseline(); for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.dot([r(0n, 0n)], [r(1n)]), 'zero rational denominator');
    assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 2, peakIntegerBits: 1 });
} });
test('23 oversized first numerator precedes invalid denominator', async () => { const old = await baseline(), p = 1n << 8192n; for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.dot([r(p, 0n)], [r(p)]), 'integer bit limit');
    assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 1, peakIntegerBits: 16385 });
} });
test('24 oversized first denominator precedes zero shortcut', async () => { const old = await baseline(), p = 1n << 8192n; for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.dot([r(0n, p)], [r(1n, p)]), 'integer bit limit');
    assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 2, peakIntegerBits: 16385 });
} });
test('25 later malformed term keeps product order and error with saved work', async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api), result = outcome(() => m.dot([r(2n, 3n), r(1n)], [r(3n, 5n)]));
    assert.equal(result.error?.name, 'TypeError');
    receipts.push({ result, stats: { ...m.counters } });
} assert.deepEqual(receipts[0].result, receipts[1].result); assert.deepEqual(receipts[0].stats, { rationalOperations: 2, integerOperations: 9, peakIntegerBits: 4 }); assert.deepEqual(receipts[1].stats, { rationalOperations: 3, integerOperations: 21, peakIntegerBits: 4 }); });
test('26 literal nearest-even and signed-underflow word bank', async () => { const old = await baseline(), D = 1n << 53n; for (const [n, d, expected] of [[D + 1n, D, '3ff0000000000000'], [D + 3n, D, '3ff0000000000002'], [1n, 1n << 1074n, '0000000000000001'], [-1n, 1n << 1075n, '8000000000000000'], [1n, 1n << 1075n, '0000000000000000']]) {
    const receipts = [];
    for (const api of [current, old]) {
        const m = arithmetic(api);
        assert.equal(word(m.number(m.dot([r(n, d)], [r(1n)]))), expected);
        receipts.push({ ...m.counters });
    }
    assert.equal(receipts[1].rationalOperations - receipts[0].rationalOperations, 1);
    assert.equal(receipts[1].integerOperations - receipts[0].integerOperations, 11);
    assert.equal(receipts[0].peakIntegerBits, receipts[1].peakIntegerBits);
} });
test('27 old stale-bit empty zero integer and nonunit behavior', async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.checked(1n << 16384n), 'integer bit limit');
    const before = { ...m.counters };
    assert.deepEqual(m.dot([], []), ZERO);
    assert.deepEqual(m.counters, before);
    assert.deepEqual(m.dot([r(0n)], [r(1n)]), ZERO);
    refusal(api, () => m.dot([r(1n)], [r(1n)]), 'integer bit limit');
    assert.deepEqual(m.dot([r(1n, 3n)], [r(1n)]), r(1n, 3n));
    assert.equal(m.counters.peakIntegerBits, 16385);
    receipts.push({ ...m.counters });
} assert.equal(receipts[1].rationalOperations - receipts[0].rationalOperations, 1); assert.equal(receipts[1].integerOperations - receipts[0].integerOperations, 11); assert.equal(receipts[0].peakIntegerBits, receipts[1].peakIntegerBits); });
test('28 actual prior rational exhaustion still stops first mul', async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api);
    for (let i = 0; i < 200000; i++)
        m.neg(ZERO);
    refusal(api, () => m.neg(ZERO), 'rational work limit');
    const before = { ...m.counters };
    assert.deepEqual(m.dot([], []), ZERO);
    assert.deepEqual(m.counters, before);
    refusal(api, () => m.dot([r(1n, 3n)], [r(1n)]), 'rational work limit');
    receipts.push({ ...m.counters });
} assert.deepEqual(receipts[0], receipts[1]); });
test('29 actual prior integer exhaustion still stops first multiply tick', async () => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api);
    for (let i = 0; i < 142857; i++)
        m.make(55n, 89n);
    refusal(api, () => m.make(55n, 89n), 'integer work limit');
    const before = { ...m.counters };
    assert.deepEqual(m.dot(Array(2), []), ZERO);
    assert.deepEqual(m.counters, before);
    refusal(api, () => m.dot([r(1n, 3n)], [r(1n)]), 'integer work limit');
    receipts.push({ ...m.counters });
} assert.deepEqual(receipts[0], receipts[1]); assert.equal(receipts[0].integerOperations, 2000002); });
test('30 one remaining rational op admits only removed-nonunit-add path', async (t) => { const old = await baseline(), receipts = []; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api);
    for (let i = 0; i < 199999; i++)
        m.neg(ZERO);
    if (candidate)
        assert.deepEqual(m.dot([r(1n, 3n)], [r(1n)]), r(1n, 3n));
    else
        refusal(api, () => m.dot([r(1n, 3n)], [r(1n)]), 'rational work limit');
    assert.equal(m.counters.rationalOperations, candidate ? 200000 : 200001);
    assert.equal(m.counters.integerOperations, 200007);
    receipts.push({ ...m.counters });
} t.diagnostic(JSON.stringify({ actualRationalAdmissionDifference: receipts, unchangedCap: 200000 })); });
function prefill(m, padding) { for (let i = 0; i < 142856; i++)
    m.make(55n, 89n); for (let i = 0; i < padding; i++)
    m.neg(ZERO); assert.equal(m.counters.integerOperations, 1999984 + padding); }
test('31 exactly eight integer ticks admit first nonunit product only', async (t) => { const old = await baseline(), receipts = []; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api);
    prefill(m, 8);
    if (candidate)
        assert.deepEqual(m.dot([r(1n, 3n)], [r(1n)]), r(1n, 3n));
    else
        refusal(api, () => m.dot([r(1n, 3n)], [r(1n)]), 'integer work limit');
    assert.deepEqual(m.counters, { rationalOperations: candidate ? 9 : 10, integerOperations: candidate ? 2000000 : 2000001, peakIntegerBits: 7 });
    receipts.push({ ...m.counters });
} t.diagnostic(JSON.stringify({ actualIntegerAdmissionDifference: receipts, unchangedCap: 2000000 })); });
test('32 first-product refusal and zero/integer initial-add guards stay old', async (t) => { const old = await baseline(), receipts = []; for (const api of [current, old]) {
    const m = arithmetic(api);
    prefill(m, 9);
    refusal(api, () => m.dot([r(1n, 3n)], [r(1n)]), 'integer work limit');
    assert.deepEqual(m.counters, { rationalOperations: 10, integerOperations: 2000001, peakIntegerBits: 7 });
    receipts.push({ ...m.counters });
} assert.deepEqual(receipts[0], receipts[1]); for (const n of [0n, 1n])
    for (const api of [current, old]) {
        const m = arithmetic(api);
        for (let i = 0; i < 142857; i++)
            m.make(55n, 89n);
        refusal(api, () => m.dot([r(n)], [r(1n)]), 'integer work limit');
        assert.deepEqual(m.counters, { rationalOperations: 2, integerOperations: 2000001, peakIntegerBits: 7 });
    } t.diagnostic(JSON.stringify({ sameProductRefusal: receipts[0], cheapInitialAddRetained: true, noCounterMutation: true })); });
