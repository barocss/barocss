export type Vec = [number, number, number];
export interface Box {
    id: string;
    positionM: Vec;
    orientationXYZW: [number, number, number, number];
    halfExtentsM: Vec;
}
export interface Pair {
    id: string;
    a: Box;
    b: Box;
}
export declare function quantizedContact(pair: Pair): unknown;
