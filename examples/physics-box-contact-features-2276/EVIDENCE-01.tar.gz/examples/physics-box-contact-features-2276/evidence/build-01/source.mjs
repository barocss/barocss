// examples/physics-box-contact-features-2276/candidate.ts
var Unresolved = class extends Error {
};
var BIT_LIMIT = 16384;
var Z = { n: 0n, d: 1n };
var O = { n: 1n, d: 1n };
var bits = (x) => (x < 0n ? -x : x).toString(2).length;
function check(x) {
  if (bits(x) > BIT_LIMIT) throw new Unresolved("EXACT_BIT_LIMIT");
  return x;
}
function product(a, b) {
  if (a !== 0n && b !== 0n && bits(a) + bits(b) > BIT_LIMIT) throw new Unresolved("EXACT_PRODUCT_BIT_LIMIT");
  return check(a * b);
}
function q(n, d = 1n) {
  if (d === 0n) throw new Unresolved("ZERO_EXACT_DENOMINATOR");
  if (n === 0n) return Z;
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  check(n);
  check(d);
  let a = n < 0n ? -n : n, b = d;
  while (b !== 0n) {
    const next = a % b;
    a = b;
    b = next;
  }
  return { n: n / a, d: d / a };
}
var neg = (a) => ({ n: -a.n, d: a.d });
var plus = (a, b) => q(check(product(a.n, b.d) + product(b.n, a.d)), product(a.d, b.d));
var minus = (a, b) => plus(a, neg(b));
var times = (a, b) => q(product(a.n, b.n), product(a.d, b.d));
var over = (a, b) => q(product(a.n, b.d), product(a.d, b.n));
var compare = (a, b) => {
  const d = minus(a, b).n;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var absolute = (a) => a.n < 0n ? neg(a) : a;
function word(value) {
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_INPUT");
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false), e = Number(raw >> 52n & 2047n);
  const m = (raw & 0xfffffffffffffn | (e ? 0x10000000000000n : 0n)) * (raw >> 63n ? -1n : 1n);
  const power = e ? e - 1075 : -1074;
  return power < 0 ? q(m, 1n << BigInt(-power)) : q(m << BigInt(power));
}
function numeric(a) {
  const n = a.n < 0n ? -a.n : a.n;
  if (!n) return 0;
  const ns = Math.max(0, bits(n) - 53), ds = Math.max(0, bits(a.d) - 53);
  const value = Number(n >> BigInt(ns)) / Number(a.d >> BigInt(ds)) * 2 ** (ns - ds);
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_OUTPUT");
  return a.n < 0n ? -value : value;
}
var vector = (a) => a.map(word);
var vplus = (a, b) => a.map((x, i) => plus(x, b[i]));
var vminus = (a, b) => a.map((x, i) => minus(x, b[i]));
var vscale = (a, t) => a.map((x) => times(x, t));
var dot = (a, b) => a.reduce((s, x, i) => plus(s, times(x, b[i])), Z);
var cross = (a, b) => [
  minus(times(a[1], b[2]), times(a[2], b[1])),
  minus(times(a[2], b[0]), times(a[0], b[2])),
  minus(times(a[0], b[1]), times(a[1], b[0]))
];
var numberVector = (a) => a.map(numeric);
var same = (a, b) => a.every((x, i) => compare(x, b[i]) === 0);
function native(box) {
  if (box.positionM.length !== 3 || box.halfExtentsM.length !== 3 || box.orientationXYZW.length !== 4 || box.positionM.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1e4) || box.halfExtentsM.some((x2) => !Number.isFinite(x2) || x2 < 1e-4 || x2 > 1e3) || box.orientationXYZW.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1) || Math.abs(Math.hypot(...box.orientationXYZW) - 1) > 1e-9) throw new Unresolved("OUTSIDE_NATIVE_INPUT_PROFILE");
  const [x, y, z, w] = box.orientationXYZW.map(word);
  const s = plus(plus(times(x, x), times(y, y)), plus(times(z, z), times(w, w))), two = word(2);
  if (s.n === 0n) throw new Unresolved("ZERO_QUATERNION");
  const rows = [
    [minus(s, times(two, plus(times(y, y), times(z, z)))), times(two, minus(times(x, y), times(z, w))), times(two, plus(times(x, z), times(y, w)))],
    [times(two, plus(times(x, y), times(z, w))), minus(s, times(two, plus(times(x, x), times(z, z)))), times(two, minus(times(y, z), times(x, w)))],
    [times(two, minus(times(x, z), times(y, w))), times(two, plus(times(y, z), times(x, w))), minus(s, times(two, plus(times(x, x), times(y, y))))]
  ];
  return {
    box,
    centre: vector(box.positionM),
    half: vector(box.halfExtentsM),
    axes: [0, 1, 2].map((i) => rows.map((row) => over(row[i], s)))
  };
}
var addN = (a, b) => a.map((x, i) => x + b[i]);
var subN = (a, b) => a.map((x, i) => x - b[i]);
var scaleN = (a, s) => a.map((x) => x * s);
var dotN = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
var crossN = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
function rawAxes(box) {
  const axis = box.orientationXYZW.slice(0, 3), w = box.orientationXYZW[3];
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((v) => {
    const t = scaleN(crossN(axis, v), 2);
    return addN(v, addN(scaleN(t, w), crossN(axis, t)));
  });
}
function select(pair, counts) {
  const aa = rawAxes(pair.a), bb = rawAxes(pair.b), delta = subN(pair.b.positionM, pair.a.positionM);
  const axes = [...aa, ...bb, ...aa.flatMap((a) => bb.map((b) => crossN(a, b)))];
  let selected = null;
  for (let index = 0; index < 15; index++) {
    counts.axisVisits++;
    const length = Math.hypot(...axes[index]);
    if (length < 1e-12) continue;
    const axis = scaleN(axes[index], 1 / length);
    const ra = aa.reduce((sum, basis, i) => sum + pair.a.halfExtentsM[i] * Math.abs(dotN(basis, axis)), 0);
    const rb = bb.reduce((sum, basis, i) => sum + pair.b.halfExtentsM[i] * Math.abs(dotN(basis, axis)), 0);
    const distance = dotN(delta, axis), overlap = ra + rb - Math.abs(distance);
    if (!Number.isFinite(overlap)) throw new Unresolved("NONFINITE_SAT");
    if (overlap < -1e-12) return null;
    if (!selected || overlap < selected.overlap) {
      const feature = index < 6 ? { kind: "FACE", owner: index < 3 ? "a" : "b", axis: index % 3, index } : { kind: "EDGE", axisA: Math.floor((index - 6) / 3), axisB: (index - 6) % 3, index };
      selected = { feature, overlap, normal: scaleN(axis, distance < 0 ? -1 : 1) };
    }
  }
  if (!selected) throw new Unresolved("NO_SAT_AXIS");
  return selected;
}
function inside(body, p) {
  const delta = vminus(p, body.centre);
  return body.axes.every((axis, i) => compare(absolute(dot(delta, axis)), body.half[i]) <= 0);
}
function certificate(a, b, p, r, normal) {
  if (!inside(a, p) || !inside(b, r)) throw new Unresolved("NATIVE_TWELVE_HALFSPACE_FAILURE");
  if (cross(vminus(r, p), normal).some((x) => x.n !== 0n)) throw new Unresolved("NONPARALLEL_NATIVE_WITNESSES");
  return { a: p, b: r, midpoint: vscale(vplus(p, r), over(O, word(2))) };
}
function clip(polygon, centre, axis, half) {
  const result = [];
  for (let i = 0; i < polygon.length; i++) {
    const current = polygon[i], next = polygon[(i + 1) % polygon.length];
    const a = minus(dot(vminus(current, centre), axis), half), b = minus(dot(vminus(next, centre), axis), half);
    if (a.n <= 0n) result.push(current);
    if (a.n <= 0n !== b.n <= 0n) {
      const t = over(a, minus(a, b));
      if (compare(t, Z) < 0 || compare(t, O) > 0) throw new Unresolved("CLIP_EXTRAPOLATION");
      result.push(vplus(current, vscale(vminus(next, current), t)));
    }
  }
  return result.filter((point, i) => result.findIndex((other) => same(point, other)) === i);
}
function face(a, b, selected, feature) {
  const reference = feature.owner === "a" ? a : b, incident = feature.owner === "a" ? b : a;
  const towardIncident = feature.owner === "a" ? selected.normal : scaleN(selected.normal, -1);
  const side = dotN(numberVector(reference.axes[feature.axis]), towardIncident) < 0 ? -1 : 1;
  const n = vscale(reference.axes[feature.axis], word(side));
  const normal = feature.owner === "a" ? n : vscale(n, word(-1));
  const centre = vplus(reference.centre, vscale(n, reference.half[feature.axis]));
  let incidentAxis = 0;
  for (let i = 1; i < 3; i++) if (compare(absolute(dot(incident.axes[i], n)), absolute(dot(incident.axes[incidentAxis], n))) > 0) incidentAxis = i;
  const incidentSide = dot(incident.axes[incidentAxis], n).n > 0n ? -1 : 1;
  const incidentCentre = vplus(incident.centre, vscale(incident.axes[incidentAxis], times(word(incidentSide), incident.half[incidentAxis])));
  const tangents = [0, 1, 2].filter((i) => i !== incidentAxis);
  let polygon = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => vplus(
    vplus(incidentCentre, vscale(incident.axes[tangents[0]], times(word(u), incident.half[tangents[0]]))),
    vscale(incident.axes[tangents[1]], times(word(v), incident.half[tangents[1]]))
  ));
  const referenceTangents = [0, 1, 2].filter((i) => i !== feature.axis);
  for (const i of referenceTangents) {
    polygon = clip(polygon, centre, reference.axes[i], reference.half[i]);
    polygon = clip(polygon, centre, vscale(reference.axes[i], word(-1)), reference.half[i]);
  }
  if (!polygon.length) throw new Unresolved("EMPTY_NATIVE_FACE_PATCH");
  const candidates = polygon.map((p) => ({ p, separation: dot(vminus(p, centre), n) }));
  const penetrating = candidates.filter((x) => x.separation.n <= 0n);
  const minimum = candidates.reduce((best, x) => compare(x.separation, best.separation) < 0 ? x : best);
  const active = penetrating.length ? penetrating : candidates.filter((x) => compare(x.separation, minimum.separation) === 0);
  let points = active.map(({ p, separation }) => {
    const referencePoint = vminus(p, vscale(n, separation));
    return feature.owner === "a" ? certificate(a, b, referencePoint, p, normal) : certificate(a, b, p, referencePoint, normal);
  });
  if (points.length > 4) points = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => points.reduce((best, point) => {
    const score = (x) => plus(
      times(word(u), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[0]])),
      times(word(v), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[1]]))
    );
    return compare(score(point), score(best)) > 0 ? point : best;
  }));
  points = points.filter((point, i) => points.findIndex((other) => same(point.midpoint, other.midpoint)) === i);
  points.sort((p, r) => compare(dot(p.midpoint, reference.axes[referenceTangents[0]]), dot(r.midpoint, reference.axes[referenceTangents[0]])) || compare(dot(p.midpoint, reference.axes[referenceTangents[1]]), dot(r.midpoint, reference.axes[referenceTangents[1]])));
  return { normal, points };
}
function supportEdge(body, axis, direction) {
  let centre = body.centre;
  for (let i = 0; i < 3; i++) if (i !== axis) {
    const sign = dot(body.axes[i], direction).n < 0n ? -1 : 1;
    centre = vplus(centre, vscale(body.axes[i], times(word(sign), body.half[i])));
  }
  const extent = vscale(body.axes[axis], body.half[axis]);
  return [vminus(centre, extent), vplus(centre, extent)];
}
var clamp = (x) => compare(x, Z) < 0 ? Z : compare(x, O) > 0 ? O : x;
function edge(a, b, selected, feature) {
  let normal = cross(a.axes[feature.axisA], b.axes[feature.axisB]);
  if (dot(normal, normal).n === 0n) throw new Unresolved("ZERO_NATIVE_EDGE_AXIS");
  if (dotN(numberVector(normal), selected.normal) < 0) normal = vscale(normal, word(-1));
  const [p, p1] = supportEdge(a, feature.axisA, normal), [r, r1] = supportEdge(b, feature.axisB, vscale(normal, word(-1)));
  const u = vminus(p1, p), v = vminus(r1, r), w = vminus(p, r);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v), dd = dot(u, w), ee = dot(v, w);
  const determinant = minus(times(aa, cc), times(bb, bb));
  const parameters = [];
  if (determinant.n > 0n) {
    const s = over(minus(times(bb, ee), times(cc, dd)), determinant);
    const t = over(minus(times(aa, ee), times(bb, dd)), determinant);
    if (compare(s, Z) >= 0 && compare(s, O) <= 0 && compare(t, Z) >= 0 && compare(t, O) <= 0) parameters.push([s, t]);
  }
  for (const s of [Z, O]) parameters.push([s, clamp(over(plus(ee, times(bb, s)), cc))]);
  for (const t of [Z, O]) parameters.push([clamp(over(minus(times(bb, t), dd), aa)), t]);
  const pairs = parameters.map(([s, t]) => ({ a: vplus(p, vscale(u, s)), b: vplus(r, vscale(v, t)) }));
  const best = pairs.reduce((old, x) => compare(dot(vminus(x.b, x.a), vminus(x.b, x.a)), dot(vminus(old.b, old.a), vminus(old.b, old.a))) < 0 ? x : old);
  return { normal, points: [certificate(a, b, best.a, best.b, normal)] };
}
var encoded = (a) => a.map((x) => `${x.n}/${x.d}`);
function boxContact(pair) {
  let selected = null;
  const counts = { axisVisits: 0 };
  try {
    const a = native(pair.a), b = native(pair.b);
    selected = select(pair, counts);
    if (!selected) return { status: "MISS", points: [], ...counts };
    const result = selected.feature.kind === "FACE" ? face(a, b, selected, selected.feature) : edge(a, b, selected, selected.feature);
    const normalWord = numberVector(result.normal), length = Math.hypot(...normalWord);
    if (!(length > 0) || !Number.isFinite(length)) throw new Unresolved("INVALID_NORMAL_OUTPUT");
    return {
      status: "HIT",
      feature: selected.feature,
      satNormal: selected.normal,
      satOverlap: selected.overlap,
      normal: scaleN(normalWord, 1 / length),
      exactNormalDirection: encoded(result.normal),
      points: result.points.map((p, i) => ({
        id: `${selected.feature.kind}:${selected.feature.index}:${i}`,
        pointM: numberVector(p.midpoint),
        aPointM: numberVector(p.a),
        bPointM: numberVector(p.b),
        exact: { a: encoded(p.a), b: encoded(p.b), midpoint: encoded(p.midpoint) },
        nativeHalfspacesCertified: 12
      })),
      ...counts,
      geometry: "EXACT_NORMALIZED_QUATERNION_NATIVE_ENDPOINTS",
      phase: "INPUT_POSES_ONLY"
    };
  } catch (error) {
    if (!(error instanceof Unresolved)) throw error;
    return { status: "UNRESOLVED", feature: selected?.feature ?? null, reason: error.message, points: [], ...counts, phase: "INPUT_POSES_ONLY" };
  }
}
export {
  boxContact
};
