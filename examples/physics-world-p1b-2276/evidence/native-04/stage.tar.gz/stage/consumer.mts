import {createPhysicsWorld, type PhysicsModel, type WorldOptions} from '@barocss/physics';
import {createPhysicsScene,createPhysicsReplaySession,serializePhysicsSnapshot,deserializePhysicsSnapshot} from '@barocss/physics/replay';
import {admitCadSurfaceProxy} from '@barocss/physics/cad-proxy';
// @ts-expect-error removed creation type
import type {PhysicsWorldConfig} from '@barocss/physics';
// @ts-expect-error independent reduced reference is not root API
import {createPlanarPendulum} from '@barocss/physics';
declare const model:PhysicsModel, options:WorldOptions;
const world=createPhysicsWorld(model,options);
world.step([]);world.getModel();world.getState();
world.query({kind:'raycast',originM:[0,0,0],direction:[1,0,0],maxDistanceM:1,includeSensors:false});
// @ts-expect-error removed flat constructor
createPhysicsWorld({bodies:[]});
// @ts-expect-error fixed step is options data, not command
world.step(1/120);
// @ts-expect-error use tagged query
world.raycast({});
// @ts-expect-error old state rotation field removed
world.getState().bodies[0].orientation;
const scene=createPhysicsScene(model,options,{revision:'compile1',sourceRevision:'compile1'});
const replay=createPhysicsReplaySession(scene);
const bytes:Uint8Array=serializePhysicsSnapshot(replay.saveSnapshot());
deserializePhysicsSnapshot(bytes);void admitCadSurfaceProxy;
