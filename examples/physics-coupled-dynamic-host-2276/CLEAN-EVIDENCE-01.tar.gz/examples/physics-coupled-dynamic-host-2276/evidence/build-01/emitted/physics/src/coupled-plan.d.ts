/** Private cold one-point, one-host-step plan. Never reads a reference or observer. */
import { type CoupledInput, type CoupledResult } from '../../D/production-entry.js';
import type { Body } from './internal-types.js';
import type { PhaseHit, PhasePoint } from './phase-hit.js';
export type CoupledCode = 'COUPLED_PROFILE_UNSUPPORTED' | 'COUPLED_UNRESOLVED';
export declare class CoupledContactError extends Error {
    readonly code: CoupledCode;
    readonly details: unknown;
    constructor(code: CoupledCode, message: string, details?: unknown);
}
export interface CoupledPlan {
    readonly key: string;
    readonly hostStep: number;
    readonly binding: string;
    readonly input: CoupledInput;
    readonly target: Extract<CoupledResult, {
        status: 'STATIC_TARGET' | 'DYNAMIC_TARGET';
    }>;
    applied: boolean;
    slots: number;
}
export declare function prepareCoupledPlan(key: string, hostStep: number, a: Body, b: Body, hit: PhaseHit, point: PhasePoint): CoupledPlan;
export declare function guardCoupledIdentity(plan: CoupledPlan, key: string, hostStep: number, a: Body, b: Body, hit: PhaseHit, point: PhasePoint): void;
export declare function guardCoupledPlan(plan: CoupledPlan, key: string, hostStep: number, a: Body, b: Body, hit: PhaseHit, point: PhasePoint): void;
