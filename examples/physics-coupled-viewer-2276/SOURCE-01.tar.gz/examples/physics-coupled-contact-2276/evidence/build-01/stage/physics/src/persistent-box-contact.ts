import type {CoupledPlan} from './coupled-plan.js';
import {transportWarmTangent} from './warm-transport.js';
import {actualContribution,emptyContribution,combineContribution,type PairContribution} from './producer.js';
import { bodyWords, phaseKind, phaseApplyBefore, phaseApplyAfter, phaseNoNormal, phaseCorrectionBefore, phaseCorrectionAfter } from './private-phase.js';
import type { Body, Vec3 } from './internal-types.js';
import { add, cross, dot, inverseInertia, scale, sub } from './math.js';

export interface PointImpulse { normalNs: number; tangentNs: Vec3 }

function apply(a: Body, b: Body, pointM: Vec3, impulse: Vec3): PairContribution {
  const traceApply = phaseApplyBefore(a,b,pointM,impulse);
  const armA = sub(pointM, a.positionM), armB = sub(pointM, b.positionM);
  a.velocityMps = sub(a.velocityMps, scale(impulse, a.inverseMass));
  b.velocityMps = add(b.velocityMps, scale(impulse, b.inverseMass));
  a.angularVelocityRadps = sub(a.angularVelocityRadps,
    inverseInertia(a, cross(armA, impulse)));
  b.angularVelocityRadps = add(b.angularVelocityRadps,
    inverseInertia(b, cross(armB, impulse)));
  const producerContribution=actualContribution(pointM,impulse);
  phaseApplyAfter(traceApply,a,b);
  return producerContribution;
}

function relativeVelocity(a: Body, b: Body, pointM: Vec3): Vec3 {
  const armA = sub(pointM, a.positionM), armB = sub(pointM, b.positionM);
  return sub(add(b.velocityMps, cross(b.angularVelocityRadps, armB)),
    add(a.velocityMps, cross(a.angularVelocityRadps, armA)));
}

function effectiveInverseMass(a: Body, b: Body, pointM: Vec3, direction: Vec3): number {
  const torqueA = cross(sub(pointM, a.positionM), direction);
  const torqueB = cross(sub(pointM, b.positionM), direction);
  return a.inverseMass + b.inverseMass + dot(torqueA, inverseInertia(a, torqueA))
    + dot(torqueB, inverseInertia(b, torqueB));
}

export function warmStartPoint(a: Body, b: Body, pointM: Vec3, normal: Vec3,
  impulse: PointImpulse): PairContribution {
  phaseKind('warm',{actualPriorApplication:true});
  impulse.tangentNs = transportWarmTangent(impulse.tangentNs, normal);
  return apply(a, b, pointM, add(scale(normal, impulse.normalNs), impulse.tangentNs));
}

export function solvePersistentPoint(a: Body, b: Body, pointM: Vec3, normal: Vec3,
  impulse: PointImpulse, normalTargetMps: number, plan: CoupledPlan): PairContribution {
  if(normalTargetMps!==0)throw new Error('Coupled static target forbids restitution');
  const first=!plan.applied;plan.slots++;
  if(first){impulse.normalNs=plan.target.normalNs;impulse.tangentNs=[...plan.target.tangentNs];}
  phaseKind('coupled-static',{targetApplied:first,zeroSlot:!first,slot:plan.slots,hostStep:plan.hostStep,key:plan.key,nativeNormal:plan.target.certificate.nativeUnitNormal,normalNs:plan.target.normalNs,tangentNs:plan.target.tangentNs,worldImpulseNs:plan.target.worldImpulseNs});
  const contribution=apply(a,b,pointM,first?[...plan.target.worldImpulseNs]:[0,0,0]);
  plan.applied=true;return contribution;
}

export function correctPersistentPair(a: Body, b: Body, normal: Vec3,
  penetration: number): void {
  const inverseTotal = a.inverseMass + b.inverseMass;
  if (inverseTotal === 0 || penetration <= 0) return;
  const traceCorrection=phaseCorrectionBefore(a,b,normal,penetration);
  const correction = scale(normal, penetration / inverseTotal);
  a.positionM = sub(a.positionM, scale(correction, a.inverseMass));
  b.positionM = add(b.positionM, scale(correction, b.inverseMass));
  phaseCorrectionAfter(traceCorrection,a,b);
}
