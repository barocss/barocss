import type { Body, Vec3 } from '../internal-types.js';
import { PhysicsError } from '../internal-types.js';
import type { NormalProblem, NormalSolverResult } from './normal-solver.js';
import type { PointLedger } from './world-types.js';
export interface FrozenStackPatch {
    aIndex: number;
    bIndex: number;
    aId: string;
    bId: string;
    pairKey: string;
    family: 'face' | 'edge';
    normal: Vec3;
    points: readonly {
        id: string;
        pointM: Vec3;
        witnessAM: Vec3;
        witnessBM: Vec3;
        normalGapM: number;
        pointPenetrationM: number;
    }[];
}
export declare class NormalPhaseFailure extends PhysicsError {
    readonly problem: NormalProblem;
    readonly result: NormalSolverResult | null;
    constructor(reason: PhysicsError, problem: NormalProblem, result: NormalSolverResult | null);
}
/** One cold solve over frozen actual points. Caller owns unaccepted bodies. */
export declare function solveStackNormal(bodies: Body[], patches: readonly FrozenStackPatch[]): {
    problem: NormalProblem;
    result: NormalSolverResult;
    pointLedger: PointLedger[];
};
