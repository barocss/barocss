"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createProductionContext = createProductionContext;
const math_core_js_1 = require("./math-core.js");
const limits_js_1 = require("./limits.js");
/** No caller-supplied limits and no test import. */
function createProductionContext() { return (0, math_core_js_1.createArithmeticContext)(limits_js_1.PRODUCTION_LIMITS); }
