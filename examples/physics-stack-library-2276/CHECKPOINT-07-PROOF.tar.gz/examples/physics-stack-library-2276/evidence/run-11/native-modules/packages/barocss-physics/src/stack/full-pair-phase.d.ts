import { PhysicsError, type Body } from '../internal-types.js';
import type { FullPairPositionAttempt, FullPairPositionStats, PositionPair } from './world-types.js';
export { FULL_PAIR_ERRORS } from './full-pair-rows.js';
export declare class PositionPhaseFailure extends PhysicsError {
    readonly stats: FullPairPositionStats;
    readonly attempt: FullPairPositionAttempt;
    constructor(reason: PhysicsError, stats: FullPairPositionStats, attempt: FullPairPositionAttempt);
}
export declare function zeroFullPairPositionStats(): FullPairPositionStats;
/** One full PRE problem and solve. Only private working positions can commit here. */
export declare function runFullPairPositionPhase(workingBodies: Body[], sortedPairs: readonly PositionPair[]): {
    stats: FullPairPositionStats;
    attempt: FullPairPositionAttempt;
};
