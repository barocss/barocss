/** Private exact static-contact arithmetic. No engine, geometry builder, or dependencies. */
export type Vec = [number, number, number];
export interface StaticInput {
    pointM: Vec;
    comM: Vec;
    orientationXYZW: [number, number, number, number];
    freeVelocityMps: Vec;
    freeAngularVelocityRadps: Vec;
    massKg: number;
    halfExtentsM: Vec;
    muStaticA: number;
    muStaticB: number;
    nativeFaceAxis: 0 | 1 | 2;
    nativeFaceSign: -1 | 1;
    nativeNormalDirection: [string, string, string];
    nativePointExact: [string, string, string];
}
export interface Counts {
    rationalOps: number;
    gcdSteps: number;
    peakBits: number;
}
export interface StaticCertificate {
    nativePointM: string[];
    armM: string[];
    freePointVelocityMps: string[];
    physicalK: string[][];
    principalMinors: string[];
    nativeUnitNormal: string[];
    exactImpulseNs: string[];
    exactNormalNs: string;
    exactTangentNs: string[];
    exactConeMarginSquared: string;
    exactContactResidual: string[];
    counts: Counts;
}
export type StaticResult = {
    status: 'STATIC_TARGET';
    worldImpulseNs: Vec;
    normalNs: number;
    tangentNs: Vec;
    certificate: StaticCertificate;
} | {
    status: 'COUPLED_DYNAMIC_REQUIRED';
    certificate: StaticCertificate;
} | {
    status: 'UNRESOLVED';
    reason: string;
    counts: Counts;
};
export declare function coupledStaticTarget(input: StaticInput): StaticResult;
