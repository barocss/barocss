"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.floorSamples = floorSamples;
exports.confine = confine;
exports.stopOutwardVelocity = stopOutwardVelocity;
exports.insideBasin = insideBasin;
const constants_js_1 = require("./constants.js");
function floorSamples() {
    const points = [];
    const xSteps = Math.round(constants_js_1.FLUID_BASIN_M[0] / constants_js_1.FLUID_SPACING_M);
    const zSteps = Math.round(constants_js_1.FLUID_BASIN_M[2] / constants_js_1.FLUID_SPACING_M);
    for (const y of [0, -constants_js_1.FLUID_SPACING_M]) {
        for (let z = 0; z <= zSteps; z++) {
            for (let x = 0; x <= xSteps; x++) {
                points.push(x * constants_js_1.FLUID_SPACING_M, y, z * constants_js_1.FLUID_SPACING_M);
            }
        }
    }
    return new Float64Array(points);
}
function confine(positions, velocities, index) {
    let hits = 0;
    const offset = index * 3;
    for (let axis = 0; axis < 3; axis++) {
        const point = offset + axis;
        const low = constants_js_1.FLUID_PARTICLE_RADIUS_M;
        const high = constants_js_1.FLUID_BASIN_M[axis] - constants_js_1.FLUID_PARTICLE_RADIUS_M;
        if (positions[point] < low || positions[point] > high) {
            positions[point] = Math.max(low, Math.min(high, positions[point]));
            velocities[point] *= -0.1;
            hits++;
        }
    }
    return hits;
}
function stopOutwardVelocity(positions, velocities, index) {
    const offset = index * 3;
    for (let axis = 0; axis < 3; axis++) {
        const point = offset + axis;
        const low = constants_js_1.FLUID_PARTICLE_RADIUS_M;
        const high = constants_js_1.FLUID_BASIN_M[axis] - constants_js_1.FLUID_PARTICLE_RADIUS_M;
        if ((positions[point] <= low + 1e-9 && velocities[point] < 0)
            || (positions[point] >= high - 1e-9 && velocities[point] > 0)) {
            velocities[point] *= -0.1;
        }
    }
}
function insideBasin(positions) {
    for (let index = 0; index < positions.length / 3; index++) {
        for (let axis = 0; axis < 3; axis++) {
            const value = positions[index * 3 + axis];
            if (!Number.isFinite(value) || value < constants_js_1.FLUID_PARTICLE_RADIUS_M - 1e-9
                || value > constants_js_1.FLUID_BASIN_M[axis] - constants_js_1.FLUID_PARTICLE_RADIUS_M + 1e-9)
                return false;
        }
    }
    return true;
}
