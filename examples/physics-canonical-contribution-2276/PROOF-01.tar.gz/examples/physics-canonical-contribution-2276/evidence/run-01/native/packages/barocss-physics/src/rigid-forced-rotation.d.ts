/** Eighth-order modified-midpoint extrapolation for constant world torque. */
import type { Body, Quat, Vec3 } from './internal-types.js';
type ForcedResult = {
    orientation: Quat;
    angularVelocityRadps: Vec3;
};
/** World applies the angular impulse and motors once before this continuous flow. */
export declare function prepareForcedRotation(body: Body, dt: number, torque: Vec3): ForcedResult | null;
export {};
