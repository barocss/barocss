"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emptyContribution = void 0;
exports.actualContribution = actualContribution;
exports.checkContribution = checkContribution;
exports.combineContribution = combineContribution;
exports.addPairContribution = addPairContribution;
exports.copyPairWrenches = copyPairWrenches;
exports.acceptedGeometry = acceptedGeometry;
exports.acceptedMembership = acceptedMembership;
// Private producer authority. No observer or event-ledger reads.
const types_js_1 = require("./types.js");
const private_phase_js_1 = require("./private-phase.js");
const candidate_js_1 = require("../../B/candidate.js");
const sides = ['onA', 'onB'];
const fields = ['linearImpulseNs', 'angularImpulseAboutWorldOriginNms'];
const zero = () => ({ linearImpulseNs: [0, 0, 0], angularImpulseAboutWorldOriginNms: [0, 0, 0] });
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const emptyContribution = () => ({ nonzero: false, onA: zero(), onB: zero() });
exports.emptyContribution = emptyContribution;
function actualContribution(anchor, actualImpulseOnB) {
    const actualImpulseOnA = [-actualImpulseOnB[0], -actualImpulseOnB[1], -actualImpulseOnB[2]];
    const result = { nonzero: actualImpulseOnB.some(v => v !== 0), onA: { linearImpulseNs: [...actualImpulseOnA], angularImpulseAboutWorldOriginNms: cross(anchor, actualImpulseOnA) }, onB: { linearImpulseNs: [...actualImpulseOnB], angularImpulseAboutWorldOriginNms: cross(anchor, actualImpulseOnB) } };
    checkContribution(result);
    return result;
}
function checkContribution(value) {
    for (const side of sides)
        for (const key of fields)
            if (value[side][key].length !== 3 || value[side][key].some(v => !Number.isFinite(v)))
                throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'unsafe producer contact contribution');
}
function combineContribution(a, b) {
    checkContribution(a);
    checkContribution(b);
    const result = { nonzero: a.nonzero || b.nonzero, onA: zero(), onB: zero() };
    for (const side of sides)
        for (const key of fields)
            result[side][key] = add(a[side][key], b[side][key]);
    checkContribution(result);
    return result;
}
function colliderId(ids, id) {
    const value = ids.get(id);
    if (value === undefined)
        throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'missing producer collider identity');
    return value;
}
function addPairContribution(map, a, b, colliderIds, value) {
    checkContribution(value);
    if (!value.nonzero)
        return;
    const key = a.id + '\u0000' + b.id;
    let entry = map.get(key);
    if (!entry) {
        entry = { colliderAId: colliderId(colliderIds, a.id), colliderBId: colliderId(colliderIds, b.id), bodyAId: a.id, bodyBId: b.id, onA: zero(), onB: zero() };
        map.set(key, entry);
    }
    for (const side of sides)
        for (const field of fields)
            entry[side][field] = add(entry[side][field], value[side][field]);
    checkContribution(entry);
    (0, private_phase_js_1.phaseProducerBucket)(key, map, value);
}
function copyPairWrenches(map) {
    return [...map.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([, v]) => structuredClone(v));
}
function acceptedGeometry(bodies, pairs, colliderIds, verify) {
    const contacts = [];
    for (const [ai, bi] of pairs) {
        const a = bodies[ai], b = bodies[bi], hit = (0, private_phase_js_1.phaseQuery)(a, b, true);
        verify(a, b, hit);
        if (!hit)
            continue;
        const pair = hit._phase.pair;
        const points = hit._phase.result.points.map((point) => { let native; try {
            native = (0, candidate_js_1.representedNativeLine)(pair, point.pointM, hit.normal);
        }
        catch (error) {
            throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'accepted native line/gap refused: ' + (error instanceof Error ? error.message : String(error)));
        } return { id: point.id, normalAtoB: [...hit.normal], anchorM: [...point.pointM], pointOnAM: native.pointOnAM, pointOnBM: native.pointOnBM, signedGapM: native.signedGapM }; }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
        if (points.some(p => !Number.isFinite(p.signedGapM)))
            throw new types_js_1.PhysicsError('NUMERIC_LIMIT', 'unsafe accepted native gap');
        contacts.push({ colliderAId: colliderId(colliderIds, a.id), colliderBId: colliderId(colliderIds, b.id), bodyAId: a.id, bodyBId: b.id, points });
    }
    return contacts.sort((a, b) => a.bodyAId < b.bodyAId ? -1 : a.bodyAId > b.bodyAId ? 1 : a.bodyBId < b.bodyBId ? -1 : a.bodyBId > b.bodyBId ? 1 : 0);
}
function acceptedMembership(contacts) {
    return new Map(contacts.map((c) => [c.bodyAId + '\u0000' + c.bodyBId, { aId: c.bodyAId, bId: c.bodyBId, kind: 'contact' }]));
}
