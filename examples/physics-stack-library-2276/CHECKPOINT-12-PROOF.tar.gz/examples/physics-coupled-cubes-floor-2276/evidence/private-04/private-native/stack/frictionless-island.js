/** Private cold island candidate. No integration, World, cache, fixture or expected-state imports. */
import { PhysicsError } from '../internal-types.js';
import { copyBody } from '../validation.js';
import { detect, validateResult } from '../collision.js';
import { add, cross, dot, inertia, inverseInertia, scale, sub } from '../math.js';
import { contactApplication, ContactPairAccumulator } from '../contact-contribution.js';
import { featureContact } from './geometry.js';
import { solveNormalContacts } from './normal-solver.js';
import { checkedFullPairInputs } from './full-pair-rows.js';
import { runFullPairPositionPhase, PositionPhaseFailure } from './full-pair-phase.js';
import { StrictLineContext, StrictLineFailure } from './strict-line.js';
export class FrictionlessIslandFailure extends PhysicsError {
    diagnostics;
    constructor(reason, diagnostics) {
        super(reason.code, reason.message);
        this.diagnostics = structuredClone(diagnostics);
    }
}
const SI = 1e-10;
function need(ok, message) {
    if (!ok)
        throw new PhysicsError('NUMERIC_LIMIT', 'frictionless island: ' + message);
}
function finite(value) {
    need(Number.isFinite(value), 'finite validation arithmetic');
    return value;
}
function maximum(values) {
    return values.reduce((value, next) => Math.max(value, Math.abs(finite(next))), 0);
}
function pairKey(a, b) { return a.id + '\0' + b.id; }
function velocityAt(body, point) {
    return add(body.velocityMps, cross(body.angularVelocityRadps, sub(point, body.positionM)));
}
function worldInverse(body) {
    if (body.inverseMass === 0)
        return [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const local = body.inverseInertiaLocal;
    if (local[0] === local[1] && local[1] === local[2]) {
        const c = local[0];
        // R(cI)R^T = cI for every physical rotation. Exact equality, no tensor repair.
        return [[c, 0, 0], [0, c, 0], [0, 0, c]];
    }
    const columns = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        .map(axis => inverseInertia(body, axis));
    // Keep the actual represented columns. No averaging, symmetry repair or fixed I24.
    return [[columns[0][0], columns[1][0], columns[2][0]],
        [columns[0][1], columns[1][1], columns[2][1]],
        [columns[0][2], columns[1][2], columns[2][2]]];
}
function normalBody(body) {
    return { id: body.id, positionM: [...body.positionM], velocityMps: [...body.velocityMps],
        angularVelocityRadps: [...body.angularVelocityRadps], inverseMass: body.inverseMass,
        inverseInertiaWorld: worldInverse(body) };
}
/** Fixed 3x3 validation factor only; not another normal solve or solver stats. */
function validationFactor(matrix) {
    const lower = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const magnitude = Math.max(1, ...matrix.flat().map(Math.abs));
    for (let i = 0; i < 3; i++)
        for (let j = 0; j < 3; j++)
            need(matrix[i][j] === matrix[j][i], 'actual inverse inertia symmetry');
    for (let i = 0; i < 3; i++)
        for (let j = 0; j <= i; j++) {
            let value = matrix[i][j];
            for (let k = 0; k < j; k++)
                value = finite(value - finite(lower[i][k] * lower[j][k]));
            if (i === j) {
                need(value > 1e-12 * magnitude, 'actual inverse inertia positive definite');
                lower[i][j] = Math.sqrt(value);
            }
            else
                lower[i][j] = finite(value / lower[j][j]);
        }
    return lower;
}
function whiten(factor, angularVelocity) {
    const out = [];
    for (let i = 0; i < 3; i++) {
        let value = angularVelocity[i];
        for (let j = 0; j < i; j++)
            value = finite(value - finite(factor[i][j] * out[j]));
        out.push(finite(value / factor[i][i]));
    }
    return out;
}
function validateApplied(free, applied, problem, solved, applications) {
    need(solved.ok && solved.normalImpulsesNs && solved.bodies.length === free.length, 'complete normal solve');
    const result = { maxClosingNormalSpeedMps: 0, maxComplementarityJ: 0,
        maxStationaritySqrtJ: 0, maxSolverVelocityDifference: 0, maxLinearMomentumResidualNs: 0,
        maxAngularMomentumResidualNms: 0, postValidationCholeskyFactorizations: 0 };
    const linear = free.map(() => [0, 0, 0]), angular = free.map(() => [0, 0, 0]);
    for (const entry of applications) {
        const application = entry.contribution.applications[0];
        need(application && entry.contribution.applications.length === 1, 'one actual point application');
        for (const [index, side] of [[entry.aIndex, application.onA], [entry.bIndex, application.onB]]) {
            linear[index] = add(linear[index], side.linearImpulseNs);
            angular[index] = add(angular[index], side.armTorqueNms);
        }
    }
    const ids = new Map(free.map((body, index) => [body.id, index]));
    for (let i = 0; i < free.length; i++) {
        need(applied[i].id === free[i].id && solved.bodies[i].id === free[i].id, 'body order retained');
        if (free[i].inverseMass === 0)
            continue;
        const factor = validationFactor(problem.bodies[i].inverseInertiaWorld);
        result.postValidationCholeskyFactorizations++;
        const rootMass = Math.sqrt(free[i].inverseMass);
        const oldAngular = whiten(factor, free[i].angularVelocityRadps);
        const newAngular = whiten(factor, applied[i].angularVelocityRadps);
        const reaction = [0, 0, 0, 0, 0, 0];
        for (let p = 0; p < problem.points.length; p++) {
            const point = problem.points[p], lambda = solved.normalImpulsesNs[p];
            const sign = point.aId === free[i].id ? -1 : point.bId === free[i].id ? 1 : 0;
            if (!sign)
                continue;
            const n = [...point.normalAtoB];
            const torque = cross(sub([...point.pointM], free[i].positionM), n);
            for (let k = 0; k < 3; k++) {
                reaction[k] = finite(reaction[k] + finite(finite(sign * n[k] * rootMass) * lambda));
                let coefficient = 0;
                for (let j = 0; j < 3; j++)
                    coefficient = finite(coefficient + finite(torque[j] * factor[j][k]));
                reaction[k + 3] = finite(reaction[k + 3] + finite(finite(sign * coefficient) * lambda));
            }
        }
        const residual = [0, 1, 2].map(k => finite(applied[i].velocityMps[k] / rootMass -
            free[i].velocityMps[k] / rootMass - reaction[k]));
        for (let k = 0; k < 3; k++)
            residual.push(finite(newAngular[k] - oldAngular[k] - reaction[k + 3]));
        result.maxStationaritySqrtJ = Math.max(result.maxStationaritySqrtJ, maximum(residual));
        result.maxSolverVelocityDifference = Math.max(result.maxSolverVelocityDifference, maximum(sub(applied[i].velocityMps, [...solved.bodies[i].velocityMps])), maximum(sub(applied[i].angularVelocityRadps, [...solved.bodies[i].angularVelocityRadps])));
        result.maxLinearMomentumResidualNs = Math.max(result.maxLinearMomentumResidualNs, maximum(sub(scale(sub(applied[i].velocityMps, free[i].velocityMps), 1 / free[i].inverseMass), linear[i])));
        result.maxAngularMomentumResidualNms = Math.max(result.maxAngularMomentumResidualNms, maximum(sub(inertia(free[i], sub(applied[i].angularVelocityRadps, free[i].angularVelocityRadps)), angular[i])));
    }
    for (let p = 0; p < problem.points.length; p++) {
        const point = problem.points[p], a = ids.get(point.aId), b = ids.get(point.bId);
        need(a !== undefined && b !== undefined, 'normal endpoints retained');
        const relative = sub(velocityAt(applied[b], [...point.pointM]), velocityAt(applied[a], [...point.pointM]));
        const speed = finite(dot(relative, [...point.normalAtoB]));
        result.maxClosingNormalSpeedMps = Math.max(result.maxClosingNormalSpeedMps, -speed);
        result.maxComplementarityJ = Math.max(result.maxComplementarityJ, Math.abs(finite(speed * solved.normalImpulsesNs[p])));
    }
    for (const key of ['maxClosingNormalSpeedMps', 'maxComplementarityJ', 'maxStationaritySqrtJ',
        'maxSolverVelocityDifference', 'maxLinearMomentumResidualNs', 'maxAngularMomentumResidualNms'])
        need(Number.isFinite(result[key]) && result[key] <= SI, 'actual applied normal certificate: ' + key);
    return result;
}
function representative(a, b, geometry) {
    const mean = scale(geometry.points.reduce((sum, point) => add(sum, point.midpointM), [0, 0, 0]), 1 / geometry.points.length);
    const exact = new StrictLineContext(a, b, geometry.planeNormalAtoB);
    need(exact.check(mean), 'post representative strict line');
    if (geometry.family === 'face') {
        const reference = geometry.reference;
        need(reference, 'post face selectors');
        const ref = { axis: reference.axis, side: reference.side };
        const inc = { axis: reference.incidentAxis, side: reference.incidentSide };
        const faceA = reference.body === 'a' ? ref : inc, faceB = reference.body === 'a' ? inc : ref;
        need(exact.selectedFaceBounds(mean, faceA, faceB) && exact.onFace(0, faceA, mean) && exact.onFace(1, faceB, mean), 'post representative finite boundary faces');
    }
    return mean;
}
/** Caller supplies actual post-integration FREE bodies and every sorted eligible pair. */
export function prepareFrictionlessIsland(freeBodies, pairs, context) {
    const diagnostics = { freeBodies: [], pairs: [], freeGeometry: [],
        normalProblem: null, normalResult: null, applications: [], velocityBodies: null,
        appliedNormalCertificate: null, positionAttempt: null, positionStats: null, postGeometry: [],
        pairContributions: [], normalSolverCalls: 0, positionPhaseCalls: 0, positionSolverCalls: 0 };
    try {
        need(context && context.jointCount === 0, 'no joints');
        need(Array.isArray(freeBodies) && freeBodies.length >= 1 && freeBodies.length <= 4 &&
            freeBodies.every(body => body !== null && typeof body === 'object') &&
            freeBodies.some(body => body.kind === 'dynamic'), 'existing persistent body bound');
        checkedFullPairInputs(freeBodies, pairs);
        for (const body of freeBodies)
            need(body.frictionStatic === 0 && body.frictionDynamic === 0 &&
                body.restitution === 0 && !body.sleeping && !body.sensor && !body.ccd && !body.collisionFilter, 'zero-friction zero-restitution unfiltered awake boxes');
        for (const body of freeBodies)
            if (body.kind === 'static')
                need(body.inverseInertiaLocal.every((value) => value === 0), 'prescribed static inverse inertia');
        const working = freeBodies.map(copyBody);
        diagnostics.freeBodies = working.map(copyBody);
        diagnostics.pairs = pairs.map(([a, b]) => [a, b]);
        const points = [];
        for (const [aIndex, bIndex] of pairs) {
            const a = working[aIndex], b = working[bIndex], hit = detect(a, b);
            if (!hit)
                continue;
            const geometry = featureContact(a, b);
            need(geometry && geometry.points.length > 0, 'actual free contact geometry');
            const key = pairKey(a, b);
            diagnostics.freeGeometry.push({ aIndex, bIndex, aId: a.id, bId: b.id, pairKey: key,
                hit: structuredClone(hit), geometry });
            for (const point of geometry.points)
                points.push({ id: JSON.stringify([key, point.key]),
                    aId: a.id, bId: b.id, pointM: [...point.midpointM], normalAtoB: [...geometry.planeNormalAtoB] });
        }
        need(points.length <= 32, 'existing normal point bound');
        const problem = { bodies: working.map(normalBody), points };
        diagnostics.normalProblem = problem;
        diagnostics.normalSolverCalls++;
        const solved = solveNormalContacts(problem);
        diagnostics.normalResult = solved;
        if (!solved.ok)
            throw new PhysicsError(solved.status === 'ITERATION_LIMIT' ? 'ITERATION_LIMIT' : 'NUMERIC_LIMIT', 'frictionless island normal: ' + solved.reason);
        need(solved.status === 'SOLVED_NORMAL_ONLY' && solved.normalImpulsesNs && solved.normalImpulsesNs.length === points.length, 'complete global normal solve');
        const totals = new ContactPairAccumulator(), byId = new Map(working.map((body, index) => [body.id, index]));
        let pointIndex = 0;
        for (const patch of diagnostics.freeGeometry)
            for (const point of patch.geometry.points) {
                const a = working[patch.aIndex], b = working[patch.bIndex], lambda = solved.normalImpulsesNs[pointIndex];
                need(Number.isFinite(lambda) && lambda >= 0 && problem.points[pointIndex].id === JSON.stringify([patch.pairKey, point.key]), 'nonnegative actual point impulse/link');
                const n = [...patch.geometry.planeNormalAtoB];
                const pointM = [...point.midpointM], onB = scale(n, lambda);
                const armA = sub(pointM, a.positionM), armB = sub(pointM, b.positionM);
                const contribution = contactApplication(a.positionM, b.positionM, armA, armB, onB);
                const actual = contribution.applications[0];
                diagnostics.applications.push({ id: problem.points[pointIndex].id, aIndex: patch.aIndex, bIndex: patch.bIndex,
                    pairKey: patch.pairKey, pointKey: point.key, pointM, normalAtoB: n, normalImpulseNs: lambda, contribution });
                totals.add(a.id, b.id, contribution);
                if (lambda !== 0)
                    for (const [body, side] of [[a, actual.onA], [b, actual.onB]])
                        if (body.inverseMass !== 0) {
                            body.velocityMps = add(body.velocityMps, scale(side.linearImpulseNs, body.inverseMass));
                            body.angularVelocityRadps = add(body.angularVelocityRadps, inverseInertia(body, side.armTorqueNms));
                        }
                pointIndex++;
            }
        need(pointIndex === points.length, 'every normal point applied exactly once');
        diagnostics.pairContributions = totals.finish();
        diagnostics.velocityBodies = working.map(copyBody);
        validateResult(working, []);
        diagnostics.appliedNormalCertificate = validateApplied(diagnostics.freeBodies, working, problem, solved, diagnostics.applications);
        diagnostics.positionPhaseCalls++;
        diagnostics.positionSolverCalls = null;
        try {
            const position = runFullPairPositionPhase(working, pairs);
            diagnostics.positionAttempt = position.attempt;
            diagnostics.positionStats = position.stats;
            diagnostics.positionSolverCalls = position.stats.solverCalls;
        }
        catch (error) {
            if (error instanceof PositionPhaseFailure) {
                diagnostics.positionAttempt = error.attempt;
                diagnostics.positionStats = error.stats;
                diagnostics.positionSolverCalls = error.stats.solverCalls;
            }
            throw error;
        }
        const impulseTotals = new Map();
        for (const application of diagnostics.applications)
            impulseTotals.set(application.pairKey, finite((impulseTotals.get(application.pairKey) ?? 0) + application.normalImpulseNs));
        const freePenetrations = new Map(diagnostics.freeGeometry.map(patch => [patch.pairKey, patch.hit?.penetration ?? 0]));
        const contacts = [], retained = new Set();
        for (const [aIndex, bIndex] of pairs) {
            const a = working[aIndex], b = working[bIndex], key = pairKey(a, b);
            const geometry = featureContact(a, b);
            if (!geometry) {
                need((impulseTotals.get(key) ?? 0) === 0, 'applied pair needs fresh post witness');
                continue;
            }
            diagnostics.postGeometry.push({ aIndex, bIndex, aId: a.id, bId: b.id, pairKey: key,
                hit: detect(a, b), geometry });
            for (const point of geometry.points) {
                const speed = finite(dot(sub(velocityAt(b, point.midpointM), velocityAt(a, point.midpointM)), geometry.planeNormalAtoB));
                need(speed >= -SI, 'fresh post contact normal feasibility');
            }
            const mean = representative(a, b, geometry);
            contacts.push({ aId: a.id, bId: b.id, normalAtoB: [...geometry.planeNormalAtoB], pointM: mean,
                penetrationM: freePenetrations.get(key) ?? 0, impulseNs: impulseTotals.get(key) ?? 0, tangentImpulseNs: [0, 0, 0] });
            retained.add(key);
        }
        for (const [key, impulse] of impulseTotals)
            need(impulse === 0 || retained.has(key), 'all applied pair summaries retained');
        need(byId.size === working.length, 'body identity retained');
        validateResult(working, contacts);
        return { candidateBodies: working.map(copyBody), contacts, pairStats: {
                eligiblePairs: pairs.length, candidatePairs: pairs.length, aabbTests: 0
            },
            pairContributions: structuredClone(diagnostics.pairContributions), diagnostics: structuredClone(diagnostics) };
    }
    catch (caught) {
        if (caught instanceof StrictLineFailure)
            throw new FrictionlessIslandFailure(new PhysicsError('NUMERIC_LIMIT', 'frictionless island post representative strict-line refusal'), diagnostics);
        if (caught instanceof PhysicsError)
            throw new FrictionlessIslandFailure(caught, diagnostics);
        throw caught;
    }
}
