import type { PhaseHit } from './phase-hit.js';
import type { Contact, PairWrench, Vec3 } from './types.js';
import type { Body, PhysicsEvent, Vec3 as MutableVec3 } from './internal-types.js';
export interface MutableBodyWrench {
    linearImpulseNs: MutableVec3;
    angularImpulseAboutWorldOriginNms: MutableVec3;
}
export interface PairContribution {
    nonzero: boolean;
    onA: MutableBodyWrench;
    onB: MutableBodyWrench;
}
export interface MutablePairWrench {
    colliderAId: string;
    colliderBId: string;
    bodyAId: string;
    bodyBId: string;
    onA: MutableBodyWrench;
    onB: MutableBodyWrench;
}
export declare const emptyContribution: () => PairContribution;
export declare function actualContribution(anchor: Vec3, actualImpulseOnB: MutableVec3): PairContribution;
export declare function checkContribution(value: Pick<PairWrench, 'onA' | 'onB'>): void;
export declare function combineContribution(a: PairContribution, b: PairContribution): PairContribution;
export declare function addPairContribution(map: Map<string, MutablePairWrench>, a: Body, b: Body, colliderIds: ReadonlyMap<string, string>, value: PairContribution): void;
export declare function copyPairWrenches(map: ReadonlyMap<string, MutablePairWrench>): PairWrench[];
export declare function acceptedGeometry(bodies: Body[], pairs: readonly (readonly [number, number])[], colliderIds: ReadonlyMap<string, string>, verify: (a: Body, b: Body, hit: PhaseHit | null) => void): Contact[];
export declare function acceptedMembership(contacts: readonly Contact[]): Map<string, Omit<PhysicsEvent, 'phase'>>;
