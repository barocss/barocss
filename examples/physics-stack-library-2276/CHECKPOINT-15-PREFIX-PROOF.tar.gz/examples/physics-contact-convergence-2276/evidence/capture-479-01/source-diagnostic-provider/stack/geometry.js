import { error } from '../validation.js';
import { MAX_STEP_DISPLACEMENT_M, ID } from '../limits.js';
import { selectBoxSATFeature, FEATURE_INPUT_MESSAGE } from './sat-feature.js';
import { faceContact } from './face-contact.js';
import { edgeContact } from './edge-contact.js';
import { WITNESS_MESSAGE, basis, extents, WITNESS_TOLERANCE_M } from './witness.js';
import { dot, sub } from '../math.js';
function witnessInside(body, w) {
    const local = basis(body).map(axis => dot(sub(w, body.positionM), axis)), e = extents(body);
    const observedInside = local.every((v, i) => Number.isFinite(v) && Math.abs(v) <= e[i] + WITNESS_TOLERANCE_M);
    if (!observedInside && globalThis.__contactWitness479?.armed) globalThis.__contactWitness479.failedWitness ??= {body,witness:w,local,extents:e,toleranceM:WITNESS_TOLERANCE_M};
    return observedInside;
}
function denseVector(v, size, min, max) {
    return Array.isArray(v) && v.length === size && Array.from({ length: size }, (_, i) => i).every(i => Object.hasOwn(v, i) && Number.isFinite(v[i]) && v[i] >= min && v[i] <= max);
}
function admitted(b) {
    return b !== null && typeof b === 'object' && typeof b.id === 'string' && ID.test(b.id)
        && ['dynamic', 'static', 'kinematic'].includes(b.kind) && b.shape?.kind === 'box'
        && denseVector(b.shape.halfExtentsM, 3, .0001, 1000)
        && denseVector(b.positionM, 3, -10000, 10000)
        && denseVector(b.orientation, 4, -1, 1)
        && Math.abs(Math.hypot(...b.orientation) - 1) <= 1e-9;
}
/** Geometry only. No world, cache, response, projection or mutable caller reference. */
export function featureContact(a, b) {
    if (globalThis.__contactWitness479?.armed) { const o=globalThis.__contactWitness479; o.currentPair={a,b}; o.lastPoint=null; o.featureFailure=null; o.faceContext=null; o.facePoint=null; o.faceCertification=null; o.faceFailure=null; o.pointFailure=null; }
    if (!admitted(a) || !admitted(b) || a.id === b.id)
        error('INVALID_CONFIG', FEATURE_INPUT_MESSAGE);
    const selection = selectBoxSATFeature(a, b);
    if (!selection)
        return null;
    if (selection.hit.penetration > MAX_STEP_DISPLACEMENT_M)
        error('NUMERIC_LIMIT', WITNESS_MESSAGE);
    let geometry; try { geometry = selection.feature.kind === 'edge-cross' ? edgeContact(a, b, selection) : faceContact(a, b, selection); }
    catch (caught) { if (globalThis.__contactWitness479?.armed) globalThis.__contactWitness479.featureFailure={site:'FACE_OR_EDGE_CONSTRUCTION',a,b,selection,error:{name:caught?.name,code:caught?.code??null,message:String(caught?.message??caught),stack:caught?.stack??null}}; throw caught; }
    if (!geometry.points.length || geometry.points.some(p => !witnessInside(a, p.witnessAM) || !witnessInside(b, p.witnessBM))) {
        if (globalThis.__contactWitness479?.armed) globalThis.__contactWitness479.featureFailure={site:'FINAL_BOX_WITNESS',a,b,selection,geometry};
        error('NUMERIC_LIMIT', WITNESS_MESSAGE);
    }
    return geometry;
}
