"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.warmStartPoint = warmStartPoint;
exports.solvePersistentPoint = solvePersistentPoint;
exports.correctPersistentPair = correctPersistentPair;
const warm_transport_js_1 = require("./warm-transport.js");
const producer_js_1 = require("./producer.js");
const private_phase_js_1 = require("./private-phase.js");
const math_js_1 = require("./math.js");
function apply(a, b, pointM, impulse) {
    const traceApply = (0, private_phase_js_1.phaseApplyBefore)(a, b, pointM, impulse);
    const armA = (0, math_js_1.sub)(pointM, a.positionM), armB = (0, math_js_1.sub)(pointM, b.positionM);
    a.velocityMps = (0, math_js_1.sub)(a.velocityMps, (0, math_js_1.scale)(impulse, a.inverseMass));
    b.velocityMps = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.scale)(impulse, b.inverseMass));
    a.angularVelocityRadps = (0, math_js_1.sub)(a.angularVelocityRadps, (0, math_js_1.inverseInertia)(a, (0, math_js_1.cross)(armA, impulse)));
    b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.inverseInertia)(b, (0, math_js_1.cross)(armB, impulse)));
    const producerContribution = (0, producer_js_1.actualContribution)(pointM, impulse);
    (0, private_phase_js_1.phaseApplyAfter)(traceApply, a, b);
    return producerContribution;
}
function relativeVelocity(a, b, pointM) {
    const armA = (0, math_js_1.sub)(pointM, a.positionM), armB = (0, math_js_1.sub)(pointM, b.positionM);
    return (0, math_js_1.sub)((0, math_js_1.add)(b.velocityMps, (0, math_js_1.cross)(b.angularVelocityRadps, armB)), (0, math_js_1.add)(a.velocityMps, (0, math_js_1.cross)(a.angularVelocityRadps, armA)));
}
function effectiveInverseMass(a, b, pointM, direction) {
    const torqueA = (0, math_js_1.cross)((0, math_js_1.sub)(pointM, a.positionM), direction);
    const torqueB = (0, math_js_1.cross)((0, math_js_1.sub)(pointM, b.positionM), direction);
    return a.inverseMass + b.inverseMass + (0, math_js_1.dot)(torqueA, (0, math_js_1.inverseInertia)(a, torqueA))
        + (0, math_js_1.dot)(torqueB, (0, math_js_1.inverseInertia)(b, torqueB));
}
function warmStartPoint(a, b, pointM, normal, impulse) {
    (0, private_phase_js_1.phaseKind)('warm', { actualPriorApplication: true });
    impulse.tangentNs = (0, warm_transport_js_1.transportWarmTangent)(impulse.tangentNs, normal);
    return apply(a, b, pointM, (0, math_js_1.add)((0, math_js_1.scale)(normal, impulse.normalNs), impulse.tangentNs));
}
function solvePersistentPoint(a, b, pointM, normal, impulse, normalTargetMps, plan) {
    if (normalTargetMps !== 0)
        throw new Error('Coupled target forbids restitution');
    const first = !plan.applied;
    plan.slots++;
    if (first) {
        impulse.normalNs = plan.target.normalNs;
        impulse.tangentNs = [...plan.target.tangentNs];
    }
    (0, private_phase_js_1.phaseKind)(plan.target.status === 'DYNAMIC_TARGET' ? 'coupled-dynamic' : 'coupled-static', { targetStatus: plan.target.status, targetApplied: first, zeroSlot: !first, slot: plan.slots, hostStep: plan.hostStep, key: plan.key, nativeNormal: plan.target.certificate.nativeUnitNormal, normalNs: plan.target.normalNs, tangentNs: plan.target.tangentNs, worldImpulseNs: plan.target.worldImpulseNs });
    const contribution = apply(a, b, pointM, first ? [...plan.target.worldImpulseNs] : [0, 0, 0]);
    plan.applied = true;
    return contribution;
}
function correctPersistentPair(a, b, normal, penetration) {
    const inverseTotal = a.inverseMass + b.inverseMass;
    if (inverseTotal === 0 || penetration <= 0)
        return;
    const traceCorrection = (0, private_phase_js_1.phaseCorrectionBefore)(a, b, normal, penetration);
    const correction = (0, math_js_1.scale)(normal, penetration / inverseTotal);
    a.positionM = (0, math_js_1.sub)(a.positionM, (0, math_js_1.scale)(correction, a.inverseMass));
    b.positionM = (0, math_js_1.add)(b.positionM, (0, math_js_1.scale)(correction, b.inverseMass));
    (0, private_phase_js_1.phaseCorrectionAfter)(traceCorrection, a, b);
}
