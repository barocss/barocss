"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUprightCapsuleController = exports.createUprightCapsuleQuery = exports.createPhysicsWorld = void 0;
__exportStar(require("./types.js"), exports);
var world_js_1 = require("./world.js");
Object.defineProperty(exports, "createPhysicsWorld", { enumerable: true, get: function () { return world_js_1.createPhysicsWorld; } });
var capsule_query_js_1 = require("./capsule-query.js");
Object.defineProperty(exports, "createUprightCapsuleQuery", { enumerable: true, get: function () { return capsule_query_js_1.createUprightCapsuleQuery; } });
var character_controller_js_1 = require("./character-controller.js");
Object.defineProperty(exports, "createUprightCapsuleController", { enumerable: true, get: function () { return character_controller_js_1.createUprightCapsuleController; } });
