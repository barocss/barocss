// Authored natural regression model only; expected states never become World input.
import {makeCase as coupled,numericWordsHex,packet} from '../physics-coupled-cubes-floor-2276/cases.mjs';
export {numericWordsHex,packet};
export function makeCase(){const c=coupled();c.caseId='natural-anisotropic-precontact';c.model.revision='coupled-natural-anisotropic-refusal-v1';const body=c.model.bodies.find(b=>b.id==='upper'),shape=c.model.colliders.find(x=>x.bodyId===body.id);body.initial.positionM=[0,5,0];body.initial.orientationXYZW=[.1,.2,.3,Math.sqrt(.86)];shape.geometry.halfExtentsM=[.25,.5,.75];return c;}
