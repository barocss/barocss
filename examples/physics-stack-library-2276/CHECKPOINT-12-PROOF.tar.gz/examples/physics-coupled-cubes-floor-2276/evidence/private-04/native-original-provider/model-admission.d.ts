import type { PhysicsModel, WorldOptions } from './types.js';
import type { Body, Joint } from './internal-types.js';
import type { ParsedPair } from './disjoint-hinge/types.js';
import type { DomainModelData } from './domain/types.js';
export declare function admitModel(rawModel: PhysicsModel, rawOptions: WorldOptions): {
    model: PhysicsModel;
    options: WorldOptions;
    bodies: Body[];
    joints: Joint[];
    disjointHinges: [ParsedPair, ParsedPair] | null;
    domain: DomainModelData | null;
    stationary: boolean;
};
