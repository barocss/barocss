// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/types.ts
var PhysicsError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.name = "PhysicsError";
    this.details = { code, reason: message, operation: "create", phase: "admission", domain: "world", entityIds: [], accepted: null, ...details };
  }
  details;
};

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/B/native.ts
var Unresolved = class extends Error {
};
var BIT_LIMIT = 16384;
var Z = { n: 0n, d: 1n };
var O = { n: 1n, d: 1n };
var bits = (x) => (x < 0n ? -x : x).toString(2).length;
function check(x) {
  if (bits(x) > BIT_LIMIT) throw new Unresolved("EXACT_BIT_LIMIT");
  return x;
}
function product(a2, b2) {
  if (a2 !== 0n && b2 !== 0n && bits(a2) + bits(b2) > BIT_LIMIT) throw new Unresolved("EXACT_PRODUCT_BIT_LIMIT");
  return check(a2 * b2);
}
function q(n, d = 1n) {
  if (d === 0n) throw new Unresolved("ZERO_EXACT_DENOMINATOR");
  if (n === 0n) return Z;
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  check(n);
  check(d);
  let a2 = n < 0n ? -n : n, b2 = d;
  while (b2 !== 0n) {
    const next = a2 % b2;
    a2 = b2;
    b2 = next;
  }
  return { n: n / a2, d: d / a2 };
}
var neg = (a2) => ({ n: -a2.n, d: a2.d });
var plus = (a2, b2) => q(check(product(a2.n, b2.d) + product(b2.n, a2.d)), product(a2.d, b2.d));
var minus = (a2, b2) => plus(a2, neg(b2));
var times = (a2, b2) => q(product(a2.n, b2.n), product(a2.d, b2.d));
var over = (a2, b2) => q(product(a2.n, b2.d), product(a2.d, b2.n));
var compare = (a2, b2) => {
  const d = minus(a2, b2).n;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var absolute = (a2) => a2.n < 0n ? neg(a2) : a2;
function word(value) {
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_INPUT");
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false), e = Number(raw >> 52n & 2047n);
  const m = (raw & 0xfffffffffffffn | (e ? 0x10000000000000n : 0n)) * (raw >> 63n ? -1n : 1n);
  const power = e ? e - 1075 : -1074;
  return power < 0 ? q(m, 1n << BigInt(-power)) : q(m << BigInt(power));
}
function numeric(a2) {
  const n = a2.n < 0n ? -a2.n : a2.n;
  if (!n) return 0;
  let exponent = bits(n) - bits(a2.d);
  const shift = (value2, count) => {
    if (bits(value2) + count > BIT_LIMIT) throw new Unresolved("PRESENTATION_SHIFT_BIT_LIMIT");
    return check(value2 << BigInt(count));
  };
  if (exponent >= 0 ? n < shift(a2.d, exponent) : shift(n, -exponent) < a2.d) exponent--;
  if (exponent > 1023) throw new Unresolved("NONFINITE_OUTPUT");
  const unit = Math.max(-1074, exponent - 52);
  const numerator = unit < 0 ? shift(n, -unit) : n;
  const denominator = unit > 0 ? shift(a2.d, unit) : a2.d;
  let significand = numerator / denominator;
  const remainder = numerator % denominator;
  const doubled = check(remainder + remainder);
  if (doubled > denominator || doubled === denominator && (significand & 1n) !== 0n) significand++;
  const value = Number(significand) * 2 ** unit;
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_OUTPUT");
  return a2.n < 0n ? -value : value;
}
var vector = (a2) => a2.map(word);
var vplus = (a2, b2) => a2.map((x, i) => plus(x, b2[i]));
var vminus = (a2, b2) => a2.map((x, i) => minus(x, b2[i]));
var vscale = (a2, t) => a2.map((x) => times(x, t));
var dot = (a2, b2) => a2.reduce((s, x, i) => plus(s, times(x, b2[i])), Z);
var cross = (a2, b2) => [
  minus(times(a2[1], b2[2]), times(a2[2], b2[1])),
  minus(times(a2[2], b2[0]), times(a2[0], b2[2])),
  minus(times(a2[0], b2[1]), times(a2[1], b2[0]))
];
var numberVector = (a2) => a2.map(numeric);
var same = (a2, b2) => a2.every((x, i) => compare(x, b2[i]) === 0);
function native(box3) {
  if (box3.positionM.length !== 3 || box3.halfExtentsM.length !== 3 || box3.orientationXYZW.length !== 4 || box3.positionM.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1e4) || box3.halfExtentsM.some((x2) => !Number.isFinite(x2) || x2 < 1e-4 || x2 > 1e3) || box3.orientationXYZW.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1) || Math.abs(Math.hypot(...box3.orientationXYZW) - 1) > 1e-9) throw new Unresolved("OUTSIDE_NATIVE_INPUT_PROFILE");
  const [x, y, z, w] = box3.orientationXYZW.map(word);
  const s = plus(plus(times(x, x), times(y, y)), plus(times(z, z), times(w, w))), two = word(2);
  if (s.n === 0n) throw new Unresolved("ZERO_QUATERNION");
  const rows = [
    [minus(s, times(two, plus(times(y, y), times(z, z)))), times(two, minus(times(x, y), times(z, w))), times(two, plus(times(x, z), times(y, w)))],
    [times(two, plus(times(x, y), times(z, w))), minus(s, times(two, plus(times(x, x), times(z, z)))), times(two, minus(times(y, z), times(x, w)))],
    [times(two, minus(times(x, z), times(y, w))), times(two, plus(times(y, z), times(x, w))), minus(s, times(two, plus(times(x, x), times(y, y))))]
  ];
  return {
    box: box3,
    centre: vector(box3.positionM),
    half: vector(box3.halfExtentsM),
    axes: [0, 1, 2].map((i) => rows.map((row) => over(row[i], s)))
  };
}
var addN = (a2, b2) => a2.map((x, i) => x + b2[i]);
var subN = (a2, b2) => a2.map((x, i) => x - b2[i]);
var scaleN = (a2, s) => a2.map((x) => x * s);
var dotN = (a2, b2) => a2.reduce((s, x, i) => s + x * b2[i], 0);
var crossN = (a2, b2) => [a2[1] * b2[2] - a2[2] * b2[1], a2[2] * b2[0] - a2[0] * b2[2], a2[0] * b2[1] - a2[1] * b2[0]];
function rawAxes(box3) {
  const axis = box3.orientationXYZW.slice(0, 3), w = box3.orientationXYZW[3];
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((v) => {
    const t = scaleN(crossN(axis, v), 2);
    return addN(v, addN(scaleN(t, w), crossN(axis, t)));
  });
}
function select(pair2, counts) {
  const aa = rawAxes(pair2.a), bb = rawAxes(pair2.b), delta = subN(pair2.b.positionM, pair2.a.positionM);
  const axes = [...aa, ...bb, ...aa.flatMap((a2) => bb.map((b2) => crossN(a2, b2)))];
  let selected2 = null;
  for (let index = 0; index < 15; index++) {
    counts.axisVisits++;
    const length = Math.hypot(...axes[index]);
    if (length < 1e-12) continue;
    const axis = scaleN(axes[index], 1 / length);
    const ra = aa.reduce((sum, basis2, i) => sum + pair2.a.halfExtentsM[i] * Math.abs(dotN(basis2, axis)), 0);
    const rb = bb.reduce((sum, basis2, i) => sum + pair2.b.halfExtentsM[i] * Math.abs(dotN(basis2, axis)), 0);
    const distance = dotN(delta, axis), overlap = ra + rb - Math.abs(distance);
    if (!Number.isFinite(overlap)) throw new Unresolved("NONFINITE_SAT");
    if (overlap < -1e-12) return null;
    if (!selected2 || overlap < selected2.overlap) {
      const feature = index < 6 ? { kind: "FACE", owner: index < 3 ? "a" : "b", axis: index % 3, index } : { kind: "EDGE", axisA: Math.floor((index - 6) / 3), axisB: (index - 6) % 3, index };
      selected2 = { feature, overlap, normal: scaleN(axis, distance < 0 ? -1 : 1) };
    }
  }
  if (!selected2) throw new Unresolved("NO_SAT_AXIS");
  return selected2;
}
function inside(body, p) {
  const delta = vminus(p, body.centre);
  return body.axes.every((axis, i) => compare(absolute(dot(delta, axis)), body.half[i]) <= 0);
}
function certificate(a2, b2, p, r, normal) {
  if (!inside(a2, p) || !inside(b2, r)) throw new Unresolved("NATIVE_TWELVE_HALFSPACE_FAILURE");
  if (cross(vminus(r, p), normal).some((x) => x.n !== 0n)) throw new Unresolved("NONPARALLEL_NATIVE_WITNESSES");
  return { a: p, b: r, midpoint: vscale(vplus(p, r), over(O, word(2))) };
}
function nativeLineInterval(body, origin, direction) {
  const offset = vminus(origin, body.centre);
  let lo = null, hi = null;
  for (let axis = 0; axis < 3; axis++) {
    const start = dot(offset, body.axes[axis]), speed = dot(direction, body.axes[axis]);
    if (speed.n === 0n) {
      if (compare(absolute(start), body.half[axis]) > 0) return null;
      continue;
    }
    const first = over(minus(neg(body.half[axis]), start), speed);
    const second = over(minus(body.half[axis], start), speed);
    const lower = compare(first, second) <= 0 ? first : second;
    const upper = compare(first, second) <= 0 ? second : first;
    if (lo === null || compare(lower, lo) > 0) lo = lower;
    if (hi === null || compare(upper, hi) < 0) hi = upper;
    if (lo !== null && hi !== null && compare(lo, hi) > 0) return null;
  }
  return lo === null || hi === null ? null : { lo, hi };
}
function certifyPresentation(a2, b2, point2, endpointA, endpointB, normal) {
  const p = vector(point2), n = vector(normal);
  const ia = nativeLineInterval(a2, p, n), ib = nativeLineInterval(b2, p, n);
  if (!ia || !ib) throw new Unresolved("FLOAT_PRESENTATION_LINE_MISSES_NATIVE_BOX");
  const limitSquared = q(1n, 1000000000000000000000000n);
  for (const [endpoint, time] of [[endpointA, ia.hi], [endpointB, ib.lo]]) {
    const residual = vminus(vector(endpoint), vplus(p, vscale(n, time)));
    if (compare(dot(residual, residual), limitSquared) > 0) {
      throw new Unresolved("FLOAT_PRESENTATION_NATIVE_EXIT_RESIDUAL");
    }
  }
}
function clip(polygon, centre, axis, half) {
  const result = [];
  for (let i = 0; i < polygon.length; i++) {
    const current = polygon[i], next = polygon[(i + 1) % polygon.length];
    const a2 = minus(dot(vminus(current, centre), axis), half), b2 = minus(dot(vminus(next, centre), axis), half);
    if (a2.n <= 0n) result.push(current);
    if (a2.n <= 0n !== b2.n <= 0n) {
      const t = over(a2, minus(a2, b2));
      if (compare(t, Z) < 0 || compare(t, O) > 0) throw new Unresolved("CLIP_EXTRAPOLATION");
      result.push(vplus(current, vscale(vminus(next, current), t)));
    }
  }
  return result.filter((point2, i) => result.findIndex((other) => same(point2, other)) === i);
}
function face(a2, b2, selected2, feature) {
  const reference = feature.owner === "a" ? a2 : b2, incident = feature.owner === "a" ? b2 : a2;
  const towardIncident = feature.owner === "a" ? selected2.normal : scaleN(selected2.normal, -1);
  const side = dotN(numberVector(reference.axes[feature.axis]), towardIncident) < 0 ? -1 : 1;
  const n = vscale(reference.axes[feature.axis], word(side));
  const normal = feature.owner === "a" ? n : vscale(n, word(-1));
  const centre = vplus(reference.centre, vscale(n, reference.half[feature.axis]));
  let incidentAxis = 0;
  for (let i = 1; i < 3; i++) if (compare(absolute(dot(incident.axes[i], n)), absolute(dot(incident.axes[incidentAxis], n))) > 0) incidentAxis = i;
  const incidentSide = dot(incident.axes[incidentAxis], n).n > 0n ? -1 : 1;
  const incidentCentre = vplus(incident.centre, vscale(incident.axes[incidentAxis], times(word(incidentSide), incident.half[incidentAxis])));
  const tangents = [0, 1, 2].filter((i) => i !== incidentAxis);
  let polygon = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => vplus(
    vplus(incidentCentre, vscale(incident.axes[tangents[0]], times(word(u), incident.half[tangents[0]]))),
    vscale(incident.axes[tangents[1]], times(word(v), incident.half[tangents[1]]))
  ));
  const referenceTangents = [0, 1, 2].filter((i) => i !== feature.axis);
  for (const i of referenceTangents) {
    polygon = clip(polygon, centre, reference.axes[i], reference.half[i]);
    polygon = clip(polygon, centre, vscale(reference.axes[i], word(-1)), reference.half[i]);
  }
  if (!polygon.length) throw new Unresolved("EMPTY_NATIVE_FACE_PATCH");
  const candidates = polygon.map((p) => ({ p, separation: dot(vminus(p, centre), n) }));
  const penetrating = candidates.filter((x) => x.separation.n <= 0n);
  const minimum = candidates.reduce((best, x) => compare(x.separation, best.separation) < 0 ? x : best);
  const active2 = penetrating.length ? penetrating : candidates.filter((x) => compare(x.separation, minimum.separation) === 0);
  let points = active2.map(({ p, separation }) => {
    const referencePoint = vminus(p, vscale(n, separation));
    return feature.owner === "a" ? certificate(a2, b2, referencePoint, p, normal) : certificate(a2, b2, p, referencePoint, normal);
  });
  if (points.length > 4) points = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => points.reduce((best, point2) => {
    const score = (x) => plus(
      times(word(u), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[0]])),
      times(word(v), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[1]]))
    );
    return compare(score(point2), score(best)) > 0 ? point2 : best;
  }));
  points = points.filter((point2, i) => points.findIndex((other) => same(point2.midpoint, other.midpoint)) === i);
  points.sort((p, r) => compare(dot(p.midpoint, reference.axes[referenceTangents[0]]), dot(r.midpoint, reference.axes[referenceTangents[0]])) || compare(dot(p.midpoint, reference.axes[referenceTangents[1]]), dot(r.midpoint, reference.axes[referenceTangents[1]])));
  return { normal, points };
}
function supportEdge(body, axis, direction) {
  let centre = body.centre;
  for (let i = 0; i < 3; i++) if (i !== axis) {
    const sign = dot(body.axes[i], direction).n < 0n ? -1 : 1;
    centre = vplus(centre, vscale(body.axes[i], times(word(sign), body.half[i])));
  }
  const extent = vscale(body.axes[axis], body.half[axis]);
  return [vminus(centre, extent), vplus(centre, extent)];
}
var clamp = (x) => compare(x, Z) < 0 ? Z : compare(x, O) > 0 ? O : x;
function edge(a2, b2, selected2, feature) {
  let normal = cross(a2.axes[feature.axisA], b2.axes[feature.axisB]);
  if (dot(normal, normal).n === 0n) throw new Unresolved("ZERO_NATIVE_EDGE_AXIS");
  if (dotN(numberVector(normal), selected2.normal) < 0) normal = vscale(normal, word(-1));
  const [p, p1] = supportEdge(a2, feature.axisA, normal), [r, r1] = supportEdge(b2, feature.axisB, vscale(normal, word(-1)));
  const u = vminus(p1, p), v = vminus(r1, r), w = vminus(p, r);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v), dd = dot(u, w), ee = dot(v, w);
  const determinant = minus(times(aa, cc), times(bb, bb));
  const parameters = [];
  if (determinant.n > 0n) {
    const s = over(minus(times(bb, ee), times(cc, dd)), determinant);
    const t = over(minus(times(aa, ee), times(bb, dd)), determinant);
    if (compare(s, Z) >= 0 && compare(s, O) <= 0 && compare(t, Z) >= 0 && compare(t, O) <= 0) parameters.push([s, t]);
  }
  for (const s of [Z, O]) parameters.push([s, clamp(over(plus(ee, times(bb, s)), cc))]);
  for (const t of [Z, O]) parameters.push([clamp(over(minus(times(bb, t), dd), aa)), t]);
  const pairs = parameters.map(([s, t]) => ({ a: vplus(p, vscale(u, s)), b: vplus(r, vscale(v, t)) }));
  const best = pairs.reduce((old, x) => compare(dot(vminus(x.b, x.a), vminus(x.b, x.a)), dot(vminus(old.b, old.a), vminus(old.b, old.a))) < 0 ? x : old);
  return { normal, points: [certificate(a2, b2, best.a, best.b, normal)] };
}
var encoded = (a2) => a2.map((x) => `${x.n}/${x.d}`);
function boxContact(pair2) {
  let selected2 = null;
  let construction = null;
  let presentationPointId = null;
  const counts = { axisVisits: 0 };
  try {
    const a2 = native(pair2.a), b2 = native(pair2.b);
    selected2 = select(pair2, counts);
    if (!selected2) return { status: "MISS", points: [], ...counts };
    const result = selected2.feature.kind === "FACE" ? face(a2, b2, selected2, selected2.feature) : edge(a2, b2, selected2, selected2.feature);
    const normalWord = numberVector(result.normal), length = Math.hypot(...normalWord);
    if (!(length > 0) || !Number.isFinite(length)) throw new Unresolved("INVALID_NORMAL_OUTPUT");
    const normal = scaleN(normalWord, 1 / length);
    const points = result.points.map((p, i) => ({
      id: `${selected2.feature.kind}:${selected2.feature.index}:${i}`,
      pointM: numberVector(p.midpoint),
      aPointM: numberVector(p.a),
      bPointM: numberVector(p.b),
      exact: { a: encoded(p.a), b: encoded(p.b), midpoint: encoded(p.midpoint) },
      nativeHalfspacesCertified: 12
    }));
    construction = { exactNormalDirection: encoded(result.normal), normal, points };
    for (const point2 of points) {
      presentationPointId = point2.id;
      certifyPresentation(a2, b2, point2.pointM, point2.aPointM, point2.bPointM, normal);
    }
    presentationPointId = null;
    return {
      status: "HIT",
      feature: selected2.feature,
      satNormal: selected2.normal,
      satOverlap: selected2.overlap,
      normal,
      exactNormalDirection: encoded(result.normal),
      points,
      ...counts,
      geometry: "EXACT_NORMALIZED_QUATERNION_NATIVE_ENDPOINTS",
      phase: "INPUT_POSES_ONLY"
    };
  } catch (error2) {
    if (!(error2 instanceof Unresolved)) throw error2;
    return {
      status: "UNRESOLVED",
      feature: selected2?.feature ?? null,
      reason: error2.message,
      points: [],
      ...counts,
      phase: "INPUT_POSES_ONLY",
      stage: construction ? "FLOAT_PRESENTATION" : "NATIVE_CONSTRUCTION",
      presentationPointId,
      construction
    };
  }
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/B/candidate.ts
var Unresolved2 = class extends Error {
};
var BIT_LIMIT2 = 16384;
var Z2 = { n: 0n, d: 1n };
var O2 = { n: 1n, d: 1n };
var bits2 = (x) => (x < 0n ? -x : x).toString(2).length;
function check2(x) {
  if (bits2(x) > BIT_LIMIT2) throw new Unresolved2("EXACT_BIT_LIMIT");
  return x;
}
function product2(a2, b2) {
  if (a2 !== 0n && b2 !== 0n && bits2(a2) + bits2(b2) > BIT_LIMIT2) throw new Unresolved2("EXACT_PRODUCT_BIT_LIMIT");
  return check2(a2 * b2);
}
function q2(n, d = 1n) {
  if (d === 0n) throw new Unresolved2("ZERO_EXACT_DENOMINATOR");
  if (n === 0n) return Z2;
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  check2(n);
  check2(d);
  let a2 = n < 0n ? -n : n, b2 = d;
  while (b2 !== 0n) {
    const next = a2 % b2;
    a2 = b2;
    b2 = next;
  }
  return { n: n / a2, d: d / a2 };
}
var neg2 = (a2) => ({ n: -a2.n, d: a2.d });
var plus2 = (a2, b2) => q2(check2(product2(a2.n, b2.d) + product2(b2.n, a2.d)), product2(a2.d, b2.d));
var minus2 = (a2, b2) => plus2(a2, neg2(b2));
var times2 = (a2, b2) => q2(product2(a2.n, b2.n), product2(a2.d, b2.d));
var over2 = (a2, b2) => q2(product2(a2.n, b2.d), product2(a2.d, b2.n));
var compare2 = (a2, b2) => {
  const d = minus2(a2, b2).n;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var absolute2 = (a2) => a2.n < 0n ? neg2(a2) : a2;
function word2(value) {
  if (!Number.isFinite(value)) throw new Unresolved2("NONFINITE_INPUT");
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false), e = Number(raw >> 52n & 2047n);
  const m = (raw & 0xfffffffffffffn | (e ? 0x10000000000000n : 0n)) * (raw >> 63n ? -1n : 1n);
  const power = e ? e - 1075 : -1074;
  return power < 0 ? q2(m, 1n << BigInt(-power)) : q2(m << BigInt(power));
}
function numeric2(a2) {
  const n = a2.n < 0n ? -a2.n : a2.n;
  if (!n) return 0;
  let exponent = bits2(n) - bits2(a2.d);
  const shift = (value2, count) => {
    if (bits2(value2) + count > BIT_LIMIT2) throw new Unresolved2("PRESENTATION_SHIFT_BIT_LIMIT");
    return check2(value2 << BigInt(count));
  };
  if (exponent >= 0 ? n < shift(a2.d, exponent) : shift(n, -exponent) < a2.d) exponent--;
  if (exponent > 1023) throw new Unresolved2("NONFINITE_OUTPUT");
  const unit = Math.max(-1074, exponent - 52);
  const numerator = unit < 0 ? shift(n, -unit) : n;
  const denominator = unit > 0 ? shift(a2.d, unit) : a2.d;
  let significand = numerator / denominator;
  const remainder = numerator % denominator;
  const doubled = check2(remainder + remainder);
  if (doubled > denominator || doubled === denominator && (significand & 1n) !== 0n) significand++;
  const value = Number(significand) * 2 ** unit;
  if (!Number.isFinite(value)) throw new Unresolved2("NONFINITE_OUTPUT");
  return a2.n < 0n ? -value : value;
}
var vector2 = (a2) => a2.map(word2);
var vplus2 = (a2, b2) => a2.map((x, i) => plus2(x, b2[i]));
var vminus2 = (a2, b2) => a2.map((x, i) => minus2(x, b2[i]));
var vscale2 = (a2, t) => a2.map((x) => times2(x, t));
var dot2 = (a2, b2) => a2.reduce((s, x, i) => plus2(s, times2(x, b2[i])), Z2);
var cross2 = (a2, b2) => [
  minus2(times2(a2[1], b2[2]), times2(a2[2], b2[1])),
  minus2(times2(a2[2], b2[0]), times2(a2[0], b2[2])),
  minus2(times2(a2[0], b2[1]), times2(a2[1], b2[0]))
];
var numberVector2 = (a2) => a2.map(numeric2);
var same2 = (a2, b2) => a2.every((x, i) => compare2(x, b2[i]) === 0);
function native2(box3) {
  if (box3.positionM.length !== 3 || box3.halfExtentsM.length !== 3 || box3.orientationXYZW.length !== 4 || box3.positionM.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1e4) || box3.halfExtentsM.some((x2) => !Number.isFinite(x2) || x2 < 1e-4 || x2 > 1e3) || box3.orientationXYZW.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1) || Math.abs(Math.hypot(...box3.orientationXYZW) - 1) > 1e-9) throw new Unresolved2("OUTSIDE_NATIVE_INPUT_PROFILE");
  const [x, y, z, w] = box3.orientationXYZW.map(word2);
  const s = plus2(plus2(times2(x, x), times2(y, y)), plus2(times2(z, z), times2(w, w))), two = word2(2);
  if (s.n === 0n) throw new Unresolved2("ZERO_QUATERNION");
  const rows = [
    [minus2(s, times2(two, plus2(times2(y, y), times2(z, z)))), times2(two, minus2(times2(x, y), times2(z, w))), times2(two, plus2(times2(x, z), times2(y, w)))],
    [times2(two, plus2(times2(x, y), times2(z, w))), minus2(s, times2(two, plus2(times2(x, x), times2(z, z)))), times2(two, minus2(times2(y, z), times2(x, w)))],
    [times2(two, minus2(times2(x, z), times2(y, w))), times2(two, plus2(times2(y, z), times2(x, w))), minus2(s, times2(two, plus2(times2(x, x), times2(y, y))))]
  ];
  return {
    box: box3,
    centre: vector2(box3.positionM),
    half: vector2(box3.halfExtentsM),
    axes: [0, 1, 2].map((i) => rows.map((row) => over2(row[i], s)))
  };
}
var PRESENTATION_SQUARED = q2(1n, 1000000000000000000000000n);
var SURFACE = q2(1n, 1000000000n);
var NORM_GATE = q2(1n, 1000000000000n);
function rational(value) {
  const [n, d] = value.split("/");
  return q2(BigInt(n), d === void 0 ? 1n : BigInt(d));
}
var exactVector = (values) => values.map(rational);
var squaredDistance = (a2, b2) => {
  const delta = vminus2(a2, b2);
  return dot2(delta, delta);
};
var fractionString = (a2) => `${a2.n}/${a2.d}`;
function hex(value) {
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  return data.getBigUint64(0, false).toString(16).padStart(16, "0");
}
function adjacent(value, direction) {
  if (value === 0) return direction * Number.MIN_VALUE;
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false);
  data.setBigUint64(0, raw + BigInt(value > 0 ? direction : -direction), false);
  const result = data.getFloat64(0, false);
  if (!Number.isFinite(result)) throw new Unresolved2("NONFINITE_CELL_BOUND");
  return result === 0 ? 0 : result;
}
function interval(body, origin, direction) {
  const offset = vminus2(origin, body.centre);
  let lo = null, hi = null;
  for (let axis = 0; axis < 3; axis++) {
    const start = dot2(offset, body.axes[axis]), speed = dot2(direction, body.axes[axis]);
    if (speed.n === 0n) {
      if (compare2(absolute2(start), body.half[axis]) > 0) return null;
      continue;
    }
    const first = over2(minus2(neg2(body.half[axis]), start), speed), second = over2(minus2(body.half[axis], start), speed);
    const lower = compare2(first, second) <= 0 ? first : second, upper = compare2(first, second) <= 0 ? second : first;
    if (lo === null || compare2(lower, lo) > 0) lo = lower;
    if (hi === null || compare2(upper, hi) < 0) hi = upper;
    if (lo !== null && hi !== null && compare2(lo, hi) > 0) return null;
  }
  return lo === null || hi === null ? null : { lo, hi };
}
function surface(body, point2, exact3) {
  const local = body.axes.map((axis) => dot2(vminus2(point2, body.centre), axis));
  const offsets = local.map((value, axis) => minus2(absolute2(value), body.half[axis]));
  if (exact3) return offsets.every((x) => x.n <= 0n) && offsets.some((x) => x.n === 0n);
  return offsets.every((x) => compare2(x, SURFACE) <= 0) && offsets.some((x) => compare2(absolute2(x), SURFACE) <= 0);
}
function confirmNative(a2, b2, point2, exactNormal) {
  const pa = exactVector(point2.exact.a), pb = exactVector(point2.exact.b), midpoint2 = exactVector(point2.exact.midpoint);
  if (!surface(a2, pa, true) || !surface(b2, pb, true) || !same2(vscale2(vplus2(pa, pb), over2(O2, word2(2))), midpoint2) || cross2(vminus2(pb, pa), exactNormal).some((x) => x.n !== 0n)) throw new Unresolved2("NATIVE_CERTIFICATE_FAILURE");
  const ia = interval(a2, midpoint2, exactNormal), ib = interval(b2, midpoint2, exactNormal);
  if (!ia || !ib || !same2(vplus2(midpoint2, vscale2(exactNormal, ia.hi)), pa) || !same2(vplus2(midpoint2, vscale2(exactNormal, ib.lo)), pb)) throw new Unresolved2("NATIVE_LINE_EXIT_FAILURE");
  return { pa, pb, midpoint: midpoint2 };
}
function feasibility(a2, b2, anchor, midpoint2, af, bf, normal, nearTouch) {
  if (compare2(squaredDistance(anchor, midpoint2), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "MIDPOINT_DISTANCE" };
  const n2 = dot2(normal, normal);
  for (const endpoint of [af, bf]) {
    const delta = vminus2(endpoint, anchor), projected = vscale2(normal, over2(dot2(delta, normal), n2));
    if (compare2(dot2(vminus2(delta, projected), vminus2(delta, projected)), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NORMAL_LINE_DISTANCE" };
  }
  const ia = interval(a2, anchor, normal), ib = interval(b2, anchor, normal);
  if (!ia || !ib) return { feasible: false, reason: !ia ? "NATIVE_LINE_MISS_A" : "NATIVE_LINE_MISS_B" };
  if (compare2(squaredDistance(af, vplus2(anchor, vscale2(normal, ia.hi))), PRESENTATION_SQUARED) > 0 || compare2(squaredDistance(bf, vplus2(anchor, vscale2(normal, ib.lo))), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NATIVE_EXIT_DISTANCE" };
  if (nearTouch && compare2(times2(times2(minus2(ib.lo, ia.hi), minus2(ib.lo, ia.hi)), n2), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NATIVE_PAIRED_GAP" };
  return { feasible: true, reason: "FEASIBLE", intervals: [ia, ib] };
}
function quantizedContact(pair2) {
  const counts = { geometryCalls: 0, pointsAttempted: 0, anchorChecks: 0 };
  const completedPoints = [];
  let generated = null, currentCell = [];
  let geometryStatus = "", feature = null, pointId = null;
  try {
    counts.geometryCalls++;
    const base = boxContact(pair2);
    geometryStatus = base.status;
    feature = base.feature ?? null;
    if (base.status === "MISS") return { status: "MISS", points: [], counts, sourceGeometryStatus: geometryStatus };
    generated = base.status === "HIT" ? base : base.stage === "FLOAT_PRESENTATION" ? base.construction ?? null : null;
    if (!generated) throw new Unresolved2("SOURCE_NATIVE_CONSTRUCTION_UNRESOLVED:" + base.reason);
    if (generated.points.length > 96) throw new Unresolved2("POINT_BUDGET");
    const a2 = native2(pair2.a), b2 = native2(pair2.b), exactNormal = exactVector(generated.exactNormalDirection), normal = vector2(generated.normal);
    if (compare2(absolute2(minus2(dot2(normal, normal), O2)), NORM_GATE) > 0) throw new Unresolved2("PUBLIC_NORMAL_NORM");
    for (const original of generated.points) {
      counts.pointsAttempted++;
      pointId = original.id;
      currentCell = [];
      const { pa, pb, midpoint: midpoint2 } = confirmNative(a2, b2, original, exactNormal);
      const rounded = numberVector2(midpoint2).map((x) => x === 0 ? 0 : x);
      const aPointM = numberVector2(pa), bPointM = numberVector2(pb), af = vector2(aPointM), bf = vector2(bPointM);
      if (compare2(squaredDistance(af, pa), PRESENTATION_SQUARED) > 0 || compare2(squaredDistance(bf, pb), PRESENTATION_SQUARED) > 0 || !surface(a2, af, false) || !surface(b2, bf, false)) throw new Unresolved2("FIXED_ENDPOINT_PRESENTATION");
      const nearTouch = compare2(squaredDistance(pa, pb), PRESENTATION_SQUARED) <= 0;
      const grid = rounded.map((x) => [adjacent(x, -1), x, adjacent(x, 1)]);
      let best = null;
      for (const x of grid[0]) for (const y of grid[1]) for (const z of grid[2]) {
        if (++counts.anchorChecks > 2592) throw new Unresolved2("ANCHOR_BUDGET");
        const anchor = [x, y, z], key = anchor.map(hex).join(":");
        const exactAnchor = vector2(anchor), score = squaredDistance(exactAnchor, midpoint2);
        const check4 = feasibility(a2, b2, exactAnchor, midpoint2, af, bf, normal, nearTouch);
        currentCell.push({ anchor, words: anchor.map(hex), feasible: check4.feasible, reason: check4.reason });
        if (check4.feasible && (!best || compare2(score, best.score) < 0 || compare2(score, best.score) === 0 && key < best.key)) {
          best = { anchor, key, score, intervals: check4.intervals };
        }
      }
      if (!best) throw new Unresolved2("CELL_INFEASIBLE");
      completedPoints.push({
        id: original.id,
        pointM: best.anchor,
        aPointM,
        bPointM,
        exact: original.exact,
        nativeHalfspacesCertified: 12,
        idealRoundedMidpoint: rounded,
        selectedDistanceSquaredExact: fractionString(best.score),
        selectedWordKey: best.key,
        selectedIntervals: best.intervals.map((i) => ({ lower: fractionString(i.lo), upper: fractionString(i.hi) })),
        nearTouch,
        cell: currentCell,
        nearestScope: "COMPLETE_FROZEN_27_MEMBER_CELL_ONLY"
      });
    }
    return {
      status: "HIT",
      feature,
      normal: generated.normal,
      exactNormalDirection: generated.exactNormalDirection,
      points: completedPoints,
      counts,
      sourceGeometryStatus: geometryStatus,
      geometry: "EXACT_NATIVE_WITH_DIRECT_FINITE_CELL_PRESENTATION",
      phase: "INPUT_POSES_ONLY",
      oldSingleRoundedMidpointProtocol: "UNCHANGED_NO_GO",
      globalNearest: "NOT_CLAIMED"
    };
  } catch (error2) {
    if (!(error2 instanceof Unresolved2)) throw error2;
    return {
      status: "UNRESOLVED",
      feature,
      pointId,
      reason: error2.message,
      points: [],
      counts,
      completedPoints,
      currentCell,
      generatedExactConstruction: generated,
      sourceGeometryStatus: geometryStatus,
      globalInfeasibility: "NOT_CLAIMED"
    };
  }
}
function representedNativeLine(pair2, anchorM, normal) {
  const a2 = native2(pair2.a), b2 = native2(pair2.b), anchor = vector2(anchorM), n = vector2(normal), ia = interval(a2, anchor, n), ib = interval(b2, anchor, n);
  if (!ia || !ib) throw new Error("PRODUCER_NATIVE_LINE_UNRESOLVED");
  const gap = numeric2(minus2(ib.lo, ia.hi)) * Math.sqrt(numeric2(dot2(n, n)));
  if (!Number.isFinite(gap)) throw new Error("PRODUCER_NATIVE_GAP_NONFINITE");
  return { pointOnAM: numberVector2(vplus2(anchor, vscale2(n, ia.hi))), pointOnBM: numberVector2(vplus2(anchor, vscale2(n, ib.lo))), signedGapM: gap };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/phase-hit.ts
function record(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function vector3(value) {
  return Array.isArray(value) && value.length === 3 && value.every((x) => typeof x === "number" && Number.isFinite(x));
}
function stringVector(value) {
  return Array.isArray(value) && value.length === 3 && value.every((x) => typeof x === "string");
}
function point(value) {
  return record(value) && typeof value.id === "string" && vector3(value.pointM) && vector3(value.aPointM) && vector3(value.bPointM) && record(value.exact) && stringVector(value.exact.a) && stringVector(value.exact.b) && stringVector(value.exact.midpoint);
}
function box(value) {
  return record(value) && typeof value.id === "string" && vector3(value.positionM) && vector3(value.halfExtentsM) && Array.isArray(value.orientationXYZW) && value.orientationXYZW.length === 4 && value.orientationXYZW.every((x) => typeof x === "number" && Number.isFinite(x));
}
function pair(value) {
  return record(value) && typeof value.id === "string" && box(value.a) && box(value.b);
}
function hitResult(value) {
  return record(value) && value.status === "HIT" && vector3(value.normal) && record(value.feature) && (value.feature.kind === "FACE" || value.feature.kind === "EDGE") && Array.isArray(value.points) && value.points.length >= 1 && value.points.length <= 4 && value.points.every(point);
}
function checkedPhaseHit(normal, penetration, pointM, queryId, result, queryPair) {
  if (!vector3(normal) || typeof penetration !== "number" || !Number.isFinite(penetration) || penetration < 0 || !vector3(pointM) || typeof queryId !== "number" || !Number.isSafeInteger(queryId) || queryId <= 0 || !hitResult(result) || !pair(queryPair)) {
    throw new PhysicsError("NUMERIC_LIMIT", "invalid typed private geometry-hit boundary");
  }
  return { normal, penetration, pointM, _phase: { queryId, result, pair: queryPair } };
}
function isPhaseHit(hit) {
  return "_phase" in hit && record(hit._phase) && hitResult(hit._phase.result) && pair(hit._phase.pair) && typeof hit._phase.queryId === "number" && Number.isSafeInteger(hit._phase.queryId) && hit._phase.queryId > 0;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/private-phase.ts
var clone = (x) => structuredClone(x);
var phaseLimits = { worlds: 4, attempts: 8, records: 8192, applications: 4352, queries: 72, queryPoints: 288, anchorChecks: 7776, bytes: 16 * 1024 * 1024 - 65536 };
var contexts = [];
var active = null;
var records = 0;
var applications = 0;
var queries = 0;
var queryPoints = 0;
var anchorChecks = 0;
var traceBytes = 0;
var attempts = 0;
var unknownMarker = new Error("PRIVATE_PHASE_AFTER_ACTUAL_CANDIDATE_IMPULSE");
function refuse(message) {
  throw new PhysicsError("NUMERIC_LIMIT", message);
}
function bodyWords(b2) {
  return clone({ id: b2.id, kind: b2.kind, shape: b2.shape, positionM: b2.positionM, orientationXYZW: b2.orientation, velocityMps: b2.velocityMps, angularVelocityRadps: b2.angularVelocityRadps, inertiaKgM2: b2.inertiaKgM2 ?? null, inertiaDiagonalKgM2: b2.inertiaDiagonalKgM2 ?? null, inverseMass: b2.inverseMass });
}
function emit(kind, data) {
  if (!active) throw Error("No private phase attempt");
  const record6 = { kind, world: active.id, attempt: active.current.attempt, stepIndex: active.current.stepIndex, owner: active.current.attempt === 0 ? "creation" : "step", outerPass: active.current.pass, ...clone(data) };
  const size = new TextEncoder().encode(JSON.stringify(record6)).length;
  if (records + 1 > phaseLimits.records || traceBytes + size > phaseLimits.bytes) refuse("PRIVATE_PHASE_TRACE_RESOURCE");
  active.current.records.push(record6);
  records++;
  traceBytes += size;
  return record6;
}
function phaseWorld(read) {
  if (contexts.length >= phaseLimits.worlds) refuse("PRIVATE_PHASE_WORLD_CAP");
  const c = { id: contexts.length + 1, read, accepted: { cursor: 0, stepIndex: 0, cacheFrames: {} }, current: null, history: [], fault: null };
  contexts.push(c);
  return c;
}
function phaseInitial(c, prepare) {
  const previous = active;
  active = c;
  c.creation = { attempt: 0, stepIndex: 0, pass: -1, records: [], cacheFrames: {}, cacheOrigins: {}, point: null, kind: null, fault: null };
  c.current = c.creation;
  try {
    const value = prepare();
    c.accepted = { ...c.accepted, cursor: c.creation.records.length };
    return value;
  } finally {
    c.current = null;
    active = previous;
  }
}
function phaseBegin(c, stepIndex, bodies) {
  if (++attempts > phaseLimits.attempts) refuse("PRIVATE_PHASE_ATTEMPT_CAP");
  active = c;
  c.current = { attempt: attempts, stepIndex, pass: -1, records: [], cacheFrames: {}, cacheOrigins: {}, point: null, kind: null, fault: c.fault };
  c.history.push(c.current);
  emit("attempt-start", { acceptedCursor: c.accepted.cursor, bodies: bodies.map(bodyWords) });
}
function phaseBody(kind, before, after, extra = {}) {
  emit(kind, { before, after: bodyWords(after), ...extra });
}
function phasePass(pass) {
  active.current.pass = pass;
}
function box2(b2) {
  return { id: b2.id, positionM: [...b2.positionM], orientationXYZW: [...b2.orientation], halfExtentsM: [...b2.shape.halfExtentsM] };
}
function phaseQuery(a2, b2, final = false) {
  if (!final && active.current.fault === "known") refuse("PRIVATE_B_FAULT_BEFORE_APPLICATION");
  if (queries + 1 > phaseLimits.queries) refuse("PRIVATE_B_QUERY_CAP");
  const pair2 = { id: `w${active.id}-a${active.current.attempt}-q${queries + 1}`, a: box2(a2), b: box2(b2) };
  const result = quantizedContact(pair2);
  queries++;
  queryPoints += result.points?.length ?? 0;
  anchorChecks += result.counts?.anchorChecks ?? 0;
  if (queryPoints > phaseLimits.queryPoints || anchorChecks > phaseLimits.anchorChecks) refuse("PRIVATE_B_POINT_ANCHOR_CAP");
  const projectedDepthM = result.status === "HIT" ? Math.max(0, ...result.points.map((p) => -p.bPointM.reduce((s, v, i) => s + (v - p.aPointM[i]) * result.normal[i], 0))) : null;
  const record6 = emit("geometry-query", { queryId: queries, final, pair: pair2, result, projectedDepthM, depthMapping: "SAMPLED_PATCH_DEPTH", bodyA: bodyWords(a2), bodyB: bodyWords(b2) });
  if (result.status === "UNRESOLVED") refuse("PRIVATE_B_UNRESOLVED:" + result.reason);
  if (result.status === "MISS") return null;
  if (result.status !== "HIT" || !["FACE", "EDGE"].includes(result.feature?.kind) || !result.points.length || result.points.length > 4) refuse("PRIVATE_B_UNSUPPORTED_POINT_LIST");
  const n = result.normal;
  const penetration = projectedDepthM;
  return checkedPhaseHit([...n], penetration, [...result.points[0].pointM], record6.queryId, result, pair2);
}
function phaseCacheInit(key, point2, normal, hit, impulse, prior) {
  const old = active.accepted.cacheFrames[key] ?? null;
  active.current.cacheOrigins[key] = prior ? "prior-step" : "cold";
  emit("cache-init", { key, pointId: point2.id, queryId: hit._phase.queryId, feature: hit._phase.result.feature, normal, prior: prior ?? null, producingFrame: old, actualCache: impulse });
}
function phasePoint(key, point2, normal, hit, impulse, iteration, order) {
  active.current.point = { key, pointId: point2.id, queryId: hit._phase.queryId, feature: clone(hit._phase.result.feature), queryPair: clone(hit._phase.pair), native: clone(point2.exact), aPointM: clone(point2.aPointM), bPointM: clone(point2.bPointM), normal: clone(normal), iteration, order, cacheOrigin: active.current.cacheOrigins[key] ?? "current-pass", producingFrame: clone(active.current.cacheFrames[key] ?? active.accepted.cacheFrames[key] ?? null), cacheBefore: clone(impulse), impulse };
}
function phaseKind(kind, branch = {}) {
  active.current.kind = kind;
  active.current.branch = clone(branch);
}
function phaseApplyBefore(a2, b2, p, j) {
  if (applications + 1 > phaseLimits.applications) refuse("PRIVATE_APPLY_CAP");
  return { pointM: clone(p), anchorOnAM: clone(p), anchorOnBM: clone(p), impulseOnANs: j.map((v) => -v), impulseOnBNs: clone(j), bodyABefore: bodyWords(a2), bodyBBefore: bodyWords(b2) };
}
function phaseApplyAfter(token, a2, b2) {
  applications++;
  const point2 = active.current.point;
  if (!point2) throw Error("Missing actual point/cache context");
  const { impulse, queryPair, ...metadata3 } = point2;
  emit("impulse-application", { ...metadata3, eventKind: active.current.kind, branch: active.current.branch, ...token, bodyAAfter: bodyWords(a2), bodyBAfter: bodyWords(b2), cacheAfter: clone(impulse) });
  active.current.cacheFrames[point2.key] = { normal: clone(point2.normal), feature: clone(point2.feature), pointId: point2.pointId, native: clone(point2.native), pair: clone(queryPair), queryId: point2.queryId };
  point2.cacheBefore = clone(impulse);
  point2.producingFrame = clone(active.current.cacheFrames[point2.key]);
}
function phaseNoNormal() {
  emit("normal-zero-no-call", { key: active.current.point?.key, normal: active.current.point?.normal });
}
function phaseCorrectionBefore(a2, b2, n, depth) {
  return { queryId: active.current.point.queryId, feature: clone(active.current.point.feature), bodyABefore: bodyWords(a2), bodyBBefore: bodyWords(b2), normal: clone(n), penetration: depth };
}
function phaseCorrectionAfter(token, a2, b2) {
  emit("pose-correction", { ...token, bodyAAfter: bodyWords(a2), bodyBAfter: bodyWords(b2) });
}
function phasePrepare(c, cache) {
  const prepared = { cursor: c.accepted.cursor + c.current.records.length, stepIndex: c.current.stepIndex, cacheFrames: clone(c.current.cacheFrames), actualCache: clone([...cache]) };
  emit("attempt-prepared", { candidateAcceptedCursor: prepared.cursor, cache: prepared.actualCache });
  prepared.cursor++;
  return prepared;
}
function phasePrivateSnapshot(worldId) {
  const c = contexts[worldId - 1];
  return clone({ accepted: c.accepted, world: c.read() });
}
function phaseFault(worldId, mode) {
  contexts[worldId - 1].fault = mode;
}
function phaseHistory() {
  return clone({ counts: { worlds: contexts.length, attempts, records, applications, queries, queryPoints, anchorChecks, traceBytes }, worlds: contexts.map((c) => ({ id: c.id, accepted: c.accepted, creation: c.creation ? (({ point: point2, ...rest }) => rest)(c.creation) : null, history: c.history.map(({ point: point2, ...rest }) => rest) })) });
}
function phaseProducerBucket(key, map, contribution) {
  if (active.current.fault === "unknown" && contribution.nonzero) {
    const bucket = map.get(key);
    if (!bucket) throw Error("Unknown fault must follow actual producer bucket mutation");
    emit("producer-bucket-mutated-before-unknown", { key, contributionNonzero: true, bucket: clone(bucket) });
    throw unknownMarker;
  }
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/producer.ts
var sides = ["onA", "onB"];
var fields = ["linearImpulseNs", "angularImpulseAboutWorldOriginNms"];
var zero = () => ({ linearImpulseNs: [0, 0, 0], angularImpulseAboutWorldOriginNms: [0, 0, 0] });
var add = (a2, b2) => [a2[0] + b2[0], a2[1] + b2[1], a2[2] + b2[2]];
var cross3 = (a2, b2) => [a2[1] * b2[2] - a2[2] * b2[1], a2[2] * b2[0] - a2[0] * b2[2], a2[0] * b2[1] - a2[1] * b2[0]];
var emptyContribution = () => ({ nonzero: false, onA: zero(), onB: zero() });
function actualContribution(anchor, actualImpulseOnB) {
  const actualImpulseOnA = [-actualImpulseOnB[0], -actualImpulseOnB[1], -actualImpulseOnB[2]];
  const result = { nonzero: actualImpulseOnB.some((v) => v !== 0), onA: { linearImpulseNs: [...actualImpulseOnA], angularImpulseAboutWorldOriginNms: cross3(anchor, actualImpulseOnA) }, onB: { linearImpulseNs: [...actualImpulseOnB], angularImpulseAboutWorldOriginNms: cross3(anchor, actualImpulseOnB) } };
  checkContribution(result);
  return result;
}
function checkContribution(value) {
  for (const side of sides) for (const key of fields) if (value[side][key].length !== 3 || value[side][key].some((v) => !Number.isFinite(v))) throw new PhysicsError("NUMERIC_LIMIT", "unsafe producer contact contribution");
}
function combineContribution(a2, b2) {
  checkContribution(a2);
  checkContribution(b2);
  const result = { nonzero: a2.nonzero || b2.nonzero, onA: zero(), onB: zero() };
  for (const side of sides) for (const key of fields) result[side][key] = add(a2[side][key], b2[side][key]);
  checkContribution(result);
  return result;
}
function colliderId(ids2, id) {
  const value = ids2.get(id);
  if (value === void 0) throw new PhysicsError("NUMERIC_LIMIT", "missing producer collider identity");
  return value;
}
function addPairContribution(map, a2, b2, colliderIds, value) {
  checkContribution(value);
  if (!value.nonzero) return;
  const key = a2.id + "\0" + b2.id;
  let entry = map.get(key);
  if (!entry) {
    entry = { colliderAId: colliderId(colliderIds, a2.id), colliderBId: colliderId(colliderIds, b2.id), bodyAId: a2.id, bodyBId: b2.id, onA: zero(), onB: zero() };
    map.set(key, entry);
  }
  for (const side of sides) for (const field2 of fields) entry[side][field2] = add(entry[side][field2], value[side][field2]);
  checkContribution(entry);
  phaseProducerBucket(key, map, value);
}
function copyPairWrenches(map) {
  return [...map.entries()].sort(([a2], [b2]) => a2 < b2 ? -1 : a2 > b2 ? 1 : 0).map(([, v]) => structuredClone(v));
}
function acceptedGeometry(bodies, pairs, colliderIds) {
  const contacts = [];
  for (const [ai, bi] of pairs) {
    const a2 = bodies[ai], b2 = bodies[bi], hit = phaseQuery(a2, b2, true);
    if (!hit) continue;
    const pair2 = hit._phase.pair;
    const points = hit._phase.result.points.map((point2) => {
      let native3;
      try {
        native3 = representedNativeLine(pair2, point2.pointM, hit.normal);
      } catch (error2) {
        throw new PhysicsError("NUMERIC_LIMIT", "accepted native line/gap refused: " + (error2 instanceof Error ? error2.message : String(error2)));
      }
      return { id: point2.id, normalAtoB: [...hit.normal], anchorM: [...point2.pointM], pointOnAM: native3.pointOnAM, pointOnBM: native3.pointOnBM, signedGapM: native3.signedGapM };
    }).sort((a3, b3) => a3.id < b3.id ? -1 : a3.id > b3.id ? 1 : 0);
    if (points.some((p) => !Number.isFinite(p.signedGapM))) throw new PhysicsError("NUMERIC_LIMIT", "unsafe accepted native gap");
    contacts.push({ colliderAId: colliderId(colliderIds, a2.id), colliderBId: colliderId(colliderIds, b2.id), bodyAId: a2.id, bodyBId: b2.id, points });
  }
  return contacts.sort((a2, b2) => a2.bodyAId < b2.bodyAId ? -1 : a2.bodyAId > b2.bodyAId ? 1 : a2.bodyBId < b2.bodyBId ? -1 : a2.bodyBId > b2.bodyBId ? 1 : 0);
}
function acceptedMembership(contacts) {
  return new Map(contacts.map((c) => [c.bodyAId + "\0" + c.bodyBId, { aId: c.bodyAId, bId: c.bodyBId, kind: "contact" }]));
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/identity.ts
function copyData(input) {
  let count = 0;
  function copy(value, depth) {
    if (++count > 1e6 || depth > 32) throw new PhysicsError("INVALID_CONFIG", "data exceeds bounded depth or size");
    if (value === null || typeof value === "boolean") return value;
    if (typeof value === "string") {
      for (const character of value) {
        const point2 = character.codePointAt(0);
        if (point2 >= 55296 && point2 <= 57343) throw new PhysicsError("INVALID_CONFIG", "strings must be well-formed Unicode");
      }
      return value;
    }
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || value === null) throw new PhysicsError("INVALID_CONFIG", "only finite plain data is supported");
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Reflect.ownKeys(value);
    if (Array.isArray(value)) {
      if (Object.getPrototypeOf(value) !== Array.prototype || keys.length !== value.length + 1 || !Array.from({ length: value.length }, (_, i) => descriptors[i]?.enumerable && "value" in descriptors[i]).every(Boolean)) {
        throw new PhysicsError("INVALID_CONFIG", "arrays must be dense ordinary data arrays");
      }
      return Array.from({ length: value.length }, (_, i) => copy(descriptors[i].value, depth + 1));
    }
    if (Object.getPrototypeOf(value) !== Object.prototype || keys.some((key) => typeof key !== "string" || !/^[\x20-\x7e]+$/.test(key) || !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
      throw new PhysicsError("INVALID_CONFIG", "records must have plain ASCII data fields");
    }
    return Object.fromEntries(keys.map((key) => [key, copy(descriptors[key].value, depth + 1)]));
  }
  return copy(input, 0);
}
function canonicalEncode(input) {
  const value = copyData(input);
  const bytes = [];
  const encodeUtf8 = (text2) => {
    const result = [];
    for (const character of text2) {
      let point2 = character.codePointAt(0);
      if (point2 >= 55296 && point2 <= 57343) point2 = 65533;
      if (point2 < 128) result.push(point2);
      else if (point2 < 2048) result.push(192 | point2 >> 6, 128 | point2 & 63);
      else if (point2 < 65536) result.push(224 | point2 >> 12, 128 | point2 >> 6 & 63, 128 | point2 & 63);
      else result.push(240 | point2 >> 18, 128 | point2 >> 12 & 63, 128 | point2 >> 6 & 63, 128 | point2 & 63);
    }
    return result;
  };
  const uint32 = (number2) => {
    for (let i = 0; i < 4; i++) bytes.push(number2 >>> i * 8 & 255);
  };
  function write(item) {
    if (item === null) {
      bytes.push(0);
      return;
    }
    if (typeof item === "boolean") {
      bytes.push(item ? 2 : 1);
      return;
    }
    if (typeof item === "string") {
      const encoded2 = encodeUtf8(item);
      bytes.push(3);
      uint32(encoded2.length);
      for (const byte of encoded2) bytes.push(byte);
      return;
    }
    if (typeof item === "number") {
      bytes.push(4);
      const data = new DataView(new ArrayBuffer(8));
      data.setFloat64(0, item, true);
      for (let i = 0; i < 8; i++) bytes.push(data.getUint8(i));
      return;
    }
    if (Array.isArray(item)) {
      bytes.push(5);
      uint32(item.length);
      for (const entry of item) write(entry);
      return;
    }
    const record6 = item;
    const keys = Object.keys(record6).sort();
    bytes.push(6);
    uint32(keys.length);
    for (const key of keys) {
      write(key);
      write(record6[key]);
    }
  }
  write(value);
  return Uint8Array.from(bytes);
}
var K = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
var rotate = (x, n) => x >>> n | x << 32 - n;
function sha256(bytes) {
  const padded = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  const bits3 = bytes.length * 8;
  view.setUint32(padded.length - 8, Math.floor(bits3 / 4294967296));
  view.setUint32(padded.length - 4, bits3 >>> 0);
  const h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4);
    for (let i = 16; i < 64; i++) {
      const a3 = w[i - 15], b3 = w[i - 2];
      w[i] = w[i - 16] + (rotate(a3, 7) ^ rotate(a3, 18) ^ a3 >>> 3) + w[i - 7] + (rotate(b3, 17) ^ rotate(b3, 19) ^ b3 >>> 10) >>> 0;
    }
    let [a2, b2, c, d, e, f, g, j] = h;
    for (let i = 0; i < 64; i++) {
      const t1 = j + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
      const t2 = (rotate(a2, 2) ^ rotate(a2, 13) ^ rotate(a2, 22)) + (a2 & b2 ^ a2 & c ^ b2 & c) >>> 0;
      j = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b2;
      b2 = a2;
      a2 = t1 + t2 >>> 0;
    }
    for (const [i, v] of [a2, b2, c, d, e, f, g, j].entries()) h[i] = h[i] + v >>> 0;
  }
  return `sha256:${h.map((word3) => word3.toString(16).padStart(8, "0")).join("")}`;
}
function digest(value) {
  return sha256(canonicalEncode(value));
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/limits.ts
var ID = /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/;
var MAX_STEPS = 3600;
var MAX_STEP_DISPLACEMENT_M = 10;
var MAX_COMMANDS = 64;
var MAX_FORCE_N = 1e6;
var MAX_IMPULSE_NS = 1e5;
var MAX_TORQUE_NM = 1e6;
var MAX_ANGULAR_IMPULSE_NMS = 1e5;
var SOLVER_PASSES = 8;

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/validation.ts
function error(code, message) {
  throw new PhysicsError(code, message);
}
function record2(value, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) error("INVALID_CONFIG", `${label} must be an object`);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) error("INVALID_CONFIG", `${label} must be a plain object`);
  return value;
}
function fields2(value, allowed, label) {
  if (Reflect.ownKeys(value).some((key) => typeof key !== "string" || !allowed.includes(key))) {
    error("INVALID_CONFIG", `${label} has an unsupported field`);
  }
}
function finite(value, min, max, label) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max) {
    error("INVALID_CONFIG", `${label} must be finite and in [${min}, ${max}]`);
  }
  return value;
}
function vector4(value, min, max, label) {
  if (!Array.isArray(value) || value.length !== 3) error("INVALID_CONFIG", `${label} must be a 3-vector`);
  return [0, 1, 2].map((index) => finite(value[index], min, max, `${label}[${index}]`));
}
function angularVector(value) {
  if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "angularVelocityRadps must be a dense 3-vector");
  }
  return vector4(value, -1e3, 1e3, "angularVelocityRadps");
}
function quaternion(value) {
  if (!Array.isArray(value) || value.length !== 4 || Reflect.ownKeys(value).length !== 5 || ![0, 1, 2, 3].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "orientation must be a dense [x,y,z,w] quaternion");
  }
  const values = value.map((component) => finite(component, -1, 1, "orientation"));
  const magnitude2 = Math.hypot(...values);
  if (Math.abs(magnitude2 - 1) > 1e-6) error("INVALID_CONFIG", "orientation must have unit norm");
  return values.map((component) => component / magnitude2);
}
function shape(value) {
  const input = record2(value, "shape");
  if (input.kind === "sphere") {
    fields2(input, ["kind", "radiusM"], "sphere");
    return { kind: "sphere", radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM") };
  }
  if (input.kind === "box") {
    fields2(input, ["kind", "halfExtentsM"], "box");
    return { kind: "box", halfExtentsM: vector4(input.halfExtentsM, 1e-4, 1e3, "halfExtentsM") };
  }
  if (input.kind === "capsule") {
    fields2(input, ["kind", "radiusM", "halfLengthM"], "capsule");
    return {
      kind: "capsule",
      radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM"),
      halfLengthM: finite(input.halfLengthM, 1e-4, 1e3, "halfLengthM")
    };
  }
  return error("INVALID_CONFIG", "unsupported collider shape");
}
function friction(value) {
  const input = record2(value, "friction");
  fields2(input, ["static", "dynamic"], "friction");
  const staticCoefficient = finite(input.static, 0, 2, "friction.static");
  const dynamicCoefficient = finite(input.dynamic, 0, staticCoefficient, "friction.dynamic");
  return { static: staticCoefficient, dynamic: dynamicCoefficient };
}
function collisionFilter(value) {
  const input = record2(value, "collisionFilter");
  fields2(input, ["categoryBits", "maskBits"], "collisionFilter");
  if (!Number.isInteger(input.categoryBits) || !Number.isInteger(input.maskBits)) {
    error("INVALID_CONFIG", "collision filter bits must be integers");
  }
  return {
    categoryBits: finite(input.categoryBits, 1, 65535, "categoryBits"),
    maskBits: finite(input.maskBits, 0, 65535, "maskBits")
  };
}
function parseBody(value, largeMode = false) {
  const input = record2(value, "body");
  if (typeof input.id !== "string" || !ID.test(input.id)) error("INVALID_CONFIG", "invalid body ID");
  if (input.kind !== "dynamic" && input.kind !== "static" && input.kind !== "kinematic") {
    error("INVALID_CONFIG", "invalid body kind");
  }
  const kind = input.kind;
  fields2(input, kind === "dynamic" ? [
    "id",
    "kind",
    "shape",
    "positionM",
    "velocityMps",
    "massKg",
    "restitution",
    "orientation",
    "angularVelocityRadps",
    "inertiaKgM2",
    "friction",
    "ccd",
    ...largeMode ? ["collisionFilter"] : []
  ] : [
    "id",
    "kind",
    "shape",
    "positionM",
    "restitution",
    "orientation",
    "sensor",
    "friction",
    ...largeMode ? ["collisionFilter"] : []
  ], "body");
  if (Object.hasOwn(input, "sensor") && input.sensor !== true) error("INVALID_CONFIG", "sensor must be true");
  const sensor = input.sensor === true;
  const parsedShape = shape(input.shape);
  if (Object.hasOwn(input, "ccd") && (input.ccd !== true || parsedShape.kind !== "sphere" && parsedShape.kind !== "box")) {
    error("INVALID_CONFIG", "ccd is supported for dynamic spheres or boxes only and must be true");
  }
  const positionM = vector4(input.positionM, -1e4, 1e4, "positionM");
  const restitution = finite(input.restitution, 0, 1, "restitution");
  const material = Object.hasOwn(input, "friction") ? friction(input.friction) : { static: 0, dynamic: 0 };
  const filter = largeMode ? Object.hasOwn(input, "collisionFilter") ? collisionFilter(input.collisionFilter) : { categoryBits: 1, maskBits: 65535 } : void 0;
  const orientation = Object.hasOwn(input, "orientation") ? quaternion(input.orientation) : [0, 0, 0, 1];
  if (kind !== "dynamic") {
    return {
      id: input.id,
      kind,
      shape: parsedShape,
      positionM,
      velocityMps: [0, 0, 0],
      orientation,
      angularVelocityRadps: [0, 0, 0],
      inverseInertiaLocal: [0, 0, 0],
      sensor,
      inverseMass: 0,
      restitution,
      frictionStatic: material.static,
      frictionDynamic: material.dynamic,
      ...filter ? { collisionFilter: filter } : {}
    };
  }
  const massKg = finite(input.massKg, 1e-6, 1e6, "massKg");
  if (parsedShape.kind !== "sphere" && Object.hasOwn(input, "inertiaKgM2")) {
    error("INVALID_CONFIG", "inertiaKgM2 override is supported for spheres only");
  }
  const inertiaKgM2 = parsedShape.kind === "sphere" ? Object.hasOwn(input, "inertiaKgM2") ? finite(input.inertiaKgM2, 1e-12, 1e12, "inertiaKgM2") : 0.4 * massKg * parsedShape.radiusM ** 2 : void 0;
  const inertiaDiagonalKgM2 = parsedShape.kind === "box" ? [
    massKg / 3 * (parsedShape.halfExtentsM[1] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[1] ** 2)
  ] : parsedShape.kind === "capsule" ? capsuleMoments(massKg, parsedShape.radiusM, parsedShape.halfLengthM) : void 0;
  const inertia2 = inertiaDiagonalKgM2 ?? [inertiaKgM2, inertiaKgM2, inertiaKgM2];
  return {
    id: input.id,
    kind,
    shape: parsedShape,
    positionM,
    sensor,
    ...filter ? { collisionFilter: filter, sleeping: false } : {},
    ...input.ccd === true ? { ccd: true } : {},
    velocityMps: vector4(input.velocityMps, -1e3, 1e3, "velocityMps"),
    orientation,
    angularVelocityRadps: Object.hasOwn(input, "angularVelocityRadps") ? angularVector(input.angularVelocityRadps) : [0, 0, 0],
    ...inertiaKgM2 === void 0 ? {} : { inertiaKgM2 },
    ...inertiaDiagonalKgM2 === void 0 ? {} : { inertiaDiagonalKgM2 },
    inverseInertiaLocal: inertia2.map((value2) => 1 / value2),
    inverseMass: 1 / massKg,
    restitution,
    frictionStatic: material.static,
    frictionDynamic: material.dynamic
  };
}
function capsuleMoments(massKg, radiusM, halfLengthM) {
  const cylinderMass = massKg * (3 * halfLengthM) / (3 * halfLengthM + 2 * radiusM);
  const capMass = massKg - cylinderMass;
  const radiusSquared = radiusM * radiusM;
  const axial = cylinderMass * radiusSquared / 2 + capMass * 2 * radiusSquared / 5;
  const transverse = cylinderMass * (radiusSquared / 4 + halfLengthM * halfLengthM / 3) + capMass * (2 * radiusSquared / 5 + halfLengthM * halfLengthM + 3 * halfLengthM * radiusM / 4);
  return [transverse, axial, transverse];
}
function copyShape(value) {
  return value.kind === "sphere" ? { kind: "sphere", radiusM: value.radiusM } : value.kind === "box" ? { kind: "box", halfExtentsM: [...value.halfExtentsM] } : { kind: "capsule", radiusM: value.radiusM, halfLengthM: value.halfLengthM };
}
function copyBody(body) {
  return {
    ...body,
    shape: copyShape(body.shape),
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    orientation: [...body.orientation],
    angularVelocityRadps: [...body.angularVelocityRadps],
    ...body.collisionFilter ? { collisionFilter: { ...body.collisionFilter } } : {},
    ...body.inertiaDiagonalKgM2 ? { inertiaDiagonalKgM2: [...body.inertiaDiagonalKgM2] } : {},
    inverseInertiaLocal: [...body.inverseInertiaLocal]
  };
}
function commandVector(input, bound, label) {
  if (!Array.isArray(input) || input.length !== 3 || Reflect.ownKeys(input).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(input, index))) {
    error("INVALID_COMMAND", `${label} must be a dense 3-vector`);
  }
  const result = [input[0], input[1], input[2]];
  if (result.some((value) => typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > bound)) {
    error("INVALID_COMMAND", `${label} must have finite components within \xB1${bound}`);
  }
  return result;
}
function parseCommands(input, bodies) {
  if (!Array.isArray(input) || input.length > MAX_COMMANDS || Reflect.ownKeys(input).length !== input.length + 1 || !Array.from({ length: input.length }, (_, index) => Object.hasOwn(input, index)).every(Boolean)) {
    error("INVALID_COMMAND", `commands must be a dense array of at most ${MAX_COMMANDS}`);
  }
  const byId = new Map(bodies.map((body) => [body.id, body]));
  const admitted = /* @__PURE__ */ new Map();
  for (const [index, raw] of input.entries()) {
    if (raw === null || typeof raw !== "object" || Array.isArray(raw) || Object.getPrototypeOf(raw) !== Object.prototype && Object.getPrototypeOf(raw) !== null) {
      error("INVALID_COMMAND", `command ${index} must be a plain object`);
    }
    const descriptors = Object.getOwnPropertyDescriptors(raw);
    const keys = Reflect.ownKeys(raw);
    const kind = descriptors.kind?.value;
    const valueKey = kind === "force" ? "forceN" : kind === "impulse" ? "impulseNs" : kind === "torque" ? "torqueNm" : kind === "angularImpulse" ? "angularImpulseNms" : kind === "kinematicTarget" ? "positionM" : null;
    if (!valueKey || keys.length !== 3 || keys.some((key) => typeof key !== "string" || !["kind", "bodyId", valueKey].includes(key)) || ["kind", "bodyId", valueKey].some((key) => !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
      error("INVALID_COMMAND", `command ${index} has unsupported fields`);
    }
    const bodyId = descriptors.bodyId.value;
    const body = typeof bodyId === "string" ? byId.get(bodyId) : void 0;
    if (!body || (kind === "kinematicTarget" ? body.kind !== "kinematic" : body.kind !== "dynamic")) {
      error("INVALID_COMMAND", `command ${index} targets an unknown or unsupported body`);
    }
    const previous = admitted.get(body.id) ?? {};
    if (Object.hasOwn(previous, valueKey)) error("INVALID_COMMAND", `duplicate ${kind} command for ${body.id}`);
    const bound = kind === "force" ? MAX_FORCE_N : kind === "impulse" ? MAX_IMPULSE_NS : kind === "torque" ? MAX_TORQUE_NM : kind === "angularImpulse" ? MAX_ANGULAR_IMPULSE_NMS : 1e4;
    const value = commandVector(descriptors[valueKey].value, bound, `command ${index}.${valueKey}`);
    admitted.set(body.id, { ...previous, [valueKey]: value });
  }
  return admitted;
}
function queryRecord(input, required, optional) {
  if (input === null || typeof input !== "object" || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype && Object.getPrototypeOf(input) !== null) {
    error("INVALID_QUERY", "query must be a plain object");
  }
  const descriptors = Object.getOwnPropertyDescriptors(input);
  const keys = Reflect.ownKeys(input);
  if (keys.some((key) => typeof key !== "string" || ![...required, ...optional].includes(key)) || required.some((key) => !Object.hasOwn(descriptors, key)) || keys.some((key) => !descriptors[key]?.enumerable || !("value" in descriptors[key]))) {
    error("INVALID_QUERY", "query has missing or unsupported fields");
  }
  return Object.fromEntries(keys.map((key) => [key, descriptors[key].value]));
}
function queryVector(input, bound, label) {
  if (!Array.isArray(input) || input.length !== 3 || Reflect.ownKeys(input).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(input, index))) {
    error("INVALID_QUERY", `${label} must be a dense 3-vector`);
  }
  const values = [input[0], input[1], input[2]];
  if (values.some((value) => typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > bound)) {
    error("INVALID_QUERY", `${label} components must be finite within \xB1${bound}`);
  }
  return values;
}
function queryNumber(input, min, max, label) {
  if (typeof input !== "number" || !Number.isFinite(input) || input < min || input > max) {
    error("INVALID_QUERY", `${label} must be finite and in [${min}, ${max}]`);
  }
  return input;
}
function includeSensors(query) {
  if (!Object.hasOwn(query, "includeSensors")) return true;
  if (typeof query.includeSensors !== "boolean") error("INVALID_QUERY", "includeSensors must be boolean");
  return query.includeSensors;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/math.ts
function multiplyQuaternion(a2, b2) {
  const [ax, ay, az, aw] = a2, [bx, by, bz, bw] = b2;
  return [
    aw * bx + ax * bw + ay * bz - az * by,
    aw * by - ax * bz + ay * bw + az * bx,
    aw * bz + ax * by - ay * bx + az * bw,
    aw * bw - ax * bx - ay * by - az * bz
  ];
}
function advanceOrientation(orientation, angularVelocity, dt) {
  const speed = Math.hypot(...angularVelocity);
  if (speed === 0) return [...orientation];
  const halfAngle = speed * dt / 2;
  const scale4 = Math.sin(halfAngle) / speed;
  const delta = [
    angularVelocity[0] * scale4,
    angularVelocity[1] * scale4,
    angularVelocity[2] * scale4,
    Math.cos(halfAngle)
  ];
  const next = multiplyQuaternion(delta, orientation);
  const norm2 = Math.hypot(...next);
  return next.map((component) => component / norm2);
}
var add2 = (a2, b2) => a2.map((value, index) => value + b2[index]);
var sub = (a2, b2) => a2.map((value, index) => value - b2[index]);
var scale = (a2, value) => a2.map((component) => component * value);
var dot3 = (a2, b2) => a2.reduce((sum, value, index) => sum + value * b2[index], 0);
var cross4 = (a2, b2) => [a2[1] * b2[2] - a2[2] * b2[1], a2[2] * b2[0] - a2[0] * b2[2], a2[0] * b2[1] - a2[1] * b2[0]];
var inverse = (q3) => [-q3[0], -q3[1], -q3[2], q3[3]];
function rotate2(q3, v) {
  const axis = [q3[0], q3[1], q3[2]];
  const t = scale(cross4(axis, v), 2);
  return add2(v, add2(scale(t, q3[3]), cross4(axis, t)));
}
var localPoint = (body, point2) => rotate2(inverse(body.orientation), sub(point2, body.positionM));
var worldPoint = (body, point2) => add2(body.positionM, rotate2(body.orientation, point2));
function inverseInertia(body, vector6) {
  const local = rotate2(inverse(body.orientation), vector6);
  return rotate2(body.orientation, local.map((value, index) => value * body.inverseInertiaLocal[index]));
}
function inertia(body, vector6) {
  const local = rotate2(inverse(body.orientation), vector6);
  return rotate2(body.orientation, local.map((value, index) => value / body.inverseInertiaLocal[index]));
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/dynamic-anchor-pair.ts
function solvePairMatrix(columns, target) {
  const rows = [0, 1, 2].map((row) => [
    columns[0][row],
    columns[1][row],
    columns[2][row],
    target[row]
  ]);
  for (let column = 0; column < 3; column++) {
    let pivot = column;
    for (let row = column + 1; row < 3; row++) {
      if (Math.abs(rows[row][column]) > Math.abs(rows[pivot][column])) pivot = row;
    }
    if (!Number.isFinite(rows[pivot][column]) || Math.abs(rows[pivot][column]) < 1e-12) {
      error("NUMERIC_LIMIT", "dynamic pair effective mass is singular");
    }
    [rows[column], rows[pivot]] = [rows[pivot], rows[column]];
    const divisor = rows[column][column];
    for (let index = column; index < 4; index++) rows[column][index] /= divisor;
    for (let row = 0; row < 3; row++) {
      if (row === column) continue;
      const factor = rows[row][column];
      for (let index = column; index < 4; index++) rows[row][index] -= factor * rows[column][index];
    }
  }
  const result = rows.map((row) => row[3]);
  if (result.some((value) => !Number.isFinite(value))) {
    error("NUMERIC_LIMIT", "dynamic pair correction is not finite");
  }
  return result;
}
function applyPairAngle(body, angle2, dt) {
  if (Math.hypot(...angle2) > 1) error("NUMERIC_LIMIT", "dynamic pair angular correction exceeds limit");
  body.orientation = advanceOrientation(body.orientation, angle2, 1);
  body.angularVelocityRadps = add2(body.angularVelocityRadps, scale(angle2, 1 / dt));
}
function projectDynamicPairAnchors(a2, b2, anchorA, anchorB, dt) {
  const armA = rotate2(a2.orientation, anchorA);
  const armB = rotate2(b2.orientation, anchorB);
  const separation = sub(worldPoint(b2, anchorB), worldPoint(a2, anchorA));
  if (Math.hypot(...separation) > MAX_STEP_DISPLACEMENT_M) {
    error("NUMERIC_LIMIT", "dynamic pair anchor separation exceeds limit");
  }
  const basis2 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const columns = basis2.map((axis) => add2(
    scale(axis, a2.inverseMass + b2.inverseMass),
    add2(
      cross4(inverseInertia(a2, cross4(armA, axis)), armA),
      cross4(inverseInertia(b2, cross4(armB, axis)), armB)
    )
  ));
  const correction = solvePairMatrix(columns, scale(separation, -1));
  const moveA = scale(correction, -a2.inverseMass);
  const moveB = scale(correction, b2.inverseMass);
  a2.positionM = add2(a2.positionM, moveA);
  b2.positionM = add2(b2.positionM, moveB);
  a2.velocityMps = add2(a2.velocityMps, scale(moveA, 1 / dt));
  b2.velocityMps = add2(b2.velocityMps, scale(moveB, 1 / dt));
  applyPairAngle(a2, scale(inverseInertia(a2, cross4(armA, correction)), -1), dt);
  applyPairAngle(b2, inverseInertia(b2, cross4(armB, correction)), dt);
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/dynamic-fixed-joint.ts
function orientationError(actual, desired) {
  const relative = multiplyQuaternion(actual, inverse(desired));
  const sign = relative[3] < 0 ? -1 : 1;
  const vector6 = scale([relative[0], relative[1], relative[2]], sign);
  const sine = Math.hypot(...vector6);
  if (sine < 1e-12) return scale(vector6, 2);
  return scale(vector6, 2 * Math.atan2(sine, sign * relative[3]) / sine);
}
function projectDynamicFixedJoint(joint, bodies, dt) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const beforeLinear = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  const desired = multiplyQuaternion(a2.orientation, joint.referenceOrientation);
  const angularError = orientationError(b2.orientation, desired);
  if (Math.hypot(...angularError) > 1) {
    error("NUMERIC_LIMIT", "dynamic fixed joint relative orientation exceeds limit");
  }
  const basis2 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const angularColumns = basis2.map((axis) => add2(inverseInertia(a2, axis), inverseInertia(b2, axis)));
  const angularImpulse = solvePairMatrix(angularColumns, scale(angularError, -1));
  applyPairAngle(a2, scale(inverseInertia(a2, angularImpulse), -1), dt);
  applyPairAngle(b2, inverseInertia(b2, angularImpulse), dt);
  projectDynamicPairAnchors(a2, b2, joint.anchorALocalM, joint.anchorBLocalM, dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeLinear), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular))
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/dynamic-hinge-joint.ts
var magnitude = (vector6) => Math.hypot(...vector6);
var near = (a2, b2) => magnitude(sub(a2, b2)) <= 1e-9;
function offsetFixture(joint, a2, b2) {
  return near(a2.positionM, [-0.1, 0, 0]) && near(b2.positionM, [0.1, 0, 0]) && near(joint.anchorALocalM, [0.1, 0, 0]) && near(joint.anchorBLocalM, [-0.1, 0, 0]) && near(joint.axisWorld, [0, 0, 1]) && Math.abs(joint.limitRad[0] + 0.8) <= 1e-9 && Math.abs(joint.limitRad[1] - 0.8) <= 1e-9 && a2.inverseMass === 1 && b2.inverseMass === 1 && a2.shape.kind === "sphere" && b2.shape.kind === "sphere" && a2.shape.radiusM === 0.1 && b2.shape.radiusM === 0.1 && joint.motor?.targetSpeedRadps === 0.5 && joint.motor.maxImpulseNms === 1e-4 && joint.motor.maxReactionNms === 0.01;
}
function admitDynamicHingeScene(joint, bodies, gravity) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const identity3 = [0, 0, 0, 1];
  const centred = near(a2.positionM, b2.positionM) && magnitude(joint.anchorALocalM) === 0 && magnitude(joint.anchorBLocalM) === 0;
  if (magnitude(gravity) !== 0 || !centred && !offsetFixture(joint, a2, b2) || [a2, b2].some((body) => magnitude(body.velocityMps) !== 0 || magnitude(body.angularVelocityRadps) !== 0 || body.orientation.some((value, index) => Math.abs(value - identity3[index]) > 1e-12))) {
    error("INVALID_CONFIG", "dynamic hinge needs an admitted resting pair and zero gravity");
  }
}
function admitDynamicHingeCommands(joint, bodies, actions) {
  const axis = joint.axisWorld;
  for (const bodyIndex of [joint.aIndex, joint.bIndex]) {
    const action = actions.get(bodies[bodyIndex].id);
    if (!action) continue;
    if (action.forceN || action.impulseNs || [action.torqueNm, action.angularImpulseNms].filter((vector6) => vector6 !== void 0).some((vector6) => magnitude(sub(vector6, scale(axis, dot3(vector6, axis)))) > 1e-12)) {
      error("INVALID_COMMAND", "dynamic hinge admits axis-aligned angular commands only");
    }
  }
}
function projectDynamicHingeJoint(joint, bodies, dt) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
  const axis = joint.axisWorld;
  const beforeLinear = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  const relative = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const signed = dot3([relative[0], relative[1], relative[2]], axis);
  if (magnitude(sub([relative[0], relative[1], relative[2]], scale(axis, signed))) > 1e-8) {
    error("NUMERIC_LIMIT", "dynamic hinge left its planar axis");
  }
  const raw = 2 * Math.atan2(signed, relative[3]);
  const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
  const angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
  const inverseA = dot3(axis, inverseInertia(a2, axis));
  const inverseB = dot3(axis, inverseInertia(b2, axis));
  const inverseSum = inverseA + inverseB;
  const excess = wrapped - angleRad;
  if (excess !== 0) {
    const angleA = excess * inverseA / inverseSum;
    const angleB = -excess * inverseB / inverseSum;
    a2.orientation = advanceOrientation(a2.orientation, scale(axis, angleA), 1);
    b2.orientation = advanceOrientation(b2.orientation, scale(axis, angleB), 1);
    a2.angularVelocityRadps = add2(a2.angularVelocityRadps, scale(axis, angleA / dt));
    b2.angularVelocityRadps = add2(b2.angularVelocityRadps, scale(axis, angleB / dt));
  }
  const relativeSpeed = dot3(sub(b2.angularVelocityRadps, a2.angularVelocityRadps), axis);
  if (angleRad === joint.limitRad[0] && relativeSpeed < 0 || angleRad === joint.limitRad[1] && relativeSpeed > 0) {
    const impulse = -relativeSpeed / inverseSum;
    a2.angularVelocityRadps = sub(
      a2.angularVelocityRadps,
      inverseInertia(a2, scale(axis, impulse))
    );
    b2.angularVelocityRadps = add2(
      b2.angularVelocityRadps,
      inverseInertia(b2, scale(axis, impulse))
    );
  }
  projectDynamicPairAnchors(a2, b2, joint.anchorALocalM, joint.anchorBLocalM, dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeLinear), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular)),
    angleRad
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/joints.ts
function denseJointVector(value, bound, label) {
  if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", `${label} must be a dense 3-vector`);
  }
  return vector4(value, -bound, bound, label);
}
function parseJoints(value, bodies) {
  if (!Array.isArray(value) || value.length > 8 || Reflect.ownKeys(value).length !== value.length + 1 || !Array.from({ length: value.length }, (_, index) => Object.hasOwn(value, index)).every(Boolean)) {
    error("INVALID_CONFIG", "joints must be a dense array of at most 8");
  }
  const byId = new Map(bodies.map((body, index) => [body.id, { body, index }]));
  const seenIds = /* @__PURE__ */ new Set(), seenDynamic = /* @__PURE__ */ new Set();
  const joints = value.map((raw) => {
    const input = record2(raw, "joint");
    if (input.kind !== "fixed" && input.kind !== "hinge") error("INVALID_CONFIG", "unsupported joint kind");
    fields2(input, input.kind === "fixed" ? ["id", "kind", "aId", "bId", "anchorALocalM", "anchorBLocalM"] : ["id", "kind", "aId", "bId", "anchorALocalM", "anchorBLocalM", "axisWorld", "limitRad", "motor"], "joint");
    if (typeof input.id !== "string" || !ID.test(input.id) || seenIds.has(input.id)) {
      error("INVALID_CONFIG", "joint IDs must be unique valid identifiers");
    }
    const a2 = typeof input.aId === "string" ? byId.get(input.aId) : void 0;
    const b2 = typeof input.bId === "string" ? byId.get(input.bId) : void 0;
    if (!a2 || !b2 || a2.index === b2.index || b2.body.kind !== "dynamic" || seenDynamic.has(b2.body.id)) {
      error("INVALID_CONFIG", "joint needs a distinct A and unique dynamic B");
    }
    if (a2.body.kind === "dynamic" && (value.length !== 1 || bodies.length !== 2 || a2.body.shape.kind !== "sphere" || b2.body.shape.kind !== "sphere")) {
      error("INVALID_CONFIG", "dynamic pair supports one joint between two dynamic spheres");
    }
    const anchorALocalM = denseJointVector(input.anchorALocalM, 100, "anchorALocalM");
    const anchorBLocalM = denseJointVector(input.anchorBLocalM, 100, "anchorBLocalM");
    if (Math.hypot(...sub(worldPoint(a2.body, anchorALocalM), worldPoint(b2.body, anchorBLocalM))) > 1e-6) {
      error("INVALID_CONFIG", "initial joint anchors must coincide");
    }
    let axisWorld, limitRad;
    let motor;
    if (input.kind === "hinge") {
      axisWorld = denseJointVector(input.axisWorld, 1 + 1e-9, "axisWorld");
      if (Math.abs(Math.hypot(...axisWorld) - 1) > 1e-9) error("INVALID_CONFIG", "hinge axis must be unit length");
      const limits = input.limitRad;
      if (!Array.isArray(limits) || limits.length !== 2 || Reflect.ownKeys(limits).length !== 3 || ![0, 1].every((index) => Object.hasOwn(limits, index))) {
        error("INVALID_CONFIG", "hinge limits must be a dense pair");
      }
      const low = finite(limits[0], -Math.PI / 2, 0, "limitRad[0]");
      const high = finite(limits[1], 0, Math.PI / 2, "limitRad[1]");
      limitRad = [low, high];
      if (Object.hasOwn(input, "motor")) {
        const motorInput = record2(input.motor, "motor");
        fields2(motorInput, ["targetSpeedRadps", "maxImpulseNms", "maxReactionNms"], "motor");
        const targetSpeedRadps = finite(motorInput.targetSpeedRadps, -2, 2, "motor.targetSpeedRadps");
        const maxImpulseNms = finite(motorInput.maxImpulseNms, 0, 0.05, "motor.maxImpulseNms");
        const maxReactionNms = finite(motorInput.maxReactionNms, 0, 1, "motor.maxReactionNms");
        if (maxImpulseNms === 0 || maxReactionNms === 0) {
          error("INVALID_CONFIG", "motor impulse and reaction limits must be positive");
        }
        motor = { targetSpeedRadps, maxImpulseNms, maxReactionNms };
      }
    }
    seenIds.add(input.id);
    seenDynamic.add(b2.body.id);
    return {
      id: input.id,
      kind: input.kind,
      aIndex: a2.index,
      bIndex: b2.index,
      anchorALocalM,
      anchorBLocalM,
      referenceOrientation: input.kind === "fixed" ? multiplyQuaternion(inverse(a2.body.orientation), b2.body.orientation) : [...b2.body.orientation],
      ...axisWorld ? { axisWorld } : {},
      ...limitRad ? { limitRad } : {},
      ...motor ? { motor } : {}
    };
  });
  return joints;
}
function projectJoint(joint, next, previous, dt) {
  const a2 = next[joint.aIndex], b2 = next[joint.bIndex];
  if (a2.kind === "dynamic") return joint.kind === "fixed" ? projectDynamicFixedJoint(joint, next, dt) : projectDynamicHingeJoint(joint, next, dt);
  const beforeVelocity = [...b2.velocityMps];
  const beforeAngular = [...b2.angularVelocityRadps];
  let targetOrientation, angleRad;
  if (joint.kind === "fixed") {
    targetOrientation = multiplyQuaternion(a2.orientation, joint.referenceOrientation);
    b2.angularVelocityRadps = [0, 0, 0];
  } else {
    const axis = joint.axisWorld;
    const delta = multiplyQuaternion(b2.orientation, inverse(joint.referenceOrientation));
    const signed = dot3([delta[0], delta[1], delta[2]], axis);
    const raw = 2 * Math.atan2(signed, delta[3]);
    const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
    angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
    const half = angleRad / 2;
    targetOrientation = multiplyQuaternion([
      axis[0] * Math.sin(half),
      axis[1] * Math.sin(half),
      axis[2] * Math.sin(half),
      Math.cos(half)
    ], joint.referenceOrientation);
    let speed = dot3(b2.angularVelocityRadps, axis);
    if (angleRad === joint.limitRad[0] && speed < 0 || angleRad === joint.limitRad[1] && speed > 0) speed = 0;
    b2.angularVelocityRadps = scale(axis, speed);
  }
  const norm2 = Math.hypot(...targetOrientation);
  b2.orientation = targetOrientation.map((value) => value / norm2);
  const targetPosition = sub(worldPoint(a2, joint.anchorALocalM), rotate2(b2.orientation, joint.anchorBLocalM));
  if (Math.hypot(...sub(targetPosition, b2.positionM)) > MAX_STEP_DISPLACEMENT_M) {
    error("NUMERIC_LIMIT", `${joint.id} projection exceeded movement limit`);
  }
  b2.positionM = targetPosition;
  b2.velocityMps = scale(sub(targetPosition, previous[joint.bIndex].positionM), 1 / dt);
  return {
    id: joint.id,
    kind: joint.kind,
    aId: a2.id,
    bId: b2.id,
    linearImpulseNs: scale(sub(b2.velocityMps, beforeVelocity), 1 / b2.inverseMass),
    angularImpulseNms: inertia(b2, sub(b2.angularVelocityRadps, beforeAngular)),
    ...angleRad === void 0 ? {} : { angleRad }
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/admission.ts
var RESTRICTION = "dynamic pair supports one joint between two dynamic spheres";
var equal = (values, wanted) => values.length === wanted.length && values.every((value, index) => value === wanted[index]);
var refuse2 = () => error("INVALID_CONFIG", RESTRICTION);
function parseDisjointHingeProfile(model, options, inputs, bodies) {
  if (bodies.length !== 4 || bodies.some((body) => body.kind !== "dynamic") || inputs.length !== 2 || inputs.some((input) => input.kind !== "hinge")) return null;
  const byId = new Map(bodies.map((body, index) => [body.id, { body, index }]));
  const seenB = /* @__PURE__ */ new Set();
  const joints = inputs.map((input) => {
    const a2 = typeof input.aId === "string" ? byId.get(input.aId) : void 0;
    const b2 = typeof input.bId === "string" ? byId.get(input.bId) : void 0;
    if (!a2 || !b2 || a2.index === b2.index || seenB.has(b2.body.id)) {
      error("INVALID_CONFIG", "joint needs a distinct A and unique dynamic B");
    }
    const local = parseJoints([input], [a2.body, b2.body])[0];
    seenB.add(b2.body.id);
    return { ...local, aIndex: a2.index, bIndex: b2.index };
  });
  if (options.profile !== "rigid-discrete-v1" || options.broadPhase !== "direct" || options.fixedStepSeconds !== 1 / 120 || !equal(model.gravityMps2, [0, 0, 0]) || model.cloths.length !== 0 || model.fluids.length !== 0 || model.bodies.some((body) => body.kind !== "dynamic" || body.inertia.kind !== "primitive-com" || !body.initial.orientationXYZW.every((component, index) => Object.is(component, index === 3 ? 1 : 0)))) refuse2();
  for (const body of bodies) {
    if (body.shape.kind !== "sphere" || body.shape.radiusM !== 0.1 || body.inverseMass !== 1 || body.inertiaKgM2 !== 0.4 * 0.1 ** 2 || body.restitution !== 0 || body.frictionStatic !== 1 || body.frictionDynamic !== 0.7 || body.sensor || body.ccd || body.collisionFilter || !equal(body.velocityMps, [0, 0, 0]) || !equal(body.angularVelocityRadps, [0, 0, 0]) || !equal(body.orientation, [0, 0, 0, 1])) refuse2();
  }
  const used = /* @__PURE__ */ new Set();
  const pairs = joints.map((joint, jointInputIndex) => {
    const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex];
    if (used.has(joint.aIndex) || used.has(joint.bIndex)) refuse2();
    used.add(joint.aIndex);
    used.add(joint.bIndex);
    const z = a2.positionM[2];
    if (z !== 0 && z !== 1 || !equal(a2.positionM, [-0.1, 0, z]) || !equal(b2.positionM, [0.1, 0, z]) || !equal(joint.anchorALocalM, [0.1, 0, 0]) || !equal(joint.anchorBLocalM, [-0.1, 0, 0]) || !equal(joint.axisWorld, [0, 0, 1]) || !equal(joint.limitRad, [-0.8, 0.8]) || joint.motor?.targetSpeedRadps !== 0.5 || joint.motor.maxImpulseNms !== 1e-4 || joint.motor.maxReactionNms !== 0.01) refuse2();
    return {
      joint: { ...joint, aIndex: 0, bIndex: 1 },
      originM: [0, 0, z],
      bodyIndices: [joint.aIndex, joint.bIndex],
      jointInputIndex
    };
  });
  pairs.sort((a2, b2) => a2.originM[2] - b2.originM[2]);
  if (used.size !== 4 || pairs[0].originM[2] !== 0 || pairs[1].originM[2] !== 1) refuse2();
  return { joints, pairs };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/cloth/profile.ts
var CLOTH_STEP_SECONDS = 1 / 120;
var CLOTH_SUBSTEPS = 8;
var CLOTH_PROFILE = Object.freeze({
  size: 17,
  sideM: 1,
  heightM: 0.55,
  densityKgM2: 0.2,
  dt: CLOTH_STEP_SECONDS / CLOTH_SUBSTEPS,
  gravityMps2: Object.freeze([0, -9.81, 0]),
  velocityDecayPerSecond: 1,
  sphereCentreM: Object.freeze([0, 0.1, 0]),
  sphereRadiusM: 0.3,
  collisionOffsetM: 2e-3,
  stretchComplianceMPerN: 1e-3,
  bendComplianceMPerN: 0.1
});

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/fluid/constants.ts
var FLUID_STEP_SECONDS = 1 / 120;
var FLUID_BASIN_M = [0.7, 1.3, 0.5];
var FLUID_SPACING_M = 0.05;
var FLUID_MIN_SPACING_M = 0.025;
var FLUID_PARTICLE_RADIUS_M = 0.0125;
var FLUID_SMOOTHING_RADIUS_M = 1.8 * FLUID_SPACING_M;

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/fluid/static-box.ts
function inflatedBoxBounds(centerM, halfExtentsM) {
  return {
    low: centerM.map((value, axis) => value - halfExtentsM[axis] - FLUID_PARTICLE_RADIUS_M),
    high: centerM.map((value, axis) => value + halfExtentsM[axis] + FLUID_PARTICLE_RADIUS_M)
  };
}
function insideStaticBox(positions, box3) {
  const { low, high } = box3;
  for (let index = 0; index < positions.length / 3; index++) {
    if ([0, 1, 2].every((axis) => positions[index * 3 + axis] > low[axis] + 1e-9 && positions[index * 3 + axis] < high[axis] - 1e-9)) return true;
  }
  return false;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/domain/cloth-reference.generated.ts
function freeze(value) {
  if (value !== null && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
var nativeClothReference = freeze({ "id": "p5Cloth", "restPositionsM": [[-0.5, 0.55, -0.5], [-0.4375, 0.55, -0.5], [-0.375, 0.55, -0.5], [-0.3125, 0.55, -0.5], [-0.25, 0.55, -0.5], [-0.1875, 0.55, -0.5], [-0.125, 0.55, -0.5], [-0.0625, 0.55, -0.5], [0, 0.55, -0.5], [0.0625, 0.55, -0.5], [0.125, 0.55, -0.5], [0.1875, 0.55, -0.5], [0.25, 0.55, -0.5], [0.3125, 0.55, -0.5], [0.375, 0.55, -0.5], [0.4375, 0.55, -0.5], [0.5, 0.55, -0.5], [-0.5, 0.55, -0.4375], [-0.4375, 0.55, -0.4375], [-0.375, 0.55, -0.4375], [-0.3125, 0.55, -0.4375], [-0.25, 0.55, -0.4375], [-0.1875, 0.55, -0.4375], [-0.125, 0.55, -0.4375], [-0.0625, 0.55, -0.4375], [0, 0.55, -0.4375], [0.0625, 0.55, -0.4375], [0.125, 0.55, -0.4375], [0.1875, 0.55, -0.4375], [0.25, 0.55, -0.4375], [0.3125, 0.55, -0.4375], [0.375, 0.55, -0.4375], [0.4375, 0.55, -0.4375], [0.5, 0.55, -0.4375], [-0.5, 0.55, -0.375], [-0.4375, 0.55, -0.375], [-0.375, 0.55, -0.375], [-0.3125, 0.55, -0.375], [-0.25, 0.55, -0.375], [-0.1875, 0.55, -0.375], [-0.125, 0.55, -0.375], [-0.0625, 0.55, -0.375], [0, 0.55, -0.375], [0.0625, 0.55, -0.375], [0.125, 0.55, -0.375], [0.1875, 0.55, -0.375], [0.25, 0.55, -0.375], [0.3125, 0.55, -0.375], [0.375, 0.55, -0.375], [0.4375, 0.55, -0.375], [0.5, 0.55, -0.375], [-0.5, 0.55, -0.3125], [-0.4375, 0.55, -0.3125], [-0.375, 0.55, -0.3125], [-0.3125, 0.55, -0.3125], [-0.25, 0.55, -0.3125], [-0.1875, 0.55, -0.3125], [-0.125, 0.55, -0.3125], [-0.0625, 0.55, -0.3125], [0, 0.55, -0.3125], [0.0625, 0.55, -0.3125], [0.125, 0.55, -0.3125], [0.1875, 0.55, -0.3125], [0.25, 0.55, -0.3125], [0.3125, 0.55, -0.3125], [0.375, 0.55, -0.3125], [0.4375, 0.55, -0.3125], [0.5, 0.55, -0.3125], [-0.5, 0.55, -0.25], [-0.4375, 0.55, -0.25], [-0.375, 0.55, -0.25], [-0.3125, 0.55, -0.25], [-0.25, 0.55, -0.25], [-0.1875, 0.55, -0.25], [-0.125, 0.55, -0.25], [-0.0625, 0.55, -0.25], [0, 0.55, -0.25], [0.0625, 0.55, -0.25], [0.125, 0.55, -0.25], [0.1875, 0.55, -0.25], [0.25, 0.55, -0.25], [0.3125, 0.55, -0.25], [0.375, 0.55, -0.25], [0.4375, 0.55, -0.25], [0.5, 0.55, -0.25], [-0.5, 0.55, -0.1875], [-0.4375, 0.55, -0.1875], [-0.375, 0.55, -0.1875], [-0.3125, 0.55, -0.1875], [-0.25, 0.55, -0.1875], [-0.1875, 0.55, -0.1875], [-0.125, 0.55, -0.1875], [-0.0625, 0.55, -0.1875], [0, 0.55, -0.1875], [0.0625, 0.55, -0.1875], [0.125, 0.55, -0.1875], [0.1875, 0.55, -0.1875], [0.25, 0.55, -0.1875], [0.3125, 0.55, -0.1875], [0.375, 0.55, -0.1875], [0.4375, 0.55, -0.1875], [0.5, 0.55, -0.1875], [-0.5, 0.55, -0.125], [-0.4375, 0.55, -0.125], [-0.375, 0.55, -0.125], [-0.3125, 0.55, -0.125], [-0.25, 0.55, -0.125], [-0.1875, 0.55, -0.125], [-0.125, 0.55, -0.125], [-0.0625, 0.55, -0.125], [0, 0.55, -0.125], [0.0625, 0.55, -0.125], [0.125, 0.55, -0.125], [0.1875, 0.55, -0.125], [0.25, 0.55, -0.125], [0.3125, 0.55, -0.125], [0.375, 0.55, -0.125], [0.4375, 0.55, -0.125], [0.5, 0.55, -0.125], [-0.5, 0.55, -0.0625], [-0.4375, 0.55, -0.0625], [-0.375, 0.55, -0.0625], [-0.3125, 0.55, -0.0625], [-0.25, 0.55, -0.0625], [-0.1875, 0.55, -0.0625], [-0.125, 0.55, -0.0625], [-0.0625, 0.55, -0.0625], [0, 0.55, -0.0625], [0.0625, 0.55, -0.0625], [0.125, 0.55, -0.0625], [0.1875, 0.55, -0.0625], [0.25, 0.55, -0.0625], [0.3125, 0.55, -0.0625], [0.375, 0.55, -0.0625], [0.4375, 0.55, -0.0625], [0.5, 0.55, -0.0625], [-0.5, 0.55, 0], [-0.4375, 0.55, 0], [-0.375, 0.55, 0], [-0.3125, 0.55, 0], [-0.25, 0.55, 0], [-0.1875, 0.55, 0], [-0.125, 0.55, 0], [-0.0625, 0.55, 0], [0, 0.55, 0], [0.0625, 0.55, 0], [0.125, 0.55, 0], [0.1875, 0.55, 0], [0.25, 0.55, 0], [0.3125, 0.55, 0], [0.375, 0.55, 0], [0.4375, 0.55, 0], [0.5, 0.55, 0], [-0.5, 0.55, 0.0625], [-0.4375, 0.55, 0.0625], [-0.375, 0.55, 0.0625], [-0.3125, 0.55, 0.0625], [-0.25, 0.55, 0.0625], [-0.1875, 0.55, 0.0625], [-0.125, 0.55, 0.0625], [-0.0625, 0.55, 0.0625], [0, 0.55, 0.0625], [0.0625, 0.55, 0.0625], [0.125, 0.55, 0.0625], [0.1875, 0.55, 0.0625], [0.25, 0.55, 0.0625], [0.3125, 0.55, 0.0625], [0.375, 0.55, 0.0625], [0.4375, 0.55, 0.0625], [0.5, 0.55, 0.0625], [-0.5, 0.55, 0.125], [-0.4375, 0.55, 0.125], [-0.375, 0.55, 0.125], [-0.3125, 0.55, 0.125], [-0.25, 0.55, 0.125], [-0.1875, 0.55, 0.125], [-0.125, 0.55, 0.125], [-0.0625, 0.55, 0.125], [0, 0.55, 0.125], [0.0625, 0.55, 0.125], [0.125, 0.55, 0.125], [0.1875, 0.55, 0.125], [0.25, 0.55, 0.125], [0.3125, 0.55, 0.125], [0.375, 0.55, 0.125], [0.4375, 0.55, 0.125], [0.5, 0.55, 0.125], [-0.5, 0.55, 0.1875], [-0.4375, 0.55, 0.1875], [-0.375, 0.55, 0.1875], [-0.3125, 0.55, 0.1875], [-0.25, 0.55, 0.1875], [-0.1875, 0.55, 0.1875], [-0.125, 0.55, 0.1875], [-0.0625, 0.55, 0.1875], [0, 0.55, 0.1875], [0.0625, 0.55, 0.1875], [0.125, 0.55, 0.1875], [0.1875, 0.55, 0.1875], [0.25, 0.55, 0.1875], [0.3125, 0.55, 0.1875], [0.375, 0.55, 0.1875], [0.4375, 0.55, 0.1875], [0.5, 0.55, 0.1875], [-0.5, 0.55, 0.25], [-0.4375, 0.55, 0.25], [-0.375, 0.55, 0.25], [-0.3125, 0.55, 0.25], [-0.25, 0.55, 0.25], [-0.1875, 0.55, 0.25], [-0.125, 0.55, 0.25], [-0.0625, 0.55, 0.25], [0, 0.55, 0.25], [0.0625, 0.55, 0.25], [0.125, 0.55, 0.25], [0.1875, 0.55, 0.25], [0.25, 0.55, 0.25], [0.3125, 0.55, 0.25], [0.375, 0.55, 0.25], [0.4375, 0.55, 0.25], [0.5, 0.55, 0.25], [-0.5, 0.55, 0.3125], [-0.4375, 0.55, 0.3125], [-0.375, 0.55, 0.3125], [-0.3125, 0.55, 0.3125], [-0.25, 0.55, 0.3125], [-0.1875, 0.55, 0.3125], [-0.125, 0.55, 0.3125], [-0.0625, 0.55, 0.3125], [0, 0.55, 0.3125], [0.0625, 0.55, 0.3125], [0.125, 0.55, 0.3125], [0.1875, 0.55, 0.3125], [0.25, 0.55, 0.3125], [0.3125, 0.55, 0.3125], [0.375, 0.55, 0.3125], [0.4375, 0.55, 0.3125], [0.5, 0.55, 0.3125], [-0.5, 0.55, 0.375], [-0.4375, 0.55, 0.375], [-0.375, 0.55, 0.375], [-0.3125, 0.55, 0.375], [-0.25, 0.55, 0.375], [-0.1875, 0.55, 0.375], [-0.125, 0.55, 0.375], [-0.0625, 0.55, 0.375], [0, 0.55, 0.375], [0.0625, 0.55, 0.375], [0.125, 0.55, 0.375], [0.1875, 0.55, 0.375], [0.25, 0.55, 0.375], [0.3125, 0.55, 0.375], [0.375, 0.55, 0.375], [0.4375, 0.55, 0.375], [0.5, 0.55, 0.375], [-0.5, 0.55, 0.4375], [-0.4375, 0.55, 0.4375], [-0.375, 0.55, 0.4375], [-0.3125, 0.55, 0.4375], [-0.25, 0.55, 0.4375], [-0.1875, 0.55, 0.4375], [-0.125, 0.55, 0.4375], [-0.0625, 0.55, 0.4375], [0, 0.55, 0.4375], [0.0625, 0.55, 0.4375], [0.125, 0.55, 0.4375], [0.1875, 0.55, 0.4375], [0.25, 0.55, 0.4375], [0.3125, 0.55, 0.4375], [0.375, 0.55, 0.4375], [0.4375, 0.55, 0.4375], [0.5, 0.55, 0.4375], [-0.5, 0.55, 0.5], [-0.4375, 0.55, 0.5], [-0.375, 0.55, 0.5], [-0.3125, 0.55, 0.5], [-0.25, 0.55, 0.5], [-0.1875, 0.55, 0.5], [-0.125, 0.55, 0.5], [-0.0625, 0.55, 0.5], [0, 0.55, 0.5], [0.0625, 0.55, 0.5], [0.125, 0.55, 0.5], [0.1875, 0.55, 0.5], [0.25, 0.55, 0.5], [0.3125, 0.55, 0.5], [0.375, 0.55, 0.5], [0.4375, 0.55, 0.5], [0.5, 0.55, 0.5]], "initialPositionsM": [[-0.5, 0.55, -0.5], [-0.4375, 0.55, -0.5], [-0.375, 0.55, -0.5], [-0.3125, 0.55, -0.5], [-0.25, 0.55, -0.5], [-0.1875, 0.55, -0.5], [-0.125, 0.55, -0.5], [-0.0625, 0.55, -0.5], [0, 0.55, -0.5], [0.0625, 0.55, -0.5], [0.125, 0.55, -0.5], [0.1875, 0.55, -0.5], [0.25, 0.55, -0.5], [0.3125, 0.55, -0.5], [0.375, 0.55, -0.5], [0.4375, 0.55, -0.5], [0.5, 0.55, -0.5], [-0.5, 0.55, -0.4375], [-0.4375, 0.55, -0.4375], [-0.375, 0.55, -0.4375], [-0.3125, 0.55, -0.4375], [-0.25, 0.55, -0.4375], [-0.1875, 0.55, -0.4375], [-0.125, 0.55, -0.4375], [-0.0625, 0.55, -0.4375], [0, 0.55, -0.4375], [0.0625, 0.55, -0.4375], [0.125, 0.55, -0.4375], [0.1875, 0.55, -0.4375], [0.25, 0.55, -0.4375], [0.3125, 0.55, -0.4375], [0.375, 0.55, -0.4375], [0.4375, 0.55, -0.4375], [0.5, 0.55, -0.4375], [-0.5, 0.55, -0.375], [-0.4375, 0.55, -0.375], [-0.375, 0.55, -0.375], [-0.3125, 0.55, -0.375], [-0.25, 0.55, -0.375], [-0.1875, 0.55, -0.375], [-0.125, 0.55, -0.375], [-0.0625, 0.55, -0.375], [0, 0.55, -0.375], [0.0625, 0.55, -0.375], [0.125, 0.55, -0.375], [0.1875, 0.55, -0.375], [0.25, 0.55, -0.375], [0.3125, 0.55, -0.375], [0.375, 0.55, -0.375], [0.4375, 0.55, -0.375], [0.5, 0.55, -0.375], [-0.5, 0.55, -0.3125], [-0.4375, 0.55, -0.3125], [-0.375, 0.55, -0.3125], [-0.3125, 0.55, -0.3125], [-0.25, 0.55, -0.3125], [-0.1875, 0.55, -0.3125], [-0.125, 0.55, -0.3125], [-0.0625, 0.55, -0.3125], [0, 0.55, -0.3125], [0.0625, 0.55, -0.3125], [0.125, 0.55, -0.3125], [0.1875, 0.55, -0.3125], [0.25, 0.55, -0.3125], [0.3125, 0.55, -0.3125], [0.375, 0.55, -0.3125], [0.4375, 0.55, -0.3125], [0.5, 0.55, -0.3125], [-0.5, 0.55, -0.25], [-0.4375, 0.55, -0.25], [-0.375, 0.55, -0.25], [-0.3125, 0.55, -0.25], [-0.25, 0.55, -0.25], [-0.1875, 0.55, -0.25], [-0.125, 0.55, -0.25], [-0.0625, 0.55, -0.25], [0, 0.55, -0.25], [0.0625, 0.55, -0.25], [0.125, 0.55, -0.25], [0.1875, 0.55, -0.25], [0.25, 0.55, -0.25], [0.3125, 0.55, -0.25], [0.375, 0.55, -0.25], [0.4375, 0.55, -0.25], [0.5, 0.55, -0.25], [-0.5, 0.55, -0.1875], [-0.4375, 0.55, -0.1875], [-0.375, 0.55, -0.1875], [-0.3125, 0.55, -0.1875], [-0.25, 0.55, -0.1875], [-0.1875, 0.55, -0.1875], [-0.125, 0.55, -0.1875], [-0.0625, 0.55, -0.1875], [0, 0.55, -0.1875], [0.0625, 0.55, -0.1875], [0.125, 0.55, -0.1875], [0.1875, 0.55, -0.1875], [0.25, 0.55, -0.1875], [0.3125, 0.55, -0.1875], [0.375, 0.55, -0.1875], [0.4375, 0.55, -0.1875], [0.5, 0.55, -0.1875], [-0.5, 0.55, -0.125], [-0.4375, 0.55, -0.125], [-0.375, 0.55, -0.125], [-0.3125, 0.55, -0.125], [-0.25, 0.55, -0.125], [-0.1875, 0.55, -0.125], [-0.125, 0.55, -0.125], [-0.0625, 0.55, -0.125], [0, 0.55, -0.125], [0.0625, 0.55, -0.125], [0.125, 0.55, -0.125], [0.1875, 0.55, -0.125], [0.25, 0.55, -0.125], [0.3125, 0.55, -0.125], [0.375, 0.55, -0.125], [0.4375, 0.55, -0.125], [0.5, 0.55, -0.125], [-0.5, 0.55, -0.0625], [-0.4375, 0.55, -0.0625], [-0.375, 0.55, -0.0625], [-0.3125, 0.55, -0.0625], [-0.25, 0.55, -0.0625], [-0.1875, 0.55, -0.0625], [-0.125, 0.55, -0.0625], [-0.0625, 0.55, -0.0625], [0, 0.55, -0.0625], [0.0625, 0.55, -0.0625], [0.125, 0.55, -0.0625], [0.1875, 0.55, -0.0625], [0.25, 0.55, -0.0625], [0.3125, 0.55, -0.0625], [0.375, 0.55, -0.0625], [0.4375, 0.55, -0.0625], [0.5, 0.55, -0.0625], [-0.5, 0.55, 0], [-0.4375, 0.55, 0], [-0.375, 0.55, 0], [-0.3125, 0.55, 0], [-0.25, 0.55, 0], [-0.1875, 0.55, 0], [-0.125, 0.55, 0], [-0.0625, 0.55, 0], [0, 0.55, 0], [0.0625, 0.55, 0], [0.125, 0.55, 0], [0.1875, 0.55, 0], [0.25, 0.55, 0], [0.3125, 0.55, 0], [0.375, 0.55, 0], [0.4375, 0.55, 0], [0.5, 0.55, 0], [-0.5, 0.55, 0.0625], [-0.4375, 0.55, 0.0625], [-0.375, 0.55, 0.0625], [-0.3125, 0.55, 0.0625], [-0.25, 0.55, 0.0625], [-0.1875, 0.55, 0.0625], [-0.125, 0.55, 0.0625], [-0.0625, 0.55, 0.0625], [0, 0.55, 0.0625], [0.0625, 0.55, 0.0625], [0.125, 0.55, 0.0625], [0.1875, 0.55, 0.0625], [0.25, 0.55, 0.0625], [0.3125, 0.55, 0.0625], [0.375, 0.55, 0.0625], [0.4375, 0.55, 0.0625], [0.5, 0.55, 0.0625], [-0.5, 0.55, 0.125], [-0.4375, 0.55, 0.125], [-0.375, 0.55, 0.125], [-0.3125, 0.55, 0.125], [-0.25, 0.55, 0.125], [-0.1875, 0.55, 0.125], [-0.125, 0.55, 0.125], [-0.0625, 0.55, 0.125], [0, 0.55, 0.125], [0.0625, 0.55, 0.125], [0.125, 0.55, 0.125], [0.1875, 0.55, 0.125], [0.25, 0.55, 0.125], [0.3125, 0.55, 0.125], [0.375, 0.55, 0.125], [0.4375, 0.55, 0.125], [0.5, 0.55, 0.125], [-0.5, 0.55, 0.1875], [-0.4375, 0.55, 0.1875], [-0.375, 0.55, 0.1875], [-0.3125, 0.55, 0.1875], [-0.25, 0.55, 0.1875], [-0.1875, 0.55, 0.1875], [-0.125, 0.55, 0.1875], [-0.0625, 0.55, 0.1875], [0, 0.55, 0.1875], [0.0625, 0.55, 0.1875], [0.125, 0.55, 0.1875], [0.1875, 0.55, 0.1875], [0.25, 0.55, 0.1875], [0.3125, 0.55, 0.1875], [0.375, 0.55, 0.1875], [0.4375, 0.55, 0.1875], [0.5, 0.55, 0.1875], [-0.5, 0.55, 0.25], [-0.4375, 0.55, 0.25], [-0.375, 0.55, 0.25], [-0.3125, 0.55, 0.25], [-0.25, 0.55, 0.25], [-0.1875, 0.55, 0.25], [-0.125, 0.55, 0.25], [-0.0625, 0.55, 0.25], [0, 0.55, 0.25], [0.0625, 0.55, 0.25], [0.125, 0.55, 0.25], [0.1875, 0.55, 0.25], [0.25, 0.55, 0.25], [0.3125, 0.55, 0.25], [0.375, 0.55, 0.25], [0.4375, 0.55, 0.25], [0.5, 0.55, 0.25], [-0.5, 0.55, 0.3125], [-0.4375, 0.55, 0.3125], [-0.375, 0.55, 0.3125], [-0.3125, 0.55, 0.3125], [-0.25, 0.55, 0.3125], [-0.1875, 0.55, 0.3125], [-0.125, 0.55, 0.3125], [-0.0625, 0.55, 0.3125], [0, 0.55, 0.3125], [0.0625, 0.55, 0.3125], [0.125, 0.55, 0.3125], [0.1875, 0.55, 0.3125], [0.25, 0.55, 0.3125], [0.3125, 0.55, 0.3125], [0.375, 0.55, 0.3125], [0.4375, 0.55, 0.3125], [0.5, 0.55, 0.3125], [-0.5, 0.55, 0.375], [-0.4375, 0.55, 0.375], [-0.375, 0.55, 0.375], [-0.3125, 0.55, 0.375], [-0.25, 0.55, 0.375], [-0.1875, 0.55, 0.375], [-0.125, 0.55, 0.375], [-0.0625, 0.55, 0.375], [0, 0.55, 0.375], [0.0625, 0.55, 0.375], [0.125, 0.55, 0.375], [0.1875, 0.55, 0.375], [0.25, 0.55, 0.375], [0.3125, 0.55, 0.375], [0.375, 0.55, 0.375], [0.4375, 0.55, 0.375], [0.5, 0.55, 0.375], [-0.5, 0.55, 0.4375], [-0.4375, 0.55, 0.4375], [-0.375, 0.55, 0.4375], [-0.3125, 0.55, 0.4375], [-0.25, 0.55, 0.4375], [-0.1875, 0.55, 0.4375], [-0.125, 0.55, 0.4375], [-0.0625, 0.55, 0.4375], [0, 0.55, 0.4375], [0.0625, 0.55, 0.4375], [0.125, 0.55, 0.4375], [0.1875, 0.55, 0.4375], [0.25, 0.55, 0.4375], [0.3125, 0.55, 0.4375], [0.375, 0.55, 0.4375], [0.4375, 0.55, 0.4375], [0.5, 0.55, 0.4375], [-0.5, 0.55, 0.5], [-0.4375, 0.55, 0.5], [-0.375, 0.55, 0.5], [-0.3125, 0.55, 0.5], [-0.25, 0.55, 0.5], [-0.1875, 0.55, 0.5], [-0.125, 0.55, 0.5], [-0.0625, 0.55, 0.5], [0, 0.55, 0.5], [0.0625, 0.55, 0.5], [0.125, 0.55, 0.5], [0.1875, 0.55, 0.5], [0.25, 0.55, 0.5], [0.3125, 0.55, 0.5], [0.375, 0.55, 0.5], [0.4375, 0.55, 0.5], [0.5, 0.55, 0.5]], "initialVelocitiesMps": [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]], "vertexMassesKg": [13020833333333333e-20, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 26041666666666666e-20, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 390625e-9, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 7812499999999999e-19, 390625e-9, 26041666666666666e-20, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 390625e-9, 13020833333333333e-20], "triangles": [[0, 17, 1], [1, 17, 18], [1, 18, 2], [2, 18, 19], [2, 19, 3], [3, 19, 20], [3, 20, 4], [4, 20, 21], [4, 21, 5], [5, 21, 22], [5, 22, 6], [6, 22, 23], [6, 23, 7], [7, 23, 24], [7, 24, 8], [8, 24, 25], [8, 25, 9], [9, 25, 26], [9, 26, 10], [10, 26, 27], [10, 27, 11], [11, 27, 28], [11, 28, 12], [12, 28, 29], [12, 29, 13], [13, 29, 30], [13, 30, 14], [14, 30, 31], [14, 31, 15], [15, 31, 32], [15, 32, 16], [16, 32, 33], [17, 34, 18], [18, 34, 35], [18, 35, 19], [19, 35, 36], [19, 36, 20], [20, 36, 37], [20, 37, 21], [21, 37, 38], [21, 38, 22], [22, 38, 39], [22, 39, 23], [23, 39, 40], [23, 40, 24], [24, 40, 41], [24, 41, 25], [25, 41, 42], [25, 42, 26], [26, 42, 43], [26, 43, 27], [27, 43, 44], [27, 44, 28], [28, 44, 45], [28, 45, 29], [29, 45, 46], [29, 46, 30], [30, 46, 47], [30, 47, 31], [31, 47, 48], [31, 48, 32], [32, 48, 49], [32, 49, 33], [33, 49, 50], [34, 51, 35], [35, 51, 52], [35, 52, 36], [36, 52, 53], [36, 53, 37], [37, 53, 54], [37, 54, 38], [38, 54, 55], [38, 55, 39], [39, 55, 56], [39, 56, 40], [40, 56, 57], [40, 57, 41], [41, 57, 58], [41, 58, 42], [42, 58, 59], [42, 59, 43], [43, 59, 60], [43, 60, 44], [44, 60, 61], [44, 61, 45], [45, 61, 62], [45, 62, 46], [46, 62, 63], [46, 63, 47], [47, 63, 64], [47, 64, 48], [48, 64, 65], [48, 65, 49], [49, 65, 66], [49, 66, 50], [50, 66, 67], [51, 68, 52], [52, 68, 69], [52, 69, 53], [53, 69, 70], [53, 70, 54], [54, 70, 71], [54, 71, 55], [55, 71, 72], [55, 72, 56], [56, 72, 73], [56, 73, 57], [57, 73, 74], [57, 74, 58], [58, 74, 75], [58, 75, 59], [59, 75, 76], [59, 76, 60], [60, 76, 77], [60, 77, 61], [61, 77, 78], [61, 78, 62], [62, 78, 79], [62, 79, 63], [63, 79, 80], [63, 80, 64], [64, 80, 81], [64, 81, 65], [65, 81, 82], [65, 82, 66], [66, 82, 83], [66, 83, 67], [67, 83, 84], [68, 85, 69], [69, 85, 86], [69, 86, 70], [70, 86, 87], [70, 87, 71], [71, 87, 88], [71, 88, 72], [72, 88, 89], [72, 89, 73], [73, 89, 90], [73, 90, 74], [74, 90, 91], [74, 91, 75], [75, 91, 92], [75, 92, 76], [76, 92, 93], [76, 93, 77], [77, 93, 94], [77, 94, 78], [78, 94, 95], [78, 95, 79], [79, 95, 96], [79, 96, 80], [80, 96, 97], [80, 97, 81], [81, 97, 98], [81, 98, 82], [82, 98, 99], [82, 99, 83], [83, 99, 100], [83, 100, 84], [84, 100, 101], [85, 102, 86], [86, 102, 103], [86, 103, 87], [87, 103, 104], [87, 104, 88], [88, 104, 105], [88, 105, 89], [89, 105, 106], [89, 106, 90], [90, 106, 107], [90, 107, 91], [91, 107, 108], [91, 108, 92], [92, 108, 109], [92, 109, 93], [93, 109, 110], [93, 110, 94], [94, 110, 111], [94, 111, 95], [95, 111, 112], [95, 112, 96], [96, 112, 113], [96, 113, 97], [97, 113, 114], [97, 114, 98], [98, 114, 115], [98, 115, 99], [99, 115, 116], [99, 116, 100], [100, 116, 117], [100, 117, 101], [101, 117, 118], [102, 119, 103], [103, 119, 120], [103, 120, 104], [104, 120, 121], [104, 121, 105], [105, 121, 122], [105, 122, 106], [106, 122, 123], [106, 123, 107], [107, 123, 124], [107, 124, 108], [108, 124, 125], [108, 125, 109], [109, 125, 126], [109, 126, 110], [110, 126, 127], [110, 127, 111], [111, 127, 128], [111, 128, 112], [112, 128, 129], [112, 129, 113], [113, 129, 130], [113, 130, 114], [114, 130, 131], [114, 131, 115], [115, 131, 132], [115, 132, 116], [116, 132, 133], [116, 133, 117], [117, 133, 134], [117, 134, 118], [118, 134, 135], [119, 136, 120], [120, 136, 137], [120, 137, 121], [121, 137, 138], [121, 138, 122], [122, 138, 139], [122, 139, 123], [123, 139, 140], [123, 140, 124], [124, 140, 141], [124, 141, 125], [125, 141, 142], [125, 142, 126], [126, 142, 143], [126, 143, 127], [127, 143, 144], [127, 144, 128], [128, 144, 145], [128, 145, 129], [129, 145, 146], [129, 146, 130], [130, 146, 147], [130, 147, 131], [131, 147, 148], [131, 148, 132], [132, 148, 149], [132, 149, 133], [133, 149, 150], [133, 150, 134], [134, 150, 151], [134, 151, 135], [135, 151, 152], [136, 153, 137], [137, 153, 154], [137, 154, 138], [138, 154, 155], [138, 155, 139], [139, 155, 156], [139, 156, 140], [140, 156, 157], [140, 157, 141], [141, 157, 158], [141, 158, 142], [142, 158, 159], [142, 159, 143], [143, 159, 160], [143, 160, 144], [144, 160, 161], [144, 161, 145], [145, 161, 162], [145, 162, 146], [146, 162, 163], [146, 163, 147], [147, 163, 164], [147, 164, 148], [148, 164, 165], [148, 165, 149], [149, 165, 166], [149, 166, 150], [150, 166, 167], [150, 167, 151], [151, 167, 168], [151, 168, 152], [152, 168, 169], [153, 170, 154], [154, 170, 171], [154, 171, 155], [155, 171, 172], [155, 172, 156], [156, 172, 173], [156, 173, 157], [157, 173, 174], [157, 174, 158], [158, 174, 175], [158, 175, 159], [159, 175, 176], [159, 176, 160], [160, 176, 177], [160, 177, 161], [161, 177, 178], [161, 178, 162], [162, 178, 179], [162, 179, 163], [163, 179, 180], [163, 180, 164], [164, 180, 181], [164, 181, 165], [165, 181, 182], [165, 182, 166], [166, 182, 183], [166, 183, 167], [167, 183, 184], [167, 184, 168], [168, 184, 185], [168, 185, 169], [169, 185, 186], [170, 187, 171], [171, 187, 188], [171, 188, 172], [172, 188, 189], [172, 189, 173], [173, 189, 190], [173, 190, 174], [174, 190, 191], [174, 191, 175], [175, 191, 192], [175, 192, 176], [176, 192, 193], [176, 193, 177], [177, 193, 194], [177, 194, 178], [178, 194, 195], [178, 195, 179], [179, 195, 196], [179, 196, 180], [180, 196, 197], [180, 197, 181], [181, 197, 198], [181, 198, 182], [182, 198, 199], [182, 199, 183], [183, 199, 200], [183, 200, 184], [184, 200, 201], [184, 201, 185], [185, 201, 202], [185, 202, 186], [186, 202, 203], [187, 204, 188], [188, 204, 205], [188, 205, 189], [189, 205, 206], [189, 206, 190], [190, 206, 207], [190, 207, 191], [191, 207, 208], [191, 208, 192], [192, 208, 209], [192, 209, 193], [193, 209, 210], [193, 210, 194], [194, 210, 211], [194, 211, 195], [195, 211, 212], [195, 212, 196], [196, 212, 213], [196, 213, 197], [197, 213, 214], [197, 214, 198], [198, 214, 215], [198, 215, 199], [199, 215, 216], [199, 216, 200], [200, 216, 217], [200, 217, 201], [201, 217, 218], [201, 218, 202], [202, 218, 219], [202, 219, 203], [203, 219, 220], [204, 221, 205], [205, 221, 222], [205, 222, 206], [206, 222, 223], [206, 223, 207], [207, 223, 224], [207, 224, 208], [208, 224, 225], [208, 225, 209], [209, 225, 226], [209, 226, 210], [210, 226, 227], [210, 227, 211], [211, 227, 228], [211, 228, 212], [212, 228, 229], [212, 229, 213], [213, 229, 230], [213, 230, 214], [214, 230, 231], [214, 231, 215], [215, 231, 232], [215, 232, 216], [216, 232, 233], [216, 233, 217], [217, 233, 234], [217, 234, 218], [218, 234, 235], [218, 235, 219], [219, 235, 236], [219, 236, 220], [220, 236, 237], [221, 238, 222], [222, 238, 239], [222, 239, 223], [223, 239, 240], [223, 240, 224], [224, 240, 241], [224, 241, 225], [225, 241, 242], [225, 242, 226], [226, 242, 243], [226, 243, 227], [227, 243, 244], [227, 244, 228], [228, 244, 245], [228, 245, 229], [229, 245, 246], [229, 246, 230], [230, 246, 247], [230, 247, 231], [231, 247, 248], [231, 248, 232], [232, 248, 249], [232, 249, 233], [233, 249, 250], [233, 250, 234], [234, 250, 251], [234, 251, 235], [235, 251, 252], [235, 252, 236], [236, 252, 253], [236, 253, 237], [237, 253, 254], [238, 255, 239], [239, 255, 256], [239, 256, 240], [240, 256, 257], [240, 257, 241], [241, 257, 258], [241, 258, 242], [242, 258, 259], [242, 259, 243], [243, 259, 260], [243, 260, 244], [244, 260, 261], [244, 261, 245], [245, 261, 262], [245, 262, 246], [246, 262, 263], [246, 263, 247], [247, 263, 264], [247, 264, 248], [248, 264, 265], [248, 265, 249], [249, 265, 266], [249, 266, 250], [250, 266, 267], [250, 267, 251], [251, 267, 268], [251, 268, 252], [252, 268, 269], [252, 269, 253], [253, 269, 270], [253, 270, 254], [254, 270, 271], [255, 272, 256], [256, 272, 273], [256, 273, 257], [257, 273, 274], [257, 274, 258], [258, 274, 275], [258, 275, 259], [259, 275, 276], [259, 276, 260], [260, 276, 277], [260, 277, 261], [261, 277, 278], [261, 278, 262], [262, 278, 279], [262, 279, 263], [263, 279, 280], [263, 280, 264], [264, 280, 281], [264, 281, 265], [265, 281, 282], [265, 282, 266], [266, 282, 283], [266, 283, 267], [267, 283, 284], [267, 284, 268], [268, 284, 285], [268, 285, 269], [269, 285, 286], [269, 286, 270], [270, 286, 287], [270, 287, 271], [271, 287, 288]], "pinnedVertexIndices": [0, 16], "constraints": [{ "a": 0, "b": 1, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 0, "b": 17, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 0, "b": 18, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 1, "b": 17, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 0, "b": 2, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 0, "b": 34, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 1, "b": 2, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 1, "b": 18, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 1, "b": 19, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 2, "b": 18, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 1, "b": 3, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 1, "b": 35, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 2, "b": 3, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 2, "b": 19, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 2, "b": 20, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 3, "b": 19, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 2, "b": 4, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 2, "b": 36, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 3, "b": 4, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 3, "b": 20, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 3, "b": 21, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 4, "b": 20, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 3, "b": 5, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 3, "b": 37, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 4, "b": 5, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 4, "b": 21, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 4, "b": 22, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 5, "b": 21, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 4, "b": 6, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 4, "b": 38, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 5, "b": 6, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 5, "b": 22, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 5, "b": 23, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 6, "b": 22, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 5, "b": 7, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 5, "b": 39, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 6, "b": 7, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 6, "b": 23, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 6, "b": 24, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 7, "b": 23, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 6, "b": 8, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 6, "b": 40, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 7, "b": 8, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 7, "b": 24, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 7, "b": 25, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 8, "b": 24, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 7, "b": 9, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 7, "b": 41, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 8, "b": 9, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 8, "b": 25, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 8, "b": 26, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 9, "b": 25, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 8, "b": 10, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 8, "b": 42, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 9, "b": 10, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 9, "b": 26, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 9, "b": 27, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 10, "b": 26, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 9, "b": 11, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 9, "b": 43, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 10, "b": 11, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 10, "b": 27, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 10, "b": 28, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 11, "b": 27, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 10, "b": 12, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 10, "b": 44, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 11, "b": 12, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 11, "b": 28, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 11, "b": 29, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 12, "b": 28, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 11, "b": 13, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 11, "b": 45, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 12, "b": 13, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 12, "b": 29, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 12, "b": 30, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 13, "b": 29, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 12, "b": 14, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 12, "b": 46, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 13, "b": 14, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 13, "b": 30, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 13, "b": 31, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 14, "b": 30, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 13, "b": 15, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 13, "b": 47, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 14, "b": 15, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 14, "b": 31, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 14, "b": 32, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 15, "b": 31, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 14, "b": 16, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 14, "b": 48, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 15, "b": 16, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 15, "b": 32, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 15, "b": 33, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 16, "b": 32, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 15, "b": 49, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 16, "b": 33, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 16, "b": 50, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 17, "b": 18, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 17, "b": 34, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 17, "b": 35, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 18, "b": 34, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 17, "b": 19, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 17, "b": 51, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 18, "b": 19, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 18, "b": 35, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 18, "b": 36, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 19, "b": 35, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 18, "b": 20, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 18, "b": 52, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 19, "b": 20, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 19, "b": 36, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 19, "b": 37, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 20, "b": 36, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 19, "b": 21, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 19, "b": 53, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 20, "b": 21, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 20, "b": 37, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 20, "b": 38, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 21, "b": 37, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 20, "b": 22, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 20, "b": 54, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 21, "b": 22, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 21, "b": 38, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 21, "b": 39, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 22, "b": 38, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 21, "b": 23, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 21, "b": 55, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 22, "b": 23, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 22, "b": 39, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 22, "b": 40, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 23, "b": 39, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 22, "b": 24, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 22, "b": 56, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 23, "b": 24, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 23, "b": 40, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 23, "b": 41, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 24, "b": 40, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 23, "b": 25, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 23, "b": 57, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 24, "b": 25, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 24, "b": 41, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 24, "b": 42, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 25, "b": 41, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 24, "b": 26, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 24, "b": 58, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 25, "b": 26, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 25, "b": 42, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 25, "b": 43, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 26, "b": 42, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 25, "b": 27, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 25, "b": 59, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 26, "b": 27, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 26, "b": 43, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 26, "b": 44, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 27, "b": 43, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 26, "b": 28, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 26, "b": 60, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 27, "b": 28, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 27, "b": 44, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 27, "b": 45, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 28, "b": 44, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 27, "b": 29, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 27, "b": 61, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 28, "b": 29, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 28, "b": 45, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 28, "b": 46, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 29, "b": 45, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 28, "b": 30, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 28, "b": 62, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 29, "b": 30, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 29, "b": 46, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 29, "b": 47, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 30, "b": 46, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 29, "b": 31, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 29, "b": 63, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 30, "b": 31, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 30, "b": 47, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 30, "b": 48, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 31, "b": 47, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 30, "b": 32, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 30, "b": 64, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 31, "b": 32, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 31, "b": 48, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 31, "b": 49, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 32, "b": 48, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 31, "b": 33, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 31, "b": 65, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 32, "b": 33, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 32, "b": 49, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 32, "b": 50, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 33, "b": 49, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 32, "b": 66, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 33, "b": 50, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 33, "b": 67, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 34, "b": 35, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 34, "b": 51, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 34, "b": 52, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 35, "b": 51, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 34, "b": 36, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 34, "b": 68, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 35, "b": 36, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 35, "b": 52, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 35, "b": 53, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 36, "b": 52, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 35, "b": 37, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 35, "b": 69, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 36, "b": 37, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 36, "b": 53, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 36, "b": 54, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 37, "b": 53, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 36, "b": 38, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 36, "b": 70, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 37, "b": 38, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 37, "b": 54, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 37, "b": 55, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 38, "b": 54, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 37, "b": 39, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 37, "b": 71, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 38, "b": 39, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 38, "b": 55, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 38, "b": 56, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 39, "b": 55, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 38, "b": 40, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 38, "b": 72, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 39, "b": 40, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 39, "b": 56, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 39, "b": 57, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 40, "b": 56, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 39, "b": 41, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 39, "b": 73, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 40, "b": 41, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 40, "b": 57, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 40, "b": 58, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 41, "b": 57, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 40, "b": 42, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 40, "b": 74, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 41, "b": 42, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 41, "b": 58, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 41, "b": 59, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 42, "b": 58, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 41, "b": 43, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 41, "b": 75, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 42, "b": 43, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 42, "b": 59, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 42, "b": 60, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 43, "b": 59, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 42, "b": 44, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 42, "b": 76, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 43, "b": 44, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 43, "b": 60, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 43, "b": 61, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 44, "b": 60, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 43, "b": 45, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 43, "b": 77, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 44, "b": 45, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 44, "b": 61, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 44, "b": 62, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 45, "b": 61, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 44, "b": 46, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 44, "b": 78, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 45, "b": 46, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 45, "b": 62, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 45, "b": 63, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 46, "b": 62, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 45, "b": 47, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 45, "b": 79, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 46, "b": 47, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 46, "b": 63, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 46, "b": 64, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 47, "b": 63, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 46, "b": 48, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 46, "b": 80, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 47, "b": 48, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 47, "b": 64, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 47, "b": 65, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 48, "b": 64, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 47, "b": 49, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 47, "b": 81, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 48, "b": 49, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 48, "b": 65, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 48, "b": 66, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 49, "b": 65, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 48, "b": 50, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 48, "b": 82, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 49, "b": 50, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 49, "b": 66, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 49, "b": 67, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 50, "b": 66, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 49, "b": 83, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 50, "b": 67, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 50, "b": 84, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 51, "b": 52, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 51, "b": 68, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 51, "b": 69, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 52, "b": 68, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 51, "b": 53, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 51, "b": 85, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 52, "b": 53, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 52, "b": 69, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 52, "b": 70, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 53, "b": 69, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 52, "b": 54, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 52, "b": 86, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 53, "b": 54, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 53, "b": 70, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 53, "b": 71, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 54, "b": 70, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 53, "b": 55, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 53, "b": 87, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 54, "b": 55, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 54, "b": 71, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 54, "b": 72, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 55, "b": 71, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 54, "b": 56, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 54, "b": 88, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 55, "b": 56, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 55, "b": 72, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 55, "b": 73, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 56, "b": 72, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 55, "b": 57, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 55, "b": 89, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 56, "b": 57, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 56, "b": 73, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 56, "b": 74, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 57, "b": 73, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 56, "b": 58, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 56, "b": 90, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 57, "b": 58, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 57, "b": 74, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 57, "b": 75, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 58, "b": 74, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 57, "b": 59, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 57, "b": 91, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 58, "b": 59, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 58, "b": 75, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 58, "b": 76, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 59, "b": 75, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 58, "b": 60, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 58, "b": 92, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 59, "b": 60, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 59, "b": 76, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 59, "b": 77, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 60, "b": 76, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 59, "b": 61, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 59, "b": 93, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 60, "b": 61, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 60, "b": 77, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 60, "b": 78, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 61, "b": 77, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 60, "b": 62, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 60, "b": 94, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 61, "b": 62, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 61, "b": 78, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 61, "b": 79, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 62, "b": 78, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 61, "b": 63, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 61, "b": 95, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 62, "b": 63, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 62, "b": 79, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 62, "b": 80, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 63, "b": 79, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 62, "b": 64, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 62, "b": 96, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 63, "b": 64, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 63, "b": 80, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 63, "b": 81, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 64, "b": 80, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 63, "b": 65, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 63, "b": 97, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 64, "b": 65, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 64, "b": 81, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 64, "b": 82, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 65, "b": 81, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 64, "b": 66, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 64, "b": 98, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 65, "b": 66, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 65, "b": 82, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 65, "b": 83, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 66, "b": 82, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 65, "b": 67, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 65, "b": 99, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 66, "b": 67, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 66, "b": 83, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 66, "b": 84, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 67, "b": 83, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 66, "b": 100, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 67, "b": 84, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 67, "b": 101, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 68, "b": 69, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 68, "b": 85, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 68, "b": 86, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 69, "b": 85, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 68, "b": 70, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 68, "b": 102, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 69, "b": 70, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 69, "b": 86, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 69, "b": 87, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 70, "b": 86, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 69, "b": 71, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 69, "b": 103, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 70, "b": 71, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 70, "b": 87, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 70, "b": 88, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 71, "b": 87, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 70, "b": 72, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 70, "b": 104, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 71, "b": 72, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 71, "b": 88, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 71, "b": 89, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 72, "b": 88, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 71, "b": 73, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 71, "b": 105, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 72, "b": 73, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 72, "b": 89, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 72, "b": 90, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 73, "b": 89, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 72, "b": 74, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 72, "b": 106, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 73, "b": 74, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 73, "b": 90, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 73, "b": 91, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 74, "b": 90, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 73, "b": 75, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 73, "b": 107, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 74, "b": 75, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 74, "b": 91, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 74, "b": 92, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 75, "b": 91, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 74, "b": 76, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 74, "b": 108, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 75, "b": 76, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 75, "b": 92, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 75, "b": 93, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 76, "b": 92, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 75, "b": 77, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 75, "b": 109, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 76, "b": 77, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 76, "b": 93, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 76, "b": 94, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 77, "b": 93, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 76, "b": 78, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 76, "b": 110, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 77, "b": 78, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 77, "b": 94, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 77, "b": 95, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 78, "b": 94, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 77, "b": 79, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 77, "b": 111, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 78, "b": 79, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 78, "b": 95, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 78, "b": 96, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 79, "b": 95, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 78, "b": 80, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 78, "b": 112, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 79, "b": 80, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 79, "b": 96, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 79, "b": 97, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 80, "b": 96, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 79, "b": 81, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 79, "b": 113, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 80, "b": 81, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 80, "b": 97, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 80, "b": 98, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 81, "b": 97, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 80, "b": 82, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 80, "b": 114, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 81, "b": 82, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 81, "b": 98, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 81, "b": 99, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 82, "b": 98, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 81, "b": 83, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 81, "b": 115, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 82, "b": 83, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 82, "b": 99, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 82, "b": 100, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 83, "b": 99, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 82, "b": 84, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 82, "b": 116, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 83, "b": 84, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 83, "b": 100, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 83, "b": 101, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 84, "b": 100, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 83, "b": 117, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 84, "b": 101, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 84, "b": 118, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 85, "b": 86, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 85, "b": 102, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 85, "b": 103, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 86, "b": 102, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 85, "b": 87, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 85, "b": 119, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 86, "b": 87, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 86, "b": 103, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 86, "b": 104, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 87, "b": 103, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 86, "b": 88, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 86, "b": 120, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 87, "b": 88, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 87, "b": 104, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 87, "b": 105, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 88, "b": 104, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 87, "b": 89, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 87, "b": 121, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 88, "b": 89, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 88, "b": 105, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 88, "b": 106, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 89, "b": 105, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 88, "b": 90, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 88, "b": 122, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 89, "b": 90, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 89, "b": 106, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 89, "b": 107, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 90, "b": 106, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 89, "b": 91, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 89, "b": 123, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 90, "b": 91, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 90, "b": 107, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 90, "b": 108, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 91, "b": 107, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 90, "b": 92, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 90, "b": 124, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 91, "b": 92, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 91, "b": 108, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 91, "b": 109, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 92, "b": 108, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 91, "b": 93, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 91, "b": 125, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 92, "b": 93, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 92, "b": 109, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 92, "b": 110, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 93, "b": 109, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 92, "b": 94, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 92, "b": 126, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 93, "b": 94, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 93, "b": 110, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 93, "b": 111, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 94, "b": 110, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 93, "b": 95, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 93, "b": 127, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 94, "b": 95, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 94, "b": 111, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 94, "b": 112, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 95, "b": 111, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 94, "b": 96, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 94, "b": 128, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 95, "b": 96, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 95, "b": 112, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 95, "b": 113, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 96, "b": 112, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 95, "b": 97, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 95, "b": 129, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 96, "b": 97, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 96, "b": 113, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 96, "b": 114, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 97, "b": 113, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 96, "b": 98, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 96, "b": 130, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 97, "b": 98, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 97, "b": 114, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 97, "b": 115, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 98, "b": 114, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 97, "b": 99, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 97, "b": 131, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 98, "b": 99, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 98, "b": 115, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 98, "b": 116, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 99, "b": 115, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 98, "b": 100, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 98, "b": 132, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 99, "b": 100, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 99, "b": 116, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 99, "b": 117, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 100, "b": 116, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 99, "b": 101, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 99, "b": 133, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 100, "b": 101, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 100, "b": 117, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 100, "b": 118, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 101, "b": 117, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 100, "b": 134, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 101, "b": 118, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 101, "b": 135, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 102, "b": 103, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 102, "b": 119, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 102, "b": 120, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 103, "b": 119, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 102, "b": 104, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 102, "b": 136, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 103, "b": 104, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 103, "b": 120, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 103, "b": 121, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 104, "b": 120, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 103, "b": 105, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 103, "b": 137, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 104, "b": 105, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 104, "b": 121, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 104, "b": 122, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 105, "b": 121, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 104, "b": 106, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 104, "b": 138, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 105, "b": 106, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 105, "b": 122, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 105, "b": 123, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 106, "b": 122, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 105, "b": 107, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 105, "b": 139, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 106, "b": 107, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 106, "b": 123, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 106, "b": 124, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 107, "b": 123, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 106, "b": 108, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 106, "b": 140, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 107, "b": 108, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 107, "b": 124, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 107, "b": 125, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 108, "b": 124, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 107, "b": 109, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 107, "b": 141, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 108, "b": 109, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 108, "b": 125, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 108, "b": 126, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 109, "b": 125, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 108, "b": 110, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 108, "b": 142, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 109, "b": 110, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 109, "b": 126, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 109, "b": 127, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 110, "b": 126, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 109, "b": 111, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 109, "b": 143, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 110, "b": 111, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 110, "b": 127, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 110, "b": 128, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 111, "b": 127, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 110, "b": 112, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 110, "b": 144, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 111, "b": 112, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 111, "b": 128, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 111, "b": 129, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 112, "b": 128, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 111, "b": 113, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 111, "b": 145, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 112, "b": 113, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 112, "b": 129, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 112, "b": 130, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 113, "b": 129, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 112, "b": 114, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 112, "b": 146, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 113, "b": 114, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 113, "b": 130, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 113, "b": 131, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 114, "b": 130, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 113, "b": 115, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 113, "b": 147, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 114, "b": 115, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 114, "b": 131, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 114, "b": 132, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 115, "b": 131, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 114, "b": 116, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 114, "b": 148, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 115, "b": 116, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 115, "b": 132, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 115, "b": 133, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 116, "b": 132, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 115, "b": 117, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 115, "b": 149, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 116, "b": 117, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 116, "b": 133, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 116, "b": 134, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 117, "b": 133, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 116, "b": 118, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 116, "b": 150, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 117, "b": 118, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 117, "b": 134, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 117, "b": 135, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 118, "b": 134, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 117, "b": 151, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 118, "b": 135, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 118, "b": 152, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 119, "b": 120, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 119, "b": 136, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 119, "b": 137, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 120, "b": 136, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 119, "b": 121, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 119, "b": 153, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 120, "b": 121, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 120, "b": 137, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 120, "b": 138, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 121, "b": 137, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 120, "b": 122, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 120, "b": 154, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 121, "b": 122, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 121, "b": 138, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 121, "b": 139, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 122, "b": 138, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 121, "b": 123, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 121, "b": 155, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 122, "b": 123, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 122, "b": 139, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 122, "b": 140, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 123, "b": 139, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 122, "b": 124, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 122, "b": 156, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 123, "b": 124, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 123, "b": 140, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 123, "b": 141, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 124, "b": 140, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 123, "b": 125, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 123, "b": 157, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 124, "b": 125, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 124, "b": 141, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 124, "b": 142, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 125, "b": 141, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 124, "b": 126, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 124, "b": 158, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 125, "b": 126, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 125, "b": 142, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 125, "b": 143, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 126, "b": 142, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 125, "b": 127, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 125, "b": 159, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 126, "b": 127, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 126, "b": 143, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 126, "b": 144, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 127, "b": 143, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 126, "b": 128, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 126, "b": 160, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 127, "b": 128, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 127, "b": 144, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 127, "b": 145, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 128, "b": 144, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 127, "b": 129, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 127, "b": 161, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 128, "b": 129, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 128, "b": 145, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 128, "b": 146, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 129, "b": 145, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 128, "b": 130, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 128, "b": 162, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 129, "b": 130, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 129, "b": 146, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 129, "b": 147, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 130, "b": 146, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 129, "b": 131, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 129, "b": 163, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 130, "b": 131, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 130, "b": 147, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 130, "b": 148, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 131, "b": 147, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 130, "b": 132, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 130, "b": 164, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 131, "b": 132, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 131, "b": 148, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 131, "b": 149, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 132, "b": 148, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 131, "b": 133, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 131, "b": 165, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 132, "b": 133, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 132, "b": 149, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 132, "b": 150, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 133, "b": 149, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 132, "b": 134, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 132, "b": 166, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 133, "b": 134, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 133, "b": 150, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 133, "b": 151, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 134, "b": 150, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 133, "b": 135, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 133, "b": 167, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 134, "b": 135, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 134, "b": 151, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 134, "b": 152, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 135, "b": 151, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 134, "b": 168, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 135, "b": 152, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 135, "b": 169, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 136, "b": 137, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 136, "b": 153, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 136, "b": 154, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 137, "b": 153, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 136, "b": 138, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 136, "b": 170, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 137, "b": 138, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 137, "b": 154, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 137, "b": 155, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 138, "b": 154, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 137, "b": 139, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 137, "b": 171, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 138, "b": 139, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 138, "b": 155, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 138, "b": 156, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 139, "b": 155, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 138, "b": 140, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 138, "b": 172, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 139, "b": 140, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 139, "b": 156, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 139, "b": 157, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 140, "b": 156, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 139, "b": 141, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 139, "b": 173, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 140, "b": 141, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 140, "b": 157, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 140, "b": 158, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 141, "b": 157, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 140, "b": 142, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 140, "b": 174, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 141, "b": 142, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 141, "b": 158, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 141, "b": 159, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 142, "b": 158, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 141, "b": 143, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 141, "b": 175, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 142, "b": 143, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 142, "b": 159, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 142, "b": 160, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 143, "b": 159, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 142, "b": 144, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 142, "b": 176, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 143, "b": 144, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 143, "b": 160, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 143, "b": 161, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 144, "b": 160, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 143, "b": 145, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 143, "b": 177, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 144, "b": 145, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 144, "b": 161, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 144, "b": 162, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 145, "b": 161, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 144, "b": 146, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 144, "b": 178, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 145, "b": 146, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 145, "b": 162, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 145, "b": 163, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 146, "b": 162, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 145, "b": 147, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 145, "b": 179, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 146, "b": 147, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 146, "b": 163, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 146, "b": 164, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 147, "b": 163, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 146, "b": 148, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 146, "b": 180, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 147, "b": 148, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 147, "b": 164, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 147, "b": 165, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 148, "b": 164, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 147, "b": 149, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 147, "b": 181, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 148, "b": 149, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 148, "b": 165, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 148, "b": 166, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 149, "b": 165, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 148, "b": 150, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 148, "b": 182, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 149, "b": 150, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 149, "b": 166, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 149, "b": 167, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 150, "b": 166, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 149, "b": 151, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 149, "b": 183, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 150, "b": 151, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 150, "b": 167, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 150, "b": 168, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 151, "b": 167, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 150, "b": 152, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 150, "b": 184, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 151, "b": 152, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 151, "b": 168, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 151, "b": 169, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 152, "b": 168, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 151, "b": 185, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 152, "b": 169, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 152, "b": 186, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 153, "b": 154, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 153, "b": 170, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 153, "b": 171, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 154, "b": 170, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 153, "b": 155, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 153, "b": 187, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 154, "b": 155, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 154, "b": 171, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 154, "b": 172, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 155, "b": 171, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 154, "b": 156, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 154, "b": 188, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 155, "b": 156, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 155, "b": 172, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 155, "b": 173, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 156, "b": 172, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 155, "b": 157, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 155, "b": 189, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 156, "b": 157, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 156, "b": 173, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 156, "b": 174, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 157, "b": 173, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 156, "b": 158, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 156, "b": 190, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 157, "b": 158, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 157, "b": 174, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 157, "b": 175, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 158, "b": 174, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 157, "b": 159, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 157, "b": 191, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 158, "b": 159, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 158, "b": 175, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 158, "b": 176, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 159, "b": 175, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 158, "b": 160, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 158, "b": 192, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 159, "b": 160, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 159, "b": 176, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 159, "b": 177, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 160, "b": 176, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 159, "b": 161, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 159, "b": 193, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 160, "b": 161, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 160, "b": 177, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 160, "b": 178, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 161, "b": 177, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 160, "b": 162, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 160, "b": 194, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 161, "b": 162, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 161, "b": 178, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 161, "b": 179, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 162, "b": 178, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 161, "b": 163, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 161, "b": 195, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 162, "b": 163, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 162, "b": 179, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 162, "b": 180, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 163, "b": 179, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 162, "b": 164, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 162, "b": 196, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 163, "b": 164, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 163, "b": 180, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 163, "b": 181, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 164, "b": 180, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 163, "b": 165, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 163, "b": 197, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 164, "b": 165, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 164, "b": 181, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 164, "b": 182, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 165, "b": 181, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 164, "b": 166, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 164, "b": 198, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 165, "b": 166, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 165, "b": 182, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 165, "b": 183, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 166, "b": 182, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 165, "b": 167, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 165, "b": 199, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 166, "b": 167, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 166, "b": 183, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 166, "b": 184, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 167, "b": 183, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 166, "b": 168, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 166, "b": 200, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 167, "b": 168, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 167, "b": 184, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 167, "b": 185, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 168, "b": 184, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 167, "b": 169, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 167, "b": 201, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 168, "b": 169, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 168, "b": 185, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 168, "b": 186, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 169, "b": 185, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 168, "b": 202, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 169, "b": 186, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 169, "b": 203, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 170, "b": 171, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 170, "b": 187, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 170, "b": 188, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 171, "b": 187, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 170, "b": 172, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 170, "b": 204, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 171, "b": 172, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 171, "b": 188, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 171, "b": 189, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 172, "b": 188, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 171, "b": 173, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 171, "b": 205, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 172, "b": 173, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 172, "b": 189, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 172, "b": 190, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 173, "b": 189, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 172, "b": 174, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 172, "b": 206, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 173, "b": 174, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 173, "b": 190, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 173, "b": 191, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 174, "b": 190, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 173, "b": 175, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 173, "b": 207, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 174, "b": 175, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 174, "b": 191, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 174, "b": 192, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 175, "b": 191, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 174, "b": 176, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 174, "b": 208, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 175, "b": 176, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 175, "b": 192, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 175, "b": 193, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 176, "b": 192, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 175, "b": 177, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 175, "b": 209, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 176, "b": 177, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 176, "b": 193, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 176, "b": 194, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 177, "b": 193, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 176, "b": 178, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 176, "b": 210, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 177, "b": 178, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 177, "b": 194, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 177, "b": 195, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 178, "b": 194, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 177, "b": 179, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 177, "b": 211, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 178, "b": 179, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 178, "b": 195, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 178, "b": 196, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 179, "b": 195, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 178, "b": 180, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 178, "b": 212, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 179, "b": 180, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 179, "b": 196, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 179, "b": 197, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 180, "b": 196, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 179, "b": 181, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 179, "b": 213, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 180, "b": 181, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 180, "b": 197, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 180, "b": 198, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 181, "b": 197, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 180, "b": 182, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 180, "b": 214, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 181, "b": 182, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 181, "b": 198, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 181, "b": 199, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 182, "b": 198, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 181, "b": 183, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 181, "b": 215, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 182, "b": 183, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 182, "b": 199, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 182, "b": 200, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 183, "b": 199, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 182, "b": 184, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 182, "b": 216, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 183, "b": 184, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 183, "b": 200, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 183, "b": 201, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 184, "b": 200, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 183, "b": 185, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 183, "b": 217, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 184, "b": 185, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 184, "b": 201, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 184, "b": 202, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 185, "b": 201, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 184, "b": 186, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 184, "b": 218, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 185, "b": 186, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 185, "b": 202, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 185, "b": 203, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 186, "b": 202, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 185, "b": 219, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 186, "b": 203, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 186, "b": 220, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 187, "b": 188, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 187, "b": 204, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 187, "b": 205, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 188, "b": 204, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 187, "b": 189, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 187, "b": 221, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 188, "b": 189, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 188, "b": 205, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 188, "b": 206, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 189, "b": 205, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 188, "b": 190, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 188, "b": 222, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 189, "b": 190, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 189, "b": 206, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 189, "b": 207, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 190, "b": 206, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 189, "b": 191, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 189, "b": 223, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 190, "b": 191, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 190, "b": 207, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 190, "b": 208, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 191, "b": 207, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 190, "b": 192, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 190, "b": 224, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 191, "b": 192, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 191, "b": 208, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 191, "b": 209, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 192, "b": 208, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 191, "b": 193, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 191, "b": 225, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 192, "b": 193, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 192, "b": 209, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 192, "b": 210, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 193, "b": 209, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 192, "b": 194, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 192, "b": 226, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 193, "b": 194, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 193, "b": 210, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 193, "b": 211, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 194, "b": 210, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 193, "b": 195, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 193, "b": 227, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 194, "b": 195, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 194, "b": 211, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 194, "b": 212, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 195, "b": 211, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 194, "b": 196, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 194, "b": 228, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 195, "b": 196, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 195, "b": 212, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 195, "b": 213, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 196, "b": 212, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 195, "b": 197, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 195, "b": 229, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 196, "b": 197, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 196, "b": 213, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 196, "b": 214, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 197, "b": 213, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 196, "b": 198, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 196, "b": 230, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 197, "b": 198, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 197, "b": 214, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 197, "b": 215, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 198, "b": 214, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 197, "b": 199, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 197, "b": 231, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 198, "b": 199, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 198, "b": 215, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 198, "b": 216, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 199, "b": 215, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 198, "b": 200, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 198, "b": 232, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 199, "b": 200, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 199, "b": 216, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 199, "b": 217, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 200, "b": 216, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 199, "b": 201, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 199, "b": 233, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 200, "b": 201, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 200, "b": 217, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 200, "b": 218, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 201, "b": 217, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 200, "b": 202, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 200, "b": 234, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 201, "b": 202, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 201, "b": 218, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 201, "b": 219, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 202, "b": 218, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 201, "b": 203, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 201, "b": 235, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 202, "b": 203, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 202, "b": 219, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 202, "b": 220, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 203, "b": 219, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 202, "b": 236, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 203, "b": 220, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 203, "b": 237, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 204, "b": 205, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 204, "b": 221, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 204, "b": 222, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 205, "b": 221, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 204, "b": 206, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 204, "b": 238, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 205, "b": 206, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 205, "b": 222, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 205, "b": 223, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 206, "b": 222, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 205, "b": 207, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 205, "b": 239, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 206, "b": 207, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 206, "b": 223, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 206, "b": 224, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 207, "b": 223, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 206, "b": 208, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 206, "b": 240, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 207, "b": 208, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 207, "b": 224, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 207, "b": 225, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 208, "b": 224, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 207, "b": 209, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 207, "b": 241, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 208, "b": 209, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 208, "b": 225, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 208, "b": 226, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 209, "b": 225, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 208, "b": 210, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 208, "b": 242, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 209, "b": 210, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 209, "b": 226, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 209, "b": 227, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 210, "b": 226, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 209, "b": 211, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 209, "b": 243, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 210, "b": 211, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 210, "b": 227, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 210, "b": 228, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 211, "b": 227, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 210, "b": 212, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 210, "b": 244, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 211, "b": 212, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 211, "b": 228, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 211, "b": 229, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 212, "b": 228, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 211, "b": 213, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 211, "b": 245, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 212, "b": 213, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 212, "b": 229, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 212, "b": 230, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 213, "b": 229, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 212, "b": 214, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 212, "b": 246, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 213, "b": 214, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 213, "b": 230, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 213, "b": 231, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 214, "b": 230, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 213, "b": 215, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 213, "b": 247, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 214, "b": 215, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 214, "b": 231, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 214, "b": 232, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 215, "b": 231, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 214, "b": 216, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 214, "b": 248, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 215, "b": 216, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 215, "b": 232, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 215, "b": 233, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 216, "b": 232, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 215, "b": 217, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 215, "b": 249, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 216, "b": 217, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 216, "b": 233, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 216, "b": 234, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 217, "b": 233, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 216, "b": 218, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 216, "b": 250, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 217, "b": 218, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 217, "b": 234, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 217, "b": 235, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 218, "b": 234, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 217, "b": 219, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 217, "b": 251, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 218, "b": 219, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 218, "b": 235, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 218, "b": 236, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 219, "b": 235, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 218, "b": 220, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 218, "b": 252, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 219, "b": 220, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 219, "b": 236, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 219, "b": 237, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 220, "b": 236, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 219, "b": 253, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 220, "b": 237, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 220, "b": 254, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 221, "b": 222, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 221, "b": 238, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 221, "b": 239, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 222, "b": 238, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 221, "b": 223, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 221, "b": 255, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 222, "b": 223, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 222, "b": 239, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 222, "b": 240, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 223, "b": 239, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 222, "b": 224, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 222, "b": 256, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 223, "b": 224, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 223, "b": 240, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 223, "b": 241, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 224, "b": 240, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 223, "b": 225, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 223, "b": 257, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 224, "b": 225, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 224, "b": 241, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 224, "b": 242, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 225, "b": 241, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 224, "b": 226, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 224, "b": 258, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 225, "b": 226, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 225, "b": 242, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 225, "b": 243, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 226, "b": 242, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 225, "b": 227, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 225, "b": 259, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 226, "b": 227, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 226, "b": 243, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 226, "b": 244, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 227, "b": 243, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 226, "b": 228, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 226, "b": 260, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 227, "b": 228, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 227, "b": 244, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 227, "b": 245, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 228, "b": 244, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 227, "b": 229, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 227, "b": 261, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 228, "b": 229, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 228, "b": 245, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 228, "b": 246, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 229, "b": 245, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 228, "b": 230, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 228, "b": 262, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 229, "b": 230, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 229, "b": 246, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 229, "b": 247, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 230, "b": 246, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 229, "b": 231, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 229, "b": 263, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 230, "b": 231, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 230, "b": 247, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 230, "b": 248, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 231, "b": 247, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 230, "b": 232, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 230, "b": 264, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 231, "b": 232, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 231, "b": 248, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 231, "b": 249, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 232, "b": 248, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 231, "b": 233, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 231, "b": 265, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 232, "b": 233, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 232, "b": 249, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 232, "b": 250, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 233, "b": 249, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 232, "b": 234, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 232, "b": 266, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 233, "b": 234, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 233, "b": 250, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 233, "b": 251, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 234, "b": 250, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 233, "b": 235, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 233, "b": 267, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 234, "b": 235, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 234, "b": 251, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 234, "b": 252, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 235, "b": 251, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 234, "b": 236, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 234, "b": 268, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 235, "b": 236, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 235, "b": 252, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 235, "b": 253, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 236, "b": 252, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 235, "b": 237, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 235, "b": 269, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 236, "b": 237, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 236, "b": 253, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 236, "b": 254, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 237, "b": 253, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 236, "b": 270, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 237, "b": 254, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 237, "b": 271, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 238, "b": 239, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 238, "b": 255, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 238, "b": 256, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 239, "b": 255, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 238, "b": 240, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 238, "b": 272, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 239, "b": 240, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 239, "b": 256, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 239, "b": 257, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 240, "b": 256, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 239, "b": 241, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 239, "b": 273, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 240, "b": 241, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 240, "b": 257, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 240, "b": 258, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 241, "b": 257, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 240, "b": 242, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 240, "b": 274, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 241, "b": 242, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 241, "b": 258, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 241, "b": 259, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 242, "b": 258, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 241, "b": 243, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 241, "b": 275, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 242, "b": 243, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 242, "b": 259, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 242, "b": 260, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 243, "b": 259, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 242, "b": 244, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 242, "b": 276, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 243, "b": 244, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 243, "b": 260, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 243, "b": 261, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 244, "b": 260, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 243, "b": 245, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 243, "b": 277, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 244, "b": 245, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 244, "b": 261, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 244, "b": 262, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 245, "b": 261, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 244, "b": 246, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 244, "b": 278, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 245, "b": 246, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 245, "b": 262, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 245, "b": 263, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 246, "b": 262, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 245, "b": 247, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 245, "b": 279, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 246, "b": 247, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 246, "b": 263, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 246, "b": 264, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 247, "b": 263, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 246, "b": 248, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 246, "b": 280, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 247, "b": 248, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 247, "b": 264, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 247, "b": 265, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 248, "b": 264, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 247, "b": 249, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 247, "b": 281, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 248, "b": 249, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 248, "b": 265, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 248, "b": 266, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 249, "b": 265, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 248, "b": 250, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 248, "b": 282, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 249, "b": 250, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 249, "b": 266, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 249, "b": 267, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 250, "b": 266, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 249, "b": 251, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 249, "b": 283, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 250, "b": 251, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 250, "b": 267, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 250, "b": 268, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 251, "b": 267, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 250, "b": 252, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 250, "b": 284, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 251, "b": 252, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 251, "b": 268, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 251, "b": 269, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 252, "b": 268, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 251, "b": 253, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 251, "b": 285, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 252, "b": 253, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 252, "b": 269, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 252, "b": 270, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 253, "b": 269, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 252, "b": 254, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 252, "b": 286, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 253, "b": 254, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 253, "b": 270, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 253, "b": 271, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 254, "b": 270, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 253, "b": 287, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 254, "b": 271, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 254, "b": 288, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 255, "b": 256, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 255, "b": 272, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 255, "b": 273, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 256, "b": 272, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 255, "b": 257, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 256, "b": 257, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 256, "b": 273, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 256, "b": 274, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 257, "b": 273, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 256, "b": 258, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 257, "b": 258, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 257, "b": 274, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 257, "b": 275, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 258, "b": 274, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 257, "b": 259, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 258, "b": 259, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 258, "b": 275, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 258, "b": 276, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 259, "b": 275, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 258, "b": 260, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 259, "b": 260, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 259, "b": 276, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 259, "b": 277, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 260, "b": 276, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 259, "b": 261, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 260, "b": 261, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 260, "b": 277, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 260, "b": 278, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 261, "b": 277, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 260, "b": 262, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 261, "b": 262, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 261, "b": 278, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 261, "b": 279, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 262, "b": 278, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 261, "b": 263, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 262, "b": 263, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 262, "b": 279, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 262, "b": 280, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 263, "b": 279, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 262, "b": 264, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 263, "b": 264, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 263, "b": 280, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 263, "b": 281, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 264, "b": 280, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 263, "b": 265, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 264, "b": 265, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 264, "b": 281, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 264, "b": 282, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 265, "b": 281, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 264, "b": 266, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 265, "b": 266, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 265, "b": 282, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 265, "b": 283, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 266, "b": 282, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 265, "b": 267, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 266, "b": 267, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 266, "b": 283, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 266, "b": 284, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 267, "b": 283, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 266, "b": 268, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 267, "b": 268, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 267, "b": 284, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 267, "b": 285, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 268, "b": 284, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 267, "b": 269, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 268, "b": 269, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 268, "b": 285, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 268, "b": 286, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 269, "b": 285, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 268, "b": 270, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 269, "b": 270, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 269, "b": 286, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 269, "b": 287, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 270, "b": 286, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 269, "b": 271, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 270, "b": 271, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 270, "b": 287, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 270, "b": 288, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 271, "b": 287, "kind": "shear", "restLengthM": 0.08838834764831845, "complianceMPerN": 1e-3 }, { "a": 271, "b": 288, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 272, "b": 273, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 272, "b": 274, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 273, "b": 274, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 273, "b": 275, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 274, "b": 275, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 274, "b": 276, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 275, "b": 276, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 275, "b": 277, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 276, "b": 277, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 276, "b": 278, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 277, "b": 278, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 277, "b": 279, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 278, "b": 279, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 278, "b": 280, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 279, "b": 280, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 279, "b": 281, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 280, "b": 281, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 280, "b": 282, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 281, "b": 282, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 281, "b": 283, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 282, "b": 283, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 282, "b": 284, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 283, "b": 284, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 283, "b": 285, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 284, "b": 285, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 284, "b": 286, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 285, "b": 286, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 285, "b": 287, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 286, "b": 287, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }, { "a": 286, "b": 288, "kind": "bend-distance", "restLengthM": 0.125, "complianceMPerN": 0.1 }, { "a": 287, "b": 288, "kind": "stretch", "restLengthM": 0.0625, "complianceMPerN": 1e-3 }], "staticColliderIds": ["p5SphereCollider"] });

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/domain/admission.ts
var PROFILES = [
  "cloth-pinned-sphere-visual-v1",
  "fluid-basin-visual-v1",
  "fluid-basin-xsph-visual-v1",
  "fluid-static-box-visual-v1"
];
var CLOTH_FIELDS = [
  "id",
  "restPositionsM",
  "initialPositionsM",
  "initialVelocitiesMps",
  "vertexMassesKg",
  "triangles",
  "pinnedVertexIndices",
  "constraints",
  "staticColliderIds"
];
var FLUID_FIELDS = [
  "id",
  "initialPositionsM",
  "initialVelocitiesMps",
  "massModel",
  "particleRadiusM",
  "smoothingRadiusM",
  "staticColliderIds",
  "visualSmoothing"
];
function check3(value, message) {
  if (!value) error("INVALID_CONFIG", message);
}
function exact(value, keys, label) {
  check3(value !== null && typeof value === "object" && !Array.isArray(value), `${label} requires a record`);
  const input = value;
  check3(Object.keys(input).length === keys.length && keys.every((key) => Object.hasOwn(input, key)), `${label} requires exact fields`);
  return input;
}
function array(value, count, label) {
  check3(Array.isArray(value) && value.length === count, `${label} requires exactly ${count} entries`);
  return value;
}
function triple(value, label) {
  const result = array(value, 3, label);
  result.forEach((part, index) => finite(part, -1e4, 1e4, `${label}[${index}]`));
  return result;
}
function same3(value, expected, label) {
  if (typeof expected !== "object" || expected === null) {
    check3(Object.is(value, expected), `${label} differs from the fixed native profile`);
    return;
  }
  if (Array.isArray(expected)) {
    array(value, expected.length, label).forEach((item, index) => same3(item, expected[index], `${label}[${index}]`));
    return;
  }
  const reference = expected, input = exact(value, Object.keys(reference), label);
  for (const key of Object.keys(reference)) same3(input[key], reference[key], `${label}.${key}`);
}
function transform(value, label, local = false) {
  const input = exact(value, ["positionM", "orientationXYZW"], label);
  triple(input.positionM, `${label}.positionM`);
  same3(input.orientationXYZW, [0, 0, 0, 1], `${label}.orientationXYZW`);
  if (local) same3(input.positionM, [0, 0, 0], `${label}.positionM`);
  return input;
}
function admitDomainModel(model, options) {
  if (!PROFILES.includes(options.profile)) return null;
  const profile = options.profile;
  check3(options.broadPhase === "domain-fixed" && Object.is(options.fixedStepSeconds, CLOTH_STEP_SECONDS), "Unsupported domain options");
  same3(model.gravityMps2, CLOTH_PROFILE.gravityMps2, "gravityMps2");
  const clothProfile = profile === "cloth-pinned-sphere-visual-v1";
  const boxProfile = profile === "fluid-static-box-visual-v1";
  const count = boxProfile ? 2 : 1;
  const bodyInputs = array(model.bodies, count, "bodies");
  const colliderInputs = array(model.colliders, count, "colliders");
  array(model.joints, 0, "joints");
  const clothInputs = array(model.cloths, clothProfile ? 1 : 0, "cloths");
  const fluidInputs = array(model.fluids, clothProfile ? 0 : 1, "fluids");
  check3(Array.isArray(model.sourceBindings) && model.sourceBindings.length <= 128, "Unsupported source binding population");
  const ids2 = /* @__PURE__ */ new Set();
  function id(value) {
    check3(typeof value === "string" && ID.test(value) && !ids2.has(value), "Invalid or duplicate global entity ID");
    ids2.add(value);
    return value;
  }
  const bodies = /* @__PURE__ */ new Map();
  for (const value of bodyInputs) {
    const body = exact(value, ["id", "kind", "initial"], "static body");
    const bodyId = id(body.id);
    check3(body.kind === "static", "Domain owners must be static");
    transform(body.initial, "static initial");
    bodies.set(bodyId, body);
  }
  const colliders = /* @__PURE__ */ new Map();
  const owners = /* @__PURE__ */ new Set();
  for (const value of colliderInputs) {
    const collider = exact(value, ["id", "bodyId", "geometry", "local", "material", "sensor", "ccd", "filter"], "collider");
    const colliderId2 = id(collider.id);
    check3(typeof collider.bodyId === "string" && bodies.has(collider.bodyId) && !owners.has(collider.bodyId), "Collider requires one declared static owner");
    owners.add(collider.bodyId);
    const geometry = exact(collider.geometry, collider.geometry?.kind === "sphere" ? ["kind", "radiusM"] : ["kind", "halfExtentsM"], "geometry");
    if (geometry.kind === "sphere") finite(geometry.radiusM, 1e-4, 1e3, "radiusM");
    else {
      check3(geometry.kind === "box" || geometry.kind === "box-interior", "Unsupported domain geometry");
      array(geometry.halfExtentsM, 3, "halfExtentsM").forEach((value2) => finite(value2, 1e-4, 1e3, "halfExtentsM"));
    }
    transform(collider.local, "collider.local", true);
    const material = exact(collider.material, ["restitution", "friction"], "material");
    same3(material.restitution, 0, "restitution");
    same3(material.friction, { static: 0, dynamic: 0 }, "friction");
    same3(collider.sensor, false, "sensor");
    same3(collider.ccd, false, "ccd");
    same3(collider.filter, { categoryBits: 1, maskBits: 65535 }, "filter");
    colliders.set(colliderId2, collider);
  }
  check3(owners.size === bodies.size, "Every static owner requires one collider");
  const data = clothProfile ? exact(clothInputs[0], CLOTH_FIELDS, "cloth") : exact(fluidInputs[0], FLUID_FIELDS, "fluid");
  id(data.id);
  const refs = array(data.staticColliderIds, count, "staticColliderIds");
  check3(new Set(refs).size === refs.length && refs.every((ref) => typeof ref === "string" && colliders.has(ref)), "Invalid domain collider references");
  const numericalIds = new Set(ids2);
  for (const value of model.sourceBindings) {
    const binding = exact(value, ["id", "sourceRevision", "sourceDigest", "modelId", "occurrenceId", "entityIds", "approximation"], "sourceBinding");
    id(binding.id);
    for (const key of ["sourceRevision", "modelId", "occurrenceId"]) check3(typeof binding[key] === "string" && binding[key].length > 0 && binding[key].length <= 4096, `Invalid ${key}`);
    check3(typeof binding.sourceDigest === "string" && /^sha256:[0-9a-f]{64}$/.test(binding.sourceDigest), "Invalid source digest");
    check3(Array.isArray(binding.entityIds) && binding.entityIds.length > 0 && binding.entityIds.length <= 128 && new Set(binding.entityIds).size === binding.entityIds.length && binding.entityIds.every((ref) => typeof ref === "string" && numericalIds.has(ref)), "Invalid source binding references");
    const approximation = exact(binding.approximation, ["kind", "lossLabel"], "approximation");
    check3(approximation.kind === "control-net-box" || approximation.kind === "control-net-sphere", "Unsupported approximation");
    check3(typeof approximation.lossLabel === "string" && approximation.lossLabel.length > 0 && approximation.lossLabel.length <= 4096, "Invalid loss label");
  }
  const staticData = { profile, gravityMps2: model.gravityMps2, bodies: model.bodies, colliders: model.colliders };
  if (clothProfile) {
    for (const key of CLOTH_FIELDS) if (key !== "id" && key !== "staticColliderIds") same3(data[key], nativeClothReference[key], `cloth.${key}`);
    const collider = colliderInputs[0], body = bodies.get(collider.bodyId);
    same3(collider.geometry, { kind: "sphere", radiusM: CLOTH_PROFILE.sphereRadiusM }, "cloth sphere");
    same3(body.initial.positionM, CLOTH_PROFILE.sphereCentreM, "cloth sphere position");
    return { kind: "cloth", data: model.cloths[0], staticData };
  }
  same3(data.massModel, { kind: "visual-unit-weights" }, "massModel");
  same3(data.particleRadiusM, FLUID_PARTICLE_RADIUS_M, "particleRadiusM");
  same3(data.smoothingRadiusM, FLUID_SMOOTHING_RADIUS_M, "smoothingRadiusM");
  same3(data.visualSmoothing, profile === "fluid-basin-xsph-visual-v1" ? { kind: "xsph", coefficient: 0.15 } : { kind: "none" }, "visualSmoothing");
  const points = array(data.initialPositionsM, 256, "initialPositionsM").map((point2, index) => triple(point2, `initialPositionsM[${index}]`));
  array(data.initialVelocitiesMps, 256, "initialVelocitiesMps").forEach((velocity, index) => same3(velocity, [0, 0, 0], `initialVelocitiesMps[${index}]`));
  for (const point2 of points) for (let axis = 0; axis < 3; axis++) check3(point2[axis] >= FLUID_PARTICLE_RADIUS_M && point2[axis] <= FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M, "Initial particle is outside the basin");
  const minimumSquared = FLUID_MIN_SPACING_M ** 2;
  for (let first = 0; first < 256; first++) for (let second = first + 1; second < 256; second++) {
    const dx = points[first][0] - points[second][0], dy = points[first][1] - points[second][1], dz = points[first][2] - points[second][2];
    check3(!(dx * dx + dy * dy + dz * dz < minimumSquared - 1e-12), "Initial particles must be at least 0.025 m apart");
  }
  const basin = colliderInputs.find((value) => value.geometry.kind === "box-interior");
  check3(basin, "Fluid requires one basin");
  const basinHalf = FLUID_BASIN_M.map((value) => value / 2);
  same3(basin.geometry.halfExtentsM, basinHalf, "basin half extents");
  same3(bodies.get(basin.bodyId).initial.positionM, basinHalf, "basin position");
  if (boxProfile) {
    const box3 = colliderInputs.find((value) => value.geometry.kind === "box");
    check3(box3, "Static fluid profile requires one box");
    const body = bodies.get(box3.bodyId);
    const bounds = inflatedBoxBounds(
      body.initial.positionM,
      box3.geometry.halfExtentsM
    );
    for (let axis = 0; axis < 3; axis++) check3(bounds.low[axis] >= FLUID_PARTICLE_RADIUS_M && bounds.high[axis] <= FLUID_BASIN_M[axis] - FLUID_PARTICLE_RADIUS_M, "Static box exceeds the basin");
    const overlapScratch = Float64Array.from(points.flat());
    check3(!insideStaticBox(overlapScratch, bounds), "Static box overlaps initial particles");
  } else check3(colliderInputs.length === 1, "Unsupported fluid collider population");
  return { kind: "fluid", data: model.fluids[0], staticData };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/model-admission.ts
function exact2(value, keys, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) error("INVALID_CONFIG", `${label} must be a record`);
  const input = value;
  if (Object.keys(input).length !== keys.length || keys.some((key) => !Object.hasOwn(input, key))) error("INVALID_CONFIG", `${label} requires exact fields: ${keys.join(",")}`);
  return input;
}
function text(value, label) {
  if (typeof value !== "string" || value.length === 0 || value.length > 4096) error("INVALID_CONFIG", `${label} must be a bounded nonempty string`);
  return value;
}
function list(value, maximum, label) {
  if (!Array.isArray(value) || value.length > maximum) error("INVALID_CONFIG", `${label} exceeds the profile bound`);
  return value;
}
function transform2(value, label) {
  const t = exact2(value, ["positionM", "orientationXYZW"], label);
  vector4(t.positionM, -1e4, 1e4, `${label}.positionM`);
  if (!Array.isArray(t.orientationXYZW) || t.orientationXYZW.length !== 4) error("INVALID_CONFIG", `${label} requires an XYZW quaternion`);
  const q3 = t.orientationXYZW.map((x) => finite(x, -1, 1, label));
  if (Math.abs(Math.hypot(...q3) - 1) > 1e-6) error("INVALID_CONFIG", `${label} quaternion must have unit norm`);
}
function admitModel(rawModel, rawOptions) {
  const model = copyData(rawModel);
  const options = copyData(rawOptions);
  const input = exact2(model, ["format", "version", "revision", "frame", "units", "gravityMps2", "bodies", "colliders", "joints", "cloths", "fluids", "sourceBindings"], "model");
  if (input.format !== "barocss-physics-model" || input.version !== 1) error("INVALID_CONFIG", "unsupported model format or version");
  text(input.revision, "revision");
  const frame = exact2(input.frame, ["id", "basis", "rotation"], "frame");
  text(frame.id, "frame.id");
  if (frame.basis !== "right-handed-xyz" || frame.rotation !== "local-to-world-xyzw") error("INVALID_CONFIG", "unsupported frame convention");
  const units = exact2(input.units, ["length", "mass", "time", "angle"], "units");
  if (units.length !== "m" || units.mass !== "kg" || units.time !== "s" || units.angle !== "rad") error("INVALID_CONFIG", "model units must be m/kg/s/rad");
  vector4(input.gravityMps2, -1e3, 1e3, "gravityMps2");
  const opt = exact2(options, ["profile", "fixedStepSeconds", "broadPhase"], "options");
  const domain = admitDomainModel(model, options);
  if (domain) return { model, options, bodies: [], joints: [], disjointHinges: null, domain };
  if (!["rigid-discrete-v1", "rigid-persistent-box-v1", "rigid-large-v1"].includes(opt.profile)) error("INVALID_CONFIG", "profile is not implemented");
  finite(opt.fixedStepSeconds, 1 / 240, 1 / 30, "fixedStepSeconds");
  const large = opt.profile === "rigid-large-v1";
  if (opt.broadPhase !== "aabb" && (large || opt.broadPhase !== "direct")) error("INVALID_CONFIG", "unsupported broadPhase for profile");
  const bodyInputs = list(input.bodies, large ? 64 : opt.profile === "rigid-persistent-box-v1" ? 4 : 32, "bodies");
  if (bodyInputs.length === 0) error("INVALID_CONFIG", "at least one body is required");
  const colliders = list(input.colliders, bodyInputs.length, "colliders");
  const jointInputs = list(input.joints, large ? 0 : 8, "joints");
  list(input.cloths, 0, "cloths");
  list(input.fluids, 0, "fluids");
  const bindings = list(input.sourceBindings, 128, "sourceBindings");
  const ids2 = /* @__PURE__ */ new Set();
  function id(value) {
    if (typeof value !== "string" || !ID.test(value) || ids2.has(value)) error("INVALID_CONFIG", "invalid or duplicate global entity ID");
    ids2.add(value);
    return value;
  }
  const bodiesById = /* @__PURE__ */ new Map();
  for (const value of bodyInputs) {
    const raw = value;
    const b2 = exact2(value, raw?.kind === "dynamic" ? ["id", "kind", "massKg", "inertia", "initial"] : ["id", "kind", "initial"], "body");
    const bodyId = id(b2.id);
    if (!["dynamic", "static", "kinematic"].includes(b2.kind)) error("INVALID_CONFIG", "unsupported body kind");
    if (b2.kind === "dynamic") {
      const initial = exact2(b2.initial, ["positionM", "orientationXYZW", "velocityMps", "angularVelocityRadps"], "initial");
      transform2({ positionM: initial.positionM, orientationXYZW: initial.orientationXYZW }, "initial");
      vector4(initial.velocityMps, -1e3, 1e3, "velocityMps");
      vector4(initial.angularVelocityRadps, -1e3, 1e3, "angularVelocityRadps");
      finite(b2.massKg, 1e-6, 1e6, "massKg");
      const i = b2.inertia;
      exact2(i, i?.kind === "sphere-isotropic" ? ["kind", "about", "frame", "kgM2"] : ["kind", "about", "frame"], "inertia");
      if (i.about !== "com" || i.frame !== "body-local" || !["primitive-com", "sphere-isotropic"].includes(i.kind)) error("INVALID_CONFIG", "unsupported inertia");
      if (i.kind === "sphere-isotropic") finite(i.kgM2, 1e-12, 1e12, "inertia.kgM2");
    } else transform2(b2.initial, "initial");
    bodiesById.set(bodyId, b2);
  }
  const colliderByBody = /* @__PURE__ */ new Map();
  for (const value of colliders) {
    const c = exact2(value, ["id", "bodyId", "geometry", "local", "material", "sensor", "ccd", "filter"], "collider");
    id(c.id);
    if (typeof c.bodyId !== "string" || !bodiesById.has(c.bodyId) || colliderByBody.has(c.bodyId)) error("INVALID_CONFIG", "collider requires a unique declared owner");
    transform2(c.local, "collider.local");
    const local = c.local;
    if (local.positionM.some((x) => x !== 0) || local.orientationXYZW.some((x, i) => x !== (i === 3 ? 1 : 0))) error("INVALID_CONFIG", "only identity-local colliders are admitted");
    if (typeof c.sensor !== "boolean" || typeof c.ccd !== "boolean") error("INVALID_CONFIG", "sensor and ccd must be explicit booleans");
    const material = exact2(c.material, ["restitution", "friction"], "material");
    exact2(material.friction, ["static", "dynamic"], "friction");
    const filter = exact2(c.filter, ["categoryBits", "maskBits"], "filter");
    if (!large && (filter.categoryBits !== 1 || filter.maskBits !== 65535)) error("INVALID_CONFIG", "non-large profile requires no-filter values");
    const body = bodiesById.get(c.bodyId);
    if (c.sensor && body.kind === "dynamic" || c.ccd && body.kind !== "dynamic") error("INVALID_CONFIG", "unsupported sensor or CCD body role");
    colliderByBody.set(c.bodyId, c);
  }
  if (colliderByBody.size !== bodyInputs.length) error("INVALID_CONFIG", "each rigid body requires exactly one collider");
  const bodies = bodyInputs.map((value) => {
    const b2 = value;
    const c = colliderByBody.get(b2.id);
    const initial = b2.initial;
    const material = c.material;
    const inertia2 = b2.inertia;
    return parseBody({
      id: b2.id,
      kind: b2.kind,
      shape: c.geometry,
      positionM: initial.positionM,
      orientation: initial.orientationXYZW,
      restitution: material.restitution,
      friction: material.friction,
      ...large ? { collisionFilter: c.filter } : {},
      ...c.sensor ? { sensor: true } : {},
      ...c.ccd ? { ccd: true } : {},
      ...b2.kind === "dynamic" ? {
        massKg: b2.massKg,
        velocityMps: initial.velocityMps,
        angularVelocityRadps: initial.angularVelocityRadps,
        ...inertia2?.kind === "sphere-isotropic" ? { inertiaKgM2: inertia2.kgM2 } : {}
      } : {}
    }, large);
  });
  if (!bodies.some((b2) => b2.kind === "dynamic")) error("INVALID_CONFIG", "at least one dynamic body is required");
  if (large && bodies.some((b2) => b2.ccd)) error("INVALID_CONFIG", "large profile excludes CCD");
  const numericJoints = jointInputs.map((value) => {
    const raw = value;
    const j = exact2(value, raw?.kind === "hinge" ? ["id", "kind", "bodyAId", "bodyBId", "anchorALocalM", "anchorBLocalM", "axisWorld", "limitRad", "motor"] : ["id", "kind", "bodyAId", "bodyBId", "anchorALocalM", "anchorBLocalM"], "joint");
    id(j.id);
    if (j.kind !== "fixed" && j.kind !== "hinge") error("INVALID_CONFIG", "unsupported joint kind");
    if (j.kind === "hinge" && j.motor !== null) exact2(j.motor, ["targetSpeedRadps", "maxImpulseNms", "maxReactionNms"], "motor");
    return {
      id: j.id,
      kind: j.kind,
      aId: j.bodyAId,
      bId: j.bodyBId,
      anchorALocalM: j.anchorALocalM,
      anchorBLocalM: j.anchorBLocalM,
      ...j.kind === "hinge" ? { axisWorld: j.axisWorld, limitRad: j.limitRad, ...j.motor === null ? {} : { motor: j.motor } } : {}
    };
  });
  const disjoint = parseDisjointHingeProfile(model, options, numericJoints, bodies);
  const joints = disjoint ? disjoint.joints : parseJoints(numericJoints, bodies);
  const numericalIds = new Set(ids2);
  for (const value of bindings) {
    const s = exact2(value, ["id", "sourceRevision", "sourceDigest", "modelId", "occurrenceId", "entityIds", "approximation"], "sourceBinding");
    id(s.id);
    for (const key of ["sourceRevision", "modelId", "occurrenceId"]) text(s[key], key);
    if (typeof s.sourceDigest !== "string" || !/^sha256:[0-9a-f]{64}$/.test(s.sourceDigest)) error("INVALID_CONFIG", "invalid source digest");
    const refs = list(s.entityIds, 128, "entityIds");
    if (refs.length === 0 || new Set(refs).size !== refs.length || refs.some((ref) => typeof ref !== "string" || !numericalIds.has(ref))) error("INVALID_CONFIG", "invalid source binding references");
    const a2 = exact2(s.approximation, ["kind", "lossLabel"], "approximation");
    if (a2.kind !== "control-net-box" && a2.kind !== "control-net-sphere") error("INVALID_CONFIG", "unsupported approximation");
    text(a2.lossLabel, "lossLabel");
  }
  return { model, options, bodies, joints, disjointHinges: disjoint?.pairs ?? null, domain: null };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/recording-owner.ts
var recordingWorlds = /* @__PURE__ */ new WeakMap();

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/provider-manifest.generated.ts
var providerManifest = {
  "format": "barocss-physics-private-typed-producer-02",
  "version": 1,
  "graph": "PRIVATE_TYPED_SOURCE_AND_EMITTED",
  "parentQualifiedManifestSha256": "c9d894ad3af023ebd0834341bc559163163401c54aa8652986dacf0f0b2add12",
  "files": {
    "B/candidate.ts": {
      "bytes": 15364,
      "sha256": "1fda2dd0a8f8d39ecdbe50c391c707c800ec7f0c4be69de7bd09730b656cde48"
    },
    "B/native.ts": {
      "bytes": 17864,
      "sha256": "15a1931ed4fc5cc91bbae4fde700258a039aa3e081c128bc61030474de38200d"
    },
    "entry.ts": {
      "bytes": 326,
      "sha256": "254a30b400e5ed6fef8c6cc71e4f81af0555db68a3d56ed7d30e0a43b29e8502"
    },
    "physics/src/broadphase.ts": {
      "bytes": 1371,
      "sha256": "d93e38d78cc3d202481ceeba83631d528032426d03a8adafb2e461fc72a042a0"
    },
    "physics/src/cad-fluid-data.ts": {
      "bytes": 2345,
      "sha256": "5a15e23ba65663433501f07d2f35f323960879218d52a007efeb09ca7934ce10"
    },
    "physics/src/cad-proxy-admission.ts": {
      "bytes": 7744,
      "sha256": "898fb55af369727440fef9f4bfadba0ea455b4c800a719909e5311029a663441"
    },
    "physics/src/cad-proxy-pose.ts": {
      "bytes": 1479,
      "sha256": "8b5f50642144e335421ee6483f8b016b8a0babdb0c312ddf6ba4afbcf8bda322"
    },
    "physics/src/cad-proxy-types.ts": {
      "bytes": 887,
      "sha256": "31bbf6766887913149d6fa2185c173adb0c6b78cdb21d1556ae4ffd055666128"
    },
    "physics/src/cad-proxy-validation.ts": {
      "bytes": 1598,
      "sha256": "4429f957bb51ff2604a15478095e35642368dcf91ca0d854561693d3f99f748e"
    },
    "physics/src/cad-proxy.ts": {
      "bytes": 321,
      "sha256": "cc7715b4fc974c8ed4511ebf684cdc7c2923f7ab4b8b7f5db45b208f8e6ffa99"
    },
    "physics/src/capsule-contact.ts": {
      "bytes": 5615,
      "sha256": "cc29d60423bd9a1883585cf164cca0b0736b9fc72e7feb3575c5208c7d892929"
    },
    "physics/src/capsule-query-error.ts": {
      "bytes": 137,
      "sha256": "fc49c7e09495dee70e9f5cea4782b29e1350f72a470a3059f1df3533768e565f"
    },
    "physics/src/capsule-query.ts": {
      "bytes": 222,
      "sha256": "ff66d04550032e0328793f52516edf1ad47fc427f954b031b5836defa14367d1"
    },
    "physics/src/capsule-query/admission.ts": {
      "bytes": 5248,
      "sha256": "9b67efc7a8824ce49361485eff925afa50017e05bc23d900db5ec7c4e2c8760d"
    },
    "physics/src/capsule-query/geometry.ts": {
      "bytes": 2570,
      "sha256": "5fdbe1eb40f46e930161e98244a9e5ec0e00c29297caf6f91d530c98df3df4a7"
    },
    "physics/src/capsule-query/profile.ts": {
      "bytes": 303,
      "sha256": "e74faf4a8d0d0e14765e97270619acebb4c2bff531d57bc42a0e3abf65d647ff"
    },
    "physics/src/capsule-query/snapshot.ts": {
      "bytes": 2537,
      "sha256": "6a0994b1b55c962fe7ffc4e5fb55fd90404e1051568b16edf3adda8dc9adb7bd"
    },
    "physics/src/capsule-query/sweep.ts": {
      "bytes": 1861,
      "sha256": "a8f4d16879b2ff88086ceec54cef19d04d58fb063893e7a146382cad59cbaf77"
    },
    "physics/src/capsule-query/types.ts": {
      "bytes": 979,
      "sha256": "c22d17887cd8ab889a443c828200310a4c560fd3b4f8ed49f3f1f60e5dd46f44"
    },
    "physics/src/ccd-box.ts": {
      "bytes": 1988,
      "sha256": "076eadf591500684332bd19b53a780de480ccdde205196ad072a11e1abc4f7a4"
    },
    "physics/src/ccd-pair.ts": {
      "bytes": 1303,
      "sha256": "87ea34e6b662b223874857651839407f351b0beaa03a4a85d1e4797744027e1a"
    },
    "physics/src/ccd-rounded-box.ts": {
      "bytes": 8125,
      "sha256": "b4ad5a06435b1bacb796dace179f95904fd9d35e4e9dac17ead55bc2f675f59c"
    },
    "physics/src/ccd-slab.ts": {
      "bytes": 1125,
      "sha256": "f2bad0028aa148ec00073d02a865273389f5a032ea9fc8a3c5b244af20b7e340"
    },
    "physics/src/ccd-sphere-pair-exact.ts": {
      "bytes": 5307,
      "sha256": "2ee601d4e363d135fc356cef37a43495524449bb4dc38abe8f62848bdf28645c"
    },
    "physics/src/ccd.ts": {
      "bytes": 3183,
      "sha256": "861e2b8fa56c746232581f1debddab0b88574df81187cb6dd2d6b8db7377d95e"
    },
    "physics/src/character-controller.ts": {
      "bytes": 1363,
      "sha256": "3895d5bcd44b99d7f036f0a8a9d95e4ced268c837a6aa293c5e09dfa791d3927"
    },
    "physics/src/character/admission.ts": {
      "bytes": 4488,
      "sha256": "d83cdb8231620a18935d4d4d5e19ab7ec5440b043e1df71d49d5fa42f3fecb26"
    },
    "physics/src/character/core.ts": {
      "bytes": 4057,
      "sha256": "6c6251e9782baed07be65cce68bfdbca14e2f930ca04a54ee6812cbbfc925a02"
    },
    "physics/src/character/ground.ts": {
      "bytes": 1242,
      "sha256": "bd1621641ebc9300943b88c9083710218768454acb0a5e1ba8b330086d68c321"
    },
    "physics/src/character/math.ts": {
      "bytes": 859,
      "sha256": "df0e88c320d8a189004991cd5cfc3f8de3d7bb3eecb305bb01830a11191dcdc5"
    },
    "physics/src/character/profile.ts": {
      "bytes": 334,
      "sha256": "e6c57ae9bbb7f28221cf2ced05b7c17af5f575f2c6a60fa106ba5a98bb3c7c82"
    },
    "physics/src/character/query.ts": {
      "bytes": 2733,
      "sha256": "9ef96eeb1529dc42466445529b100affc2f56913081f0c2fc169079cffe1a8cf"
    },
    "physics/src/character/slide.ts": {
      "bytes": 2555,
      "sha256": "587d5512212e68fdc26068646152d2f8c52c3c6119d6c222de91b750c01fcd77"
    },
    "physics/src/character/state.ts": {
      "bytes": 2181,
      "sha256": "6eb744c82f24604a8ecadd6e9d86406600119a3fbc7918129f93983df7cbf47e"
    },
    "physics/src/character/step-assist.ts": {
      "bytes": 3129,
      "sha256": "9166857ad8509049a56d5b255ed59de17ee03e159581b495de7f1d985780c390"
    },
    "physics/src/character/types.ts": {
      "bytes": 2552,
      "sha256": "866c5974fd99ec08b5dc6b5edf165241f4d02a8ed87274faf4cf35b19a3fb938"
    },
    "physics/src/cloth/constraints.ts": {
      "bytes": 1772,
      "sha256": "a7a3985db7a7fb8d4a57a23762213372bf603903146deacfc44fb3c9315c30be"
    },
    "physics/src/cloth/metrics.ts": {
      "bytes": 1805,
      "sha256": "eed36beccf69ce65426890570055e2e65b7f76fb0de69a5af2cda429fb511cdd"
    },
    "physics/src/cloth/profile.ts": {
      "bytes": 655,
      "sha256": "11ba66ccf169ca69883f331f1fcbd38b423fa98e30ee4eb6515489d1b212f33f"
    },
    "physics/src/cloth/solver.ts": {
      "bytes": 1395,
      "sha256": "3aeb46169cf8f587f3e79196f3cdd21d28785cf2f7aa0a1be2fe7b5e5a466c1d"
    },
    "physics/src/cloth/topology.ts": {
      "bytes": 1931,
      "sha256": "5184d75dd9906e953bdb1b3e8b0b420ece01a95a400c9f8651d56d79017af203"
    },
    "physics/src/cloth/types.ts": {
      "bytes": 719,
      "sha256": "bad411f3fa02e4ba7039b5d447de395074342aa207f2eeed251705b15facb6d1"
    },
    "physics/src/collision.ts": {
      "bytes": 14404,
      "sha256": "8af301d4addf3b61a38fc54466a73dde48d27907f4143032d500962adbff47a3"
    },
    "physics/src/contact-manifold.ts": {
      "bytes": 4743,
      "sha256": "bd5ded2eb5b22422eb020f44129ef1f5687fc84831b123d9a6dadbf7f0d69428"
    },
    "physics/src/contact-tangent.ts": {
      "bytes": 2729,
      "sha256": "5e1bddc158f9a6f307fdcc60ce8078ab36a06e372d530e7f5d05466d29bf9673"
    },
    "physics/src/disjoint-hinge/admission.ts": {
      "bytes": 3764,
      "sha256": "2088e36fc689f114d31a208263d1b1273e0e49874deee90e38b290a14df0ec3d"
    },
    "physics/src/disjoint-hinge/errors.ts": {
      "bytes": 2777,
      "sha256": "5e51e5662fbce80bee3ccd3aa3694ee986b1492ed816d171774e261ab982bf4f"
    },
    "physics/src/disjoint-hinge/linear-solver.ts": {
      "bytes": 10615,
      "sha256": "4009d4d7f171be3a5d79ca309a14b039da54f9201b438a410a6e29ed0f90bfdf"
    },
    "physics/src/disjoint-hinge/measure.ts": {
      "bytes": 4626,
      "sha256": "97cbaf697dc8ef5caba0bf2c702699b025bcc6f906f553b623466618bbd77178"
    },
    "physics/src/disjoint-hinge/pose.ts": {
      "bytes": 3194,
      "sha256": "ab950c1f9f1a79f9f00cb26e4b3cef0e3dcaea7b16d74e345e711159706b39e4"
    },
    "physics/src/disjoint-hinge/postcontact.ts": {
      "bytes": 2936,
      "sha256": "8d07190383a64cb592165772109a4f462099743492f8373794ef7981b1431e38"
    },
    "physics/src/disjoint-hinge/projection.ts": {
      "bytes": 3538,
      "sha256": "9d0def632c07f8085e860a2dbf21f26d8073f3265eb57590607d23ea6d333b87"
    },
    "physics/src/disjoint-hinge/report.ts": {
      "bytes": 5726,
      "sha256": "d46b3e289c58b289b059928580ff2b89d9bd3ecfb11cb688d8b7a4735143973d"
    },
    "physics/src/disjoint-hinge/rows.ts": {
      "bytes": 3685,
      "sha256": "6556f07d1d7d22edb67af1b214c689c5b5c2b30628334abaec67280d7302903f"
    },
    "physics/src/disjoint-hinge/stage.ts": {
      "bytes": 2648,
      "sha256": "a66e09b816259c2bb1305fed8f90696585b9fd4b750406b0ce006cbe2c2f33ab"
    },
    "physics/src/disjoint-hinge/types.ts": {
      "bytes": 1610,
      "sha256": "89b2708fd9209932084eaa765f93ff6ea00a2d775911e8c9e607a7eb824c8cc1"
    },
    "physics/src/domain/admission.ts": {
      "bytes": 11327,
      "sha256": "1182fb21ec319132ac2f16ddec8494e3d1c4c5ac750bbe1ebab4c29817b4423e"
    },
    "physics/src/domain/cloth-reference.generated.ts": {
      "bytes": 158018,
      "sha256": "c9ee88af8e25b533c2694433502b28f51dffdeae5cce656b53eb36a187be60bc"
    },
    "physics/src/domain/cloth.ts": {
      "bytes": 4349,
      "sha256": "2454474a24928a9f3d92d635a9391c537ef74de77112fdc2f2872536cb447883"
    },
    "physics/src/domain/fluid.ts": {
      "bytes": 4923,
      "sha256": "bfcafa7cc2f2bbb4ec6e2c20797f5dc5410d995cd28305272a2c3665d827179a"
    },
    "physics/src/domain/types.ts": {
      "bytes": 3839,
      "sha256": "35fcadf07a848d919806955f6c3d934d01217ff1c26ca7d4eb4eb2807eb4ee6f"
    },
    "physics/src/dynamic-anchor-pair.ts": {
      "bytes": 3072,
      "sha256": "8ff622a6ce007e5e7fcb43f0b7c08521615ddacbc8195cde1ac4f574304b579d"
    },
    "physics/src/dynamic-fixed-joint.ts": {
      "bytes": 2051,
      "sha256": "f5a0fa82c062c7406f6edfeb2aeb169c927ddd8d0965957f630f87e118c52dfa"
    },
    "physics/src/dynamic-hinge-joint.ts": {
      "bytes": 4835,
      "sha256": "69c816393446b6e06d66849840ecf88a7d28baf72bd30c792180616f55e455f2"
    },
    "physics/src/fluid/boundary.ts": {
      "bytes": 1990,
      "sha256": "ba35dd2c09d811bf632ab35f8403c3632a8f8612605873b6edd7f4ad355dd58c"
    },
    "physics/src/fluid/constants.ts": {
      "bytes": 459,
      "sha256": "1eb1222c808e34501b19c226cba9c75a472bfb4897d31435f8588578b582c8ec"
    },
    "physics/src/fluid/diagnostics.ts": {
      "bytes": 1106,
      "sha256": "e983d0c68fba92c3ccf81011d26b2f0a22fe27aa2627ec0db87148a1c1037215"
    },
    "physics/src/fluid/kernel.ts": {
      "bytes": 1112,
      "sha256": "e4ff7c5679f13483d372cc9752cc658f6e36dff751edbaca1767c6c868ef08da"
    },
    "physics/src/fluid/neighbors.ts": {
      "bytes": 2949,
      "sha256": "2aa8f0e112cd45121052c9a0861e8320eca42280385a8a812ebc4ca1255817f3"
    },
    "physics/src/fluid/pbf.ts": {
      "bytes": 5161,
      "sha256": "21f11547aa3c4954f6709ee0207c98616f76235d2e38e831699a927547a30e50"
    },
    "physics/src/fluid/static-box.ts": {
      "bytes": 2481,
      "sha256": "899351a48081261902684f6b0f67c6ac3e7cd3d0eba217bbdd8a331c2ff875a9"
    },
    "physics/src/fluid/types.ts": {
      "bytes": 125,
      "sha256": "c75f020afeb760ec596c3043fc6d2a7166995ce0c3cedbc7e5424a6a83e56a62"
    },
    "physics/src/fluid/visual-viscosity.ts": {
      "bytes": 1265,
      "sha256": "0b26713f05556367d8266c0010e12a521d4adefa536e6c422eac7691309bbfc3"
    },
    "physics/src/generate-provider.mjs": {
      "bytes": 2663,
      "sha256": "c45a6eb52df5f4840aa30006ac65d15ea0758066f63d815e4a3b394e8eb20557"
    },
    "physics/src/identity.ts": {
      "bytes": 6081,
      "sha256": "ebabb654375eb0c213dca4db06769011248ed58f844b9c3f9038dfb676caf4be"
    },
    "physics/src/index.ts": {
      "bytes": 570,
      "sha256": "dc4085b1a0b4e2af15198e35c43125d907c4b0991fc1c57a24ee421bb7011d30"
    },
    "physics/src/internal-types.ts": {
      "bytes": 2615,
      "sha256": "29f39921c4a9806e2ade9126a5748b1a17cafb40a8ade1d67fc303cafe2916a8"
    },
    "physics/src/joint-motor.ts": {
      "bytes": 1723,
      "sha256": "9a50b0d006ca2386cd2d79b8ba162f6850a5d08d3eb1c7d03460d606559b56ea"
    },
    "physics/src/joints.ts": {
      "bytes": 7231,
      "sha256": "b6d0ec667a96fc26ec43d9d812c5ffd0a3b7446d135bd9b18713059327c59181"
    },
    "physics/src/limits.ts": {
      "bytes": 417,
      "sha256": "748bad886bb7acf5fedc21b8251243b018858b7e5de2478c99fb86a9276c54c3"
    },
    "physics/src/math.ts": {
      "bytes": 2421,
      "sha256": "d782fc9eab8f699e906cde0df580c625f054905f12999edf50fd60bf54e7a3c2"
    },
    "physics/src/model-admission.ts": {
      "bytes": 10384,
      "sha256": "7e77f184fed57d51ee1b0599e60c80d83b96045b139d236a37f76a4207689397"
    },
    "physics/src/persistent-box-contact.ts": {
      "bytes": 4877,
      "sha256": "ac7730c1bf083697cbc7ecd1e3d027dc7873c66f5f902bab6a8a4dec0860e3b8"
    },
    "physics/src/phase-hit.ts": {
      "bytes": 3148,
      "sha256": "9ddb20f79c73f41f58b2a386bd3d2a2b0bee75bbed80998e3b2b8230f05def32"
    },
    "physics/src/private-phase.ts": {
      "bytes": 7962,
      "sha256": "1225c0ec6dc3f2a3339bfbeb00dc75d2a5dcdd6073bbc9f36d35ea51b4715d97"
    },
    "physics/src/producer.ts": {
      "bytes": 4937,
      "sha256": "32be53571acbc0d2832ac75111196b78a56d4ba91a3be4849c45a3d2d24d4ff1"
    },
    "physics/src/recording-owner.ts": {
      "bytes": 895,
      "sha256": "378ef215a8d3c644e665492875b1993a19f5e8e514480d931cd75abacf2e74a1"
    },
    "physics/src/replay-compare.ts": {
      "bytes": 1023,
      "sha256": "918c89b8d8e84cdab25a951a44f8aa9368a904aa6a13804dafbef8ca81b421ec"
    },
    "physics/src/replay-json.ts": {
      "bytes": 7760,
      "sha256": "bdc7a0286abe05595c949a5fda0aa2522820ccb7380c0d503f3784a2c51d4fed"
    },
    "physics/src/replay-validation.ts": {
      "bytes": 9475,
      "sha256": "f8da9f6c749b45bdd3c2ae61fc1e1bf9d73218e6f286a8557cc46277179440ec"
    },
    "physics/src/replay.ts": {
      "bytes": 7119,
      "sha256": "cad01e2cdc0d5ce879e17b1e0998ce83448b1a3b2368c339a9651b227b966742"
    },
    "physics/src/rigid-forced-rotation.ts": {
      "bytes": 4961,
      "sha256": "52447f9daa9da5c7382bd59d7132e3936ddf667942cbefd3fafeb79274e06d44"
    },
    "physics/src/rigid-free-rotation.ts": {
      "bytes": 11619,
      "sha256": "63e5fd31e798a7bd85f56d0d0b5b5bad58d61e2c848594328fa74bf1c254dbbf"
    },
    "physics/src/rotation-validation.ts": {
      "bytes": 780,
      "sha256": "45281b213700f86af36ea6d1a9189ca54349d13d01c37eeb366f1cdd474c1408"
    },
    "physics/src/scene-profile.ts": {
      "bytes": 1202,
      "sha256": "e927339931ce9ebbf2f13808017bd1106e4ed4dbfa4f63fdf2f2ed0376d94ff7"
    },
    "physics/src/sleep.ts": {
      "bytes": 4411,
      "sha256": "f02ac9d68560fc8ce8f529c68a6d8657155e3f6b36beb4907534871e375569f2"
    },
    "physics/src/types.ts": {
      "bytes": 12312,
      "sha256": "21e897fbaf967888d7748a25e81def8a31b81312a573b642e3f12b13c8b450da"
    },
    "physics/src/validation.ts": {
      "bytes": 14962,
      "sha256": "c5787fdbe5e31a51e52fb6b91634f75b363a629bb4a88248273e85c8ffc948af"
    },
    "physics/src/world.ts": {
      "bytes": 26633,
      "sha256": "1494459fdfaac60f5479e65669bd7a90b1342432586056b7224722f1f459c233"
    }
  },
  "deltas": [
    "admission-forbidden domain/large branches removed",
    "typed schema2 producer and actual contribution boundaries",
    "validated unknown-to-PhaseHit boundary"
  ],
  "law": "UNCHANGED_8_OUTER_8_INNER_NORMAL_TANGENT_CACHE"
};

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/joint-motor.ts
function driveHingeMotor(joint, body, angleRad) {
  const motor = joint.motor;
  const axis = joint.axisWorld;
  const [low, high] = joint.limitRad;
  if (angleRad <= low && motor.targetSpeedRadps < 0 || angleRad >= high && motor.targetSpeedRadps > 0) return 0;
  const inverseAxisInertia = dot3(axis, inverseInertia(body, axis));
  const speed = dot3(body.angularVelocityRadps, axis);
  const needed = (motor.targetSpeedRadps - speed) / inverseAxisInertia;
  const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
  body.angularVelocityRadps = add2(
    body.angularVelocityRadps,
    inverseInertia(body, scale(axis, impulse))
  );
  return impulse;
}
function driveDynamicHingeMotor(joint, a2, b2, angleRad) {
  const motor = joint.motor;
  const axis = joint.axisWorld;
  const [low, high] = joint.limitRad;
  if (angleRad <= low && motor.targetSpeedRadps < 0 || angleRad >= high && motor.targetSpeedRadps > 0) return 0;
  const inverseSum = dot3(axis, inverseInertia(a2, axis)) + dot3(axis, inverseInertia(b2, axis));
  const speed = dot3(sub(b2.angularVelocityRadps, a2.angularVelocityRadps), axis);
  const needed = (motor.targetSpeedRadps - speed) / inverseSum;
  const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
  a2.angularVelocityRadps = sub(
    a2.angularVelocityRadps,
    inverseInertia(a2, scale(axis, impulse))
  );
  b2.angularVelocityRadps = add2(
    b2.angularVelocityRadps,
    inverseInertia(b2, scale(axis, impulse))
  );
  return impulse;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-contact.ts
var clamp2 = (value, low, high) => Math.max(low, Math.min(high, value));
function capsuleEnds(body) {
  const half = body.shape.halfLengthM;
  return [worldPoint(body, [0, -half, 0]), worldPoint(body, [0, half, 0])];
}
function segmentPair(a0, a1, b0, b1) {
  const u = sub(a1, a0), v = sub(b1, b0), w = sub(a0, b0);
  const aa = dot3(u, u), bb = dot3(u, v), cc = dot3(v, v);
  const dd = dot3(u, w), ee = dot3(v, w), determinant = aa * cc - bb * bb;
  const candidates = [
    [0, clamp2(ee / cc, 0, 1)],
    [1, clamp2((bb + ee) / cc, 0, 1)],
    [clamp2(-dd / aa, 0, 1), 0],
    [clamp2((bb - dd) / aa, 0, 1), 1],
    [0.5, clamp2((bb * 0.5 + ee) / cc, 0, 1)],
    [clamp2((bb * 0.5 - dd) / aa, 0, 1), 0.5]
  ];
  if (determinant > 1e-12 * aa * cc) {
    const s = (bb * ee - cc * dd) / determinant;
    const t = (aa * ee - bb * dd) / determinant;
    if (s >= 0 && s <= 1 && t >= 0 && t <= 1) candidates.push([s, t]);
  }
  let best = candidates[0], bestDistance = Infinity, bestTie = Infinity;
  for (const candidate of candidates) {
    const difference = sub(add2(a0, scale(u, candidate[0])), add2(b0, scale(v, candidate[1])));
    const distance = dot3(difference, difference);
    const tie = Math.abs(candidate[0] - 0.5) + Math.abs(candidate[1] - 0.5);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && tie < bestTie) {
      best = candidate;
      bestDistance = distance;
      bestTie = tie;
    }
  }
  return [add2(a0, scale(u, best[0])), add2(b0, scale(v, best[1]))];
}
function segmentBox(segmentStart, segmentEnd, extents) {
  const direction = sub(segmentEnd, segmentStart);
  const breaks = [0, 1];
  for (let axis = 0; axis < 3; axis++) {
    if (Math.abs(direction[axis]) < 1e-15) continue;
    for (const face2 of [-extents[axis], extents[axis]]) {
      const t = (face2 - segmentStart[axis]) / direction[axis];
      if (t > 0 && t < 1) breaks.push(t);
    }
  }
  breaks.sort((a2, b2) => a2 - b2);
  let bestT = 0.5, bestDistance = Infinity;
  for (let interval2 = 0; interval2 < breaks.length - 1; interval2++) {
    const low = breaks[interval2], high = breaks[interval2 + 1];
    if (high - low < 1e-15) continue;
    const midpoint2 = (low + high) / 2;
    let numerator = 0, denominator = 0;
    for (let axis = 0; axis < 3; axis++) {
      const value = segmentStart[axis] + midpoint2 * direction[axis];
      const face2 = value < -extents[axis] ? -extents[axis] : value > extents[axis] ? extents[axis] : null;
      if (face2 === null) continue;
      numerator += direction[axis] * (segmentStart[axis] - face2);
      denominator += direction[axis] ** 2;
    }
    const t = clamp2(denominator ? -numerator / denominator : 0.5, low, high);
    const point3 = add2(segmentStart, scale(direction, t));
    const nearest = point3.map((value, axis) => clamp2(value, -extents[axis], extents[axis]));
    const delta = sub(point3, nearest), distance = dot3(delta, delta);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && Math.abs(t - 0.5) < Math.abs(bestT - 0.5)) {
      bestT = t;
      bestDistance = distance;
    }
  }
  const point2 = add2(segmentStart, scale(direction, bestT));
  return [point2, point2.map((value, axis) => clamp2(value, -extents[axis], extents[axis]))];
}
function capsuleCapsule(a2, b2) {
  const [aPoint, bPoint] = segmentPair(...capsuleEnds(a2), ...capsuleEnds(b2));
  const delta = sub(bPoint, aPoint), distance = Math.hypot(...delta);
  const aRadius = a2.shape.radiusM;
  const bRadius = b2.shape.radiusM;
  if (distance > aRadius + bRadius) return null;
  const centerDelta = sub(b2.positionM, a2.positionM);
  const normal = distance > 1e-12 ? scale(delta, 1 / distance) : Math.hypot(...centerDelta) > 1e-12 ? scale(centerDelta, 1 / Math.hypot(...centerDelta)) : a2.id < b2.id ? [1, 0, 0] : [-1, 0, 0];
  const surfaceA = add2(aPoint, scale(normal, aRadius));
  const surfaceB = sub(bPoint, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add2(surfaceA, surfaceB), 0.5)
  };
}
function capsuleBox(capsule, box3) {
  const [start, end] = capsuleEnds(capsule).map((point2) => localPoint(box3, point2));
  const extents = box3.shape.halfExtentsM;
  const [axisPoint, boxPoint] = segmentBox(start, end, extents);
  const delta = sub(boxPoint, axisPoint), distance = Math.hypot(...delta);
  const radius = capsule.shape.radiusM;
  if (distance > radius) return null;
  if (distance > 1e-12) return {
    normal: rotate2(box3.orientation, scale(delta, 1 / distance)),
    penetration: radius - distance,
    pointM: worldPoint(box3, boxPoint)
  };
  let bestAxis = 0, bestSide = -1, bestGap = Infinity;
  for (let axis = 0; axis < 3; axis++) for (const side of [-1, 1]) {
    const gap = extents[axis] - side * axisPoint[axis];
    if (gap < bestGap) {
      bestGap = gap;
      bestAxis = axis;
      bestSide = side;
    }
  }
  const normalLocal = [0, 0, 0];
  normalLocal[bestAxis] = -bestSide;
  boxPoint[bestAxis] = bestSide * extents[bestAxis];
  return {
    normal: rotate2(box3.orientation, normalLocal),
    penetration: radius + bestGap,
    pointM: worldPoint(box3, boxPoint)
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/collision.ts
function capsuleCenter(body, point2) {
  const half = body.shape.halfLengthM;
  const local = localPoint(body, point2);
  return worldPoint(body, [0, Math.max(-half, Math.min(half, local[1])), 0]);
}
function boxAxes(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
}
function boxSupport(body, direction) {
  const axes = boxAxes(body);
  const extents = body.shape.halfExtentsM;
  return add2(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot3(axis, direction);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents[index] : -extents[index];
    return add2(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function sphereSphere(a2, b2) {
  const aRadius = a2.shape.radiusM;
  const bRadius = b2.shape.radiusM;
  const delta = sub(b2.positionM, a2.positionM);
  const distance = Math.hypot(...delta);
  if (distance > aRadius + bRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  const aSurface = add2(a2.positionM, scale(normal, aRadius));
  const bSurface = sub(b2.positionM, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add2(aSurface, bSurface), 0.5)
  };
}
function sphereBox(sphere, box3) {
  const radius = sphere.shape.radiusM;
  const extents = box3.shape.halfExtentsM;
  const relative = localPoint(box3, sphere.positionM);
  const nearest = relative.map((value, index) => Math.max(-extents[index], Math.min(extents[index], value)));
  const towardBox = sub(nearest, relative);
  const distance = Math.hypot(...towardBox);
  if (distance > radius) return null;
  if (distance > 0) return {
    normal: rotate2(box3.orientation, scale(towardBox, 1 / distance)),
    penetration: Math.max(0, radius - distance),
    pointM: worldPoint(box3, nearest)
  };
  let axis = 0, side = -1, faceDistance = Infinity;
  for (let index = 0; index < 3; index++) for (const candidate of [-1, 1]) {
    const gap = extents[index] - candidate * relative[index];
    if (gap < faceDistance) {
      faceDistance = gap;
      axis = index;
      side = candidate;
    }
  }
  const localNormal = [0, 0, 0];
  localNormal[axis] = -side;
  nearest[axis] = side * extents[axis];
  return {
    normal: rotate2(box3.orientation, localNormal),
    penetration: radius + faceDistance,
    pointM: worldPoint(box3, nearest)
  };
}
function capsuleSphere(capsule, sphere) {
  const center = capsuleCenter(capsule, sphere.positionM);
  const delta = sub(sphere.positionM, center);
  const distance = Math.hypot(...delta);
  const capsuleRadius = capsule.shape.radiusM;
  const sphereRadius = sphere.shape.radiusM;
  if (distance > capsuleRadius + sphereRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  return {
    normal,
    penetration: Math.max(0, capsuleRadius + sphereRadius - distance),
    pointM: scale(add2(
      add2(center, scale(normal, capsuleRadius)),
      sub(sphere.positionM, scale(normal, sphereRadius))
    ), 0.5)
  };
}
function boxBox(a2, b2) {
  const axesA = boxAxes(a2), axesB = boxAxes(b2);
  const extentA = a2.shape.halfExtentsM, extentB = b2.shape.halfExtentsM;
  const delta = sub(b2.positionM, a2.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross4(axisA, axisB)))];
  for (const candidate of candidates) {
    const length = Math.hypot(...candidate);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis2, index) => sum + extentA[index] * Math.abs(dot3(basis2, axis)), 0);
    const radiusB = axesB.reduce((sum, basis2, index) => sum + extentB[index] * Math.abs(dot3(basis2, axis)), 0);
    const signedDistance = dot3(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    if (overlap < -1e-12) return null;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
    }
  }
  const aPoint = boxSupport(a2, bestAxis);
  const bPoint = boxSupport(b2, scale(bestAxis, -1));
  return { normal: bestAxis, penetration: Math.max(0, bestOverlap), pointM: scale(add2(aPoint, bPoint), 0.5) };
}
function detect(a2, b2) {
  if (a2.shape.kind === "sphere" && b2.shape.kind === "sphere") return sphereSphere(a2, b2);
  if (a2.shape.kind === "sphere" && b2.shape.kind === "box") return sphereBox(a2, b2);
  if (a2.shape.kind === "box" && b2.shape.kind === "sphere") {
    const hit = sphereBox(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "capsule" && b2.shape.kind === "sphere") return capsuleSphere(a2, b2);
  if (a2.shape.kind === "sphere" && b2.shape.kind === "capsule") {
    const hit = capsuleSphere(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "box" && b2.shape.kind === "box") return boxBox(a2, b2);
  if (a2.shape.kind === "capsule" && b2.shape.kind === "box") return capsuleBox(a2, b2);
  if (a2.shape.kind === "box" && b2.shape.kind === "capsule") {
    const hit = capsuleBox(b2, a2);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a2.shape.kind === "capsule" && b2.shape.kind === "capsule") return capsuleCapsule(a2, b2);
  return null;
}
function sphereOverlaps(center, radius, body) {
  if (body.shape.kind === "sphere") {
    return Math.hypot(...sub(center, body.positionM)) <= radius + body.shape.radiusM;
  }
  if (body.shape.kind === "capsule") {
    return Math.hypot(...sub(center, capsuleCenter(body, center))) <= radius + body.shape.radiusM;
  }
  const extents = body.shape.halfExtentsM;
  const local = localPoint(body, center);
  const delta = local.map((value, index) => Math.max(0, Math.abs(value) - extents[index]));
  return Math.hypot(...delta) <= radius;
}
function raySphere(origin, direction, center, radius) {
  const relative = sub(origin, center);
  const c = dot3(relative, relative) - radius ** 2;
  if (c <= 0) return 0;
  const projection = dot3(relative, direction);
  const discriminant = projection ** 2 - c;
  return projection > 0 || discriminant < 0 ? null : -projection - Math.sqrt(discriminant);
}
function rayDistance(origin, direction, body) {
  if (body.shape.kind === "sphere") return raySphere(origin, direction, body.positionM, body.shape.radiusM);
  const localOrigin = localPoint(body, origin);
  const localDirection = rotate2(inverse(body.orientation), direction);
  if (body.shape.kind === "capsule") {
    const { radiusM: radius, halfLengthM: half } = body.shape;
    const closest = [0, Math.max(-half, Math.min(half, localOrigin[1])), 0];
    if (Math.hypot(...sub(localOrigin, closest)) <= radius) return 0;
    const results = [];
    for (const y of [-half, half]) {
      const hit = raySphere(localOrigin, localDirection, [0, y, 0], radius);
      if (hit !== null) results.push(hit);
    }
    const a2 = localDirection[0] ** 2 + localDirection[2] ** 2;
    if (a2 > 1e-12) {
      const b2 = 2 * (localOrigin[0] * localDirection[0] + localOrigin[2] * localDirection[2]);
      const c = localOrigin[0] ** 2 + localOrigin[2] ** 2 - radius ** 2;
      const discriminant = b2 ** 2 - 4 * a2 * c;
      if (discriminant >= 0) for (const sign of [-1, 1]) {
        const hit = (-b2 + sign * Math.sqrt(discriminant)) / (2 * a2);
        const y = localOrigin[1] + localDirection[1] * hit;
        if (hit >= 0 && y >= -half && y <= half) results.push(hit);
      }
    }
    return results.length ? Math.min(...results) : null;
  }
  let near2 = -Infinity, far = Infinity;
  for (let index = 0; index < 3; index++) {
    const lower = -body.shape.halfExtentsM[index];
    const upper = body.shape.halfExtentsM[index];
    const component = localDirection[index];
    if (Math.abs(component) < 1e-12) {
      if (localOrigin[index] < lower || localOrigin[index] > upper) return null;
      continue;
    }
    const first = (lower - localOrigin[index]) / component;
    const second = (upper - localOrigin[index]) / component;
    near2 = Math.max(near2, Math.min(first, second));
    far = Math.min(far, Math.max(first, second));
    if (far < near2) return null;
  }
  return far < 0 ? null : Math.max(0, near2);
}
function validateResult(bodies, contacts) {
  for (const body of bodies) {
    for (const [label, values, bound] of [
      ["position", body.positionM, 1e4],
      ["velocity", body.velocityMps, 1e3],
      ["angularVelocity", body.angularVelocityRadps, 1e3]
    ]) {
      if (values.some((value) => !Number.isFinite(value) || Math.abs(value) > bound)) error("NUMERIC_LIMIT", `${body.id} ${label} exceeded bounds`);
    }
    if (body.orientation.some((value) => !Number.isFinite(value)) || Math.abs(Math.hypot(...body.orientation) - 1) > 1e-12) error("NUMERIC_LIMIT", `${body.id} orientation exceeded tolerance`);
  }
  if (contacts.some((contact) => !Number.isFinite(contact.impulseNs) || !Number.isFinite(contact.penetrationM) || contact.normalAtoB.some((value) => !Number.isFinite(value)) || contact.pointM.some((value) => !Number.isFinite(value)) || contact.tangentImpulseNs.some((value) => !Number.isFinite(value)))) error("NUMERIC_LIMIT", "unsafe contact result");
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/contact-manifold.ts
var basis = (body) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
function referenceFace(body, axes, normal) {
  for (let axis = 0; axis < 3; axis++) {
    const alignment = dot3(axes[axis], normal);
    if (Math.abs(alignment) >= 1 - 1e-6) {
      return {
        body,
        axes,
        extents: body.shape.halfExtentsM,
        axis,
        side: Math.sign(alignment)
      };
    }
  }
  return null;
}
function clip2(polygon, centre, axis, limit) {
  const result = [];
  for (let index = 0; index < polygon.length; index++) {
    const current = polygon[index], next = polygon[(index + 1) % polygon.length];
    const a2 = dot3(sub(current, centre), axis) - limit - 1e-9;
    const b2 = dot3(sub(next, centre), axis) - limit - 1e-9;
    const insideA = a2 <= 0, insideB = b2 <= 0;
    if (insideA) result.push(current);
    if (insideA !== insideB) result.push(add2(current, scale(sub(next, current), a2 / (a2 - b2))));
  }
  return result;
}
function faceVertices(face2) {
  const tangents = [0, 1, 2].filter((axis) => axis !== face2.axis);
  const centre = add2(face2.body.positionM, scale(
    face2.axes[face2.axis],
    face2.side * face2.extents[face2.axis]
  ));
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => add2(
    add2(centre, scale(face2.axes[tangents[0]], u * face2.extents[tangents[0]])),
    scale(face2.axes[tangents[1]], v * face2.extents[tangents[1]])
  ));
}
function boxFaceManifold(a2, b2, hit) {
  if (a2.shape.kind !== "box" || b2.shape.kind !== "box") return null;
  const axesA = basis(a2), axesB = basis(b2);
  const faceA = referenceFace(a2, axesA, hit.normal);
  const faceB = referenceFace(b2, axesB, scale(hit.normal, -1));
  const reference = faceA ?? faceB;
  if (!reference) return null;
  const incidentBody = reference.body === a2 ? b2 : a2;
  const incidentAxes = reference.body === a2 ? axesB : axesA;
  const normal = reference.body === a2 ? hit.normal : scale(hit.normal, -1);
  let incidentAxis = 0, greatest = -Infinity;
  for (let axis = 0; axis < 3; axis++) {
    const alignment = Math.abs(dot3(incidentAxes[axis], normal));
    if (alignment > greatest) {
      greatest = alignment;
      incidentAxis = axis;
    }
  }
  const incident = {
    body: incidentBody,
    axes: incidentAxes,
    extents: incidentBody.shape.halfExtentsM,
    axis: incidentAxis,
    side: dot3(incidentAxes[incidentAxis], normal) > 0 ? -1 : 1
  };
  const centre = add2(reference.body.positionM, scale(
    reference.axes[reference.axis],
    reference.side * reference.extents[reference.axis]
  ));
  const tangents = [0, 1, 2].filter((axis) => axis !== reference.axis);
  let polygon = faceVertices(incident);
  for (const axis of tangents) {
    polygon = clip2(polygon, centre, reference.axes[axis], reference.extents[axis]);
    polygon = clip2(polygon, centre, scale(reference.axes[axis], -1), reference.extents[axis]);
  }
  const candidates = polygon.map((point2) => {
    const separation = dot3(sub(point2, centre), normal);
    const midpoint2 = sub(point2, scale(normal, separation / 2));
    return {
      pointM: midpoint2,
      separation,
      u: dot3(sub(midpoint2, centre), reference.axes[tangents[0]]),
      v: dot3(sub(midpoint2, centre), reference.axes[tangents[1]])
    };
  }).filter((point2) => point2.separation <= 1e-6);
  if (!candidates.length) return null;
  const selected2 = candidates.length <= 4 ? candidates : [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => candidates.reduce((best, point2) => u * point2.u + v * point2.v > u * best.u + v * best.v ? point2 : best, candidates[0]));
  const unique = selected2.filter((point2, index) => selected2.findIndex((other) => Math.hypot(...sub(point2.pointM, other.pointM)) <= 1e-9) === index);
  unique.sort((first, second) => first.u - second.u || first.v - second.v);
  return unique.map((point2, index) => ({ id: `${reference.body.id}:${reference.axis}:${reference.side}:${index}`, pointM: point2.pointM }));
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/persistent-box-contact.ts
function apply(a2, b2, pointM, impulse) {
  const traceApply = phaseApplyBefore(a2, b2, pointM, impulse);
  const armA = sub(pointM, a2.positionM), armB = sub(pointM, b2.positionM);
  a2.velocityMps = sub(a2.velocityMps, scale(impulse, a2.inverseMass));
  b2.velocityMps = add2(b2.velocityMps, scale(impulse, b2.inverseMass));
  a2.angularVelocityRadps = sub(
    a2.angularVelocityRadps,
    inverseInertia(a2, cross4(armA, impulse))
  );
  b2.angularVelocityRadps = add2(
    b2.angularVelocityRadps,
    inverseInertia(b2, cross4(armB, impulse))
  );
  const producerContribution = actualContribution(pointM, impulse);
  phaseApplyAfter(traceApply, a2, b2);
  return producerContribution;
}
function relativeVelocity(a2, b2, pointM) {
  const armA = sub(pointM, a2.positionM), armB = sub(pointM, b2.positionM);
  return sub(
    add2(b2.velocityMps, cross4(b2.angularVelocityRadps, armB)),
    add2(a2.velocityMps, cross4(a2.angularVelocityRadps, armA))
  );
}
function effectiveInverseMass(a2, b2, pointM, direction) {
  const torqueA = cross4(sub(pointM, a2.positionM), direction);
  const torqueB = cross4(sub(pointM, b2.positionM), direction);
  return a2.inverseMass + b2.inverseMass + dot3(torqueA, inverseInertia(a2, torqueA)) + dot3(torqueB, inverseInertia(b2, torqueB));
}
function warmStartPoint(a2, b2, pointM, normal, impulse) {
  phaseKind("warm", { actualPriorApplication: true });
  return apply(a2, b2, pointM, add2(scale(normal, impulse.normalNs), impulse.tangentNs));
}
function solvePersistentPoint(a2, b2, pointM, normal, impulse, normalTargetMps) {
  let producerContribution = emptyContribution();
  const normalSpeed = dot3(relativeVelocity(a2, b2, pointM), normal);
  const normalMass = effectiveInverseMass(a2, b2, pointM, normal);
  const nextNormal = Math.max(0, normalTargetMps === 0 ? impulse.normalNs - normalSpeed / normalMass : impulse.normalNs + (normalTargetMps - normalSpeed) / normalMass);
  const deltaNormal = nextNormal - impulse.normalNs;
  impulse.normalNs = nextNormal;
  phaseKind("normal", { normalTargetMps, normalSpeed, normalMass, deltaNormal });
  if (deltaNormal !== 0) producerContribution = combineContribution(producerContribution, apply(a2, b2, pointM, scale(normal, deltaNormal)));
  else phaseNoNormal();
  const relative = relativeVelocity(a2, b2, pointM);
  const tangent = sub(relative, scale(normal, dot3(relative, normal)));
  const tangentSpeed = Math.hypot(...tangent);
  let requested = impulse.tangentNs;
  if (tangentSpeed >= 1e-12) {
    const direction = scale(tangent, 1 / tangentSpeed);
    const tangentMass = effectiveInverseMass(a2, b2, pointM, direction);
    requested = sub(impulse.tangentNs, scale(direction, tangentSpeed / tangentMass));
  }
  const requestedMagnitude = Math.hypot(...requested);
  const staticLimit = Math.sqrt(a2.frictionStatic * b2.frictionStatic) * impulse.normalNs;
  const dynamicLimit = Math.sqrt(a2.frictionDynamic * b2.frictionDynamic) * impulse.normalNs;
  const limit = requestedMagnitude <= staticLimit ? staticLimit : dynamicLimit;
  const nextTangent = requestedMagnitude > limit && requestedMagnitude > 0 ? scale(requested, limit / requestedMagnitude) : requested;
  const deltaTangent = sub(nextTangent, impulse.tangentNs);
  impulse.tangentNs = nextTangent;
  phaseKind("tangent", { tangentSpeed, requestedMagnitude, staticLimit, dynamicLimit, branch: requestedMagnitude <= staticLimit ? "static" : "dynamic" });
  producerContribution = combineContribution(producerContribution, apply(a2, b2, pointM, deltaTangent));
  return producerContribution;
}
function correctPersistentPair(a2, b2, normal, penetration) {
  const inverseTotal = a2.inverseMass + b2.inverseMass;
  if (inverseTotal === 0 || penetration <= 0) return;
  const traceCorrection = phaseCorrectionBefore(a2, b2, normal, penetration);
  const correction = scale(normal, penetration / inverseTotal);
  a2.positionM = sub(a2.positionM, scale(correction, a2.inverseMass));
  b2.positionM = add2(b2.positionM, scale(correction, b2.inverseMass));
  phaseCorrectionAfter(traceCorrection, a2, b2);
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd-rounded-box.ts
var ZERO = { n: 0n, d: 1n };
var ONE = { n: 1n, d: 1n };
function numericLimit() {
  return error("NUMERIC_LIMIT", "sphere CCD rounded-box calculation exceeded numeric limits");
}
function compare3(a2, b2) {
  const difference = a2.n * b2.d - b2.n * a2.d;
  return difference < 0n ? -1 : difference > 0n ? 1 : 0;
}
function integerCoordinates(values) {
  const words = new DataView(new ArrayBuffer(8));
  const parts = values.map((value) => {
    if (!Number.isFinite(value)) numericLimit();
    words.setFloat64(0, value, false);
    const bits3 = words.getBigUint64(0, false);
    const exponent2 = Number(bits3 >> 52n & 2047n);
    const significand = bits3 & 0xfffffffffffffn | (exponent2 === 0 ? 0n : 0x10000000000000n);
    return {
      significand: bits3 >> 63n ? -significand : significand,
      exponent: exponent2 === 0 ? -1074 : exponent2 - 1075
    };
  });
  const exponent = Math.min(...parts.filter((part) => part.significand !== 0n).map((part) => part.exponent));
  return parts.map((part) => part.significand === 0n ? 0n : part.significand << BigInt(part.exponent - exponent));
}
function leading(value) {
  const magnitude2 = value < 0n ? -value : value;
  if (magnitude2 === 0n) return { value: 0, exponent: 0 };
  const exponent = Math.max(0, magnitude2.toString(2).length - 53);
  return { value: Number(magnitude2 >> BigInt(exponent)) * (value < 0n ? -1 : 1), exponent };
}
function powerOfTwo(value, exponent) {
  if (exponent < -1022) return value * 2 ** (exponent + 1022) * 2 ** -1022;
  if (exponent > 1023) return value * 2 ** (exponent - 1023) * 2 ** 1023;
  return value * 2 ** exponent;
}
function ratio(numerator, denominator) {
  const n = leading(numerator);
  const d = leading(denominator);
  return powerOfTwo(n.value / d.value, n.exponent - d.exponent);
}
function scaled(value, exponent) {
  const head = leading(value);
  return powerOfTwo(head.value, head.exponent - exponent);
}
function rootCompare(a2, b2, discriminant, branch, boundary) {
  const offset = -b2 * boundary.d - 2n * a2 * boundary.n;
  if (branch === -1 && offset < 0n) return -1;
  if (branch === 1 && offset > 0n) return 1;
  const squaredDifference = offset * offset - discriminant * boundary.d * boundary.d;
  const sign = squaredDifference < 0n ? -1 : squaredDifference > 0n ? 1 : 0;
  return branch === -1 ? sign : -sign;
}
function sweepRoundedBox(start, end, halfExtents, radius) {
  if (!(radius > 0) || halfExtents.some((value) => !(value > 0))) numericLimit();
  const coordinates = integerCoordinates([...start, ...end, ...halfExtents, radius]);
  const p = coordinates.slice(0, 3);
  const velocity = coordinates.slice(3, 6).map((value, axis) => value - p[axis]);
  const half = coordinates.slice(6, 9);
  const r = coordinates[9];
  const radiusSquared = r * r;
  let initialDistanceSquared = 0n;
  const breaks = [ZERO, ONE];
  for (let axis = 0; axis < 3; axis++) {
    const gap = p[axis] < -half[axis] ? p[axis] + half[axis] : p[axis] > half[axis] ? p[axis] - half[axis] : 0n;
    initialDistanceSquared += gap * gap;
    if (velocity[axis] === 0n) continue;
    for (const side of [-1n, 1n]) {
      let n = side * half[axis] - p[axis];
      let d = velocity[axis];
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      if (n > 0n && n < d) breaks.push({ n, d });
    }
  }
  if (initialDistanceSquared <= radiusSquared) return null;
  if (velocity.every((value) => value === 0n)) return null;
  breaks.sort(compare3);
  const boundaries = breaks.filter((value, index) => index === 0 || compare3(value, breaks[index - 1]) !== 0);
  for (let interval2 = 0; interval2 + 1 < boundaries.length; interval2++) {
    const lo = boundaries[interval2];
    const hi = boundaries[interval2 + 1];
    const middle = { n: lo.n * hi.d + hi.n * lo.d, d: 2n * lo.d * hi.d };
    const gap = [0n, 0n, 0n];
    const motion = [0n, 0n, 0n];
    const sides2 = [0, 0, 0];
    let a2 = 0n;
    let b2 = 0n;
    let c = -radiusSquared;
    for (let axis = 0; axis < 3; axis++) {
      const point2 = p[axis] * middle.d + velocity[axis] * middle.n;
      const bound = half[axis] * middle.d;
      const side = point2 < -bound ? -1 : point2 > bound ? 1 : 0;
      sides2[axis] = side;
      if (side === 0) continue;
      gap[axis] = p[axis] - BigInt(side) * half[axis];
      motion[axis] = velocity[axis];
      a2 += motion[axis] * motion[axis];
      b2 += 2n * gap[axis] * motion[axis];
      c += gap[axis] * gap[axis];
    }
    if (a2 === 0n) {
      if (c > 0n) continue;
      if (c < 0n) numericLimit();
      const normal = gap.map((value) => ratio(value, r));
      return finish(ratio(lo.n, lo.d), normal, sides2);
    }
    const discriminant = b2 * b2 - 4n * a2 * c;
    if (discriminant < 0n) continue;
    for (const branch of [-1, 1]) {
      if (branch === 1 && discriminant === 0n) continue;
      if (rootCompare(a2, b2, discriminant, branch, lo) < 0 || rootCompare(a2, b2, discriminant, branch, hi) > 0) continue;
      if (discriminant === 0n) {
        const normal2 = gap.map((value, axis) => ratio(
          2n * a2 * value - motion[axis] * b2,
          2n * a2 * r
        ));
        return finish(ratio(-b2, 2n * a2), normal2, sides2);
      }
      const sqrtExponent = Math.ceil(discriminant.toString(2).length / 2);
      const sqrtMantissa = Math.sqrt(scaled(discriminant, 2 * sqrtExponent));
      const coefficientExponent = Math.max(
        a2.toString(2).length,
        (b2 < 0n ? -b2 : b2).toString(2).length,
        (c < 0n ? -c : c).toString(2).length
      );
      const aa = scaled(a2, coefficientExponent);
      const bb = scaled(b2, coefficientExponent);
      const cc = scaled(c, coefficientExponent);
      const rootDiscriminant = powerOfTwo(sqrtMantissa, sqrtExponent - coefficientExponent);
      const q3 = -0.5 * (bb + (b2 < 0n ? -rootDiscriminant : rootDiscriminant));
      if (!(aa > 0) || !(rootDiscriminant > 0) || q3 === 0 || ![aa, bb, cc, q3].every(Number.isFinite)) numericLimit();
      const fraction = branch === (b2 < 0n ? 1 : -1) ? q3 / aa : cc / q3;
      const normal = gap.map((value, axis) => {
        const projected = ratio(2n * a2 * value - motion[axis] * b2, 2n * a2 * r);
        const offset = ratio(motion[axis] << BigInt(sqrtExponent), 2n * a2 * r) * sqrtMantissa;
        return projected + branch * offset;
      });
      return finish(fraction, normal, sides2);
    }
  }
  return null;
}
function finish(fraction, normal, sides2) {
  if (!Number.isFinite(fraction) || fraction < 0 || fraction > 1 || normal.some((value, axis) => !Number.isFinite(value) || value * sides2[axis] < 0)) numericLimit();
  const magnitude2 = Math.hypot(...normal);
  if (!(magnitude2 > 0) || Math.abs(magnitude2 - 1) > 1e-12) numericLimit();
  return { fraction, normalLocal: normal.map((value) => value / magnitude2) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd-slab.ts
function sweepBox(start, end, halfExtents) {
  if (start.every((value, axis) => Math.abs(value) <= halfExtents[axis])) return null;
  const travel = sub(end, start);
  let entry = 0;
  let exit = 1;
  let normalLocal = null;
  for (let axis = 0; axis < 3; axis++) {
    const velocity = travel[axis];
    if (velocity === 0) {
      if (Math.abs(start[axis]) > halfExtents[axis]) return null;
      continue;
    }
    const first = (-halfExtents[axis] - start[axis]) / velocity;
    const second = (halfExtents[axis] - start[axis]) / velocity;
    const near2 = Math.min(first, second);
    const far = Math.max(first, second);
    if (near2 > entry) {
      entry = near2;
      normalLocal = [0, 0, 0];
      normalLocal[axis] = velocity > 0 ? -1 : 1;
    }
    exit = Math.min(exit, far);
    if (entry > exit) return null;
  }
  return normalLocal && entry <= 1 && exit >= 0 ? { fraction: entry, normalLocal } : null;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd-box.ts
var ANGULAR_TOLERANCE = 1e-12;
function axisAlignedBox(body) {
  return body.shape.kind === "box" && body.orientation.slice(0, 3).every((component) => Math.abs(component) <= ANGULAR_TOLERANCE) && Math.abs(Math.abs(body.orientation[3]) - 1) <= ANGULAR_TOLERANCE && body.angularVelocityRadps.every((component) => Math.abs(component) <= ANGULAR_TOLERANCE);
}
function rejectAngularBoxCommand(action) {
  if (action?.torqueNm?.some((component) => component !== 0) || action?.angularImpulseNms?.some((component) => component !== 0)) {
    error("INVALID_COMMAND", "axis-aligned box CCD excludes angular commands");
  }
}
function sweepDynamicBox(previous, candidate, fixture) {
  if (!axisAlignedBox(previous) || !axisAlignedBox(candidate) || !axisAlignedBox(fixture)) {
    error("NUMERIC_LIMIT", "box CCD candidate rotated outside the admitted profile");
  }
  if (previous.shape.kind !== "box" || fixture.shape.kind !== "box") return null;
  const fixtureHalfExtents = fixture.shape.halfExtentsM;
  const expanded2 = previous.shape.halfExtentsM.map((extent, axis) => extent + fixtureHalfExtents[axis]);
  const start = sub(previous.positionM, fixture.positionM);
  const end = sub(candidate.positionM, fixture.positionM);
  const hit = sweepBox(start, end, expanded2);
  if (!hit) return null;
  const travel = sub(candidate.positionM, previous.positionM);
  candidate.positionM = sub(
    add2(previous.positionM, scale(travel, hit.fraction)),
    scale(hit.normalLocal, 1e-9)
  );
  return {
    bodyId: previous.id,
    fixtureId: fixture.id,
    toiFraction: hit.fraction,
    normalFixtureToBody: hit.normalLocal
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd.ts
function admitCcd(bodies, jointCount, gravity) {
  const selected2 = bodies.filter((body) => body.ccd);
  if (selected2.length === 0) return { kind: "none" };
  const sphereIndex = bodies.findIndex((body) => body.ccd);
  if (selected2.length === 1 && bodies.length === 2 && jointCount === 0 && gravity.every((component) => component === 0) && bodies.every((body) => body.kind === "dynamic" && body.shape.kind === "sphere" && !body.sensor)) {
    return { kind: "sphere-pair", sphereIndex, otherIndex: 1 - sphereIndex };
  }
  if (selected2.length === 1 && selected2[0].shape.kind === "box" && bodies.length === 2 && jointCount === 0) {
    const fixtureIndex = 1 - sphereIndex;
    if (bodies[sphereIndex].kind === "dynamic" && bodies[fixtureIndex].kind === "static" && !bodies[fixtureIndex].sensor && axisAlignedBox(bodies[sphereIndex]) && axisAlignedBox(bodies[fixtureIndex])) {
      return { kind: "box-pair", boxIndex: sphereIndex, fixtureIndex };
    }
  }
  const fixtures = bodies.filter((body) => body.kind === "static" && !body.sensor && body.shape.kind === "box");
  if (selected2.length !== 1 || bodies.length !== fixtures.length + 1 || bodies.filter((body) => body.kind === "dynamic").length !== 1 || fixtures.length < 1 || fixtures.length > 8 || jointCount !== 0) {
    error("INVALID_CONFIG", "unsupported CCD body pair or world profile");
  }
  if (selected2[0].shape.kind !== "sphere") {
    error("INVALID_CONFIG", "static-box CCD requires a dynamic sphere");
  }
  return {
    kind: "static-boxes",
    sphereIndex,
    fixtures: fixtures.sort((a2, b2) => a2.id < b2.id ? -1 : a2.id > b2.id ? 1 : 0)
  };
}
function sweepSphere(previous, candidate, fixtures) {
  if (previous.shape.kind !== "sphere") return null;
  const radius = previous.shape.radiusM;
  const travel = sub(candidate.positionM, previous.positionM);
  let earliest = null;
  for (const fixture of fixtures) {
    if (fixture.shape.kind !== "box") continue;
    const hit = sweepRoundedBox(
      localPoint(fixture, previous.positionM),
      localPoint(fixture, candidate.positionM),
      fixture.shape.halfExtentsM,
      radius
    );
    if (!hit || earliest && hit.fraction >= earliest.toiFraction) continue;
    earliest = {
      bodyId: previous.id,
      fixtureId: fixture.id,
      toiFraction: hit.fraction,
      normalFixtureToBody: rotate2(fixture.orientation, hit.normalLocal)
    };
  }
  if (earliest) {
    candidate.positionM = sub(
      add2(previous.positionM, scale(travel, earliest.toiFraction)),
      scale(earliest.normalFixtureToBody, 1e-9)
    );
  }
  return earliest;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd-sphere-pair-exact.ts
function numericLimit2() {
  return error("NUMERIC_LIMIT", "unsafe exact sphere-pair sweep");
}
function integerCoordinates2(values) {
  const words = new DataView(new ArrayBuffer(8));
  const parts = values.map((value) => {
    if (!Number.isFinite(value)) numericLimit2();
    words.setFloat64(0, value, false);
    const bits3 = words.getBigUint64(0, false);
    const exponent2 = Number(bits3 >> 52n & 2047n);
    const significand = bits3 & 0xfffffffffffffn | (exponent2 === 0 ? 0n : 0x10000000000000n);
    return {
      significand: bits3 >> 63n ? -significand : significand,
      exponent: exponent2 === 0 ? -1074 : exponent2 - 1075
    };
  });
  const exponent = Math.min(...parts.filter((part) => part.significand !== 0n).map((part) => part.exponent));
  return parts.map((part) => part.significand === 0n ? 0n : part.significand << BigInt(part.exponent - exponent));
}
function leading2(value) {
  const magnitude2 = value < 0n ? -value : value;
  if (magnitude2 === 0n) return { value: 0, exponent: 0 };
  const exponent = Math.max(0, magnitude2.toString(2).length - 53);
  return { value: Number(magnitude2 >> BigInt(exponent)) * (value < 0n ? -1 : 1), exponent };
}
function powerOfTwo2(value, exponent) {
  if (exponent < -1022) return value * 2 ** (exponent + 1022) * 2 ** -1022;
  if (exponent > 1023) return value * 2 ** (exponent - 1023) * 2 ** 1023;
  return value * 2 ** exponent;
}
function ratio2(numerator, denominator) {
  const n = leading2(numerator);
  const d = leading2(denominator);
  return powerOfTwo2(n.value / d.value, n.exponent - d.exponent);
}
function scaled2(value, exponent) {
  const head = leading2(value);
  return powerOfTwo2(head.value, head.exponent - exponent);
}
function sweepSpherePairExact(markedStart, markedEnd, otherStart, otherEnd, markedRadius, otherRadius) {
  if (!(markedRadius > 0) || !(otherRadius > 0)) numericLimit2();
  const coordinates = integerCoordinates2([
    ...markedStart,
    ...markedEnd,
    ...otherStart,
    ...otherEnd,
    markedRadius,
    otherRadius
  ]);
  const p = coordinates.slice(0, 3).map((value, axis) => value - coordinates[6 + axis]);
  const v = coordinates.slice(3, 6).map((value, axis) => value - coordinates[axis] - coordinates[9 + axis] + coordinates[6 + axis]);
  const radius = coordinates[12] + coordinates[13];
  let a2 = 0n;
  let b2 = 0n;
  let c = -radius * radius;
  for (let axis = 0; axis < 3; axis++) {
    a2 += v[axis] * v[axis];
    b2 += 2n * p[axis] * v[axis];
    c += p[axis] * p[axis];
  }
  if (c <= 0n || a2 === 0n || b2 >= 0n) return null;
  const discriminant = b2 * b2 - 4n * a2 * c;
  if (discriminant < 0n) return null;
  const endpointOffset = -b2 - 2n * a2;
  const endpointDifference = endpointOffset < 0n ? -1n : endpointOffset * endpointOffset - discriminant;
  if (endpointDifference > 0n) return null;
  let fraction;
  let normal;
  if (discriminant === 0n) {
    fraction = endpointDifference === 0n ? 1 : ratio2(-b2, 2n * a2);
    normal = p.map((value, axis) => ratio2(2n * a2 * value - b2 * v[axis], 2n * a2 * radius));
  } else {
    const sqrtExponent = Math.ceil(discriminant.toString(2).length / 2);
    const sqrtMantissa = Math.sqrt(scaled2(discriminant, 2 * sqrtExponent));
    const coefficientExponent = Math.max(
      a2.toString(2).length,
      (-b2).toString(2).length,
      c.toString(2).length
    );
    const bb = scaled2(b2, coefficientExponent);
    const cc = scaled2(c, coefficientExponent);
    const rootDiscriminant = powerOfTwo2(sqrtMantissa, sqrtExponent - coefficientExponent);
    const q3 = -0.5 * (bb - rootDiscriminant);
    if (!(rootDiscriminant > 0) || !(q3 > 0) || ![bb, cc, q3].every(Number.isFinite)) numericLimit2();
    fraction = endpointDifference === 0n ? 1 : cc / q3;
    normal = p.map((value, axis) => {
      const projected = ratio2(2n * a2 * value - b2 * v[axis], 2n * a2 * radius);
      const offset = ratio2(v[axis] << BigInt(sqrtExponent), 2n * a2 * radius) * sqrtMantissa;
      return projected - offset;
    });
  }
  if (!Number.isFinite(fraction) || fraction < 0 || fraction > 1 || normal.some((value) => !Number.isFinite(value))) numericLimit2();
  const magnitude2 = Math.hypot(...normal);
  if (!(magnitude2 > 0) || Math.abs(magnitude2 - 1) > 1e-12) numericLimit2();
  return { fraction, normal: normal.map((value) => value / magnitude2) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/ccd-pair.ts
function sweepSpherePair(markedStart, markedEnd, otherStart, otherEnd) {
  if (markedStart.shape.kind !== "sphere" || otherStart.shape.kind !== "sphere") return null;
  const hit = sweepSpherePairExact(
    markedStart.positionM,
    markedEnd.positionM,
    otherStart.positionM,
    otherEnd.positionM,
    markedStart.shape.radiusM,
    otherStart.shape.radiusM
  );
  if (!hit) return null;
  const markedTravel = sub(markedEnd.positionM, markedStart.positionM);
  const otherTravel = sub(otherEnd.positionM, otherStart.positionM);
  const { fraction, normal: normalFixtureToBody } = hit;
  const markedAtHit = add2(markedStart.positionM, scale(markedTravel, fraction));
  const otherAtHit = add2(otherStart.positionM, scale(otherTravel, fraction));
  markedEnd.positionM = sub(markedAtHit, scale(normalFixtureToBody, 5e-10));
  otherEnd.positionM = add2(otherAtHit, scale(normalFixtureToBody, 5e-10));
  return {
    bodyId: markedStart.id,
    fixtureId: otherStart.id,
    toiFraction: fraction,
    normalFixtureToBody
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/broadphase.ts
function bodyBounds(body) {
  const shape2 = body.shape;
  let half;
  if (shape2.kind === "sphere") {
    half = [shape2.radiusM, shape2.radiusM, shape2.radiusM];
  } else if (shape2.kind === "capsule") {
    const axis = rotate2(body.orientation, [0, 1, 0]);
    half = axis.map((value) => shape2.radiusM + shape2.halfLengthM * Math.abs(value));
  } else {
    const axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate2(body.orientation, axis));
    half = [0, 1, 2].map((axis) => axes.reduce((extent, basis2, localAxis) => extent + Math.abs(basis2[axis]) * shape2.halfExtentsM[localAxis], 0));
  }
  const min = body.positionM.map((value, axis) => value - half[axis]);
  const max = body.positionM.map((value, axis) => value + half[axis]);
  if ([...min, ...max].some((value) => !Number.isFinite(value))) error("NUMERIC_LIMIT", "nonfinite broad-phase bounds");
  return { min, max };
}
function boundsOverlap(a2, b2) {
  for (let axis = 0; axis < 3; axis++) {
    if (a2.max[axis] + 1e-9 < b2.min[axis] || b2.max[axis] + 1e-9 < a2.min[axis]) return false;
  }
  return true;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/measure.ts
function measureBodies(bodies, joint, origin) {
  const masses = bodies.map((b3) => 1 / b3.inverseMass), total = masses[0] + masses[1];
  const centerOfMassM = scale(add2(scale(bodies[0].positionM, masses[0]), scale(bodies[1].positionM, masses[1])), 1 / total);
  const linearMomentumVectorKgMps = bodies.reduce((sum, b3, i) => add2(sum, scale(b3.velocityMps, masses[i])), [0, 0, 0]);
  const orbitalAngularMomentumVectorKgM2ps = bodies.reduce((sum, b3, i) => add2(sum, scale(cross4(sub(b3.positionM, origin), b3.velocityMps), masses[i])), [0, 0, 0]);
  const spinAngularMomentumVectorKgM2ps = bodies.reduce((sum, b3) => add2(sum, scale(b3.angularVelocityRadps, b3.inertiaKgM2)), [0, 0, 0]);
  const angularMomentumVectorKgM2ps = add2(orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps);
  const energyJ = bodies.reduce((sum, b3, i) => sum + 0.5 * masses[i] * dot3(b3.velocityMps, b3.velocityMps) + 0.5 * b3.inertiaKgM2 * dot3(b3.angularVelocityRadps, b3.angularVelocityRadps), 0);
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], relative = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const raw = 2 * Math.atan2(dot3([relative[0], relative[1], relative[2]], joint.axisWorld), relative[3]);
  const relativeAngleRad = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
  const anchorAM = worldPoint(a2, joint.anchorALocalM), anchorBM = worldPoint(b2, joint.anchorBLocalM);
  const anchorVelocityAMps = add2(a2.velocityMps, cross4(a2.angularVelocityRadps, rotate2(a2.orientation, joint.anchorALocalM)));
  const anchorVelocityBMps = add2(b2.velocityMps, cross4(b2.angularVelocityRadps, rotate2(b2.orientation, joint.anchorBLocalM)));
  const axisDeviationRad = Math.max(...bodies.map((body) => {
    const axis = rotate2(body.orientation, [0, 0, 1]);
    return Math.atan2(Math.hypot(axis[0], axis[1]), axis[2]);
  }));
  return {
    relativeAngleRad,
    anchorAM,
    anchorBM,
    anchorGapM: Math.hypot(...sub(anchorBM, anchorAM)),
    axisDeviationRad,
    quaternionNormError: Math.max(...bodies.map((body) => Math.abs(Math.hypot(...body.orientation) - 1))),
    limitExcessRad: Math.max(0, joint.limitRad[0] - relativeAngleRad, relativeAngleRad - joint.limitRad[1]),
    centerOfMassM,
    linearMomentumVectorKgMps,
    orbitalAngularMomentumVectorKgM2ps,
    spinAngularMomentumVectorKgM2ps,
    angularMomentumVectorKgM2ps,
    energyJ,
    anchorVelocityAMps,
    anchorVelocityBMps,
    anchorRelativeVelocityMps: sub(anchorVelocityAMps, anchorVelocityBMps),
    relativeAngularVelocityRadps: sub(b2.angularVelocityRadps, a2.angularVelocityRadps)
  };
}
function angle(a2, b2, axis) {
  const q3 = multiplyQuaternion(b2.orientation, inverse(a2.orientation));
  const raw = 2 * Math.atan2(dot3([q3[0], q3[1], q3[2]], axis), q3[3]);
  return raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
}
function momentum(bodies, origin) {
  const masses = bodies.map((b2) => 1 / b2.inverseMass), total = masses[0] + masses[1];
  const centerOfMassM = scale(add2(scale(bodies[0].positionM, masses[0]), scale(bodies[1].positionM, masses[1])), 1 / total);
  const linearMomentumVectorKgMps = bodies.reduce((sum, b2, i) => add2(sum, scale(b2.velocityMps, masses[i])), [0, 0, 0]);
  const orbitalAngularMomentumVectorKgM2ps = bodies.reduce((sum, b2, i) => add2(sum, scale(cross4(sub(b2.positionM, origin), b2.velocityMps), masses[i])), [0, 0, 0]);
  const spinAngularMomentumVectorKgM2ps = bodies.reduce((sum, b2) => add2(sum, scale(b2.angularVelocityRadps, b2.inertiaKgM2)), [0, 0, 0]);
  const angularMomentumVectorKgM2ps = add2(orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps);
  const energyJ = bodies.reduce((sum, b2, i) => sum + 0.5 * masses[i] * dot3(b2.velocityMps, b2.velocityMps) + 0.5 * b2.inertiaKgM2 * dot3(b2.angularVelocityRadps, b2.angularVelocityRadps), 0);
  return { centerOfMassM, linearMomentumVectorKgMps, orbitalAngularMomentumVectorKgM2ps, spinAngularMomentumVectorKgM2ps, angularMomentumVectorKgM2ps, energyJ };
}
function measurePose(bodies, joint, origin) {
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], relativeAngleRad = angle(a2, b2, joint.axisWorld), anchorAM = worldPoint(a2, joint.anchorALocalM), anchorBM = worldPoint(b2, joint.anchorBLocalM);
  const axisDeviationRad = Math.max(...bodies.map((body) => {
    const axis = rotate2(body.orientation, [0, 0, 1]);
    return Math.atan2(Math.hypot(axis[0], axis[1]), axis[2]);
  }));
  return { relativeAngleRad, anchorAM, anchorBM, anchorGapM: Math.hypot(...sub(anchorBM, anchorAM)), axisDeviationRad, quaternionNormError: Math.max(...bodies.map((b3) => Math.abs(Math.hypot(...b3.orientation) - 1))), limitExcessRad: Math.max(0, joint.limitRad[0] - relativeAngleRad, relativeAngleRad - joint.limitRad[1]), ...momentum(bodies, origin) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/errors.ts
var ERRORS = {
  pose: "hinge pose state is invalid",
  result: "hinge projection result is invalid",
  linear: "hinge velocity problem is invalid",
  system: "hinge velocity system is singular or unsafe",
  certificate: "hinge velocity certificate is invalid"
};
var GATE = 1e-10;
function fail(kind) {
  return error("NUMERIC_LIMIT", ERRORS[kind]);
}
function exactFields(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return false;
  const own = Reflect.ownKeys(value);
  return own.length === keys.length && own.every((k) => typeof k === "string" && keys.includes(k) && Object.hasOwn(Object.getOwnPropertyDescriptor(value, k), "value"));
}
function dense(value, size) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === size && Reflect.ownKeys(value).length === size + 1 && Array.from({ length: size }, (_, i) => i).every((i) => Object.hasOwn(value, i) && typeof value[i] === "number" && Number.isFinite(value[i]));
}
function matrix(value, rows, columns) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === rows && Reflect.ownKeys(value).length === rows + 1 && Array.from({ length: rows }, (_, i) => i).every((i) => Object.hasOwn(value, i) && dense(value[i], columns));
}
function finiteData(value) {
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (Array.isArray(value)) return Object.getPrototypeOf(value) === Array.prototype && Reflect.ownKeys(value).length === value.length + 1 && Array.from({ length: value.length }, (_, i) => i).every((i) => Object.hasOwn(value, i) && finiteData(value[i]));
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return (proto === Object.prototype || proto === null) && Reflect.ownKeys(value).every((k) => typeof k === "string" && finiteData(value[k]));
}
function readProblem(value) {
  if (!exactFields(value, ["a", "b", "h", "y0", "stopKind", "stopRow"]) || !matrix(value.a, 11, 12) || !dense(value.b, 11) || !dense(value.h, 12) || value.h.some((x) => x <= 0) || !dense(value.y0, 12)) fail("linear");
  if (value.stopKind !== "none" && value.stopKind !== "upper" && value.stopKind !== "lower") fail("linear");
  if (!dense(value.stopRow, value.stopKind === "none" ? 0 : 12)) fail("linear");
  return structuredClone(value);
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/pose.ts
function finiteData2(value) {
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (Array.isArray(value)) return value.every(finiteData2);
  if (value && typeof value === "object") return Object.values(value).every(finiteData2);
  return false;
}
function projectCoupledHinge(input) {
  const before = input.bodies.map(copyBody), bodies = input.bodies.map(copyBody), joint = input.pair.joint;
  const origin = [...input.pair.originM], beforeMetric = measurePose(before, joint, origin);
  const targetAngleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], beforeMetric.relativeAngleRad)), excess = beforeMetric.relativeAngleRad - targetAngleRad;
  const a2 = bodies[joint.aIndex], b2 = bodies[joint.bIndex], axis = joint.axisWorld, inverseA = dot3(axis, inverseInertia(a2, axis)), inverseB = dot3(axis, inverseInertia(b2, axis)), inverseSum = inverseA + inverseB;
  const angleCorrectionsRad = [excess * inverseA / inverseSum, -excess * inverseB / inverseSum];
  a2.orientation = advanceOrientation(a2.orientation, scale(axis, angleCorrectionsRad[0]), 1);
  b2.orientation = advanceOrientation(b2.orientation, scale(axis, angleCorrectionsRad[1]), 1);
  const massA = 1 / a2.inverseMass, massB = 1 / b2.inverseMass, totalMass = massA + massB;
  const center = scale(add2(scale(before[joint.aIndex].positionM, massA), scale(before[joint.bIndex].positionM, massB)), 1 / totalMass);
  const offset = sub(rotate2(b2.orientation, joint.anchorBLocalM), rotate2(a2.orientation, joint.anchorALocalM));
  a2.positionM = add2(center, scale(offset, massB / totalMass));
  b2.positionM = sub(center, scale(offset, massA / totalMass));
  validateResult(bodies, []);
  const afterMetric = measurePose(bodies, joint, origin), velocityBitsUnchanged = bodies.every((body, i) => body.velocityMps.every((v, k) => Object.is(v, before[i].velocityMps[k]))), angularVelocityBitsUnchanged = bodies.every((body, i) => body.angularVelocityRadps.every((v, k) => Object.is(v, before[i].angularVelocityRadps[k])));
  const poseReport = { jointId: joint.id, finalAngleRad: afterMetric.relativeAngleRad, targetAngleRad };
  const diagnostics = { before: beforeMetric, after: afterMetric, targetAngleRad, angleCorrectionsRad, translationCorrectionsM: bodies.map((body, i) => sub(body.positionM, before[i].positionM)), sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds, velocityBitsUnchanged, angularVelocityBitsUnchanged, lawEvaluations: 1 };
  if (!finiteData2(poseReport) || !finiteData2(diagnostics) || !velocityBitsUnchanged || !angularVelocityBitsUnchanged) fail("result");
  return { bodies: bodies.map(copyBody), poseReport: structuredClone(poseReport), diagnostics: structuredClone(diagnostics) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/rows.ts
var DOF_ORDER = ["vAx", "vAy", "vAz", "wAx", "wAy", "wAz", "vBx", "vBy", "vBz", "wBx", "wBy", "wBz"];
var ROW_IDS = ["P.x", "P.y", "P.z", "L.x", "L.y", "L.z", "anchor.x", "anchor.y", "anchor.z", "transverse.x", "transverse.y"];
var skew = (r) => [[0, -r[2], r[1]], [r[2], 0, -r[0]], [-r[1], r[0], 0]];
var canonical = (value) => value === 0 ? 0 : value;
function makeRows(beforeBodies, finalBodies, joint, before, origin, target) {
  const masses = beforeBodies.map((body) => 1 / body.inverseMass), inertias = beforeBodies.map((body) => body.inertiaKgM2);
  const center = [...before.centerOfMassM], centeredTarget = sub(before.angularMomentumVectorKgM2ps, cross4(sub(center, origin), before.linearMomentumVectorKgMps));
  const physicalA = Array.from({ length: 11 }, () => Array(12).fill(0));
  const rA = rotate2(finalBodies[0].orientation, joint.anchorALocalM), rB = rotate2(finalBodies[1].orientation, joint.anchorBLocalM);
  const ra = skew(rA), rb = skew(rB), sa = skew(sub(finalBodies[0].positionM, center)), sb = skew(sub(finalBodies[1].positionM, center));
  for (let i = 0; i < 3; i++) {
    physicalA[i][i] = masses[0];
    physicalA[i][6 + i] = masses[1];
    for (let j = 0; j < 3; j++) {
      physicalA[3 + i][j] = masses[0] * sa[i][j];
      physicalA[3 + i][6 + j] = masses[1] * sb[i][j];
      physicalA[6 + i][3 + j] = -ra[i][j];
      physicalA[6 + i][9 + j] = rb[i][j];
    }
    physicalA[3 + i][3 + i] = inertias[0];
    physicalA[3 + i][9 + i] = inertias[1];
    physicalA[6 + i][i] = 1;
    physicalA[6 + i][6 + i] = -1;
  }
  physicalA[9][3] = -1;
  physicalA[9][9] = 1;
  physicalA[10][4] = -1;
  physicalA[10][10] = 1;
  for (const row of physicalA) for (let j = 0; j < 12; j++) row[j] = canonical(row[j]);
  const physicalB = [...before.linearMomentumVectorKgMps, ...centeredTarget, 0, 0, 0, 0, 0];
  const physicalH = [...Array(3).fill(masses[0]), ...Array(3).fill(inertias[0]), ...Array(3).fill(masses[1]), ...Array(3).fill(inertias[1])];
  const physicalX0 = beforeBodies.flatMap((body) => [...body.velocityMps, ...body.angularVelocityRadps]);
  const columnScales = [1, 1, 1, 10, 10, 10, 1, 1, 1, 10, 10, 10], rowDivisors = [1, 1, 1, 0.1, 0.1, 0.1, 1, 1, 1, 10, 10];
  const dimensionlessA = physicalA.map((row, i) => row.map((value, j) => value * columnScales[j] / rowDivisors[i]));
  const dimensionlessB = physicalB.map((value, i) => value / rowDivisors[i]);
  const dimensionlessH = physicalH.map((value, j) => value * columnScales[j] * columnScales[j] / 1);
  const dimensionlessX0 = physicalX0.map((value, j) => value / columnScales[j]);
  const stopKind = target === joint.limitRad[1] ? "upper" : target === joint.limitRad[0] ? "lower" : "none";
  const physicalStopRow = stopKind === "none" ? [] : Array(12).fill(0);
  if (stopKind !== "none") {
    physicalStopRow[5] = stopKind === "upper" ? -1 : 1;
    physicalStopRow[11] = -physicalStopRow[5];
  }
  const dimensionlessStopRow = physicalStopRow.map((value, j) => value * columnScales[j] / 10);
  const h = sub(rA, rB), d = sub(finalBodies[1].positionM, finalBodies[0].positionM);
  const rankSufficientMarginKgM2 = 2 * inertias[0] - masses[0] * Math.hypot(...h) * Math.hypot(...sub(d, h));
  const problem = { a: dimensionlessA, b: dimensionlessB, h: dimensionlessH, y0: dimensionlessX0, stopKind, stopRow: dimensionlessStopRow };
  const result = {
    dofOrder: [...DOF_ORDER],
    rowIds: [...ROW_IDS],
    physicalA,
    physicalB,
    physicalH,
    physicalX0,
    columnScales,
    rowDivisors,
    dimensionlessA,
    dimensionlessB,
    dimensionlessH,
    dimensionlessX0,
    centerOfMassOriginM: center,
    originalOriginM: [...origin],
    stopKind,
    physicalStopRow,
    dimensionlessStopRow,
    rankSufficientMarginKgM2,
    problem
  };
  if (!finiteData(result) || physicalH.some((value) => value <= 0)) fail("linear");
  return result;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/linear-solver.ts
function checked(value, kind = "system") {
  if (!Number.isFinite(value)) fail(kind);
  return value;
}
function dot4(a2, b2, kind = "system") {
  let sum = 0;
  for (let j = 0; j < a2.length; j++) sum = checked(sum + checked(a2[j] * b2[j], kind), kind);
  return sum;
}
function normInf(a2, kind = "system") {
  let maximum = 0;
  for (const row of a2) {
    let sum = 0;
    for (const value of row) sum = checked(sum + Math.abs(value), kind);
    maximum = Math.max(maximum, sum);
  }
  return maximum;
}
function selected(problem, active2) {
  return { a: active2 ? [...problem.a.map((row) => [...row]), [...problem.stopRow]] : problem.a.map((row) => [...row]), b: active2 ? [...problem.b, 0] : [...problem.b] };
}
function gram(a2, h, kind = "system") {
  for (const value of h) checked(1 / value, kind);
  return a2.map((row) => a2.map((other) => {
    let sum = 0;
    for (let j = 0; j < 12; j++) {
      const divided = checked(row[j] / h[j], kind);
      sum = checked(sum + checked(divided * other[j], kind), kind);
    }
    return sum;
  }));
}
function safeReciprocals(problem) {
  for (const value of problem.h) checked(1 / value);
}
function fromLambda(problem, a2, lambda, kind = "system") {
  const y = [];
  for (let j = 0; j < 12; j++) {
    let sum = 0;
    for (let i = 0; i < a2.length; i++) sum = checked(sum + checked(a2[i][j] * lambda[i], kind), kind);
    y.push(checked(problem.y0[j] + checked(sum / problem.h[j], kind), kind));
  }
  return y;
}
function objective(problem, y) {
  let sum = 0;
  for (let j = 0; j < 12; j++) {
    const difference = checked(y[j] - problem.y0[j], "certificate");
    const square = checked(difference * difference, "certificate");
    sum = checked(sum + checked(problem.h[j] * square, "certificate"), "certificate");
  }
  return checked(0.5 * sum, "certificate");
}
function phaseResiduals(g, rhs, lambda, inverse2, kind = "system") {
  let linear = 0, inverseError = 0;
  for (let i = 0; i < g.length; i++) {
    linear = Math.max(linear, Math.abs(checked(dot4(g[i], lambda, kind) - rhs[i], kind)));
    let rowError = 0;
    for (let j = 0; j < g.length; j++) {
      let sum = 0;
      for (let k = 0; k < g.length; k++) sum = checked(sum + checked(g[i][k] * inverse2[k][j], kind), kind);
      rowError = checked(rowError + Math.abs(checked(sum - (i === j ? 1 : 0), kind)), kind);
    }
    inverseError = Math.max(inverseError, rowError);
  }
  return { linear, inverse: inverseError };
}
function solvePhase(problem, active2) {
  const system = selected(problem, active2), a2 = system.a, b2 = system.b, n = a2.length, g = gram(a2, problem.h), rhs = b2.map((value, i) => checked(value - dot4(a2[i], problem.y0)));
  const norm2 = normInf(g), threshold = checked(1e-12 * Math.max(1, norm2));
  const augmented = g.map((row, i) => [...row, rhs[i], ...Array.from({ length: n }, (_, j) => i === j ? 1 : 0)]), pivots = [];
  for (let k = 0; k < n; k++) {
    let chosen = k;
    for (let i = k + 1; i < n; i++) if (Math.abs(augmented[i][k]) > Math.abs(augmented[chosen][k])) chosen = i;
    if (Math.abs(augmented[chosen][k]) <= threshold) fail("system");
    if (chosen !== k) [augmented[k], augmented[chosen]] = [augmented[chosen], augmented[k]];
    const pivot = augmented[k][k];
    pivots.push(pivot);
    for (let i = k + 1; i < n; i++) {
      const factor = checked(augmented[i][k] / pivot);
      augmented[i][k] = 0;
      for (let j = k + 1; j <= 2 * n; j++) augmented[i][j] = checked(augmented[i][j] - checked(factor * augmented[k][j]));
    }
  }
  const solutions = [];
  for (let column = n; column <= 2 * n; column++) {
    const x = Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      let sum = 0;
      for (let j = i + 1; j < n; j++) sum = checked(sum + checked(augmented[i][j] * x[j]));
      x[i] = checked(checked(augmented[i][column] - sum) / augmented[i][i]);
    }
    solutions.push(x);
  }
  const lambda = solutions[0], inverse2 = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_2, j) => solutions[j + 1][i]));
  const conditionInf = checked(norm2 * normInf(inverse2));
  if (conditionInf > 1e12) fail("system");
  const y = fromLambda(problem, a2, lambda), residuals = phaseResiduals(g, rhs, lambda, inverse2);
  if (residuals.linear > GATE || residuals.inverse > GATE) fail("certificate");
  return { rowIds: Array.from({ length: n }, (_, i) => i), rowCount: n, pivots, inverse: inverse2, normInf: norm2, conditionInf, lambda, y, residuals };
}
function certificate2(problem, result) {
  const system = selected(problem, result.activeStop), a2 = system.a, b2 = system.b;
  let primal = 0, stationarity = 0;
  for (let i = 0; i < a2.length; i++) primal = Math.max(primal, Math.abs(checked(dot4(a2[i], result.y, "certificate") - b2[i], "certificate")));
  for (let j = 0; j < 12; j++) {
    let sum = 0;
    for (let i = 0; i < a2.length; i++) sum = checked(sum + checked(a2[i][j] * result.lambda[i], "certificate"), "certificate");
    const lhs = checked(problem.h[j] * checked(result.y[j] - problem.y0[j], "certificate"), "certificate");
    stationarity = Math.max(stationarity, Math.abs(checked(lhs - sum, "certificate")));
  }
  const signed = problem.stopKind === "none" ? 0 : dot4(problem.stopRow, result.y, "certificate"), mu = result.activeStop ? -result.lambda[11] : 0;
  const negativeMu = Math.max(0, -mu), complementarity = Math.abs(checked(mu * signed, "certificate"));
  const objectiveError = Math.abs(checked(objective(problem, result.y) - result.objectiveDimensionless, "certificate"));
  const value = { primal, stationarity, negativeMu, complementarity, objective: objectiveError };
  if (problem.stopKind !== "none" && signed > GATE || Object.values(value).some((v) => v > GATE) || result.objectiveDimensionless < 0) fail("certificate");
  return value;
}
function exactIdentity(problem) {
  return problem.a.every((row, i) => checked(dot4(row, problem.y0) - problem.b[i]) === 0) && (problem.stopKind === "none" || dot4(problem.stopRow, problem.y0) <= 0);
}
function readPhase(value, n) {
  if (!exactFields(value, ["rowIds", "rowCount", "pivots", "inverse", "normInf", "conditionInf", "lambda", "y", "residuals"]) || value.rowCount !== n || !dense(value.rowIds, n) || value.rowIds.some((id, i) => id !== i) || !dense(value.pivots, n) || !matrix(value.inverse, n, n) || !dense(value.lambda, n) || !dense(value.y, 12) || typeof value.normInf !== "number" || !Number.isFinite(value.normInf) || value.normInf < 0 || typeof value.conditionInf !== "number" || !Number.isFinite(value.conditionInf) || value.conditionInf < 0 || !exactFields(value.residuals, ["linear", "inverse"]) || ![value.residuals.linear, value.residuals.inverse].every((v) => typeof v === "number" && Number.isFinite(v) && v >= 0)) fail("certificate");
  return value;
}
function validatePhase(problem, phase, active2) {
  const system = selected(problem, active2), g = gram(system.a, problem.h, "certificate"), rhs = system.b.map((value, i) => checked(value - dot4(system.a[i], problem.y0, "certificate"), "certificate"));
  const norm2 = normInf(g, "certificate"), condition = checked(norm2 * normInf(phase.inverse, "certificate"), "certificate");
  if (!Object.is(norm2, phase.normInf) || !Object.is(condition, phase.conditionInf) || condition > 1e12 || phase.pivots.some((value) => Math.abs(value) <= 1e-12 * Math.max(1, norm2))) fail("certificate");
  const residuals = phaseResiduals(g, rhs, phase.lambda, phase.inverse, "certificate");
  if (residuals.linear > GATE || residuals.inverse > GATE || !Object.is(residuals.linear, phase.residuals.linear) || !Object.is(residuals.inverse, phase.residuals.inverse)) fail("certificate");
  const y = fromLambda(problem, system.a, phase.lambda, "certificate");
  if (y.some((v, i) => !Object.is(v, phase.y[i]))) fail("certificate");
}
function validateVelocityCertificate(problemValue, resultValue) {
  const problem = readProblem(problemValue);
  safeReciprocals(problem);
  if (!exactFields(resultValue, ["y", "lambda", "activeStop", "identity", "solveAttempts", "phases", "objectiveDimensionless", "certificate"]) || typeof resultValue.activeStop !== "boolean" || typeof resultValue.identity !== "boolean" || !dense(resultValue.y, 12) || !dense(resultValue.lambda, resultValue.activeStop ? 12 : 11) || typeof resultValue.objectiveDimensionless !== "number" || !Number.isFinite(resultValue.objectiveDimensionless) || !Number.isInteger(resultValue.solveAttempts) || !Array.isArray(resultValue.phases) || Object.getPrototypeOf(resultValue.phases) !== Array.prototype || Reflect.ownKeys(resultValue.phases).length !== resultValue.phases.length + 1 || !Array.from({ length: resultValue.phases.length }, (_, i) => i).every((i) => Object.hasOwn(resultValue.phases, i)) || !exactFields(resultValue.certificate, ["primal", "stationarity", "negativeMu", "complementarity", "objective"]) || Object.values(resultValue.certificate).some((v) => typeof v !== "number" || !Number.isFinite(v) || v < 0)) fail("certificate");
  const result = resultValue, identity3 = exactIdentity(problem);
  if (result.identity !== identity3 || result.phases.length !== result.solveAttempts) fail("certificate");
  if (identity3) {
    if (result.solveAttempts !== 0 || result.activeStop || result.lambda.some((value) => value !== 0) || result.y.some((value, j) => !Object.is(value, problem.y0[j]))) fail("certificate");
  } else {
    if (result.solveAttempts !== 1 && result.solveAttempts !== 2) fail("certificate");
    const equality = readPhase(result.phases[0], 11);
    validatePhase(problem, equality, false);
    const active2 = problem.stopKind !== "none" && dot4(problem.stopRow, equality.y, "certificate") > 0;
    if (result.activeStop !== active2 || result.solveAttempts !== (active2 ? 2 : 1)) fail("certificate");
    if (active2) validatePhase(problem, readPhase(result.phases[1], 12), true);
    const final = result.phases[result.phases.length - 1];
    if (result.y.some((value, j) => !Object.is(value, final.y[j])) || result.lambda.some((value, i) => !Object.is(value, final.lambda[i]))) fail("certificate");
  }
  const computed = certificate2(problem, result);
  for (const key of Object.keys(computed)) if (Math.abs(computed[key] - result.certificate[key]) > GATE) fail("certificate");
  return { ...computed };
}
function solveDimensionlessVelocity(value) {
  const problem = readProblem(value);
  safeReciprocals(problem);
  const identity3 = exactIdentity(problem);
  let phases = [], activeStop = false, y, lambda;
  if (identity3) {
    y = [...problem.y0];
    lambda = Array(11).fill(0);
  } else {
    phases = [solvePhase(problem, false)];
    activeStop = problem.stopKind !== "none" && dot4(problem.stopRow, phases[0].y) > 0;
    if (activeStop) phases.push(solvePhase(problem, true));
    const final = phases[phases.length - 1];
    y = [...final.y];
    lambda = [...final.lambda];
  }
  const result = { y, lambda, activeStop, identity: identity3, solveAttempts: phases.length, phases, objectiveDimensionless: objective(problem, y), certificate: { primal: 0, stationarity: 0, negativeMu: 0, complementarity: 0, objective: 0 } };
  result.certificate = certificate2(problem, result);
  validateVelocityCertificate(problem, result);
  return structuredClone(result);
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/projection.ts
function projectHingePoseVelocity(input) {
  const beforeBodies = input.bodies.map(copyBody);
  const originalOriginM = [...input.pair.originM];
  const before = measureBodies(beforeBodies, input.pair.joint, originalOriginM);
  const pose = projectCoupledHinge(input);
  const bodies = pose.bodies.map(copyBody), rows = makeRows(beforeBodies, bodies, input.pair.joint, before, originalOriginM, pose.poseReport.targetAngleRad);
  const result = solveDimensionlessVelocity(rows.problem);
  if (!result.identity) {
    for (let i = 0; i < 2; i++) {
      bodies[i].velocityMps = result.y.slice(i * 6, i * 6 + 3).map((value, j) => value * rows.columnScales[i * 6 + j]);
      bodies[i].angularVelocityRadps = result.y.slice(i * 6 + 3, i * 6 + 6).map((value, j) => value * rows.columnScales[i * 6 + 3 + j]);
    }
  }
  validateResult(bodies, []);
  const after = measureBodies(bodies, input.pair.joint, originalOriginM);
  const velocityCorrections = { linearMps: bodies.map((body, i) => sub(body.velocityMps, beforeBodies[i].velocityMps)), angularRadps: bodies.map((body, i) => sub(body.angularVelocityRadps, beforeBodies[i].angularVelocityRadps)) };
  const changedComponents = bodies.map((body, i) => [...body.velocityMps, ...body.angularVelocityRadps].map((value, j) => !Object.is(value, [...beforeBodies[i].velocityMps, ...beforeBodies[i].angularVelocityRadps][j])));
  const identityVelocityBitsPreserved = result.identity && changedComponents.every((row) => row.every((changed) => !changed));
  const finalX = bodies.flatMap((body) => [...body.velocityMps, ...body.angularVelocityRadps]);
  let sum = 0;
  for (let j = 0; j < 12; j++) {
    const delta = finalX[j] - rows.physicalX0[j];
    sum += rows.physicalH[j] * (delta * delta);
  }
  const objectiveJ = 0.5 * sum;
  const physicalLambda = result.lambda.map((value, i) => 1 * value / (i === 11 ? 10 : rows.rowDivisors[i]));
  const projection = {
    dofOrder: rows.dofOrder,
    rowIds: result.activeStop ? [...rows.rowIds, `stop.${rows.stopKind}`] : rows.rowIds,
    physicalA: rows.physicalA,
    physicalB: rows.physicalB,
    physicalH: rows.physicalH,
    physicalX0: rows.physicalX0,
    columnScales: rows.columnScales,
    rowDivisors: rows.rowDivisors,
    dimensionlessA: rows.dimensionlessA,
    dimensionlessB: rows.dimensionlessB,
    dimensionlessH: rows.dimensionlessH,
    dimensionlessX0: rows.dimensionlessX0,
    centerOfMassOriginM: rows.centerOfMassOriginM,
    originalOriginM: rows.originalOriginM,
    stopKind: rows.stopKind,
    physicalStopRow: rows.physicalStopRow,
    dimensionlessStopRow: rows.dimensionlessStopRow,
    result,
    physicalLambda,
    objectiveJ,
    rankSufficientMarginKgM2: rows.rankSufficientMarginKgM2
  };
  const diagnostics = { poseStage: pose.diagnostics, before, after, velocityCorrections, projection, changedComponents, identityVelocityBitsPreserved, poseLawEvaluations: 1, sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds };
  if (!finiteData(diagnostics) || !finiteData(pose.poseReport) || objectiveJ < 0 || result.identity && !identityVelocityBitsPreserved) fail("result");
  return { bodies: bodies.map(copyBody), poseReport: structuredClone(pose.poseReport), diagnostics: structuredClone(diagnostics) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/report.ts
var REPORT_KEYS = ["id", "kind", "aId", "bId", "angleRad", "linearImpulseNs", "angularImpulseNms", "motorImpulseNms"];
var nonempty = (value) => typeof value === "string" && value.length > 0;
var finite2 = (value) => typeof value === "number" && Number.isFinite(value);
function validateHingeMotorReport(value, identity3) {
  const ids2 = ownData(identity3, ["id", "aId", "bId"]);
  const report = ownData(value, REPORT_KEYS);
  if (!ids2 || !nonempty(ids2.id) || !nonempty(ids2.aId) || !nonempty(ids2.bId) || !report || report.id !== ids2.id || report.aId !== ids2.aId || report.bId !== ids2.bId || report.kind !== "hinge" || !finite2(report.angleRad) || !finite2(report.motorImpulseNms)) reactionError();
  const linear = denseNumbers(report.linearImpulseNs, 3), angular = denseNumbers(report.angularImpulseNms, 3);
  if (!linear || !angular) reactionError();
  return {
    id: ids2.id,
    kind: "hinge",
    aId: ids2.aId,
    bId: ids2.bId,
    angleRad: report.angleRad,
    linearImpulseNs: linear,
    angularImpulseNms: angular,
    motorImpulseNms: report.motorImpulseNms
  };
}
function enforceHingeMotorReactionCap(jointId, angularImpulseNms) {
  const vector6 = denseNumbers(angularImpulseNms, 3);
  if (!nonempty(jointId) || !vector6) reactionError();
  const norm2 = Math.hypot(...vector6);
  if (!Number.isFinite(norm2)) reactionError();
  if (norm2 > 0.01) throw new PhysicsError("NUMERIC_LIMIT", `${jointId} exceeded motor reaction limit`);
}
function bodyCorrections(free, projected) {
  return projected.map((body, i) => ({
    bodyId: body.id,
    linearImpulseNs: scale(sub(body.velocityMps, free[i].velocityMps), 1 / free[i].inverseMass),
    angularImpulseNms: scale(sub(body.angularVelocityRadps, free[i].angularVelocityRadps), free[i].inertiaKgM2)
  }));
}
function makeReport(joint, free, projected, targetAngleRad, motorImpulseNms) {
  const corrections = bodyCorrections(free, projected);
  for (const c of corrections) if (!denseNumbers(c.linearImpulseNs, 3) || !denseNumbers(c.angularImpulseNms, 3)) reactionError();
  const identity3 = { id: joint.id, aId: free[joint.aIndex].id, bId: free[joint.bIndex].id };
  const b2 = corrections[joint.bIndex];
  const jointReport = validateHingeMotorReport({
    ...identity3,
    kind: "hinge",
    angleRad: targetAngleRad,
    linearImpulseNs: [...b2.linearImpulseNs],
    angularImpulseNms: [...b2.angularImpulseNms],
    motorImpulseNms
  }, identity3);
  const angularReactionNormNms = Math.hypot(...b2.angularImpulseNms);
  if (!Number.isFinite(angularReactionNormNms)) reactionError();
  return {
    jointReport,
    bodyCorrections: copyData2(corrections),
    reportCap: { angularReactionNormNms, maxReactionNms: 0.01, exceedsCap: angularReactionNormNms > 0.01 }
  };
}
function reactionError() {
  throw new PhysicsError("NUMERIC_LIMIT", "unsafe joint reaction");
}
function copyData2(value) {
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map((item) => copyData2(item));
  const copied = {};
  for (const key of Object.keys(value)) {
    Object.defineProperty(copied, key, {
      value: copyData2(value[key]),
      enumerable: true,
      configurable: true,
      writable: true
    });
  }
  return copied;
}
function ownData(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return null;
  const actual = Reflect.ownKeys(value);
  if (actual.length !== keys.length || actual.some((k) => typeof k !== "string" || !keys.includes(k))) return null;
  const result = {};
  for (const key of keys) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return null;
    Object.defineProperty(result, key, { value: descriptor.value, enumerable: true, configurable: true, writable: true });
  }
  return result;
}
function denseNumbers(value, length) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length !== length || Reflect.ownKeys(value).length !== length + 1) return null;
  const result = [];
  for (let i = 0; i < length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor) || typeof descriptor.value !== "number" || !Number.isFinite(descriptor.value)) return null;
    result.push(descriptor.value);
  }
  return result;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/postcontact.ts
function publicBody(body) {
  return {
    id: body.id,
    kind: body.kind,
    shape: copyShape(body.shape),
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    orientation: [...body.orientation],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inertiaKgM2: body.inertiaKgM2
  };
}
function rawHex(bodies) {
  const bytes = new Uint8Array(104 * bodies.length), view = new DataView(bytes.buffer);
  let cursor = 0;
  for (const body of bodies) for (const value of [
    ...body.positionM,
    ...body.velocityMps,
    ...body.orientation,
    ...body.angularVelocityRadps
  ]) {
    view.setFloat64(cursor, value, true);
    cursor += 8;
  }
  return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
}
function projectDisjointPostContact(input) {
  const next = input.bodies.map(copyBody);
  const jointReports = [];
  const bodyCorrections2 = [];
  const reportCaps = [];
  const calls = { projectionCalls: 0, reportCalls: 0 };
  for (const index of [0, 1]) {
    const pair2 = input.pairs[index];
    const before = [
      copyBody(input.bodies[pair2.bodyIndices[0]]),
      copyBody(input.bodies[pair2.bodyIndices[1]])
    ];
    calls.projectionCalls++;
    const projected = projectHingePoseVelocity({
      pair: pair2,
      bodies: before,
      sourceStepIndex: input.sourceStepIndex,
      sourceTimeSeconds: input.sourceTimeSeconds
    });
    const returned = [copyBody(projected.bodies[0]), copyBody(projected.bodies[1])];
    next[pair2.bodyIndices[0]] = returned[0];
    next[pair2.bodyIndices[1]] = returned[1];
    calls.reportCalls++;
    const report = makeReport(
      pair2.joint,
      before,
      returned,
      projected.poseReport.targetAngleRad,
      input.motorImpulsesNms[index]
    );
    jointReports[pair2.jointInputIndex] = report.jointReport;
    bodyCorrections2.push(report.bodyCorrections);
    reportCaps.push(report.reportCap);
  }
  for (const report of jointReports) enforceHingeMotorReactionCap(report.id, report.angularImpulseNms);
  return {
    projectedBodies: next.map(publicBody),
    projectedRawHex: rawHex(next),
    jointReports,
    bodyCorrections: bodyCorrections2,
    reportCaps,
    calls
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/disjoint-hinge/stage.ts
function admitDisjointHingeCommands(pairs, bodies, actions, commandCount) {
  for (const pair2 of pairs) {
    admitDynamicHingeCommands(
      pair2.joint,
      [bodies[pair2.bodyIndices[0]], bodies[pair2.bodyIndices[1]]],
      actions
    );
  }
  if (commandCount !== 0) error("INVALID_COMMAND", "disjoint hinge profile supports empty commands only");
}
function driveDisjointHingeMotors(pairs, bodies, reports, impulses) {
  for (const pair2 of pairs) impulses[pair2.jointInputIndex] = driveDynamicHingeMotor(
    pair2.joint,
    bodies[pair2.bodyIndices[0]],
    bodies[pair2.bodyIndices[1]],
    reports[pair2.jointInputIndex].angleRad
  );
}
function applyDisjointHingePostContact(pairs, bodies, reports, motorImpulses, sourceStepIndex, sourceTimeSeconds) {
  const canonical2 = [
    { ...pairs[0], jointInputIndex: 0 },
    { ...pairs[1], jointInputIndex: 1 }
  ];
  const result = projectDisjointPostContact({
    bodies,
    pairs: canonical2,
    motorImpulsesNms: [motorImpulses[pairs[0].jointInputIndex], motorImpulses[pairs[1].jointInputIndex]],
    sourceStepIndex,
    sourceTimeSeconds
  });
  for (let index = 0; index < bodies.length; index++) {
    const target = bodies[index], returned = result.projectedBodies[index];
    target.positionM = [...returned.positionM];
    target.velocityMps = [...returned.velocityMps];
    target.orientation = [...returned.orientation];
    target.angularVelocityRadps = [...returned.angularVelocityRadps];
  }
  for (const index of [0, 1]) reports[pairs[index].jointInputIndex] = result.jointReports[index];
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/rotation-validation.ts
function validateRotationResult(result, dt) {
  if (result.angularVelocityRadps.some((value) => !Number.isFinite(value) || Math.abs(value) > 1e3) || !Number.isFinite(dt) || dt <= 0 || Math.hypot(...result.angularVelocityRadps) * dt > 10) {
    error("NUMERIC_LIMIT", "free rotation exceeded angular movement limit");
  }
  if (result.orientation.some((value) => !Number.isFinite(value)) || Math.abs(Math.hypot(...result.orientation) - 1) > 1e-12) {
    error("NUMERIC_LIMIT", "free rotation orientation exceeded tolerance");
  }
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/rigid-free-rotation.ts
var exponents = Object.freeze([3, 5, 7]);
var roots = Object.freeze(exponents.map((exponent) => {
  return Math.pow(2, 1 / exponent);
}));
var a = Object.freeze(roots.map((root) => 1 / (2 - root)));
var b = Object.freeze(a.map((value) => 1 - 2 * value));
var expanded = [1];
for (let level = 0; level < 3; level++) {
  expanded = [
    ...expanded.map((value) => a[level] * value),
    ...expanded.map((value) => b[level] * value),
    ...expanded.map((value) => a[level] * value)
  ];
}
var triaxialFreeRotationCoefficients = Object.freeze({
  exponents,
  roots,
  a,
  b,
  weights: Object.freeze(expanded)
});
var ROUNDING_UNIT = 2 ** -52;
var unitVectorBound = (value) => value.every((component) => Number.isFinite(component) && Math.abs(component) <= 1);
var maximumComponent = (value) => Math.max(Math.abs(value[0]), Math.abs(value[1]), Math.abs(value[2]));
function field(p, diagonal) {
  return [
    (diagonal[2] - diagonal[1]) * p[1] * p[2],
    (diagonal[0] - diagonal[2]) * p[2] * p[0],
    (diagonal[1] - diagonal[0]) * p[0] * p[1]
  ];
}
function derivative(p, diagonal) {
  return [
    [0, (diagonal[2] - diagonal[1]) * p[2], (diagonal[2] - diagonal[1]) * p[1]],
    [(diagonal[0] - diagonal[2]) * p[2], 0, (diagonal[0] - diagonal[2]) * p[0]],
    [(diagonal[1] - diagonal[0]) * p[1], (diagonal[1] - diagonal[0]) * p[0], 0]
  ];
}
function linearSolve(matrix3, right) {
  const rows = matrix3.map((row, index) => [...row, right[index]]);
  for (let column = 0; column < 3; column++) {
    let selected2 = column;
    for (let row = column + 1; row < 3; row++) {
      if (Math.abs(rows[row][column]) > Math.abs(rows[selected2][column])) selected2 = row;
    }
    if (selected2 !== column) [rows[selected2], rows[column]] = [rows[column], rows[selected2]];
    const selectedPivot = rows[column][column];
    const pivotMagnitude = Math.abs(selectedPivot);
    if (!Number.isFinite(selectedPivot) || pivotMagnitude < 1 / 4) {
      error("NUMERIC_LIMIT", "triaxial midpoint pivot outside qualified bound");
    }
    for (let row = column + 1; row < 3; row++) {
      const multiplier = rows[row][column] / selectedPivot;
      rows[row][column] = 0;
      for (let entry = column + 1; entry < 4; entry++) rows[row][entry] -= multiplier * rows[column][entry];
    }
  }
  const result = [0, 0, 0];
  for (let row = 2; row >= 0; row--) {
    let total = rows[row][3];
    for (let column = row + 1; column < 3; column++) total -= rows[row][column] * result[column];
    result[row] = total / rows[row][row];
  }
  if (!result.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite triaxial midpoint correction");
  const residual = matrix3.map((row, index) => row.reduce((sum, value, column) => sum + value * result[column], 0) - right[index]);
  const matrixNorm = Math.max(...matrix3.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0)));
  const residualMaximum = maximumComponent(residual);
  const residualScale = Math.max(1, matrixNorm * maximumComponent(result) + maximumComponent(right));
  const residualBound = 64 * ROUNDING_UNIT * residualScale;
  if (!Number.isFinite(residualMaximum) || !Number.isFinite(residualBound) || residualMaximum > residualBound) {
    error("NUMERIC_LIMIT", "triaxial linear correction residual outside qualified bound");
  }
  return { value: result, residualMaximum, residualBound };
}
function midpoint(p0, diagonal, signedStep) {
  if (!Number.isFinite(signedStep) || !unitVectorBound(p0)) {
    error("NUMERIC_LIMIT", "triaxial midpoint initial iterate outside bound");
  }
  const initialField = field(p0, diagonal);
  let guess = p0.map((value, index) => value + signedStep * initialField[index]);
  if (!unitVectorBound(guess)) error("NUMERIC_LIMIT", "triaxial midpoint predictor outside bound");
  for (let update = 0; update < 4; update++) {
    const middle2 = p0.map((value, index) => (value + guess[index]) / 2);
    const velocity2 = field(middle2, diagonal);
    const residual2 = guess.map((value, index) => value - p0[index] - signedStep * velocity2[index]);
    const jacobianField = derivative(middle2, diagonal);
    const perturbation = maximumComponent(jacobianField.map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
    if (!unitVectorBound(middle2) || !Number.isFinite(perturbation) || perturbation > 1 / 4) {
      error("NUMERIC_LIMIT", "triaxial midpoint Jacobian outside qualified bound");
    }
    const jacobian = jacobianField.map((row, i) => row.map((value, j) => (i === j ? 1 : 0) - signedStep * value / 2));
    const linearResult = linearSolve(jacobian, residual2.map((value) => -value));
    const correction = linearResult.value;
    const linearResidualMaximum = linearResult.residualMaximum;
    const linearResidualBound = linearResult.residualBound;
    guess = guess.map((value, index) => value + correction[index]);
    if (!unitVectorBound(guess)) error("NUMERIC_LIMIT", "triaxial midpoint update outside bound");
  }
  const middle = p0.map((value, index) => (value + guess[index]) / 2);
  const velocity = field(middle, diagonal);
  const residual = guess.map((value, index) => value - p0[index] - signedStep * velocity[index]);
  const residualMaximum = maximumComponent(residual);
  const residualScale = Math.max(
    1,
    maximumComponent(p0),
    maximumComponent(guess),
    maximumComponent(velocity.map((value) => signedStep * value))
  );
  const residualBound = 64 * ROUNDING_UNIT * residualScale;
  const finalPerturbation = maximumComponent(derivative(middle, diagonal).map((row) => row.reduce((sum, value) => sum + Math.abs(signedStep * value / 2), 0)));
  if (!unitVectorBound(middle) || !Number.isFinite(residualMaximum) || !Number.isFinite(finalPerturbation) || finalPerturbation > 1 / 4 || residualMaximum > residualBound) {
    error("NUMERIC_LIMIT", "triaxial midpoint residual outside qualified bound");
  }
  return { p: guess, omegaMid: middle.map((value, index) => value * diagonal[index]) };
}
function prepareFreeRotation(body, dt) {
  if (body.kind !== "dynamic") return null;
  const moments = body.inertiaDiagonalKgM2 ?? [body.inertiaKgM2, body.inertiaKgM2, body.inertiaKgM2];
  if (!moments.every((value) => Number.isFinite(value) && value > 0) || !Number.isFinite(dt) || dt <= 0) {
    error("NUMERIC_LIMIT", "triaxial flow outside qualified time/inertia bounds");
  }
  if (moments[0] === moments[1] && moments[1] === moments[2]) return null;
  if (body.angularVelocityRadps.every((value) => value === 0)) {
    return { orientation: [...body.orientation], angularVelocityRadps: [...body.angularVelocityRadps] };
  }
  const magnitude2 = Math.hypot(...body.orientation);
  if (!Number.isFinite(magnitude2) || magnitude2 === 0) error("NUMERIC_LIMIT", "invalid triaxial orientation");
  let orientation = body.orientation.map((value) => value / magnitude2);
  const localOmega = rotate2(inverse(orientation), body.angularVelocityRadps);
  if (!localOmega.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite triaxial body spin");
  const momentum2 = localOmega.map((value, index) => moments[index] * value);
  const momentumNorm = Math.hypot(...momentum2);
  const momentumScale = 2 * momentumNorm;
  if (!momentum2.every(Number.isFinite) || !Number.isFinite(momentumScale) || momentumNorm === 0) {
    error("NUMERIC_LIMIT", "free rotation momentum outside finite range");
  }
  if (localOmega.filter((value) => value !== 0).length === 1) {
    return {
      orientation: advanceOrientation(orientation, body.angularVelocityRadps, dt),
      angularVelocityRadps: [...body.angularVelocityRadps]
    };
  }
  const diagonal = moments.map((value) => momentumScale / value);
  let p = momentum2.map((value) => value / momentumScale);
  if (!diagonal.every(Number.isFinite) || Math.hypot(...p) > 1 / 2 + 4 * ROUNDING_UNIT) {
    error("NUMERIC_LIMIT", "free rotation scaled momentum outside bound");
  }
  const maximumDifference = Math.max(
    Math.abs(diagonal[2] - diagonal[1]),
    Math.abs(diagonal[0] - diagonal[2]),
    Math.abs(diagonal[1] - diagonal[0])
  );
  const maximumWeight = Math.max(...triaxialFreeRotationCoefficients.weights.map(Math.abs));
  const subdivisions = Math.max(1, Math.ceil(4 * maximumWeight * dt * maximumDifference));
  if (!Number.isFinite(subdivisions) || subdivisions > 64) {
    error("NUMERIC_LIMIT", "free rotation exceeded internal subdivision limit");
  }
  for (let subdivision = 0; subdivision < subdivisions; subdivision++) {
    for (let stage = 0; stage < 27; stage++) {
      const weight = triaxialFreeRotationCoefficients.weights[stage];
      if (!Number.isFinite(weight) || Math.abs(weight) >= 3) error("NUMERIC_LIMIT", "invalid triaxial composition coefficient");
      const signedStep = weight * (dt / subdivisions);
      const prepared = midpoint(p, diagonal, signedStep);
      const vector6 = prepared.omegaMid.map((value) => signedStep * value / 2);
      const deltaNorm = Math.hypot(...vector6, 1);
      if (!Number.isFinite(deltaNorm) || deltaNorm === 0) error("NUMERIC_LIMIT", "invalid Cayley increment");
      const delta = [vector6[0] / deltaNorm, vector6[1] / deltaNorm, vector6[2] / deltaNorm, 1 / deltaNorm];
      const composed = multiplyQuaternion(orientation, delta);
      const composedNorm = Math.hypot(...composed);
      if (!Number.isFinite(composedNorm) || composedNorm === 0) error("NUMERIC_LIMIT", "nonfinite Cayley orientation");
      orientation = composed.map((value) => value / composedNorm);
      p = prepared.p;
    }
  }
  const angularVelocityRadps = rotate2(orientation, p.map((value, index) => value * diagonal[index]));
  return { orientation, angularVelocityRadps };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/rigid-forced-rotation.ts
function rotation(q3) {
  const [x, y, z, w] = q3;
  const n = x * x + y * y + z * z + w * w;
  if (!q3.every(Number.isFinite) || !Number.isFinite(n) || n <= 0) {
    error("NUMERIC_LIMIT", "invalid forced stage quaternion");
  }
  return [
    [(w * w + x * x - y * y - z * z) / n, 2 * (x * y - z * w) / n, 2 * (x * z + y * w) / n],
    [2 * (x * y + z * w) / n, (w * w - x * x + y * y - z * z) / n, 2 * (y * z - x * w) / n],
    [2 * (x * z - y * w) / n, 2 * (y * z + x * w) / n, (w * w - x * x - y * y + z * z) / n]
  ];
}
function product3(r, v, transpose = false) {
  return [0, 1, 2].map((i) => [0, 1, 2].reduce((s, j) => s + (transpose ? r[j][i] : r[i][j]) * v[j], 0));
}
function movement(omega, dt) {
  if (omega.some((x) => !Number.isFinite(x) || Math.abs(x) > 1e3) || Math.hypot(...omega) * dt > 10) {
    error("NUMERIC_LIMIT", "forced rotation exceeded angular movement limit");
  }
}
function prepareForcedRotation(body, dt, torque) {
  if (body.kind !== "dynamic" || torque.every((x) => x === 0)) return null;
  const moments = body.inertiaDiagonalKgM2 ?? [body.inertiaKgM2, body.inertiaKgM2, body.inertiaKgM2];
  if (!moments.every((x) => Number.isFinite(x) && x > 0) || !Number.isFinite(dt) || dt <= 0 || !torque.every(Number.isFinite)) {
    error("NUMERIC_LIMIT", "forced rotation outside finite time/inertia/load bounds");
  }
  movement(body.angularVelocityRadps, dt);
  const r0 = rotation(body.orientation);
  const localOmega = product3(r0, body.angularVelocityRadps, true);
  const momentum2 = product3(r0, localOmega.map((x, i) => x * moments[i]));
  if (!momentum2.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced initial momentum");
  const angularRateBound = (Math.hypot(...momentum2) + dt * Math.hypot(...torque)) / Math.min(...moments);
  const subdivisions = Math.max(1, Math.ceil(dt * angularRateBound / (1 / 8)));
  if (!Number.isFinite(subdivisions) || subdivisions > 64) {
    error("NUMERIC_LIMIT", "forced rotation exceeded internal subdivision limit");
  }
  const omegaAt = (q4, time) => {
    const r = rotation(q4);
    const stageL = momentum2.map((x, i) => x + torque[i] * time);
    if (!stageL.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced stage momentum");
    const localL = product3(r, stageL, true);
    const omega = product3(r, localL.map((x, i) => x / moments[i]));
    movement(omega, dt);
    return omega;
  };
  const rhs = (q4, time) => {
    const [a2, b2, c] = omegaAt(q4, time), [x, y, z, w] = q4;
    const rate = [
      (a2 * w + b2 * z - c * y) / 2,
      (-a2 * z + b2 * w + c * x) / 2,
      (a2 * y - b2 * x + c * w) / 2,
      (-a2 * x - b2 * y - c * z) / 2
    ];
    if (!rate.every(Number.isFinite)) error("NUMERIC_LIMIT", "nonfinite forced quaternion rate");
    return rate;
  };
  const offset = (q4, rate, h) => q4.map((x, i) => x + h * rate[i]);
  const levels = [2, 4, 6, 8];
  let q3 = [...body.orientation];
  const macroStep = dt / subdivisions;
  for (let macro = 0; macro < subdivisions; macro++) {
    const start = macro * macroStep;
    const table = [];
    for (let k = 0; k < levels.length; k++) {
      const count = levels[k], h = macroStep / count;
      let previous = q3;
      let current = offset(q3, rhs(q3, start), h);
      for (let m = 1; m < count; m++) {
        const next2 = offset(previous, rhs(current, start + m * h), 2 * h);
        previous = current;
        current = next2;
      }
      const endpointRate = rhs(current, start + macroStep);
      const row = [current.map((x, i) => (x + previous[i] + h * endpointRate[i]) / 2)];
      for (let j = 1; j <= k; j++) {
        const denominator = (count / levels[k - j]) ** 2 - 1;
        row.push(row[j - 1].map((x, i) => x + (x - table[k - 1][j - 1][i]) / denominator));
      }
      table.push(row);
    }
    const next = table[3][3];
    const norm2 = Math.hypot(...next);
    if (!next.every(Number.isFinite) || !Number.isFinite(norm2) || norm2 <= 0) {
      error("NUMERIC_LIMIT", "nonfinite forced extrapolated orientation");
    }
    q3 = next.map((x) => x / norm2);
  }
  const angularVelocityRadps = omegaAt(q3, dt);
  if (Math.abs(q3.reduce((s, x) => s + x * x, 0) - 1) > 1e-12) {
    error("NUMERIC_LIMIT", "forced final quaternion exceeded norm limit");
  }
  return { orientation: q3, angularVelocityRadps };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/world.ts
function publicState(bodies, contacts, events, joints, ccdHits, pairStats, stepIndex, dt, identity3, colliderIds, pairWrenches) {
  return {
    schemaVersion: 2,
    identity: { ...identity3 },
    stepIndex,
    timeSeconds: stepIndex * dt,
    bodies: bodies.map((body) => ({
      id: body.id,
      kind: body.kind,
      positionM: [...body.positionM],
      orientationXYZW: [...body.orientation],
      velocityMps: [...body.velocityMps],
      angularVelocityRadps: [...body.angularVelocityRadps],
      sleeping: body.sleeping ?? false
    })),
    contacts: copyData(contacts),
    pairWrenches: copyData(pairWrenches),
    events: events.map((event) => ({
      colliderAId: colliderIds.get(event.aId),
      colliderBId: colliderIds.get(event.bId),
      kind: event.kind,
      phase: event.phase
    })),
    joints: joints.map((joint) => ({
      id: joint.id,
      bodyAId: joint.aId,
      bodyBId: joint.bId,
      linearImpulseOnBNs: [...joint.linearImpulseNs],
      angularImpulseOnBNms: [...joint.angularImpulseNms],
      angleRad: joint.angleRad ?? null,
      motorImpulseNms: joint.motorImpulseNms ?? null
    })),
    ccdHits: ccdHits.map((hit) => ({
      bodyId: hit.bodyId,
      colliderId: colliderIds.get(hit.fixtureId),
      toiFraction: hit.toiFraction,
      normalFixtureToBody: [...hit.normalFixtureToBody]
    })),
    cloths: [],
    fluids: [],
    pairStats: { ...pairStats }
  };
}
function createPhysicsWorld(model, options) {
  const admitted = admitModel(model, options);
  if (admitted.domain || admitted.options.profile !== "rigid-persistent-box-v1" || admitted.bodies.length !== 2 || admitted.bodies.some((b2) => b2.shape.kind !== "box" || b2.sensor || b2.ccd) || admitted.joints.length) error("INVALID_CONFIG", "private STATE2 producer qualifies only the frozen two-box persistent profile");
  const dt = admitted.options.fixedStepSeconds;
  const stepLimit = MAX_STEPS;
  const gravity = [...admitted.model.gravityMps2];
  const useAabb = admitted.options.broadPhase === "aabb";
  const usePersistentBox = admitted.options.profile === "rigid-persistent-box-v1";
  let bodies = admitted.bodies;
  let joints = admitted.joints;
  let disjointHinges = admitted.disjointHinges;
  let modelCopy = admitted.model;
  let optionsCopy = admitted.options;
  const colliderIds = new Map(admitted.model.colliders.map((collider) => [collider.bodyId, collider.id]));
  const identity3 = {
    modelRevision: admitted.model.revision,
    modelDigest: digest(admitted.model),
    configurationDigest: digest(admitted.options),
    providerDigest: digest(providerManifest),
    profile: admitted.options.profile,
    frameId: admitted.model.frame.id,
    fixedStepSeconds: dt
  };
  let dynamicHinge = joints.find((joint) => joint.kind === "hinge" && bodies[joint.aIndex].kind === "dynamic");
  if (dynamicHinge && !disjointHinges) admitDynamicHingeScene(dynamicHinge, bodies, gravity);
  let ccd = admitCcd(bodies, joints.length, gravity);
  if (ccd.kind === "box-pair" && usePersistentBox) {
    error("INVALID_CONFIG", "box CCD excludes persistent-box-v1");
  }
  const disabledPairs = new Set(joints.map((joint) => [bodies[joint.aIndex].id, bodies[joint.bIndex].id].sort().join("\0")));
  const pairs = [];
  for (let a2 = 0; a2 < bodies.length; a2++) for (let b2 = a2 + 1; b2 < bodies.length; b2++) {
    if (bodies[a2].inverseMass !== 0 || bodies[b2].inverseMass !== 0) {
      if (disabledPairs.has([bodies[a2].id, bodies[b2].id].sort().join("\0"))) continue;
      pairs.push(bodies[a2].id < bodies[b2].id ? [a2, b2] : [b2, a2]);
    }
  }
  pairs.sort((left, right) => bodies[left[0]].id < bodies[right[0]].id ? -1 : bodies[left[0]].id > bodies[right[0]].id ? 1 : bodies[left[1]].id < bodies[right[1]].id ? -1 : 1);
  let contacts = [];
  let pairWrenches = [];
  let events = [];
  let ccdHits = [];
  let pairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
  let jointStates = joints.map((joint) => ({
    id: joint.id,
    kind: joint.kind,
    aId: bodies[joint.aIndex].id,
    bId: bodies[joint.bIndex].id,
    linearImpulseNs: [0, 0, 0],
    angularImpulseNms: [0, 0, 0],
    ...joint.kind === "hinge" ? { angleRad: 0 } : {},
    ...joint.motor ? { motorImpulseNms: 0 } : {}
  }));
  let activePairs = /* @__PURE__ */ new Map();
  let persistentPoints = /* @__PURE__ */ new Map();
  let sleepFrames = bodies.map(() => 0);
  let stepIndex = 0;
  const phaseContext = phaseWorld(() => ({ bodies: bodies.map(bodyWords), persistentPoints: [...persistentPoints], contacts: copyData(contacts), pairWrenches: copyData(pairWrenches), activePairs: [...activePairs], sleepFrames: [...sleepFrames], stepIndex }));
  let disposed = false;
  let owner = null;
  let advancingOwner = null;
  const ensureActive = () => {
    if (disposed) error("DISPOSED", "world is disposed");
  };
  contacts = phaseInitial(phaseContext, () => acceptedGeometry(bodies, pairs, colliderIds));
  activePairs = acceptedMembership(contacts);
  const world = {
    getModel() {
      ensureActive();
      return copyData(modelCopy);
    },
    getState() {
      ensureActive();
      return publicState(bodies, contacts, events, jointStates, ccdHits, pairStats, stepIndex, dt, identity3, colliderIds, pairWrenches);
    },
    step(commands = []) {
      ensureActive();
      if (owner !== advancingOwner) error("WORLD_OWNED", "World has an exclusive recorder");
      if (stepIndex >= stepLimit) error("WORLD_LIMIT", "world step limit reached");
      if (owner && (owner.recording.frames.length >= 512 || Array.isArray(commands) && owner.commandCount + commands.length > 4096)) {
        error("WORLD_LIMIT", "recording frame or command limit reached");
      }
      let admittedCommands;
      try {
        admittedCommands = copyData(commands);
      } catch (failure) {
        if (failure instanceof PhysicsError && failure.code === "INVALID_CONFIG") error("INVALID_COMMAND", failure.message);
        throw failure;
      }
      if (owner && Array.isArray(admittedCommands) && owner.commandCount + admittedCommands.length > 4096) {
        error("WORLD_LIMIT", "recording command limit reached");
      }
      const actions = parseCommands(admittedCommands, bodies);
      if (disjointHinges) admitDisjointHingeCommands(disjointHinges, bodies, actions, admittedCommands.length);
      else if (dynamicHinge) admitDynamicHingeCommands(dynamicHinge, bodies, actions);
      if (ccd.kind === "box-pair") rejectAngularBoxCommand(actions.get(bodies[ccd.boxIndex].id));
      const preparedFrames = owner ? owner.prepareFrames(admittedCommands, stepIndex + 1) : null;
      phaseBegin(phaseContext, stepIndex + 1, bodies);
      const next = bodies.map(copyBody);
      const motorImpulses = joints.map(() => 0);
      const nextSleepFrames = sleepFrames.slice();
      for (const body of next) {
        if (body.kind !== "dynamic") continue;
        const action = actions.get(body.id);
        body.angularVelocityRadps = add2(
          body.angularVelocityRadps,
          inverseInertia(body, action?.angularImpulseNms ?? [0, 0, 0])
        );
      }
      if (disjointHinges) driveDisjointHingeMotors(disjointHinges, next, jointStates, motorImpulses);
      else for (let index = 0; index < joints.length; index++) {
        const joint = joints[index];
        if (!joint.motor) continue;
        motorImpulses[index] = next[joint.aIndex].kind === "dynamic" ? driveDynamicHingeMotor(
          joint,
          next[joint.aIndex],
          next[joint.bIndex],
          jointStates[index].angleRad
        ) : driveHingeMotor(joint, next[joint.bIndex], jointStates[index].angleRad);
      }
      for (let bodyIndex = 0; bodyIndex < next.length; bodyIndex++) {
        const body = next[bodyIndex];
        const action = actions.get(body.id);
        if (body.kind === "kinematic") {
          const target = action?.positionM ?? body.positionM;
          const delta = target.map((value, index) => value - body.positionM[index]);
          if (Math.hypot(...delta) > MAX_STEP_DISPLACEMENT_M || delta.some((value) => Math.abs(value / dt) > 1e3)) {
            error("NUMERIC_LIMIT", `${body.id} exceeded kinematic movement limit`);
          }
          body.velocityMps = delta.map((value) => value / dt);
          body.positionM = [...target];
        } else if (body.kind === "dynamic") {
          if (body.angularVelocityRadps.some((value) => !Number.isFinite(value) || Math.abs(value) > 1e3) || Math.hypot(...body.angularVelocityRadps) * dt > 10) {
            error("NUMERIC_LIMIT", `${body.id} exceeded angular movement limit`);
          }
          const traceRotation = bodyWords(body);
          const preparedRotation = prepareForcedRotation(body, dt, action?.torqueNm ?? [0, 0, 0]) ?? prepareFreeRotation(body, dt) ?? {
            orientation: advanceOrientation(body.orientation, body.angularVelocityRadps, dt),
            angularVelocityRadps: [...body.angularVelocityRadps]
          };
          validateRotationResult(preparedRotation, dt);
          body.angularVelocityRadps = preparedRotation.angularVelocityRadps;
          body.orientation = preparedRotation.orientation;
          phaseBody("rotation", traceRotation, body);
          const traceKick = bodyWords(body);
          for (let i = 0; i < 3; i++) {
            body.velocityMps[i] += (action?.impulseNs?.[i] ?? 0) * body.inverseMass;
            body.velocityMps[i] += (gravity[i] + (action?.forceN?.[i] ?? 0) * body.inverseMass) * dt;
          }
          phaseBody("gravity-kick", traceKick, body, { gravity, dt });
          const traceDrift = bodyWords(body);
          if (Math.hypot(...body.velocityMps) * dt > MAX_STEP_DISPLACEMENT_M) {
            error("NUMERIC_LIMIT", `${body.id} exceeded step displacement limit`);
          }
          for (let i = 0; i < 3; i++) body.positionM[i] += body.velocityMps[i] * dt;
          phaseBody("drift", traceDrift, body, { dt });
        }
      }
      const hit = ccd.kind === "static-boxes" ? sweepSphere(bodies[ccd.sphereIndex], next[ccd.sphereIndex], ccd.fixtures) : ccd.kind === "sphere-pair" ? sweepSpherePair(
        bodies[ccd.sphereIndex],
        next[ccd.sphereIndex],
        bodies[ccd.otherIndex],
        next[ccd.otherIndex]
      ) : ccd.kind === "box-pair" ? sweepDynamicBox(
        bodies[ccd.boxIndex],
        next[ccd.boxIndex],
        next[ccd.fixtureIndex]
      ) : null;
      const nextCcdHits = hit ? [hit] : [];
      const nextPairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
      const found = /* @__PURE__ */ new Set();
      const stepPairWrenches = /* @__PURE__ */ new Map();
      const nextPersistentPoints = /* @__PURE__ */ new Map();
      const persistentNormalTargets = /* @__PURE__ */ new Map();
      const sensed = /* @__PURE__ */ new Map();
      const nextJoints = jointStates.map((joint, index) => ({
        ...joint,
        linearImpulseNs: [0, 0, 0],
        angularImpulseNms: [0, 0, 0],
        ...joint.motorImpulseNms === void 0 ? {} : { motorImpulseNms: motorImpulses[index] }
      }));
      const bounds = useAabb ? next.map(bodyBounds) : null;
      for (let pass = 0; pass < SOLVER_PASSES; pass++) {
        phasePass(pass);
        if (bounds && pass > 0) for (let index = 0; index < next.length; index++) {
          if (next[index].kind !== "static") bounds[index] = bodyBounds(next[index]);
        }
        for (const [aIndex, bIndex] of pairs) {
          nextPairStats.eligiblePairs++;
          if (bounds) {
            nextPairStats.aabbTests++;
            if (!boundsOverlap(bounds[aIndex], bounds[bIndex])) continue;
          }
          nextPairStats.candidatePairs++;
          const a2 = next[aIndex], b2 = next[bIndex];
          const hit2 = usePersistentBox && a2.shape.kind === "box" && b2.shape.kind === "box" ? phaseQuery(a2, b2) : detect(a2, b2);
          if (!hit2) continue;
          if (hit2.penetration > MAX_STEP_DISPLACEMENT_M) error("NUMERIC_LIMIT", "contact penetration exceeded limit");
          const key = `${a2.id}\0${b2.id}`;
          if (a2.sensor || b2.sensor) {
            sensed.set(key, { aId: a2.id, bId: b2.id, kind: "sensor" });
            continue;
          }
          found.add(key);
          const manifold = isPhaseHit(hit2) ? hit2._phase.result.points : usePersistentBox ? boxFaceManifold(a2, b2, hit2) : null;
          if (manifold) {
            const restitution = Math.min(a2.restitution, b2.restitution);
            for (const point2 of manifold) {
              const pointKey = `${key}\0${point2.id}`;
              if (persistentNormalTargets.has(pointKey)) continue;
              let target = 0;
              if (restitution !== 0) {
                const velocityA = add2(
                  a2.velocityMps,
                  cross4(a2.angularVelocityRadps, sub(point2.pointM, a2.positionM))
                );
                const velocityB = add2(
                  b2.velocityMps,
                  cross4(b2.angularVelocityRadps, sub(point2.pointM, b2.positionM))
                );
                const speed = dot3(hit2.normal, sub(velocityB, velocityA));
                if (-speed > 0.5) target = -speed * restitution;
              }
              persistentNormalTargets.set(pointKey, target);
            }
            for (const point2 of manifold) {
              const pointKey = `${key}\0${point2.id}`;
              let impulse = nextPersistentPoints.get(pointKey);
              if (!impulse) {
                const prior = persistentPoints.get(pointKey);
                impulse = prior ? { normalNs: prior.normalNs, tangentNs: [...prior.tangentNs] } : { normalNs: 0, tangentNs: [0, 0, 0] };
                nextPersistentPoints.set(pointKey, impulse);
                phaseCacheInit(pointKey, point2, hit2.normal, hit2, impulse, prior);
                if (prior) {
                  phasePoint(pointKey, point2, hit2.normal, hit2, impulse, -1, -1);
                  addPairContribution(stepPairWrenches, a2, b2, colliderIds, warmStartPoint(a2, b2, point2.pointM, hit2.normal, impulse));
                }
              }
            }
            for (let iteration = 0; iteration < 8; iteration++) {
              const order = iteration % 2 ? [...manifold].reverse() : manifold;
              for (const point2 of order) {
                const pointKey = `${key}\0${point2.id}`;
                const impulse = nextPersistentPoints.get(pointKey);
                phasePoint(pointKey, point2, hit2.normal, hit2, impulse, iteration, order.indexOf(point2));
                addPairContribution(stepPairWrenches, a2, b2, colliderIds, solvePersistentPoint(
                  a2,
                  b2,
                  point2.pointM,
                  hit2.normal,
                  impulse,
                  persistentNormalTargets.get(pointKey)
                ));
              }
            }
            correctPersistentPair(a2, b2, hit2.normal, hit2.penetration);
          } else {
            error("NUMERIC_LIMIT", "private producer forbids unconverted scalar contact path");
          }
          if (bounds) {
            bounds[aIndex] = bodyBounds(a2);
            bounds[bIndex] = bodyBounds(b2);
          }
        }
        if (!disjointHinges) for (let index = 0; index < joints.length; index++) {
          const reaction = projectJoint(joints[index], next, bodies, dt);
          nextJoints[index].linearImpulseNs = add2(nextJoints[index].linearImpulseNs, reaction.linearImpulseNs);
          nextJoints[index].angularImpulseNms = add2(nextJoints[index].angularImpulseNms, reaction.angularImpulseNms);
          if (reaction.angleRad !== void 0) nextJoints[index].angleRad = reaction.angleRad;
        }
      }
      if (disjointHinges) {
        if (found.size !== 0 || sensed.size !== 0) {
          error("NUMERIC_LIMIT", "disjoint hinge contact profile is unsupported");
        }
        applyDisjointHingePostContact(disjointHinges, next, nextJoints, motorImpulses, stepIndex, stepIndex * dt);
      }
      const nextContacts = acceptedGeometry(next, pairs, colliderIds);
      const nextPairWrenches = copyPairWrenches(stepPairWrenches);
      const nextActive = acceptedMembership(nextContacts);
      const nextEvents = [.../* @__PURE__ */ new Set([...activePairs.keys(), ...nextActive.keys()])].sort().map((key) => {
        const current = nextActive.get(key);
        const previous = activePairs.get(key);
        return { ...current ?? previous, phase: current ? previous ? "stay" : "begin" : "end" };
      });
      validateResult(next, []);
      if (ccd.kind === "box-pair" && !axisAlignedBox(next[ccd.boxIndex])) {
        error("NUMERIC_LIMIT", "box CCD contact rotated outside the admitted profile");
      }
      if (nextJoints.some((joint) => [...joint.linearImpulseNs, ...joint.angularImpulseNms].some((value) => !Number.isFinite(value)) || joint.angleRad !== void 0 && !Number.isFinite(joint.angleRad))) {
        error("NUMERIC_LIMIT", "unsafe joint reaction");
      }
      for (let index = 0; index < joints.length; index++) {
        const motor = joints[index].motor;
        if (motor && Math.hypot(...nextJoints[index].angularImpulseNms) > motor.maxReactionNms) {
          error("NUMERIC_LIMIT", `${joints[index].id} exceeded motor reaction limit`);
        }
      }
      const state = publicState(next, nextContacts, nextEvents, nextJoints, nextCcdHits, nextPairStats, stepIndex + 1, dt, identity3, colliderIds, nextPairWrenches);
      const preparedPhase = phasePrepare(phaseContext, nextPersistentPoints);
      const preparedRecording = owner ? owner.prepare(preparedFrames, state) : null;
      const preparedCommandCount = owner ? owner.commandCount + admittedCommands.length : 0;
      bodies = next;
      contacts = nextContacts;
      pairWrenches = nextPairWrenches;
      events = nextEvents;
      jointStates = nextJoints;
      ccdHits = nextCcdHits;
      pairStats = nextPairStats;
      activePairs = nextActive;
      persistentPoints = nextPersistentPoints;
      phaseContext.accepted = preparedPhase;
      sleepFrames = nextSleepFrames;
      stepIndex++;
      if (owner) {
        owner.recording = preparedRecording;
        owner.commandCount = preparedCommandCount;
      }
      return state;
    },
    query(input) {
      ensureActive();
      const data = queryRecord(input, ["kind", "includeSensors"], ["centerM", "radiusM", "originM", "direction", "maxDistanceM"]);
      const sensors = includeSensors(data);
      if (data.kind === "overlap-sphere") {
        const query3 = queryRecord(data, ["kind", "centerM", "radiusM", "includeSensors"], []);
        const center = queryVector(query3.centerM, 1e4, "centerM");
        const radius = queryNumber(query3.radiusM, 1e-4, 1e3, "radiusM");
        return { kind: "overlap-sphere", colliderIds: bodies.filter((body) => (sensors || !body.sensor) && sphereOverlaps(center, radius, body)).map((body) => body.id).sort().map((id) => colliderIds.get(id)) };
      }
      if (data.kind !== "raycast") error("INVALID_QUERY", "unsupported query kind");
      const query2 = queryRecord(data, ["kind", "originM", "direction", "maxDistanceM", "includeSensors"], []);
      const origin = queryVector(query2.originM, 1e4, "originM");
      const direction = queryVector(query2.direction, 1 + 1e-9, "direction");
      if (Math.abs(Math.hypot(...direction) - 1) > 1e-9) error("INVALID_QUERY", "direction must be a unit 3-vector");
      const limit = queryNumber(query2.maxDistanceM, 1e-4, 1e4, "maxDistanceM");
      let best = null;
      for (const body of bodies) {
        if (!sensors && body.sensor) continue;
        const distance = rayDistance(origin, direction, body);
        if (distance === null || distance > limit) continue;
        if (best === null || distance < best.distanceM || distance === best.distanceM && body.id < best.bodyId) best = { bodyId: body.id, distanceM: distance };
      }
      return { kind: "raycast", hit: best === null ? null : { ...best, colliderId: colliderIds.get(best.bodyId) } };
    },
    dispose() {
      disposed = true;
      if (owner) {
        owner.recording = null;
        owner.commandCount = 0;
        owner = null;
      }
      optionsCopy = null;
      advancingOwner = null;
      bodies = [];
      contacts = [];
      pairWrenches = [];
      events = [];
      ccdHits = [];
      activePairs.clear();
      persistentPoints.clear();
      sleepFrames = [];
      jointStates = [];
      joints = [];
      dynamicHinge = void 0;
      disjointHinges = null;
      ccd = { kind: "none" };
      pairs.length = 0;
      colliderIds.clear();
      modelCopy = null;
    }
  };
  let running = false;
  function guarded(operation, action) {
    if (disposed) throw new PhysicsError("DISPOSED", "world is disposed", {
      operation,
      phase: "lifecycle",
      domain: "world",
      entityIds: [],
      accepted: { stepIndex, timeSeconds: stepIndex * dt }
    });
    if (running) throw new PhysicsError("REENTRANT_CALL", "World call is reentrant", {
      operation,
      phase: "lifecycle",
      domain: "world",
      entityIds: [],
      accepted: { stepIndex, timeSeconds: stepIndex * dt }
    });
    running = true;
    try {
      return action();
    } catch (failure) {
      if (!(failure instanceof PhysicsError)) throw failure;
      const enriched = new PhysicsError(failure.code, failure.message, {
        operation,
        phase: ["DISPOSED", "WORLD_OWNED", "REENTRANT_CALL"].includes(failure.code) ? "lifecycle" : failure.code === "WORLD_LIMIT" ? "budget" : failure.code === "NUMERIC_LIMIT" ? "validation" : "admission",
        domain: "rigid",
        entityIds: failure.details.entityIds,
        accepted: { stepIndex, timeSeconds: stepIndex * dt }
      });
      enriched.stack = failure.stack;
      throw enriched;
    } finally {
      running = false;
    }
  }
  const getModel = world.getModel;
  const getState = world.getState;
  const step = world.step;
  const query = world.query;
  const dispose = world.dispose;
  world.getModel = () => guarded("read", getModel);
  world.getState = () => guarded("read", getState);
  world.step = (commands) => guarded("step", () => step(commands));
  world.query = (input) => guarded("query", () => query(input));
  world.dispose = () => {
    if (!disposed) guarded("read", dispose);
  };
  recordingWorlds.set(world, {
    attach: (prepare) => guarded("record", () => {
      if (owner) error("WORLD_OWNED", "World has an exclusive recorder");
      if (stepIndex !== 0) error("INVALID_SNAPSHOT", "recording must attach at step zero");
      const prepared = prepare({ model: copyData(modelCopy), options: copyData(optionsCopy), state: getState() });
      owner = prepared;
      return prepared;
    }),
    detach: (current) => {
      if (!disposed) guarded("record", () => {
        if (owner === current) owner = null;
        current.recording = null;
        current.commandCount = 0;
      });
    },
    read: (current) => guarded("record", () => {
      if (owner !== current) error("DISPOSED", "recorder is detached");
      return getState();
    }),
    step: (current, commands) => guarded("record", () => {
      if (owner !== current) error("DISPOSED", "recorder is detached");
      advancingOwner = current;
      try {
        return step(commands);
      } finally {
        advancingOwner = null;
      }
    })
  });
  return world;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-query/profile.ts
var PROFILE = "upright-capsule-box-v1";
var RADIUS_M = 0.15;
var HALF_LENGTH_M = 0.35;
var TIE_FRACTION = 1e-9;
var BOX_CAPACITY = 32;

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-query/admission.ts
function refuse3(code, message) {
  throw new PhysicsError(code, message);
}
function metadata(code, action) {
  try {
    return action();
  } catch {
    throw new PhysicsError(code, "Input reflection failed");
  }
}
function record3(value, keys, code) {
  if (!value || typeof value !== "object" || metadata(code, () => Object.getPrototypeOf(value)) !== Object.prototype) {
    refuse3(code, "Expected an ordinary record");
  }
  const own = metadata(code, () => Reflect.ownKeys(value));
  if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) {
    refuse3(code, "Unexpected record fields");
  }
  const copied = {};
  for (const key of keys) {
    const descriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, key));
    if (!descriptor || !("value" in descriptor)) refuse3(code, "Accessor fields are not admitted");
    copied[key] = descriptor.value;
  }
  return copied;
}
function dense2(value, limit, code, exact3) {
  if (!metadata(code, () => Array.isArray(value)) || metadata(code, () => Object.getPrototypeOf(value)) !== Array.prototype) {
    refuse3(code, "Expected an ordinary dense array");
  }
  const lengthDescriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, "length"));
  if (!lengthDescriptor || !("value" in lengthDescriptor)) refuse3(code, "Expected array length");
  const length = lengthDescriptor.value;
  if (typeof length !== "number" || !Number.isInteger(length) || length < 0 || length > limit || exact3 !== void 0 && length !== exact3 || metadata(code, () => Reflect.ownKeys(value)).length !== length + 1) {
    refuse3(code, "Invalid array length or fields");
  }
  const values = [];
  for (let index = 0; index < length; index++) {
    const descriptor = metadata(code, () => Object.getOwnPropertyDescriptor(value, String(index)));
    if (!descriptor || !("value" in descriptor)) refuse3(code, "Sparse or accessor array");
    values.push(descriptor.value);
  }
  return values;
}
function tuple(value, count, bound, code) {
  return dense2(value, count, code, count).map((component) => {
    if (typeof component !== "number" || !Number.isFinite(component) || Math.abs(component) > bound) {
      refuse3(code, "Invalid tuple component");
    }
    return component;
  });
}
function identity(value, code) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_][A-Za-z0-9_.:-]{0,63}$/.test(value)) {
    refuse3(code, "Invalid identity");
  }
  return value;
}
function admitScene(input) {
  const scene = record3(input, ["version", "profile", "revision", "boxes"], "INVALID_CONFIG");
  if (scene.version !== 1 || scene.profile !== PROFILE) refuse3("INVALID_CONFIG", "Unsupported capsule query profile");
  const revision = identity(scene.revision, "INVALID_CONFIG");
  const boxes = dense2(scene.boxes, BOX_CAPACITY, "INVALID_CONFIG").map((value) => {
    const box3 = record3(value, ["id", "centerM", "halfExtentsM", "orientationXYZW"], "INVALID_CONFIG");
    const id = identity(box3.id, "INVALID_CONFIG");
    const centerM = tuple(box3.centerM, 3, 10, "INVALID_CONFIG");
    const halfExtentsM = tuple(box3.halfExtentsM, 3, 5, "INVALID_CONFIG");
    const orientationXYZW = tuple(box3.orientationXYZW, 4, 1, "INVALID_CONFIG");
    if (halfExtentsM.some((value2) => value2 < 1e-4) || Math.abs(Math.hypot(...orientationXYZW) - 1) > 1e-12) {
      refuse3("INVALID_CONFIG", "Invalid box extents or quaternion");
    }
    return { id, centerM, halfExtentsM, orientationXYZW };
  });
  if (new Set(boxes.map((box3) => box3.id)).size !== boxes.length) refuse3("INVALID_CONFIG", "Duplicate box ID");
  return { version: 1, profile: PROFILE, revision, boxes };
}
function admitSweep(input, scene) {
  const query = record3(input, ["revision", "centerM", "displacementM", "excludeId"], "INVALID_QUERY");
  const revision = identity(query.revision, "INVALID_QUERY");
  const centerM = tuple(query.centerM, 3, 5, "INVALID_QUERY");
  const displacementM = tuple(query.displacementM, 3, 2, "INVALID_QUERY");
  if (Math.hypot(...displacementM) > 2) refuse3("INVALID_QUERY", "Displacement exceeds 2 metres");
  const excludeId = query.excludeId === null ? null : identity(query.excludeId, "INVALID_QUERY");
  if (revision !== scene.revision) throw new PhysicsError("STALE_SNAPSHOT", "Revision mismatch");
  if (excludeId !== null && !scene.boxes.some((box3) => box3.id === excludeId)) refuse3("INVALID_QUERY", "Unknown excluded ID");
  return { revision, centerM, displacementM, excludeId };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-query/geometry.ts
function matrix2(q3) {
  const [x, y, z, w] = q3, factor = 2 / (x * x + y * y + z * z + w * w);
  return [
    [1 - factor * (y * y + z * z), factor * (x * y - z * w), factor * (x * z + y * w)],
    [factor * (x * y + z * w), 1 - factor * (x * x + z * z), factor * (y * z - x * w)],
    [factor * (x * z - y * w), factor * (y * z + x * w), 1 - factor * (x * x + y * y)]
  ];
}
var dot5 = (a2, b2) => a2[0] * b2[0] + a2[1] * b2[1] + a2[2] * b2[2];
function closestCandidate(center, box3) {
  const m = matrix2(box3.orientationXYZW), h = box3.halfExtentsM;
  const toLocal = (p) => [0, 1, 2].map((j) => m[0][j] * (p[0] - box3.centerM[0]) + m[1][j] * (p[1] - box3.centerM[1]) + m[2][j] * (p[2] - box3.centerM[2]));
  const toWorld = (p) => m.map((row, i) => dot5(row, p) + box3.centerM[i]);
  const a2 = toLocal([center[0], center[1] - HALF_LENGTH_M, center[2]]);
  const b2 = toLocal([center[0], center[1] + HALF_LENGTH_M, center[2]]);
  const d = b2.map((value, i) => value - a2[i]);
  function squared(t) {
    let sum = 0;
    for (let i = 0; i < 3; i++) {
      const delta = Math.max(0, Math.abs(a2[i] + t * d[i]) - h[i]);
      sum += delta * delta;
    }
    return sum;
  }
  let lo = 0, hi = 1;
  for (let pass = 0; pass < 100; pass++) {
    const t1 = (2 * lo + hi) / 3, t2 = (lo + 2 * hi) / 3;
    if (squared(t1) <= squared(t2)) hi = t2;
    else lo = t1;
  }
  let u = 0, best = squared(0);
  for (const t of [1, (lo + hi) / 2]) {
    const value = squared(t);
    if (value < best) {
      best = value;
      u = t;
    }
  }
  const segmentLocal = a2.map((value, i) => value + u * d[i]);
  const pointLocal = segmentLocal.map((value, i) => Math.max(-h[i], Math.min(h[i], value)));
  const difference = segmentLocal.map((value, i) => value - pointLocal[i]);
  const distanceM = Math.sqrt(best);
  const normalM = distanceM > 0 ? m.map((row) => dot5(row, difference) / distanceM) : null;
  return { distanceM, normalM, pointM: toWorld(pointLocal), segmentM: toWorld(segmentLocal) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-query/sweep.ts
function sweepBox2(center, displacement, box3) {
  let fraction = 0;
  for (let iteration = 0; iteration < 64; iteration++) {
    const at = center.map((value, i) => value + fraction * displacement[i]);
    const closest = closestCandidate(at, box3), gap = closest.distanceM - RADIUS_M;
    if (!Number.isFinite(gap)) throw new PhysicsError("NUMERIC_LIMIT", "Nonfinite distance");
    if (iteration === 0 && gap < -1e-12) throw new PhysicsError("INITIAL_OVERLAP", "Initial capsule overlaps a box");
    if (!closest.normalM) throw new PhysicsError("NUMERIC_LIMIT", "No distance normal");
    if (iteration === 0 && Math.abs(gap) <= 1e-12 || gap <= 1e-14) {
      if (gap < -1e-12) throw new PhysicsError("NUMERIC_LIMIT", "Advancement crossed contact");
      return {
        bodyId: box3.id,
        toiFraction: fraction,
        normalFixtureToCapsule: closest.normalM.slice(),
        pointM: closest.pointM.slice(),
        segmentPointM: closest.segmentM.slice(),
        iterations: iteration + 1
      };
    }
    const closing = -dot5(closest.normalM, displacement);
    if (closing <= 0) return null;
    const next = fraction + gap / closing;
    if (!Number.isFinite(next)) throw new PhysicsError("NUMERIC_LIMIT", "Nonfinite advancement");
    if (next > 1) return null;
    if (next <= fraction) throw new PhysicsError("ITERATION_LIMIT", "Advancement cannot make progress");
    fraction = next;
  }
  throw new PhysicsError("ITERATION_LIMIT", "Fixed advancement cap exhausted");
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/capsule-query/snapshot.ts
function copyBox(box3) {
  return { id: box3.id, centerM: [...box3.centerM], halfExtentsM: [...box3.halfExtentsM], orientationXYZW: [...box3.orientationXYZW] };
}
function geometryKey(box3) {
  const values = [...box3.centerM, ...box3.halfExtentsM, ...box3.orientationXYZW];
  const bytes = new Uint8Array(80), view = new DataView(bytes.buffer);
  values.forEach((value, index) => view.setFloat64(index * 8, value, true));
  return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
}
function groupBoxes(boxes) {
  const groups = /* @__PURE__ */ new Map();
  for (const box3 of boxes) {
    const key = geometryKey(box3), group = groups.get(key);
    if (group) group.ids.push(box3.id);
    else groups.set(key, { representative: copyBox(box3), ids: [box3.id] });
  }
  return Array.from(groups.values());
}
function createUprightCapsuleQuery(input) {
  const scene = admitScene(input), groups = groupBoxes(scene.boxes);
  let disposed = false;
  function live() {
    if (disposed) throw new PhysicsError("DISPOSED", "Capsule query is disposed");
  }
  return {
    sweep(input2) {
      live();
      const query = admitSweep(input2, scene), hits = [];
      for (const group of groups) {
        let selectedId = null;
        for (const id of group.ids) if (id !== query.excludeId && (selectedId === null || id < selectedId)) selectedId = id;
        if (selectedId === null) continue;
        const hit = sweepBox2(query.centerM, query.displacementM, group.representative);
        if (hit) hits.push({ ...hit, bodyId: selectedId });
      }
      if (!hits.length) return null;
      const minimum = Math.min(...hits.map((hit) => hit.toiFraction));
      return hits.filter((hit) => hit.toiFraction <= minimum + TIE_FRACTION).sort((a2, b2) => a2.bodyId < b2.bodyId ? -1 : a2.bodyId > b2.bodyId ? 1 : 0)[0];
    },
    getSnapshot() {
      live();
      return { version: 1, profile: scene.profile, revision: scene.revision, boxes: scene.boxes.map(copyBox) };
    },
    dispose() {
      disposed = true;
    }
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/profile.ts
var PROFILE2 = "upright-capsule-controller-v1";
var DT = 1 / 120;
var STEPS = 240;
var GRAVITY = -9.81;
var SKIN = 2e-3;
var SNAP = 0.02;
var STEP_HEIGHT = 0.1;
var PREVIEW = 0.152;
var STEP_DOWN = 0.12;
var ASSIST_CAP = 20;
var SLIDE_CAP = 4;
var QUERY_CAP = 32;
var LOOKAHEAD = 0.02;
var WALKABLE = Math.cos(10 * Math.PI / 180);

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/admission.ts
function refuse4(code, message) {
  throw new PhysicsError(code, message);
}
function metadata2(code, action) {
  try {
    return action();
  } catch {
    throw new PhysicsError(code, "Controller input reflection failed");
  }
}
function record4(value, keys, code) {
  if (!value || typeof value !== "object" || metadata2(code, () => Object.getPrototypeOf(value)) !== Object.prototype) {
    refuse4(code, "Expected an ordinary controller record");
  }
  const own = metadata2(code, () => Reflect.ownKeys(value));
  if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) {
    refuse4(code, "Unexpected controller fields");
  }
  const copy = {};
  for (const key of keys) {
    const descriptor = metadata2(code, () => Object.getOwnPropertyDescriptor(value, key));
    if (!descriptor || !("value" in descriptor)) refuse4(code, "Controller accessors are not admitted");
    copy[key] = descriptor.value;
  }
  return copy;
}
function tuple2(value, bound, code) {
  if (!metadata2(code, () => Array.isArray(value)) || metadata2(code, () => Object.getPrototypeOf(value)) !== Array.prototype) {
    refuse4(code, "Expected an ordinary controller tuple");
  }
  const length = metadata2(code, () => Object.getOwnPropertyDescriptor(value, "length"));
  if (!length || !("value" in length) || length.value !== 3 || metadata2(code, () => Reflect.ownKeys(value)).length !== 4) {
    refuse4(code, "Invalid controller tuple length or fields");
  }
  const copy = [];
  for (let index = 0; index < 3; index++) {
    const descriptor = metadata2(code, () => Object.getOwnPropertyDescriptor(value, String(index)));
    if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "number" || !Number.isFinite(descriptor.value) || Math.abs(descriptor.value) > bound) {
      refuse4(code, "Invalid controller tuple component");
    }
    copy.push(descriptor.value);
  }
  return copy;
}
function admitConfig(input) {
  const config = record4(input, ["version", "profile", "scene", "positionM"], "INVALID_CONFIG");
  if (config.version !== 1 || config.profile !== PROFILE2) refuse4("INVALID_CONFIG", "Unsupported controller profile");
  const positionM = tuple2(config.positionM, 5, "INVALID_CONFIG");
  return { scene: config.scene, positionM };
}
function admitCommand(input) {
  const command = record4(input, ["dtSeconds", "sceneRevision", "desiredVelocityMps"], "INVALID_COMMAND");
  if (typeof command.dtSeconds !== "number" || !Number.isFinite(command.dtSeconds)) refuse4("INVALID_COMMAND", "Invalid controller time");
  if (typeof command.sceneRevision !== "string" || !/^[A-Za-z0-9_][A-Za-z0-9_.:-]{0,63}$/.test(command.sceneRevision)) {
    refuse4("INVALID_COMMAND", "Invalid controller revision");
  }
  const desiredVelocityMps = tuple2(command.desiredVelocityMps, 1, "INVALID_COMMAND");
  if (desiredVelocityMps[1] !== 0 || Math.hypot(desiredVelocityMps[0], desiredVelocityMps[2]) > 1) {
    refuse4("INVALID_COMMAND", "Controller horizontal request exceeds its bound");
  }
  return { dtSeconds: command.dtSeconds, sceneRevision: command.sceneRevision, desiredVelocityMps };
}
function admitCoreCommand(dt, velocity, revision, stateRevision, stepIndex) {
  const command = admitCommand({ dtSeconds: dt, sceneRevision: revision, desiredVelocityMps: velocity });
  if (command.dtSeconds !== DT) throw new PhysicsError("INVALID_STEP", "Controller requires exactly 1/120 second");
  if (command.sceneRevision !== stateRevision) throw new PhysicsError("STALE_SNAPSHOT", "Controller revision mismatch");
  if (stepIndex >= STEPS) throw new PhysicsError("WORLD_LIMIT", "Controller step limit exhausted");
  return command.desiredVelocityMps;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/math.ts
var dot6 = (a2, b2) => a2.reduce((sum, value, index) => sum + value * b2[index], 0);
var add3 = (a2, b2) => a2.map((value, index) => value + b2[index]);
var scale3 = (a2, factor) => a2.map((value) => value * factor);
var norm = (a2) => Math.hypot(...a2);
function clone2(value) {
  if (Array.isArray(value)) return value.map((item) => clone2(item));
  if (value !== null && typeof value === "object") {
    const result = {};
    for (const key of Object.keys(value)) result[key] = clone2(value[key]);
    return result;
  }
  return value;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/state.ts
function initialState(positionM, sceneRevision) {
  return {
    stepIndex: 0,
    timeSeconds: 0,
    positionM: [...positionM],
    velocityMps: [0, 0, 0],
    fallVelocityYMps: 0,
    orientationXYZW: [0, 0, 0, 1],
    grounded: false,
    support: null,
    blocked: false,
    assist: null,
    sceneRevision,
    queryCount: 0,
    lastQueries: [],
    lastSegments: [],
    gravityPrediction: null
  };
}
function projectState(state) {
  return {
    version: 1,
    profile: PROFILE2,
    sceneRevision: state.sceneRevision,
    stepIndex: state.stepIndex,
    timeSeconds: state.timeSeconds,
    positionM: [...state.positionM],
    velocityMps: [...state.velocityMps],
    orientationXYZW: [...state.orientationXYZW],
    fallVelocityYMps: state.fallVelocityYMps,
    grounded: state.grounded,
    support: clone2(state.support),
    blocked: state.blocked,
    assist: clone2(state.assist),
    queryCount: state.queryCount
  };
}
function validateState(position, velocity, request, previous) {
  if (position.some((value) => !Number.isFinite(value) || Math.abs(value) > 5) || velocity.some((value) => !Number.isFinite(value)) || norm(velocity) > 20) {
    throw new PhysicsError("NUMERIC_LIMIT", "Controller state exceeds its bound");
  }
  const actual = position.map((value, index) => value - previous.positionM[index]);
  const horizontal = Math.hypot(actual[0], actual[2]), allowed = Math.hypot(request[0], request[2]) * DT;
  if (horizontal > allowed + 1e-9 || Math.abs(actual[1]) > 0.1 + 1e-6) {
    throw new PhysicsError("NUMERIC_LIMIT", "Controller movement exceeds its bound");
  }
}
function errorRecord(error2) {
  const value = error2;
  return { name: value.name ?? "Error", code: value.code, message: value.message ?? String(error2) };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/query.ts
function queryContext(query, candidate, diagnostic, capture) {
  function raw(position, delta, kind, preview, excludeId = null) {
    if (candidate.queryCount >= (diagnostic.queryBudget ?? QUERY_CAP)) {
      throw new PhysicsError("WORLD_LIMIT", "Controller per-step query limit exhausted");
    }
    const input = {
      revision: candidate.sceneRevision,
      centerM: [...position],
      displacementM: [...delta],
      excludeId
    };
    const index = candidate.queryCount;
    candidate.queryCount++;
    let hit;
    try {
      hit = query.sweep(input);
    } catch (error2) {
      if (capture) candidate.lastQueries.push({ kind, preview, input: clone2(input), hit: null, error: errorRecord(error2) });
      throw error2;
    }
    if (capture) candidate.lastQueries.push({ kind, preview, input: clone2(input), hit: clone2(hit), error: null });
    return { hit, indices: [index] };
  }
  function sweep(position, delta, kind, preview = false) {
    const first = raw(position, delta, kind, preview);
    if (first.hit?.toiFraction === 0 && dot6(first.hit.normalFixtureToCapsule, delta) >= -1e-12) {
      const second = raw(position, delta, kind + "-fresh-touch-departure", preview, first.hit.bodyId);
      if (second.hit?.toiFraction === 0) throw new PhysicsError("INVALID_COMMAND", "Controller second fresh touch is unresolved");
      return { hit: second.hit, indices: [...first.indices, ...second.indices] };
    }
    return first;
  }
  function commit(position, delta, kind, indices) {
    const target = position.map((value, index) => value + delta[index]);
    if (capture) candidate.lastSegments.push({
      kind,
      fromM: [...position],
      displacementM: [...delta],
      toM: [...target],
      queryIndices: [...indices]
    });
    return target;
  }
  return { sweep, commit };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/step-assist.ts
function tryStep(position, remaining, candidate, context) {
  const horizontal = [remaining[0], 0, remaining[2]], length = norm(horizontal);
  if (length <= 1e-12 || !candidate.grounded) return null;
  const direction = scale3(horizontal, 1 / length);
  const up = context.sweep(position, [0, STEP_HEIGHT, 0], "step-up-probe", true);
  if (up.hit) return null;
  const raised = add3(position, [0, STEP_HEIGHT, 0]);
  const forward = context.sweep(raised, scale3(direction, PREVIEW), "step-ahead-probe", true);
  if (forward.hit) return null;
  const preview = add3(raised, scale3(direction, PREVIEW));
  const down = context.sweep(preview, [0, -STEP_DOWN, 0], "step-down-probe", true);
  if (!down.hit || down.hit.normalFixtureToCapsule[1] < WALKABLE) return null;
  const targetY = raised[1] - STEP_DOWN * down.hit.toiFraction + SKIN / down.hit.normalFixtureToCapsule[1];
  const rise = targetY - position[1];
  if (rise <= 1e-9 || rise > STEP_HEIGHT + 1e-6) return null;
  const actualRaised = add3(position, [0, rise, 0]);
  const actual = context.sweep(actualRaised, horizontal, "step-actual-forward", false);
  if (actual.hit) return null;
  let moved = context.commit(position, [0, rise, 0], "step-up", up.indices);
  moved = context.commit(moved, horizontal, "step-forward", actual.indices);
  candidate.assist = { bodyId: down.hit.bodyId, heightM: targetY, directionXZ: [direction[0], direction[2]], frames: 0 };
  candidate.fallVelocityYMps = 0;
  candidate.grounded = false;
  candidate.support = null;
  return moved;
}
function validateAssist(position, candidate, context, diagnostic) {
  if (!candidate.assist) return;
  const direction = [candidate.assist.directionXZ[0], 0, candidate.assist.directionXZ[1]];
  const ahead = context.sweep(position, scale3(direction, PREVIEW), "assist-ahead", true);
  if (ahead.hit) throw new PhysicsError("INVALID_COMMAND", "Controller assist forward path is blocked");
  const down = context.sweep(add3(position, scale3(direction, PREVIEW)), [0, -STEP_DOWN, 0], "assist-support", true);
  const hit = down.hit;
  const target = hit ? position[1] - STEP_DOWN * hit.toiFraction + SKIN / hit.normalFixtureToCapsule[1] : NaN;
  if (!hit || hit.normalFixtureToCapsule[1] < WALKABLE || hit.bodyId !== candidate.assist.bodyId || Math.abs(target - candidate.assist.heightM) > 1e-6) {
    throw new PhysicsError("INVALID_COMMAND", "Controller assist support is unresolved");
  }
  candidate.assist.frames++;
  if (candidate.assist.frames > (diagnostic.assistCap ?? ASSIST_CAP)) {
    throw new PhysicsError("WORLD_LIMIT", "Controller assist duration limit exhausted");
  }
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/slide.ts
function move(position, delta, candidate, context, diagnostic) {
  let p = [...position], remaining = [...delta];
  for (let pass = 0; pass < (diagnostic.slideBudget ?? SLIDE_CAP); pass++) {
    if (norm(remaining) <= 1e-12) return p;
    const length = norm(remaining), direction = scale3(remaining, 1 / length), probeLength = length + LOOKAHEAD;
    const result = context.sweep(p, scale3(direction, probeLength), "slide-lookahead", true), hit = result.hit;
    if (!hit) return context.commit(p, remaining, "travel", result.indices);
    const normal = hit.normalFixtureToCapsule, closingUnit = -dot6(normal, direction);
    if (closingUnit <= 1e-12) throw new PhysicsError("INVALID_COMMAND", "Controller lookahead closing normal is unresolved");
    const contactDistance = probeLength * hit.toiFraction;
    const safeDistance = Math.max(0, contactDistance - SKIN / closingUnit);
    const fraction = Math.min(1, safeDistance / length);
    const travel = scale3(remaining, fraction);
    if (norm(travel) > 0) p = context.commit(p, travel, "travel", result.indices);
    if (fraction === 1) return p;
    remaining = scale3(remaining, 1 - fraction);
    if (normal[1] < WALKABLE) {
      const stepped = tryStep(p, remaining, candidate, context);
      if (stepped) return stepped;
      candidate.blocked = true;
      const horizontalNormal = [normal[0], 0, normal[2]], size = norm(horizontalNormal);
      if (size > 1e-12) {
        const unit = scale3(horizontalNormal, 1 / size), into = dot6(remaining, unit);
        if (into < 0) remaining = add3(remaining, scale3(unit, -into));
      }
      if (normal[1] > 1e-12 && remaining[1] < 0) {
        remaining[1] = 0;
        candidate.fallVelocityYMps = 0;
      } else if (normal[1] < -1e-12 && remaining[1] > 0) remaining[1] = 0;
    } else {
      const into = dot6(remaining, normal);
      if (into < 0) remaining = add3(remaining, scale3(normal, -into));
      candidate.fallVelocityYMps = 0;
    }
  }
  if (norm(remaining) > 1e-12) throw new PhysicsError("WORLD_LIMIT", "Controller slide limit exhausted");
  return p;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/ground.ts
function snap(position, candidate, context) {
  const down = context.sweep(position, [0, -SNAP, 0], "ground-probe", true), hit = down.hit;
  if (!hit || hit.normalFixtureToCapsule[1] < WALKABLE) {
    candidate.grounded = false;
    candidate.support = null;
    return position;
  }
  const targetY = position[1] - SNAP * hit.toiFraction + SKIN / hit.normalFixtureToCapsule[1];
  const delta = [0, targetY - position[1], 0];
  let proof = down.indices;
  if (delta[1] > 0) {
    const up = context.sweep(position, delta, "positive-snap-validation");
    if (up.hit) throw new PhysicsError("INVALID_COMMAND", "Controller positive snap is blocked");
    proof = up.indices;
  }
  const p = context.commit(position, delta, "ground-snap", proof);
  candidate.grounded = true;
  candidate.support = { bodyId: hit.bodyId, normal: [...hit.normalFixtureToCapsule] };
  candidate.fallVelocityYMps = 0;
  candidate.assist = null;
  return p;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character/core.ts
function createCharacterCore(scene, positionM, diagnostic = {}, options = {}) {
  const admitted = admitConfig({ version: 1, profile: PROFILE2, scene, positionM });
  const query = createUprightCapsuleQuery(admitted.scene);
  let state;
  try {
    const snapshot = query.getSnapshot();
    query.sweep({ revision: snapshot.revision, centerM: [...admitted.positionM], displacementM: [0, 0, 0], excludeId: null });
    state = initialState(admitted.positionM, snapshot.revision);
  } catch (error2) {
    query.dispose();
    throw error2;
  }
  const capture = options.capture ?? true;
  let lastRejected = null, disposed = false;
  function live() {
    if (disposed) throw new PhysicsError("DISPOSED", "Capsule controller is disposed");
  }
  return {
    getState() {
      live();
      return clone2(state);
    },
    getLastRejected() {
      return clone2(lastRejected);
    },
    step(dt, velocity, revision = state.sceneRevision) {
      live();
      let attempted = null;
      try {
        const request = admitCoreCommand(dt, velocity, revision, state.sceneRevision, state.stepIndex);
        const next = clone2(state);
        attempted = next;
        next.queryCount = 0;
        next.lastQueries = [];
        next.lastSegments = [];
        next.blocked = false;
        const assisted = !!state.assist, speed = Math.hypot(request[0], request[2]);
        if (assisted && (speed === 0 || Math.abs(request[0] / speed - state.assist.directionXZ[0]) > 1e-12 || Math.abs(request[2] / speed - state.assist.directionXZ[1]) > 1e-12)) {
          throw new PhysicsError("INVALID_COMMAND", "Controller assist request changed");
        }
        const predicted = state.grounded || assisted ? 0 : state.fallVelocityYMps + GRAVITY * DT;
        next.fallVelocityYMps = predicted;
        next.gravityPrediction = capture ? {
          previousFallVelocityYMps: state.fallVelocityYMps,
          previousGrounded: state.grounded,
          previousAssisted: assisted,
          predictedFallVelocityYMps: predicted,
          predictedDeltaYM: predicted * DT
        } : null;
        const context = queryContext(query, next, diagnostic, capture);
        const delta = [request[0] * DT, predicted * DT, request[2] * DT];
        let p = move(state.positionM, delta, next, context, diagnostic);
        p = snap(p, next, context);
        validateAssist(p, next, context, diagnostic);
        if (diagnostic.numericFault) throw new PhysicsError("NUMERIC_LIMIT", "Internal controller numeric fault");
        const actualVelocity = p.map((value, index) => (value - state.positionM[index]) / DT);
        validateState(p, actualVelocity, request, state);
        next.positionM = p;
        next.velocityMps = actualVelocity;
        next.stepIndex++;
        next.timeSeconds = next.stepIndex * DT;
        state = next;
        lastRejected = null;
        return clone2(state);
      } catch (error2) {
        if (capture) lastRejected = { acceptedState: clone2(state), attemptedState: clone2(attempted), error: errorRecord(error2) };
        throw error2;
      }
    },
    dispose() {
      if (!disposed) {
        disposed = true;
        query.dispose();
      }
    }
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/character-controller.ts
function createUprightCapsuleController(config) {
  const admitted = admitConfig(config);
  const core = createCharacterCore(admitted.scene, admitted.positionM, {}, { capture: false });
  let disposed = false;
  function live() {
    if (disposed) throw new PhysicsError("DISPOSED", "Capsule controller is disposed");
  }
  return {
    getSnapshot() {
      live();
      return projectState(core.getState());
    },
    step(input) {
      live();
      const command = admitCommand(input);
      return projectState(core.step(command.dtSeconds, command.desiredVelocityMps, command.sceneRevision));
    },
    dispose() {
      if (!disposed) {
        disposed = true;
        core.dispose();
      }
    }
  };
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/replay-json.ts
function replayError(code, message) {
  throw new PhysicsError(code, message);
}
function copyValue(input, label, depth, budget) {
  if (++budget.nodes > 5e4 || depth > 32) replayError("INVALID_SNAPSHOT", `${label} exceeds JSON depth or size`);
  budget.bytes += input === null || typeof input === "boolean" ? 1 : typeof input === "number" ? 9 : 5;
  if (budget.bytes + 8 > MAX_RECORDING_BYTES) replayError("INVALID_SNAPSHOT", `${label} exceeds byte limit`);
  if (input === null || typeof input === "boolean") return input;
  if (typeof input === "string") {
    for (const character of input) {
      const point2 = character.codePointAt(0);
      budget.bytes += point2 < 128 ? 1 : point2 < 2048 ? 2 : point2 < 65536 ? 3 : 4;
      if (point2 >= 55296 && point2 <= 57343) replayError("INVALID_SNAPSHOT", `${label} contains malformed Unicode`);
    }
    if (budget.bytes + 8 > MAX_RECORDING_BYTES) replayError("INVALID_SNAPSHOT", `${label} string exceeds byte limit`);
    return input;
  }
  if (typeof input === "number") {
    if (!Number.isFinite(input)) replayError("INVALID_SNAPSHOT", `${label} contains a nonfinite number`);
    return input;
  }
  if (typeof input !== "object" || Object.getPrototypeOf(input) !== (Array.isArray(input) ? Array.prototype : Object.prototype)) {
    replayError("INVALID_SNAPSHOT", `${label} must be plain JSON-compatible data`);
  }
  if (budget.seen.has(input)) replayError("INVALID_SNAPSHOT", `${label} has a cycle`);
  budget.seen.add(input);
  let output;
  if (Array.isArray(input)) {
    if (input.length > 4096 || Reflect.ownKeys(input).length !== input.length + 1) {
      replayError("INVALID_SNAPSHOT", `${label} must be a bounded dense array`);
    }
    const copied = [];
    for (let index = 0; index < input.length; index++) {
      const field2 = Object.getOwnPropertyDescriptor(input, String(index));
      if (!field2?.enumerable || !("value" in field2)) replayError("INVALID_SNAPSHOT", `${label}[${index}] must be data`);
      copied.push(copyValue(field2.value, `${label}[${index}]`, depth + 1, budget));
    }
    output = copied;
  } else {
    const keys = Reflect.ownKeys(input);
    if (keys.length > 64 || keys.some((key) => typeof key !== "string" || !/^[\x20-\x7e]+$/.test(key))) {
      replayError("INVALID_SNAPSHOT", `${label} has unsupported fields`);
    }
    budget.nodes += keys.length;
    budget.bytes += keys.reduce((total, key) => total + 5 + key.length, 0);
    if (budget.nodes > 5e4 || budget.bytes + 8 > MAX_RECORDING_BYTES) replayError("INVALID_SNAPSHOT", `${label} exceeds size limit`);
    const copied = {};
    for (const key of keys) {
      const field2 = Object.getOwnPropertyDescriptor(input, key);
      if (!field2?.enumerable || !("value" in field2)) replayError("INVALID_SNAPSHOT", `${label}.${key} must be data`);
      Object.defineProperty(copied, key, { value: copyValue(field2.value, `${label}.${key}`, depth + 1, budget), enumerable: true, writable: true, configurable: true });
    }
    output = copied;
  }
  budget.seen.delete(input);
  return output;
}
function copyReplayJson(input, label) {
  return copyValue(input, label, 0, { nodes: 0, bytes: 0, seen: /* @__PURE__ */ new Set() });
}
function exactFields2(value, fields3, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Reflect.ownKeys(value).length !== fields3.length || Reflect.ownKeys(value).some((key) => typeof key !== "string" || !fields3.includes(key))) {
    replayError("INVALID_SNAPSHOT", `${label} has missing or unsupported fields`);
  }
}
function equivalentReplayIdentity(left, right) {
  const a2 = canonicalEncode(left), b2 = canonicalEncode(right);
  return a2.length === b2.length && a2.every((byte, index) => byte === b2[index]);
}
var RECORDING_MAGIC = Uint8Array.of(66, 67, 80, 72, 82, 69, 67, 50);
var MAX_RECORDING_BYTES = 1024 * 1024;
function encodeRecordingData(input) {
  const data = canonicalEncode(copyReplayJson(input, "recording"));
  if (data.length + RECORDING_MAGIC.length > MAX_RECORDING_BYTES) replayError("INVALID_SNAPSHOT", "recording exceeds byte limit");
  const bytes = new Uint8Array(data.length + RECORDING_MAGIC.length);
  bytes.set(RECORDING_MAGIC);
  bytes.set(data, RECORDING_MAGIC.length);
  return bytes;
}
function decodeRecordingData(input) {
  if (!(input instanceof Uint8Array) || input.length > MAX_RECORDING_BYTES || input.length <= RECORDING_MAGIC.length || !RECORDING_MAGIC.every((byte, index) => input[index] === byte)) {
    replayError("INVALID_SNAPSHOT", "unsupported recording wire format or byte limit");
  }
  const bytes = Uint8Array.from(input);
  const view = new DataView(bytes.buffer);
  const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
  let offset = RECORDING_MAGIC.length, nodes = 0;
  function take(length) {
    if (length > bytes.length - offset) replayError("INVALID_SNAPSHOT", "truncated recording");
    const start = offset;
    offset += length;
    return start;
  }
  function uint32() {
    return view.getUint32(take(4), true);
  }
  function read(depth) {
    if (++nodes > 5e4 || depth > 32) replayError("INVALID_SNAPSHOT", "recording exceeds node or depth limit");
    const tag = bytes[take(1)];
    if (tag === 0) return null;
    if (tag === 1 || tag === 2) return tag === 2;
    if (tag === 3) {
      const length = uint32(), start = take(length);
      return decoder.decode(bytes.subarray(start, start + length));
    }
    if (tag === 4) {
      const value = view.getFloat64(take(8), true);
      if (!Number.isFinite(value)) replayError("INVALID_SNAPSHOT", "recording contains nonfinite number");
      return value;
    }
    if (tag === 5) {
      const length = uint32();
      if (length > 4096) replayError("INVALID_SNAPSHOT", "recording array exceeds limit");
      return Array.from({ length }, () => read(depth + 1));
    }
    if (tag === 6) {
      const length = uint32();
      if (length > 64) replayError("INVALID_SNAPSHOT", "recording record exceeds limit");
      const result = {};
      let previous;
      for (let i = 0; i < length; i++) {
        const key = read(depth + 1);
        if (typeof key !== "string" || !/^[\x20-\x7e]+$/.test(key) || previous !== void 0 && key <= previous) {
          replayError("INVALID_SNAPSHOT", "recording record keys must be unique canonical ASCII");
        }
        Object.defineProperty(result, key, { value: read(depth + 1), enumerable: true, writable: true, configurable: true });
        previous = key;
      }
      return result;
    }
    replayError("INVALID_SNAPSHOT", "unknown recording data tag");
  }
  try {
    const result = read(0);
    if (offset !== bytes.length) replayError("INVALID_SNAPSHOT", "recording has trailing bytes");
    return result;
  } catch (error2) {
    if (error2 instanceof PhysicsError) throw error2;
    replayError("INVALID_SNAPSHOT", "invalid recording encoding");
  }
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/replay-compare.ts
function equivalentReplayValue(left, right) {
  if (typeof left === "number" || typeof right === "number") {
    return typeof left === "number" && typeof right === "number" && Number.isFinite(left) && Number.isFinite(right) && Math.abs(left - right) <= 1e-12 * Math.max(1, Math.abs(left), Math.abs(right));
  }
  if (left === null || right === null || typeof left !== "object" || typeof right !== "object") {
    return left === right;
  }
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equivalentReplayValue(value, right[index]));
  }
  const leftKeys = Object.keys(left).sort(), rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every((key, index) => key === rightKeys[index] && equivalentReplayValue(
    left[key],
    right[key]
  ));
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/replay-validation.ts
function record5(value, keys, label) {
  exactFields2(value, keys, label);
  return value;
}
function number(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) replayError("INVALID_SNAPSHOT", "state number is invalid");
}
function vector5(value, length = 3) {
  if (!Array.isArray(value) || value.length !== length) replayError("INVALID_SNAPSHOT", "state vector is invalid");
  value.forEach(number);
}
function ids(values, expected, fields3, validate) {
  if (!Array.isArray(values) || values.length !== expected.length) replayError("INVALID_SNAPSHOT", "state entity list differs from model");
  values.forEach((value, index) => {
    const data = record5(value, fields3, "state entity");
    if (data.id !== expected[index]) replayError("INVALID_SNAPSHOT", "state entity ID differs from model");
    validate(data);
  });
}
function identity2(value) {
  const data = record5(value, ["modelRevision", "modelDigest", "configurationDigest", "providerDigest", "profile", "frameId", "fixedStepSeconds"], "identity");
  for (const name of ["modelDigest", "configurationDigest", "providerDigest"]) {
    if (typeof data[name] !== "string" || !/^sha256:[a-f0-9]{64}$/.test(data[name])) replayError("INVALID_SNAPSHOT", "identity digest is invalid");
  }
  if (typeof data.modelRevision !== "string" || typeof data.frameId !== "string" || typeof data.profile !== "string") replayError("INVALID_SNAPSHOT", "identity fields are invalid");
  number(data.fixedStepSeconds);
}
function admitRecording(input) {
  const copied = copyReplayJson(input, "recording");
  const data = record5(copied, ["format", "version", "model", "options", "identity", "frames", "finalState"], "recording");
  if (data.format !== "barocss-physics-recording" || data.version !== 2) replayError("INVALID_SNAPSHOT", "unsupported recording");
  encodeRecordingData(copied);
  if (canonicalEncode(data.model).length > 128 * 1024) replayError("INVALID_SNAPSHOT", "recording model exceeds byte limit");
  let admitted;
  try {
    admitted = admitModel(data.model, data.options);
  } catch {
    replayError("INVALID_SNAPSHOT", "recording model or options are invalid");
  }
  if (admitted.domain) replayError("INVALID_SNAPSHOT", "visual domain recording is unsupported");
  const model = admitted.model, options = admitted.options;
  identity2(data.identity);
  if (!Array.isArray(data.frames) || data.frames.length > 512) replayError("INVALID_SNAPSHOT", "recording frame limit exceeded");
  let commandCount = 0;
  for (const [index, frame] of data.frames.entries()) {
    const f = record5(frame, ["stepIndex", "commands"], "frame");
    if (f.stepIndex !== index + 1 || !Array.isArray(f.commands) || f.commands.length > 64) replayError("INVALID_SNAPSHOT", "frame cursor or commands are invalid");
    commandCount += f.commands.length;
    try {
      parseCommands(f.commands, admitted.bodies);
    } catch {
      replayError("INVALID_SNAPSHOT", "frame commands are invalid");
    }
  }
  if (commandCount > 4096) replayError("INVALID_SNAPSHOT", "recording command limit exceeded");
  const state = record5(data.finalState, ["schemaVersion", "identity", "stepIndex", "timeSeconds", "bodies", "joints", "contacts", "pairWrenches", "events", "ccdHits", "cloths", "fluids", "pairStats"], "final state");
  if (state.schemaVersion !== 2) replayError("INVALID_SNAPSHOT", "STATE2 required");
  identity2(state.identity);
  if (state.stepIndex !== data.frames.length || state.timeSeconds !== data.frames.length * options.fixedStepSeconds) replayError("INVALID_SNAPSHOT", "final cursor differs from log");
  if (!equivalentReplayIdentity(data.identity, state.identity)) replayError("INVALID_SNAPSHOT", "final identity differs from recording");
  const ident = data.identity;
  if (ident.modelRevision !== model.revision || ident.modelDigest !== digest(model) || ident.configurationDigest !== digest(options) || ident.profile !== options.profile || ident.frameId !== model.frame.id || !Object.is(ident.fixedStepSeconds, options.fixedStepSeconds)) replayError("INVALID_SNAPSHOT", "recording identity differs from inputs");
  ids(state.bodies, model.bodies.map((b2) => b2.id), ["id", "kind", "positionM", "orientationXYZW", "velocityMps", "angularVelocityRadps", "sleeping"], (b2) => {
    const source = model.bodies.find((item) => item.id === b2.id);
    if (b2.kind !== source.kind || typeof b2.sleeping !== "boolean") replayError("INVALID_SNAPSHOT", "body state kind or sleep flag is invalid");
    vector5(b2.positionM);
    vector5(b2.orientationXYZW, 4);
    vector5(b2.velocityMps);
    vector5(b2.angularVelocityRadps);
  });
  const bodyIds = new Set(model.bodies.map((b2) => b2.id)), colliders = new Map(model.colliders.map((c) => [c.id, c.bodyId]));
  const body = (value) => {
    if (typeof value !== "string" || !bodyIds.has(value)) replayError("INVALID_SNAPSHOT", "unknown body ID");
  };
  const collider = (value) => {
    if (typeof value !== "string" || !colliders.has(value)) replayError("INVALID_SNAPSHOT", "unknown collider ID");
  };
  ids(state.joints, model.joints.map((j) => j.id), ["id", "bodyAId", "bodyBId", "linearImpulseOnBNs", "angularImpulseOnBNms", "angleRad", "motorImpulseNms"], (j) => {
    const source = model.joints.find((item) => item.id === j.id);
    if (j.bodyAId !== source.bodyAId || j.bodyBId !== source.bodyBId) replayError("INVALID_SNAPSHOT", "joint owners differ");
    vector5(j.linearImpulseOnBNs);
    vector5(j.angularImpulseOnBNms);
    if (source.kind === "fixed" ? j.angleRad !== null : typeof j.angleRad !== "number") replayError("INVALID_SNAPSHOT", "joint angle is invalid");
    if (source.kind === "hinge" && source.motor ? typeof j.motorImpulseNms !== "number" : j.motorImpulseNms !== null) replayError("INVALID_SNAPSHOT", "joint motor state is invalid");
  });
  function entries(value, keys, check4) {
    if (!Array.isArray(value)) replayError("INVALID_SNAPSHOT", "state list is invalid");
    value.forEach((item) => check4(record5(item, keys, "state observation")));
  }
  function pairOwner(c) {
    body(c.bodyAId);
    body(c.bodyBId);
    collider(c.colliderAId);
    collider(c.colliderBId);
    if (c.bodyAId >= c.bodyBId || colliders.get(c.colliderAId) !== c.bodyAId || colliders.get(c.colliderBId) !== c.bodyBId) replayError("INVALID_SNAPSHOT", "pair ordering/owners differ");
    return c.bodyAId + "\0" + c.bodyBId;
  }
  let priorContact = "";
  entries(state.contacts, ["colliderAId", "colliderBId", "bodyAId", "bodyBId", "points"], (c) => {
    const key = pairOwner(c);
    if (key <= priorContact) replayError("INVALID_SNAPSHOT", "contact pairs not unique/sorted");
    priorContact = key;
    if (!Array.isArray(c.points) || c.points.length === 0) replayError("INVALID_SNAPSHOT", "contact points required");
    let priorPoint = "";
    entries(c.points, ["id", "normalAtoB", "anchorM", "pointOnAM", "pointOnBM", "signedGapM"], (p) => {
      if (typeof p.id !== "string" || p.id <= priorPoint) replayError("INVALID_SNAPSHOT", "point IDs not unique/sorted");
      priorPoint = p.id;
      vector5(p.normalAtoB);
      vector5(p.anchorM);
      vector5(p.pointOnAM);
      vector5(p.pointOnBM);
      number(p.signedGapM);
    });
  });
  let priorWrench = "";
  entries(state.pairWrenches, ["colliderAId", "colliderBId", "bodyAId", "bodyBId", "onA", "onB"], (p) => {
    const key = pairOwner(p);
    if (key <= priorWrench) replayError("INVALID_SNAPSHOT", "wrench pairs not unique/sorted");
    priorWrench = key;
    for (const side of ["onA", "onB"]) {
      const value = record5(p[side], ["linearImpulseNs", "angularImpulseAboutWorldOriginNms"], "body contact wrench");
      vector5(value.linearImpulseNs);
      vector5(value.angularImpulseAboutWorldOriginNms);
    }
  });
  let previousAcceptedEvent = "";
  entries(state.events, ["colliderAId", "colliderBId", "kind", "phase"], (e) => {
    collider(e.colliderAId);
    collider(e.colliderBId);
    const ownerA = colliders.get(e.colliderAId), ownerB = colliders.get(e.colliderBId), key = ownerA + "\0" + ownerB;
    if (ownerA >= ownerB || key <= previousAcceptedEvent) replayError("INVALID_SNAPSHOT", "event pair order/ownership invalid");
    previousAcceptedEvent = key;
    if (!["contact", "sensor"].includes(e.kind) || !["begin", "stay", "end"].includes(e.phase)) replayError("INVALID_SNAPSHOT", "event is invalid");
  });
  entries(state.ccdHits, ["bodyId", "colliderId", "toiFraction", "normalFixtureToBody"], (h) => {
    body(h.bodyId);
    collider(h.colliderId);
    number(h.toiFraction);
    vector5(h.normalFixtureToBody);
  });
  if (!Array.isArray(state.cloths) || state.cloths.length || !Array.isArray(state.fluids) || state.fluids.length) replayError("INVALID_SNAPSHOT", "domain recording is unsupported");
  const stats = record5(state.pairStats, ["eligiblePairs", "candidatePairs", "aabbTests"], "pair stats");
  for (const value of Object.values(stats)) if (!Number.isSafeInteger(value) || value < 0) replayError("INVALID_SNAPSHOT", "pair stats are invalid");
  return copied;
}

// examples/physics-contact-wrench-native-2276/evidence/native-03/stage/physics/src/replay.ts
function recordedState(state) {
  if (state.cloths.length || state.fluids.length) replayError("INVALID_SNAPSHOT", "domain recording is unsupported");
  return copyReplayJson({ ...state, cloths: [], fluids: [] }, "state");
}
function recordingBudget(prepare) {
  try {
    return prepare();
  } catch (error2) {
    if (error2 instanceof PhysicsError && error2.code === "INVALID_SNAPSHOT") {
      replayError("WORLD_LIMIT", "recording data exceeds resource bounds");
    }
    throw error2;
  }
}
function attachRecorder(world) {
  const access = recordingWorlds.get(world);
  if (!access) replayError("INVALID_SNAPSHOT", "recorder requires a genuine World");
  let recorder;
  access.attach(({ model, options, state }) => {
    if (canonicalEncode(model).length > 128 * 1024) replayError("WORLD_LIMIT", "recording model exceeds byte limit");
    if (state.fluids.length) replayError("INVALID_SNAPSHOT", "visual fluid profile recording is unsupported");
    const initial = {
      format: "barocss-physics-recording",
      version: 2,
      model,
      options,
      identity: state.identity,
      frames: [],
      finalState: recordedState(state)
    };
    encodeRecordingData(initial);
    const preparedOwner = {
      recording: initial,
      commandCount: 0,
      prepareFrames(commands, stepIndex) {
        return recordingBudget(() => {
          const frames = [
            ...preparedOwner.recording.frames,
            { stepIndex, commands: copyReplayJson(commands, "commands") }
          ];
          encodeRecordingData({ ...preparedOwner.recording, frames });
          return frames;
        });
      },
      prepare(frames, next) {
        return recordingBudget(() => {
          const recording = {
            ...preparedOwner.recording,
            frames,
            finalState: recordedState(next)
          };
          encodeRecordingData(recording);
          return recording;
        });
      }
    };
    let detached = false;
    recorder = {
      getState: () => access.read(preparedOwner),
      step: (commands = []) => access.step(preparedOwner, commands),
      saveRecording() {
        access.read(preparedOwner);
        return copyReplayJson(preparedOwner.recording, "recording");
      },
      dispose() {
        if (!detached) {
          access.detach(preparedOwner);
          detached = true;
        }
      }
    };
    return preparedOwner;
  });
  return recorder;
}
function restoreRecording(input, expectedInput) {
  const recording = admitRecording(input);
  const expected = copyReplayJson(expectedInput, "expected identity");
  exactFields2(expected, ["model", "options", "providerDigest"], "expected identity");
  if (!equivalentReplayIdentity(recording.model, expected.model) || !equivalentReplayIdentity(recording.options, expected.options) || recording.identity.providerDigest !== expected.providerDigest) replayError("STALE_SNAPSHOT", "recording identity differs from expected inputs");
  let world;
  try {
    world = createPhysicsWorld(recording.model, recording.options);
    if (!equivalentReplayIdentity(world.getState().identity, recording.identity)) replayError("STALE_SNAPSHOT", "recording provider differs from current provider");
    const recorder = createPhysicsRecorder(world);
    for (const frame of recording.frames) recorder.step(frame.commands);
    if (!equivalentReplayValue(recorder.getState(), recording.finalState)) replayError("INVALID_SNAPSHOT", "final state differs from reconstructed state");
    return { world, recorder };
  } catch (error2) {
    world?.dispose();
    if (error2 instanceof PhysicsError && error2.code === "STALE_SNAPSHOT") throw error2;
    replayError("INVALID_SNAPSHOT", "recording reconstruction failed");
  }
}
function serializeRecording(input) {
  const recording = admitRecording(input);
  const candidate = restorePhysicsRecording(recording, { model: recording.model, options: recording.options, providerDigest: recording.identity.providerDigest });
  try {
    return encodeRecordingData(recording);
  } finally {
    candidate.world.dispose();
  }
}
function deserializeRecording(bytes) {
  const recording = admitRecording(decodeRecordingData(bytes));
  const candidate = restorePhysicsRecording(recording, { model: recording.model, options: recording.options, providerDigest: recording.identity.providerDigest });
  try {
    return copyReplayJson(recording, "recording");
  } finally {
    candidate.world.dispose();
  }
}
function recordingOperation(operation, action) {
  try {
    return action();
  } catch (failure) {
    if (!(failure instanceof PhysicsError)) throw failure;
    const error2 = new PhysicsError(failure.code, failure.message, {
      operation,
      domain: "recording",
      entityIds: failure.details.entityIds,
      accepted: operation === "record" ? failure.details.accepted : null,
      phase: failure.code === "STALE_SNAPSHOT" ? "identity" : failure.code === "WORLD_LIMIT" ? "budget" : ["DISPOSED", "WORLD_OWNED", "REENTRANT_CALL"].includes(failure.code) ? "lifecycle" : "validation"
    });
    error2.stack = failure.stack;
    throw error2;
  }
}
function createPhysicsRecorder(world) {
  return recordingOperation("record", () => attachRecorder(world));
}
function restorePhysicsRecording(recording, expected) {
  return recordingOperation("restore", () => restoreRecording(recording, expected));
}
function serializePhysicsRecording(recording) {
  return recordingOperation("record", () => serializeRecording(recording));
}
function deserializePhysicsRecording(bytes) {
  return recordingOperation("record", () => deserializeRecording(bytes));
}
export {
  PhysicsError,
  createPhysicsRecorder,
  createPhysicsWorld,
  createUprightCapsuleController,
  createUprightCapsuleQuery,
  deserializePhysicsRecording,
  phaseFault,
  phaseHistory,
  phasePrivateSnapshot,
  decodeRecordingData as privateDecodeRecording,
  encodeRecordingData as privateEncodeRecording,
  restorePhysicsRecording,
  serializePhysicsRecording,
  unknownMarker
};
