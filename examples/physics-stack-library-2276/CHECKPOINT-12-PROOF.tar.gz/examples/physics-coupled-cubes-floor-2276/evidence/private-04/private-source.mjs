// packages/barocss-physics/src/types.ts
var PhysicsError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.name = "PhysicsError";
    this.details = { code, reason: message, operation: "create", phase: "admission", domain: "world", entityIds: [], accepted: null, ...details };
  }
  details;
};

// packages/barocss-physics/src/limits.ts
var ID = /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/;
var MAX_STEP_DISPLACEMENT_M = 10;

// packages/barocss-physics/src/validation.ts
function error(code, message) {
  throw new PhysicsError(code, message);
}
function copyShape(value) {
  return value.kind === "sphere" ? { kind: "sphere", radiusM: value.radiusM } : value.kind === "box" ? { kind: "box", halfExtentsM: [...value.halfExtentsM] } : { kind: "capsule", radiusM: value.radiusM, halfLengthM: value.halfLengthM };
}
function copyBody(body) {
  return {
    ...body,
    shape: copyShape(body.shape),
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    orientation: [...body.orientation],
    angularVelocityRadps: [...body.angularVelocityRadps],
    ...body.collisionFilter ? { collisionFilter: { ...body.collisionFilter } } : {},
    ...body.inertiaDiagonalKgM2 ? { inertiaDiagonalKgM2: [...body.inertiaDiagonalKgM2] } : {},
    inverseInertiaLocal: [...body.inverseInertiaLocal]
  };
}

// packages/barocss-physics/src/math.ts
var add = (a, b) => a.map((value, index) => value + b[index]);
var sub = (a, b) => a.map((value, index) => value - b[index]);
var scale = (a, value) => a.map((component) => component * value);
var dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);
var cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
var inverse = (q) => [-q[0], -q[1], -q[2], q[3]];
function rotate(q, v) {
  const axis = [q[0], q[1], q[2]];
  const t = scale(cross(axis, v), 2);
  return add(v, add(scale(t, q[3]), cross(axis, t)));
}
var localPoint = (body, point2) => rotate(inverse(body.orientation), sub(point2, body.positionM));
var worldPoint = (body, point2) => add(body.positionM, rotate(body.orientation, point2));
function inverseInertia(body, vector2) {
  const local = rotate(inverse(body.orientation), vector2);
  return rotate(body.orientation, local.map((value, index) => value * body.inverseInertiaLocal[index]));
}
function inertia(body, vector2) {
  const local = rotate(inverse(body.orientation), vector2);
  return rotate(body.orientation, local.map((value, index) => value / body.inverseInertiaLocal[index]));
}

// packages/barocss-physics/src/capsule-contact.ts
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
function capsuleEnds(body) {
  const half = body.shape.halfLengthM;
  return [worldPoint(body, [0, -half, 0]), worldPoint(body, [0, half, 0])];
}
function segmentPair(a0, a1, b0, b1) {
  const u = sub(a1, a0), v = sub(b1, b0), w = sub(a0, b0);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v);
  const dd = dot(u, w), ee = dot(v, w), determinant = aa * cc - bb * bb;
  const candidates = [
    [0, clamp(ee / cc, 0, 1)],
    [1, clamp((bb + ee) / cc, 0, 1)],
    [clamp(-dd / aa, 0, 1), 0],
    [clamp((bb - dd) / aa, 0, 1), 1],
    [0.5, clamp((bb * 0.5 + ee) / cc, 0, 1)],
    [clamp((bb * 0.5 - dd) / aa, 0, 1), 0.5]
  ];
  if (determinant > 1e-12 * aa * cc) {
    const s = (bb * ee - cc * dd) / determinant;
    const t = (aa * ee - bb * dd) / determinant;
    if (s >= 0 && s <= 1 && t >= 0 && t <= 1) candidates.push([s, t]);
  }
  let best = candidates[0], bestDistance = Infinity, bestTie = Infinity;
  for (const candidate of candidates) {
    const difference = sub(add(a0, scale(u, candidate[0])), add(b0, scale(v, candidate[1])));
    const distance = dot(difference, difference);
    const tie = Math.abs(candidate[0] - 0.5) + Math.abs(candidate[1] - 0.5);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && tie < bestTie) {
      best = candidate;
      bestDistance = distance;
      bestTie = tie;
    }
  }
  return [add(a0, scale(u, best[0])), add(b0, scale(v, best[1]))];
}
function segmentBox(segmentStart, segmentEnd, extents2) {
  const direction2 = sub(segmentEnd, segmentStart);
  const breaks = [0, 1];
  for (let axis = 0; axis < 3; axis++) {
    if (Math.abs(direction2[axis]) < 1e-15) continue;
    for (const face of [-extents2[axis], extents2[axis]]) {
      const t = (face - segmentStart[axis]) / direction2[axis];
      if (t > 0 && t < 1) breaks.push(t);
    }
  }
  breaks.sort((a, b) => a - b);
  let bestT = 0.5, bestDistance = Infinity;
  for (let interval = 0; interval < breaks.length - 1; interval++) {
    const low = breaks[interval], high = breaks[interval + 1];
    if (high - low < 1e-15) continue;
    const midpoint = (low + high) / 2;
    let numerator = 0, denominator = 0;
    for (let axis = 0; axis < 3; axis++) {
      const value = segmentStart[axis] + midpoint * direction2[axis];
      const face = value < -extents2[axis] ? -extents2[axis] : value > extents2[axis] ? extents2[axis] : null;
      if (face === null) continue;
      numerator += direction2[axis] * (segmentStart[axis] - face);
      denominator += direction2[axis] ** 2;
    }
    const t = clamp(denominator ? -numerator / denominator : 0.5, low, high);
    const point3 = add(segmentStart, scale(direction2, t));
    const nearest = point3.map((value, axis) => clamp(value, -extents2[axis], extents2[axis]));
    const delta = sub(point3, nearest), distance = dot(delta, delta);
    if (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && Math.abs(t - 0.5) < Math.abs(bestT - 0.5)) {
      bestT = t;
      bestDistance = distance;
    }
  }
  const point2 = add(segmentStart, scale(direction2, bestT));
  return [point2, point2.map((value, axis) => clamp(value, -extents2[axis], extents2[axis]))];
}
function capsuleCapsule(a, b) {
  const [aPoint, bPoint] = segmentPair(...capsuleEnds(a), ...capsuleEnds(b));
  const delta = sub(bPoint, aPoint), distance = Math.hypot(...delta);
  const aRadius = a.shape.radiusM;
  const bRadius = b.shape.radiusM;
  if (distance > aRadius + bRadius) return null;
  const centerDelta = sub(b.positionM, a.positionM);
  const normal = distance > 1e-12 ? scale(delta, 1 / distance) : Math.hypot(...centerDelta) > 1e-12 ? scale(centerDelta, 1 / Math.hypot(...centerDelta)) : a.id < b.id ? [1, 0, 0] : [-1, 0, 0];
  const surfaceA = add(aPoint, scale(normal, aRadius));
  const surfaceB = sub(bPoint, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add(surfaceA, surfaceB), 0.5)
  };
}
function capsuleBox(capsule, box) {
  const [start, end] = capsuleEnds(capsule).map((point2) => localPoint(box, point2));
  const extents2 = box.shape.halfExtentsM;
  const [axisPoint, boxPoint] = segmentBox(start, end, extents2);
  const delta = sub(boxPoint, axisPoint), distance = Math.hypot(...delta);
  const radius = capsule.shape.radiusM;
  if (distance > radius) return null;
  if (distance > 1e-12) return {
    normal: rotate(box.orientation, scale(delta, 1 / distance)),
    penetration: radius - distance,
    pointM: worldPoint(box, boxPoint)
  };
  let bestAxis = 0, bestSide = -1, bestGap = Infinity;
  for (let axis = 0; axis < 3; axis++) for (const side2 of [-1, 1]) {
    const gap = extents2[axis] - side2 * axisPoint[axis];
    if (gap < bestGap) {
      bestGap = gap;
      bestAxis = axis;
      bestSide = side2;
    }
  }
  const normalLocal = [0, 0, 0];
  normalLocal[bestAxis] = -bestSide;
  boxPoint[bestAxis] = bestSide * extents2[bestAxis];
  return {
    normal: rotate(box.orientation, normalLocal),
    penetration: radius + bestGap,
    pointM: worldPoint(box, boxPoint)
  };
}

// packages/barocss-physics/src/contact-contribution.ts
var zero = () => ({ linearImpulseNs: [0, 0, 0], angularImpulseAboutWorldOriginNms: [0, 0, 0] });
var copy = (v) => [...v];
function check(v) {
  if (v.length !== 3 || v.some((value) => !Number.isFinite(value))) {
    throw new PhysicsError("NUMERIC_LIMIT", "unsafe actual contact contribution");
  }
}
function side(com, arm, impulse, torque) {
  for (const v of [com, arm, impulse, torque]) check(v);
  return { comM: copy(com), armM: copy(arm), linearImpulseNs: copy(impulse), armTorqueNms: copy(torque) };
}
function contactApplication(comA, comB, armA, armB, impulseOnB) {
  const impulseOnA = scale(impulseOnB, -1);
  return { applications: [{
    onA: side(comA, armA, impulseOnA, scale(cross(armA, impulseOnB), -1)),
    onB: side(comB, armB, impulseOnB, cross(armB, impulseOnB))
  }] };
}
var ContactPairAccumulator = class {
  pairs = /* @__PURE__ */ new Map();
  add(aId, bId, contribution) {
    if (contribution.applications.length === 0) return;
    const key = aId + "\0" + bId;
    let pair = this.pairs.get(key);
    if (!pair) {
      pair = { aId, bId, anyNonzero: false, onA: zero(), onB: zero() };
      this.pairs.set(key, pair);
    }
    for (const application of contribution.applications) {
      for (const owner of ["onA", "onB"]) {
        const applied = application[owner];
        for (const v of [applied.comM, applied.armM, applied.linearImpulseNs, applied.armTorqueNms]) check(v);
        pair.anyNonzero ||= applied.linearImpulseNs.some((value) => value !== 0) || applied.armTorqueNms.some((value) => value !== 0);
        const moment = add(cross(applied.comM, applied.linearImpulseNs), applied.armTorqueNms);
        pair[owner].linearImpulseNs = add(pair[owner].linearImpulseNs, applied.linearImpulseNs);
        pair[owner].angularImpulseAboutWorldOriginNms = add(pair[owner].angularImpulseAboutWorldOriginNms, moment);
      }
    }
  }
  /** Validate the complete candidate ledger before World's existing commit. */
  finish() {
    for (const pair of this.pairs.values()) for (const owner of ["onA", "onB"]) {
      check(pair[owner].linearImpulseNs);
      check(pair[owner].angularImpulseAboutWorldOriginNms);
    }
    return [...this.pairs.values()].map((pair) => ({
      aId: pair.aId,
      bId: pair.bId,
      anyNonzero: pair.anyNonzero,
      onA: {
        linearImpulseNs: copy(pair.onA.linearImpulseNs),
        angularImpulseAboutWorldOriginNms: copy(pair.onA.angularImpulseAboutWorldOriginNms)
      },
      onB: {
        linearImpulseNs: copy(pair.onB.linearImpulseNs),
        angularImpulseAboutWorldOriginNms: copy(pair.onB.angularImpulseAboutWorldOriginNms)
      }
    }));
  }
};

// packages/barocss-physics/src/collision.ts
function capsuleCenter(body, point2) {
  const half = body.shape.halfLengthM;
  const local = localPoint(body, point2);
  return worldPoint(body, [0, Math.max(-half, Math.min(half, local[1])), 0]);
}
function boxAxes(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate(body.orientation, axis));
}
function boxSupport(body, direction2) {
  const axes = boxAxes(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function sphereSphere(a, b) {
  const aRadius = a.shape.radiusM;
  const bRadius = b.shape.radiusM;
  const delta = sub(b.positionM, a.positionM);
  const distance = Math.hypot(...delta);
  if (distance > aRadius + bRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  const aSurface = add(a.positionM, scale(normal, aRadius));
  const bSurface = sub(b.positionM, scale(normal, bRadius));
  return {
    normal,
    penetration: Math.max(0, aRadius + bRadius - distance),
    pointM: scale(add(aSurface, bSurface), 0.5)
  };
}
function sphereBox(sphere, box) {
  const radius = sphere.shape.radiusM;
  const extents2 = box.shape.halfExtentsM;
  const relative = localPoint(box, sphere.positionM);
  const nearest = relative.map((value, index) => Math.max(-extents2[index], Math.min(extents2[index], value)));
  const towardBox = sub(nearest, relative);
  const distance = Math.hypot(...towardBox);
  if (distance > radius) return null;
  if (distance > 0) return {
    normal: rotate(box.orientation, scale(towardBox, 1 / distance)),
    penetration: Math.max(0, radius - distance),
    pointM: worldPoint(box, nearest)
  };
  let axis = 0, side2 = -1, faceDistance = Infinity;
  for (let index = 0; index < 3; index++) for (const candidate of [-1, 1]) {
    const gap = extents2[index] - candidate * relative[index];
    if (gap < faceDistance) {
      faceDistance = gap;
      axis = index;
      side2 = candidate;
    }
  }
  const localNormal = [0, 0, 0];
  localNormal[axis] = -side2;
  nearest[axis] = side2 * extents2[axis];
  return {
    normal: rotate(box.orientation, localNormal),
    penetration: radius + faceDistance,
    pointM: worldPoint(box, nearest)
  };
}
function capsuleSphere(capsule, sphere) {
  const center = capsuleCenter(capsule, sphere.positionM);
  const delta = sub(sphere.positionM, center);
  const distance = Math.hypot(...delta);
  const capsuleRadius = capsule.shape.radiusM;
  const sphereRadius = sphere.shape.radiusM;
  if (distance > capsuleRadius + sphereRadius) return null;
  const normal = distance === 0 ? [1, 0, 0] : scale(delta, 1 / distance);
  return {
    normal,
    penetration: Math.max(0, capsuleRadius + sphereRadius - distance),
    pointM: scale(add(
      add(center, scale(normal, capsuleRadius)),
      sub(sphere.positionM, scale(normal, sphereRadius))
    ), 0.5)
  };
}
function boxBox(a, b) {
  const axesA = boxAxes(a), axesB = boxAxes(b);
  const extentA = a.shape.halfExtentsM, extentB = b.shape.halfExtentsM;
  const delta = sub(b.positionM, a.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  for (const candidate of candidates) {
    const length = Math.hypot(...candidate);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis2, index) => sum + extentA[index] * Math.abs(dot(basis2, axis)), 0);
    const radiusB = axesB.reduce((sum, basis2, index) => sum + extentB[index] * Math.abs(dot(basis2, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    if (overlap < -1e-12) return null;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
    }
  }
  const aPoint = boxSupport(a, bestAxis);
  const bPoint = boxSupport(b, scale(bestAxis, -1));
  return { normal: bestAxis, penetration: Math.max(0, bestOverlap), pointM: scale(add(aPoint, bPoint), 0.5) };
}
function detect(a, b) {
  if (a.shape.kind === "sphere" && b.shape.kind === "sphere") return sphereSphere(a, b);
  if (a.shape.kind === "sphere" && b.shape.kind === "box") return sphereBox(a, b);
  if (a.shape.kind === "box" && b.shape.kind === "sphere") {
    const hit = sphereBox(b, a);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a.shape.kind === "capsule" && b.shape.kind === "sphere") return capsuleSphere(a, b);
  if (a.shape.kind === "sphere" && b.shape.kind === "capsule") {
    const hit = capsuleSphere(b, a);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a.shape.kind === "box" && b.shape.kind === "box") return boxBox(a, b);
  if (a.shape.kind === "capsule" && b.shape.kind === "box") return capsuleBox(a, b);
  if (a.shape.kind === "box" && b.shape.kind === "capsule") {
    const hit = capsuleBox(b, a);
    return hit && { ...hit, normal: scale(hit.normal, -1) };
  }
  if (a.shape.kind === "capsule" && b.shape.kind === "capsule") return capsuleCapsule(a, b);
  return null;
}
function validateResult(bodies, contacts) {
  for (const body of bodies) {
    for (const [label, values, bound] of [
      ["position", body.positionM, 1e4],
      ["velocity", body.velocityMps, 1e3],
      ["angularVelocity", body.angularVelocityRadps, 1e3]
    ]) {
      if (values.some((value) => !Number.isFinite(value) || Math.abs(value) > bound)) error("NUMERIC_LIMIT", `${body.id} ${label} exceeded bounds`);
    }
    if (body.orientation.some((value) => !Number.isFinite(value)) || Math.abs(Math.hypot(...body.orientation) - 1) > 1e-12) error("NUMERIC_LIMIT", `${body.id} orientation exceeded tolerance`);
  }
  if (contacts.some((contact) => !Number.isFinite(contact.impulseNs) || !Number.isFinite(contact.penetrationM) || contact.normalAtoB.some((value) => !Number.isFinite(value)) || contact.pointM.some((value) => !Number.isFinite(value)) || contact.tangentImpulseNs.some((value) => !Number.isFinite(value)))) error("NUMERIC_LIMIT", "unsafe contact result");
}

// packages/barocss-physics/src/stack/sat-feature.ts
var FEATURE_INPUT_MESSAGE = "private feature geometry requires two admitted boxes";
var DIAGNOSTIC_TIE_TOLERANCE_M = 1e-12;
function boxAxes2(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate(body.orientation, axis));
}
function boxSupport2(body, direction2) {
  const axes = boxAxes2(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function featureAt(candidateIndex) {
  if (candidateIndex < 3) return { kind: "face-a", axisA: candidateIndex };
  if (candidateIndex < 6) return { kind: "face-b", axisB: candidateIndex - 3 };
  const crossIndex = candidateIndex - 6;
  return { kind: "edge-cross", axisA: Math.floor(crossIndex / 3), axisB: crossIndex % 3 };
}
function featureLabel(feature) {
  if (feature.kind === "face-a") return `A.face.${feature.axisA}`;
  if (feature.kind === "face-b") return `B.face.${feature.axisB}`;
  return `A.edge.${feature.axisA}xB.edge.${feature.axisB}`;
}
function selectBoxSATFeature(a, b) {
  if (a.shape.kind !== "box" || b.shape.kind !== "box") {
    error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE);
  }
  const axesA = boxAxes2(a), axesB = boxAxes2(b);
  const extentA = a.shape.halfExtentsM, extentB = b.shape.halfExtentsM;
  const delta = sub(b.positionM, a.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  let bestCandidateIndex = 0, bestRawLength = 0;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  const diagnostics = [];
  for (const [candidateIndex, candidate] of candidates.entries()) {
    const length = Math.hypot(...candidate);
    const feature2 = featureAt(candidateIndex);
    const diagnostic = {
      candidateIndex,
      label: featureLabel(feature2),
      feature: feature2,
      rawAxisLength: length,
      skippedByOriginalCutoff: length < 1e-12,
      signedDistanceM: null,
      overlapM: null
    };
    diagnostics.push(diagnostic);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis2, index) => sum + extentA[index] * Math.abs(dot(basis2, axis)), 0);
    const radiusB = axesB.reduce((sum, basis2, index) => sum + extentB[index] * Math.abs(dot(basis2, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    diagnostic.signedDistanceM = signedDistance;
    diagnostic.overlapM = overlap;
    if (overlap < -1e-12) return null;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
      bestCandidateIndex = candidateIndex;
      bestRawLength = length;
    }
  }
  const aPoint = boxSupport2(a, bestAxis);
  const bPoint = boxSupport2(b, scale(bestAxis, -1));
  const originalHit = {
    normal: bestAxis,
    penetration: Math.max(0, bestOverlap),
    pointM: scale(add(aPoint, bPoint), 0.5)
  };
  const feature = featureAt(bestCandidateIndex);
  return {
    hit: {
      normal: [...originalHit.normal],
      penetration: originalHit.penetration,
      pointM: [...originalHit.pointM]
    },
    feature,
    label: featureLabel(feature),
    candidateIndex: bestCandidateIndex,
    rawAxisLength: bestRawLength,
    candidates: diagnostics,
    ambiguity: {
      exactMinimumCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && candidate.overlapM === bestOverlap).map((candidate) => candidate.candidateIndex),
      withinDiagnosticTieToleranceCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && Math.abs(candidate.overlapM - bestOverlap) <= DIAGNOSTIC_TIE_TOLERANCE_M).map((candidate) => candidate.candidateIndex),
      skippedCandidateIndices: diagnostics.filter((candidate) => candidate.skippedByOriginalCutoff).map((candidate) => candidate.candidateIndex),
      diagnosticTieToleranceM: DIAGNOSTIC_TIE_TOLERANCE_M,
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// packages/barocss-physics/src/stack/witness.ts
var WITNESS_MESSAGE = "private feature contact requires valid box witnesses";
var WITNESS_TOLERANCE_M = 1e-12;
var DUPLICATE_TOLERANCE_M = 1e-12;
var basis = (b) => [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((v) => rotate(b.orientation, v));
var extents = (b) => b.shape.halfExtentsM;
function unit(v) {
  const n = Math.hypot(...v);
  if (!Number.isFinite(n) || n < 1e-12) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return scale(v, 1 / n);
}
function point(key, a, b, n) {
  const gap = dot(sub(b, a), n);
  const result = {
    key,
    witnessAM: [...a],
    witnessBM: [...b],
    midpointM: scale(add(a, b), 0.5),
    normalGapM: gap,
    pointPenetrationM: Math.max(0, -gap)
  };
  if (![...a, ...b, ...result.midpointM, gap, result.pointPenetrationM].every(Number.isFinite) || gap > WITNESS_TOLERANCE_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return result;
}

// packages/barocss-physics/src/stack/strict-line.ts
var STRICT_LINE_LIMITS = Object.freeze({
  rationalOperations: 2e5,
  integerOperations: 2e6,
  integerBits: 16384,
  roundingSteps: 16
});
var StrictLineFailure = class extends Error {
  constructor(message) {
    super(message);
    this.name = "StrictLineFailure";
  }
};
var ZERO = { n: 0n, d: 1n };
var ieee = new DataView(new ArrayBuffer(8));
function nextAfterToward(value, target) {
  if (!Number.isFinite(value) || !Number.isFinite(target)) throw new StrictLineFailure("nonfinite nextafter");
  if (value === target) return value;
  if (value === 0) return target > 0 ? Number.MIN_VALUE : -Number.MIN_VALUE;
  ieee.setFloat64(0, value, false);
  let bits2 = ieee.getBigUint64(0, false);
  bits2 += target > value === value > 0 ? 1n : -1n;
  ieee.setBigUint64(0, bits2, false);
  const result = ieee.getFloat64(0, false);
  if (!Number.isFinite(result)) throw new StrictLineFailure("nextafter overflow");
  return result;
}
var Arithmetic = class {
  counters = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 };
  guardCached() {
    if (this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
    if (this.counters.peakIntegerBits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
  }
  tick(amount = 1) {
    this.counters.integerOperations += amount;
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
  }
  op() {
    if (++this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
  }
  checked(value) {
    const hex = (value < 0n ? -value : value).toString(16), first = hex.charCodeAt(0);
    const bits2 = 4 * (hex.length - 1) + (first <= 49 ? 1 : first <= 51 ? 2 : first <= 55 ? 3 : 4);
    this.counters.peakIntegerBits = Math.max(this.counters.peakIntegerBits, bits2);
    if (bits2 > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
    return value;
  }
  multiply(a, b) {
    this.tick();
    return this.checked(a * b);
  }
  sum(a, b) {
    this.tick();
    return this.checked(a + b);
  }
  shifted(value, bits2) {
    this.tick();
    return this.checked(value << BigInt(bits2));
  }
  make(n, d = 1n) {
    this.checked(n);
    this.checked(d);
    return this.normalizeChecked(n, d);
  }
  /** Both operands have already passed checked in this call's evaluation order. */
  normalizeChecked(n, d) {
    if (d === 0n) throw new StrictLineFailure("zero rational denominator");
    if (n === 0n) return ZERO;
    if (d < 0n) {
      this.tick(2);
      n = -n;
      d = -d;
    }
    if (d === 1n) {
      this.guardCached();
      return { n, d };
    }
    let a = n < 0n ? -n : n, b = d;
    this.tick(2);
    if ((d & d - 1n) === 0n) {
      this.tick(2);
      const factor2 = a & -a, divisor = factor2 < d ? factor2 : d;
      this.tick(2);
      return { n: n / divisor, d: d / divisor };
    }
    while (b !== 0n) {
      this.tick();
      const remainder = a % b;
      a = b;
      b = remainder;
    }
    this.tick(2);
    return { n: n / a, d: d / a };
  }
  from(value) {
    this.op();
    if (!Number.isFinite(value)) throw new StrictLineFailure("nonfinite exact operand");
    ieee.setFloat64(0, value, false);
    const bits2 = ieee.getBigUint64(0, false), negative = bits2 >> 63n !== 0n;
    const exponent = Number(bits2 >> 52n & 2047n), fraction = bits2 & (1n << 52n) - 1n;
    const significand = exponent === 0 ? fraction : fraction + (1n << 52n);
    const power = exponent === 0 ? -1074 : exponent - 1023 - 52;
    const n = negative ? -significand : significand;
    return power >= 0 ? this.make(this.shifted(n, power)) : this.make(n, this.shifted(1n, -power));
  }
  add(a, b) {
    this.op();
    if (a.d === b.d) return this.make(this.sum(a.n, b.n), a.d);
    if (a.d > 0n && b.d > 0n) {
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(this.sum(a.n, this.multiply(b.n, ratio)), a.d);
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.sum(this.multiply(a.n, ratio), b.n), b.d);
      }
    }
    return this.normalizeChecked(this.sum(this.multiply(a.n, b.d), this.multiply(b.n, a.d)), this.multiply(a.d, b.d));
  }
  neg(a) {
    this.op();
    this.tick();
    return { n: -a.n, d: a.d };
  }
  sub(a, b) {
    return this.add(a, this.neg(b));
  }
  mul(a, b) {
    this.op();
    return this.normalizeChecked(this.multiply(a.n, b.n), this.multiply(a.d, b.d));
  }
  sumSquare(a, b) {
    const sum = this.add(a, b);
    this.op();
    const n = this.multiply(sum.n, sum.n), d = this.multiply(sum.d, sum.d);
    if (n === 0n) return ZERO;
    if (d === 1n) this.guardCached();
    return { n, d };
  }
  div(a, b) {
    this.op();
    if (a.d > 0n && b.d > 0n && b.n !== 0n) {
      this.guardCached();
      if (a.d === b.d) return this.make(a.n, b.n);
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(a.n, this.multiply(ratio, b.n));
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.multiply(ratio, a.n), b.n);
      }
    }
    return this.normalizeChecked(this.multiply(a.n, b.d), this.multiply(a.d, b.n));
  }
  compare(a, b) {
    this.op();
    const difference = this.sum(this.multiply(a.n, b.d), -this.multiply(b.n, a.d));
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
  }
  abs(a) {
    return a.n < 0n ? this.neg(a) : a;
  }
  vec(value, length = 3) {
    if (value.length !== length || !Array.from({ length }, (_, i) => i).every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    return value.map((x) => this.from(x));
  }
  dot(a, b) {
    return a.reduce((value, x, i) => {
      const product = this.mul(x, b[i]);
      return value === null && product.n !== 0n && product.d !== 1n ? product : this.add(value ?? ZERO, product);
    }, null) ?? ZERO;
  }
  quotient(a, b) {
    this.tick();
    return this.checked(a / b);
  }
  /** Called only after both original boxes have fully decoded and normalized. */
  prepareRotation(rotation) {
    let denominator = 1n;
    for (const row of rotation) for (const value of row) {
      if (value.d === 1n) continue;
      let a = denominator, b = value.d;
      while (b !== 0n) {
        this.tick();
        const remainder = a % b;
        a = b;
        b = remainder;
      }
      denominator = this.multiply(this.quotient(denominator, a), value.d);
    }
    if (denominator === 1n) return { denominator, columns: [0, 1, 2].map((axis) => rotation.map((row) => row[axis].n)) };
    const columns = [0, 1, 2].map((axis) => rotation.map((row) => this.multiply(row[axis].n, this.quotient(denominator, row[axis].d))));
    return { denominator, columns };
  }
  /** Relative coordinates are owned dyadics from unchanged from/sub calls. */
  localProjection(rotation, relative) {
    this.guardCached();
    let denominator = 1n;
    for (const value of relative) if (value.d > denominator) denominator = value.d;
    const scaled = relative.map((value) => this.multiply(value.n, this.quotient(denominator, value.d)));
    const divisor = this.multiply(rotation.denominator, denominator);
    return rotation.columns.map((column) => {
      this.op();
      let numerator = this.multiply(column[0], scaled[0]);
      for (let i = 1; i < 3; i++) numerator = this.sum(numerator, this.multiply(column[i], scaled[i]));
      return this.normalizeChecked(numerator, divisor);
    });
  }
  /** Correct nearest-even conversion, including subnormals; no Number(BigInt)/Number(BigInt). */
  number(value) {
    this.op();
    if (value.n === 0n) return 0;
    const negative = value.n < 0n, n = negative ? -value.n : value.n, d = value.d;
    let exponent = n.toString(2).length - d.toString(2).length;
    if (exponent >= 0 ? n < this.shifted(d, exponent) : this.shifted(n, -exponent) < d) exponent--;
    const unit2 = Math.max(-1074, exponent - 52);
    const numerator = unit2 < 0 ? this.shifted(n, -unit2) : n;
    const denominator = unit2 > 0 ? this.shifted(d, unit2) : d;
    this.tick(2);
    let quotient = numerator / denominator;
    const remainder = numerator % denominator;
    const twice = this.shifted(remainder, 1);
    if (twice > denominator || twice === denominator && (quotient & 1n) !== 0n) {
      this.tick();
      quotient++;
    }
    const result = Number(quotient) * Math.pow(2, unit2);
    if (!Number.isFinite(result)) throw new StrictLineFailure("rounded witness overflow");
    return negative ? -result : result;
  }
};
var StrictLineContext = class {
  m = new Arithmetic();
  boxes;
  integerRotations;
  normal;
  tolerance;
  normalSquared;
  fourToleranceSquared;
  directions = [void 0, void 0];
  lastMidpoint;
  constructor(a, b, normal) {
    this.normal = this.m.vec(normal);
    if (this.normal.every((x) => x.n === 0n)) throw new StrictLineFailure("zero line direction");
    this.tolerance = this.m.from(1e-12);
    this.normalSquared = this.m.dot(this.normal, this.normal);
    this.fourToleranceSquared = this.m.mul(this.m.from(4), this.m.mul(this.tolerance, this.tolerance));
    this.boxes = [this.box(a), this.box(b)];
    this.integerRotations = [this.m.prepareRotation(this.boxes[0].rotation), this.m.prepareRotation(this.boxes[1].rotation)];
  }
  stats() {
    return { ...this.m.counters };
  }
  box(body) {
    if (body.shape.kind !== "box") throw new StrictLineFailure("box required");
    const m = this.m, [x, y, z, w] = m.vec(body.orientation, 4), norm2 = m.dot([x, y, z, w], [x, y, z, w]);
    if (norm2.n === 0n) throw new StrictLineFailure("zero quaternion");
    const two = m.from(2), square = (q) => m.mul(q, q);
    const twice = (a, b) => m.mul(two, m.mul(a, b));
    const diagonal = (a, b) => m.div(m.sub(norm2, m.mul(two, m.add(square(a), square(b)))), norm2);
    const entry = (a, b, c, d, sign) => m.div(sign === 1 ? m.add(twice(a, b), twice(c, d)) : m.sub(twice(a, b), twice(c, d)), norm2);
    const rotation = [
      [diagonal(y, z), entry(x, y, z, w, -1), entry(x, z, y, w, 1)],
      [entry(x, y, z, w, 1), diagonal(x, z), entry(y, z, x, w, -1)],
      [entry(x, z, y, w, -1), entry(y, z, x, w, 1), diagonal(x, y)]
    ];
    const extent = m.vec(body.shape.halfExtentsM);
    if (extent.some((value) => value.n <= 0n)) throw new StrictLineFailure("positive extents required");
    return { centre: m.vec(body.positionM), extent, rotation };
  }
  local(box, world, direction2 = false) {
    const relative = direction2 ? world : world.map((value, i) => this.m.sub(value, box.centre[i]));
    return this.m.localProjection(this.integerRotations[box === this.boxes[0] ? 0 : 1], relative);
  }
  direction(which) {
    const cached = this.directions[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], this.normal, true);
    this.directions[which] = value;
    return value;
  }
  midpoint(value) {
    if (!Array.isArray(value) || value.length !== 3 || ![0, 1, 2].every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    const key = [value[0], value[1], value[2]], cached = this.lastMidpoint;
    if (key.every(Number.isFinite) && cached !== void 0 && key.every((v, i) => Object.is(v, cached.key[i]))) {
      this.m.guardCached();
      return cached;
    }
    const point2 = this.m.vec(key);
    const entry = { key, point: point2, local: [void 0, void 0], interval: [void 0, void 0] };
    this.lastMidpoint = entry;
    return entry;
  }
  localMidpoint(which, entry) {
    const cached = entry.local[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], entry.point);
    entry.local[which] = value;
    return value;
  }
  interval(which, entry) {
    const cached = entry.interval[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const result = this.computeInterval(which, entry);
    entry.interval[which] = result;
    return result;
  }
  computeInterval(which, entry) {
    const box = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which);
    let low = null, high = null;
    for (let i = 0; i < 3; i++) {
      if (d[i].n === 0n) {
        if (m.compare(m.abs(u[i]), box.extent[i]) > 0) return null;
        continue;
      }
      const first = m.div(m.sub(m.neg(box.extent[i]), u[i]), d[i]), second = m.div(m.sub(box.extent[i], u[i]), d[i]);
      const lower = m.compare(first, second) <= 0 ? first : second, upper = lower === first ? second : first;
      if (low === null || m.compare(lower, low) > 0) low = lower;
      if (high === null || m.compare(upper, high) < 0) high = upper;
      if (low !== null && high !== null && m.compare(low, high) > 0) return null;
    }
    if (low === null || high === null) throw new StrictLineFailure("unbounded box line interval");
    return { low, high };
  }
  /** Strict closed slabs and the actual A-exit/B-entry surface midpoint. */
  check(midpoint) {
    const m = this.m, entry = this.midpoint(midpoint), a = this.interval(0, entry);
    if (a === null) return false;
    const b = this.interval(1, entry);
    if (b === null) return false;
    const fourDistanceSquared = m.mul(m.sumSquare(a.high, b.low), this.normalSquared);
    return m.compare(fourDistanceSquared, this.fourToleranceSquared) <= 0;
  }
  faceIsBoundary(which, entry, plane, bound, exit) {
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    const box = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which), axis = plane.axis;
    if (d[axis].n === 0n) return false;
    const side2 = m.from(plane.side), outwardDirection = m.mul(side2, d[axis]);
    if (m.compare(outwardDirection, ZERO) !== (exit ? 1 : -1)) return false;
    const parameter = m.div(m.sub(m.mul(side2, box.extent[axis]), u[axis]), d[axis]);
    return m.compare(parameter, bound) === 0;
  }
  /** Named faces must be actual line bounds; closed edge/corner ties remain valid. */
  selectedFaceBounds(midpoint, faceA, faceB) {
    const entry = this.midpoint(midpoint), a = this.interval(0, entry);
    if (a === null) return false;
    const b = this.interval(1, entry);
    return b !== null && this.faceIsBoundary(0, entry, faceA, a.high, true) && this.faceIsBoundary(1, entry, faceB, b.low, false);
  }
  onFace(which, plane, witness) {
    const m = this.m, box = this.boxes[which], local = this.local(box, m.vec(witness));
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    if (local.some((value, i) => m.compare(m.sub(m.abs(value), box.extent[i]), this.tolerance) > 0)) return false;
    return m.compare(m.abs(m.sub(local[plane.axis], m.mul(m.from(plane.side), box.extent[plane.axis]))), this.tolerance) <= 0;
  }
  movementWithin(original, moved) {
    const m = this.m, a = m.vec(original), b = m.vec(moved), delta = a.map((value, i) => m.sub(b[i], value));
    return m.compare(m.dot(delta, delta), m.mul(this.tolerance, this.tolerance)) <= 0;
  }
  projectedPair(seed, faceA, faceB) {
    const m = this.m, p = m.vec(seed);
    return [faceA, faceB].map((face, which) => {
      if (!Number.isInteger(face.axis) || face.axis < 0 || face.axis > 2 || Math.abs(face.side) !== 1) throw new StrictLineFailure("face selector");
      const box = this.boxes[which], u = this.local(box, p), d = this.direction(which), axis = face.axis;
      if (d[axis].n === 0n) throw new StrictLineFailure("line parallel to selected face");
      const t = m.div(m.sub(m.mul(m.from(face.side), box.extent[axis]), u[axis]), d[axis]);
      return p.map((value, i) => m.number(m.add(value, m.mul(this.normal[i], t))));
    });
  }
};

// packages/barocss-physics/src/stack/face-contact.ts
function clipFace(polygon, centre, axis, limit) {
  const out = [];
  for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i], q = polygon[(i + 1) % polygon.length];
    const dp = dot(sub(p, centre), axis) - limit, dq = dot(sub(q, centre), axis) - limit;
    if (dp <= 0) out.push([...p]);
    if (dp <= 0 !== dq <= 0) out.push(add(p, scale(sub(q, p), dp / (dp - dq))));
  }
  return out;
}
function faceContact(a, b, selection) {
  const f = selection.feature;
  if (f.kind === "edge-cross") error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const isA = f.kind === "face-a", ref = isA ? a : b, inc = isA ? b : a;
  const axis = f.kind === "face-a" ? f.axisA : f.axisB, ra = basis(ref), ia = basis(inc), re = extents(ref), ie = extents(inc);
  const outward = isA ? selection.hit.normal : scale(selection.hit.normal, -1);
  const side2 = dot(ra[axis], outward) < 0 ? -1 : 1, n = unit(scale(ra[axis], side2));
  const centre = add(ref.positionM, scale(ra[axis], side2 * re[axis]));
  let incidentAxis = 0, greatest = -Infinity;
  for (let i = 0; i < 3; i++) {
    const v = Math.abs(dot(ia[i], n));
    if (v > greatest) {
      greatest = v;
      incidentAxis = i;
    }
  }
  const incidentSide = dot(ia[incidentAxis], n) > 0 ? -1 : 1;
  const incidentCentre = add(inc.positionM, scale(ia[incidentAxis], incidentSide * ie[incidentAxis]));
  const it = [0, 1, 2].filter((i) => i !== incidentAxis), rt = [0, 1, 2].filter((i) => i !== axis);
  let poly = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => add(add(incidentCentre, scale(ia[it[0]], u * ie[it[0]])), scale(ia[it[1]], v * ie[it[1]])));
  for (const i of rt) {
    poly = clipFace(poly, centre, ra[i], re[i]);
    poly = clipFace(poly, centre, scale(ra[i], -1), re[i]);
  }
  const planeNormalAtoB = isA ? n : scale(n, -1);
  const candidates = poly.map((p) => {
    const separation = dot(sub(p, centre), n), r = sub(p, scale(n, separation));
    return { p, r, separation, u: dot(sub(r, centre), ra[rt[0]]), v: dot(sub(r, centre), ra[rt[1]]) };
  }).filter((p) => p.separation <= WITNESS_TOLERANCE_M);
  if (!candidates.length) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const selected = candidates.length <= 4 ? candidates : [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => candidates.reduce((best, p) => u * p.u + v * p.v > u * best.u + v * best.v ? p : best, candidates[0]));
  const unique = selected.filter((p, i) => selected.findIndex((q) => Math.hypot(...sub(p.r, q.r)) <= DUPLICATE_TOLERANCE_M) === i);
  unique.sort((p, q) => p.u - q.u || p.v - q.v);
  const prefix = `face:${ref.id}:${axis}:${side2}:${inc.id}:${incidentAxis}:${incidentSide}`;
  const referencePlane = { axis, side: side2 }, incidentPlane = { axis: incidentAxis, side: incidentSide };
  const faceA = isA ? referencePlane : incidentPlane, faceB = isA ? incidentPlane : referencePlane;
  const interior = scale(candidates.reduce((sum, p) => add(sum, scale(add(p.r, p.p), 0.5)), [0, 0, 0]), 1 / candidates.length);
  let movedPoints = 0, maximumSteps = 0;
  let exact;
  let points;
  try {
    exact = new StrictLineContext(a, b, planeNormalAtoB);
    points = unique.map((p, i) => {
      const original = point(`${prefix}:${i}`, isA ? p.r : p.p, isA ? p.p : p.r, planeNormalAtoB);
      const certified = (candidate) => exact.check(candidate.midpointM) && exact.selectedFaceBounds(candidate.midpointM, faceA, faceB) && exact.onFace(0, faceA, candidate.witnessAM) && exact.onFace(1, faceB, candidate.witnessBM);
      if (certified(original)) return original;
      let seed = [...original.midpointM];
      for (let step = 1; step <= STRICT_LINE_LIMITS.roundingSteps; step++) {
        seed = seed.map((value, k) => nextAfterToward(value, interior[k]));
        const [witnessA, witnessB] = exact.projectedPair(seed, faceA, faceB);
        const candidate = point(original.key, witnessA, witnessB, planeNormalAtoB);
        if (!exact.movementWithin(original.witnessAM, candidate.witnessAM) || !exact.movementWithin(original.witnessBM, candidate.witnessBM) || !exact.movementWithin(original.midpointM, candidate.midpointM)) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
        if (certified(candidate)) {
          movedPoints++;
          maximumSteps = Math.max(maximumSteps, step);
          return candidate;
        }
      }
      error("NUMERIC_LIMIT", WITNESS_MESSAGE);
    });
  } catch (caught) {
    if (caught instanceof StrictLineFailure) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
    throw caught;
  }
  const exactWork = exact.stats();
  return {
    selection: structuredClone(selection),
    family: "face",
    planeNormalAtoB,
    reference: { body: isA ? "a" : "b", axis, side: side2, incidentAxis, incidentSide },
    points,
    conditioning: {
      clippedVertices: poly.length,
      candidates: candidates.length,
      retainedPoints: points.length,
      rawAxisLength: selection.rawAxisLength,
      uniquePhysicalFeatureClaimed: false,
      strictLineCertified: true,
      boundaryRoundingMovedPoints: movedPoints,
      boundaryRoundingMaximumSteps: maximumSteps,
      exactRationalOperations: exactWork.rationalOperations,
      exactIntegerOperations: exactWork.integerOperations,
      exactPeakIntegerBits: exactWork.peakIntegerBits
    }
  };
}

// packages/barocss-physics/src/stack/edge-contact.ts
var clamp2 = (v) => Math.max(0, Math.min(1, v));
function closestSegments(p, p1, q, q1) {
  const u = sub(p1, p), v = sub(q1, q), r = sub(q, p), uu = dot(u, u), vv = dot(v, v), uv = dot(u, v), c = cross(u, v), den = dot(c, c);
  if (![...p, ...p1, ...q, ...q1, uu, vv, den].every(Number.isFinite) || uu <= 0 || vv <= 0) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const pairs = [
    { s: 0, t: clamp2(-dot(r, v) / vv) },
    { s: 1, t: clamp2((uv - dot(r, v)) / vv) },
    { s: clamp2(dot(r, u) / uu), t: 0 },
    { s: clamp2((dot(r, u) + uv) / uu), t: 1 }
  ];
  if (den > 0) {
    const s = dot(cross(r, v), c) / den, t = dot(cross(r, u), c) / den;
    if (Number.isFinite(s) && Number.isFinite(t) && s >= 0 && s <= 1 && t >= 0 && t <= 1) pairs.push({ s, t });
  }
  let best = pairs[0], bestDistance = Infinity;
  for (const pair of pairs) {
    const d = sub(add(p, scale(u, pair.s)), add(q, scale(v, pair.t))), ds = dot(d, d);
    if (ds < bestDistance) {
      best = pair;
      bestDistance = ds;
    }
  }
  return {
    a: add(p, scale(u, best.s)),
    b: add(q, scale(v, best.t)),
    parameterA: best.s,
    parameterB: best.t,
    crossSquared: den,
    distanceSquared: bestDistance,
    parallel: den === 0,
    boundary: best.s === 0 || best.s === 1 || best.t === 0 || best.t === 1
  };
}
function supportEdge(body, axis, direction2) {
  const axes = basis(body), e = extents(body), sides = [0, 0, 0];
  let centre = [...body.positionM];
  for (let i = 0; i < 3; i++) if (i !== axis) {
    sides[i] = dot(axes[i], direction2) < 0 ? -1 : 1;
    centre = add(centre, scale(axes[i], sides[i] * e[i]));
  }
  return { lo: sub(centre, scale(axes[axis], e[axis])), hi: add(centre, scale(axes[axis], e[axis])), sides };
}
function edgeContact(a, b, selection) {
  const f = selection.feature;
  if (f.kind !== "edge-cross") error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const n = [...selection.hit.normal], ea = supportEdge(a, f.axisA, n), eb = supportEdge(b, f.axisB, scale(n, -1));
  const nearest = closestSegments(ea.lo, ea.hi, eb.lo, eb.hi);
  const difference = sub(nearest.b, nearest.a), gap = dot(difference, n), tangent = sub(difference, scale(n, gap));
  if (Math.hypot(...tangent) > WITNESS_TOLERANCE_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const key = `edge:${a.id}:${f.axisA}:${ea.sides.join(",")}:${b.id}:${f.axisB}:${eb.sides.join(",")}`;
  return {
    selection: structuredClone(selection),
    family: "edge",
    planeNormalAtoB: n,
    edges: { axisA: f.axisA, axisB: f.axisB, sidesA: ea.sides, sidesB: eb.sides, parameterA: nearest.parameterA, parameterB: nearest.parameterB },
    points: [point(key, nearest.a, nearest.b, n)],
    conditioning: {
      crossSquared: nearest.crossSquared,
      rawAxisLength: selection.rawAxisLength,
      parallel: nearest.parallel,
      boundary: nearest.boundary,
      tangentDistanceM: Math.hypot(...tangent),
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// packages/barocss-physics/src/stack/geometry.ts
function witnessInside(body, w) {
  const local = basis(body).map((axis) => dot(sub(w, body.positionM), axis)), e = extents(body);
  return local.every((v, i) => Number.isFinite(v) && Math.abs(v) <= e[i] + WITNESS_TOLERANCE_M);
}
function denseVector(v, size, min, max) {
  return Array.isArray(v) && v.length === size && Array.from({ length: size }, (_, i) => i).every((i) => Object.hasOwn(v, i) && Number.isFinite(v[i]) && v[i] >= min && v[i] <= max);
}
function admitted(b) {
  return b !== null && typeof b === "object" && typeof b.id === "string" && ID.test(b.id) && ["dynamic", "static", "kinematic"].includes(b.kind) && b.shape?.kind === "box" && denseVector(b.shape.halfExtentsM, 3, 1e-4, 1e3) && denseVector(b.positionM, 3, -1e4, 1e4) && denseVector(b.orientation, 4, -1, 1) && Math.abs(Math.hypot(...b.orientation) - 1) <= 1e-9;
}
function featureContact(a, b) {
  if (!admitted(a) || !admitted(b) || a.id === b.id) error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE);
  const selection = selectBoxSATFeature(a, b);
  if (!selection) return null;
  if (selection.hit.penetration > MAX_STEP_DISPLACEMENT_M) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  const geometry = selection.feature.kind === "edge-cross" ? edgeContact(a, b, selection) : faceContact(a, b, selection);
  if (!geometry.points.length || geometry.points.some((p) => !witnessInside(a, p.witnessAM) || !witnessInside(b, p.witnessBM))) error("NUMERIC_LIMIT", WITNESS_MESSAGE);
  return geometry;
}

// packages/barocss-physics/src/stack/normal-solver.ts
var NORMAL_CANDIDATE_GATES = Object.freeze({
  normal: 1e-10,
  complementarity: 1e-10,
  stationarity: 1e-10,
  tangent: 1e-10,
  rank: 1e-12
});
var NORMAL_CANDIDATE_BUDGET = Object.freeze({
  outerIterations: 64,
  blockQrFactorizations: 64,
  activeChanges: 64,
  rankTests: 2048,
  dotProducts: 4e5,
  dotScalarProducts: 32e6,
  vectorUpdates: 1e7,
  triangularTerms: 4e4,
  constraintTests: 4096
});
var Stop = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
function numeric(message) {
  throw new Stop("NUMERIC", message);
}
function need(value, message) {
  if (!value) numeric(message);
}
function finite(x) {
  if (!Number.isFinite(x)) numeric("nonfinite arithmetic");
  return x;
}
function stats() {
  return {
    outerIterations: 0,
    blockQrFactorizations: 0,
    activeChanges: 0,
    qrRank: 0,
    finalActiveRows: 0,
    dynamicDof: 0,
    rankTests: 0,
    dotProducts: 0,
    dotScalarProducts: 0,
    vectorUpdates: 0,
    triangularTerms: 0,
    constraintTests: 0
  };
}
function take(s, key, amount = 1) {
  if (s[key] + amount > NORMAL_CANDIDATE_BUDGET[key]) throw new Stop("ITERATION_LIMIT", "budget:" + key);
  s[key] += amount;
}
function dot2(a, b, s) {
  take(s, "dotProducts");
  take(s, "dotScalarProducts", a.length);
  let value = 0;
  for (let i = 0; i < a.length; i++) value = finite(value + finite(a[i] * b[i]));
  return value;
}
function axpy(target, source, amount, s) {
  take(s, "vectorUpdates", target.length);
  for (let i = 0; i < target.length; i++) target[i] = finite(target[i] + finite(amount * source[i]));
}
function cross2(a, b) {
  return [finite(a[1] * b[2] - a[2] * b[1]), finite(a[2] * b[0] - a[0] * b[2]), finite(a[0] * b[1] - a[1] * b[0])];
}
function subtract(a, b) {
  return [finite(a[0] - b[0]), finite(a[1] - b[1]), finite(a[2] - b[2])];
}
function validVector(v, limit) {
  return Array.isArray(v) && v.length === 3 && Array.from({ length: 3 }, (_, i) => i).every((i) => Object.hasOwn(v, i) && typeof v[i] === "number" && Number.isFinite(v[i]) && Math.abs(v[i]) <= limit);
}
function copyBody2(body) {
  return {
    id: body.id,
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inverseMass: body.inverseMass,
    inverseInertiaWorld: body.inverseInertiaWorld.map((row) => [...row])
  };
}
function read(value) {
  need(value && Array.isArray(value.bodies) && value.bodies.length >= 1 && value.bodies.length <= 9 && Array.isArray(value.points) && value.points.length <= 32, "body/point bound");
  const ids = /* @__PURE__ */ new Set();
  let dynamic = 0;
  for (const body of value.bodies) {
    need(body && typeof body.id === "string" && body.id.length > 0 && body.id.length <= 1024 && !ids.has(body.id), "body id");
    ids.add(body.id);
    need(validVector(body.positionM, 1e4) && validVector(body.velocityMps, 1e3) && validVector(body.angularVelocityRadps, 1e3), "body vectors");
    need(typeof body.inverseMass === "number" && Number.isFinite(body.inverseMass) && (body.inverseMass === 0 || body.inverseMass >= 1e-6 && body.inverseMass <= 1e6), "inverse mass");
    need(Array.isArray(body.inverseInertiaWorld) && body.inverseInertiaWorld.length === 3 && body.inverseInertiaWorld.every((row) => validVector(row, 1e6)), "inverse inertia");
    if (body.inverseMass === 0) {
      need(
        [...body.velocityMps, ...body.angularVelocityRadps, ...body.inverseInertiaWorld.flat()].every((x) => x === 0),
        "static input must have zero motion and inertia"
      );
    } else dynamic++;
  }
  need(dynamic >= 1 && dynamic <= 8, "dynamic body bound");
  const pointIds = /* @__PURE__ */ new Set();
  for (const point2 of value.points) {
    need(point2 && typeof point2.id === "string" && point2.id.length > 0 && point2.id.length <= 4096 && !pointIds.has(point2.id), "point id");
    pointIds.add(point2.id);
    need(ids.has(point2.aId) && ids.has(point2.bId) && point2.aId !== point2.bId, "point endpoints");
    need(validVector(point2.pointM, 1e4) && validVector(point2.normalAtoB, 1 + 1e-12), "point vectors");
    need(Math.abs(Math.hypot(...point2.normalAtoB) - 1) <= 1e-12, "unit normal");
  }
  return { bodies: value.bodies.map(copyBody2), points: value.points.map((p) => ({
    ...p,
    pointM: [...p.pointM],
    normalAtoB: [...p.normalAtoB]
  })) };
}
function cholesky(matrix, s) {
  const scale2 = Math.max(1, ...matrix.flat().map(Math.abs));
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) need(matrix[i][j] === matrix[j][i], "symmetric inertia required");
  const lower = Array.from({ length: 3 }, () => [0, 0, 0]);
  for (let i = 0; i < 3; i++) for (let j = 0; j <= i; j++) {
    let entry = matrix[i][j];
    for (let k = 0; k < j; k++) {
      take(s, "triangularTerms");
      entry = finite(entry - finite(lower[i][k] * lower[j][k]));
    }
    if (i === j) {
      need(entry > 1e-12 * scale2, "positive definite well-scaled inertia required");
      lower[i][j] = Math.sqrt(entry);
    } else lower[i][j] = finite(entry / lower[j][j]);
  }
  return lower;
}
function model(input, s) {
  const blocks = [], free = [];
  for (const body of input.bodies) {
    if (body.inverseMass === 0) {
      blocks.push({ offset: null, rootMass: 0, angular: [] });
      continue;
    }
    const angular = cholesky(body.inverseInertiaWorld, s), rootMass = Math.sqrt(body.inverseMass), offset = free.length;
    for (const value of body.velocityMps) free.push(finite(value / rootMass));
    const local = [0, 0, 0];
    for (let i = 0; i < 3; i++) {
      let value = body.angularVelocityRadps[i];
      for (let j = 0; j < i; j++) {
        take(s, "triangularTerms");
        value = finite(value - finite(angular[i][j] * local[j]));
      }
      local[i] = finite(value / angular[i][i]);
    }
    free.push(...local);
    blocks.push({ offset, rootMass, angular });
  }
  s.dynamicDof = free.length;
  const ids = new Map(input.bodies.map((body, i) => [body.id, i]));
  const a = input.points.map((point2) => {
    const row = Array(free.length).fill(0);
    let dynamicEndpoint = false;
    for (const [id, sign] of [[point2.aId, -1], [point2.bId, 1]]) {
      const index = ids.get(id), body = input.bodies[index], block = blocks[index];
      const arm = subtract(point2.pointM, body.positionM);
      need(arm.every((x) => Math.abs(x) <= 10), "contact arm bound");
      if (block.offset === null) continue;
      dynamicEndpoint = true;
      const torque = cross2(arm, point2.normalAtoB);
      for (let k = 0; k < 3; k++) {
        row[block.offset + k] = finite(sign * point2.normalAtoB[k] * block.rootMass);
        row[block.offset + 3 + k] = finite(sign * dot2(torque, block.angular.map((r) => r[k]), s));
      }
    }
    need(dynamicEndpoint, "static/static contact unsupported");
    return row;
  });
  return { input, blocks, a, free };
}
function factor(a, candidates, s) {
  take(s, "blockQrFactorizations");
  const residual = new Map(candidates.map((i) => [i, [...a[i]]]));
  const remaining = [...candidates], rows = [], q = [];
  const scale2 = Math.max(1, ...candidates.map((i) => Math.sqrt(dot2(a[i], a[i], s))));
  while (remaining.length) {
    let pivot = remaining[0], square = -1;
    for (const index of remaining) {
      const value = dot2(residual.get(index), residual.get(index), s);
      if (value > square || value === square && index < pivot) {
        pivot = index;
        square = value;
      }
    }
    take(s, "rankTests");
    if (Math.sqrt(Math.max(0, square)) <= NORMAL_CANDIDATE_GATES.rank * scale2) break;
    const direction2 = [...a[pivot]];
    for (let pass = 0; pass < 2; pass++) for (const basis3 of q) axpy(direction2, basis3, -dot2(direction2, basis3, s), s);
    const length = Math.sqrt(dot2(direction2, direction2, s));
    need(length > NORMAL_CANDIDATE_GATES.rank * scale2, "inconsistent rank decision");
    const basis2 = direction2.map((value) => finite(value / length));
    for (const prior of q) need(Math.abs(dot2(basis2, prior, s)) <= 1e-12, "orthogonality");
    q.push(basis2);
    rows.push(pivot);
    remaining.splice(remaining.indexOf(pivot), 1);
    for (const index of remaining) for (let pass = 0; pass < 2; pass++) {
      const target = residual.get(index);
      axpy(target, basis2, -dot2(target, basis2, s), s);
    }
  }
  const lower = rows.map((index, i) => q.slice(0, i + 1).map((basis2) => dot2(a[index], basis2, s)));
  return { rows, q, lower };
}
function equality(m, qr, s) {
  const c = qr.q.map((row) => dot2(row, m.free, s)), target = [...m.free];
  for (let i = 0; i < qr.q.length; i++) axpy(target, qr.q[i], -c[i], s);
  const lambda = Array(qr.rows.length).fill(0);
  for (let i = lambda.length - 1; i >= 0; i--) {
    let value = -c[i];
    for (let j = i + 1; j < lambda.length; j++) {
      take(s, "triangularTerms");
      value = finite(value - finite(qr.lower[j][i] * lambda[j]));
    }
    lambda[i] = finite(value / qr.lower[i][i]);
  }
  return { target, lambda };
}
function outputBodies(m, x, s) {
  return m.input.bodies.map((body, index) => {
    const result = copyBody2(body), block = m.blocks[index];
    if (block.offset !== null) {
      result.velocityMps = [0, 1, 2].map((k) => finite(block.rootMass * x[block.offset + k]));
      result.angularVelocityRadps = block.angular.map((row) => dot2(row, x.slice(block.offset + 3, block.offset + 6), s));
    }
    return result;
  });
}
function finish(m, x, active, multipliers, s) {
  const lambda = Array(m.a.length).fill(0);
  active.forEach((index, i) => {
    need(multipliers[i] >= -1e-10, "negative active multiplier");
    lambda[index] = Math.max(0, multipliers[i]);
  });
  const bodies = outputBodies(m, x, s), ids = new Map(bodies.map((body, i) => [body.id, i]));
  const rowResiduals = m.input.points.map((point2, i) => {
    take(s, "constraintTests");
    const velocities = [point2.aId, point2.bId].map((id) => {
      const body = bodies[ids.get(id)], spin = cross2(body.angularVelocityRadps, subtract(point2.pointM, body.positionM));
      return body.velocityMps.map((v, k) => finite(v + spin[k]));
    });
    const relative = subtract(velocities[1], velocities[0]), vn = dot2(relative, point2.normalAtoB, s);
    const tangent = relative.map((value, k) => finite(value - point2.normalAtoB[k] * vn));
    return {
      id: point2.id,
      normalSpeedMps: vn,
      negativeNormalImpulseNs: Math.max(0, -lambda[i]),
      complementarityJ: Math.abs(finite(lambda[i] * vn)),
      tangentSpeedMps: Math.hypot(...tangent)
    };
  });
  let stationarity = 0;
  for (let k = 0; k < x.length; k++) {
    const reaction = dot2(m.a.map((row) => row[k]), lambda, s);
    stationarity = Math.max(stationarity, Math.abs(finite(x[k] - m.free[k] - reaction)));
  }
  const certificate = {
    maxClosingNormalSpeedMps: Math.max(0, ...rowResiduals.map((row) => -row.normalSpeedMps)),
    maxNegativeNormalImpulseNs: Math.max(0, ...rowResiduals.map((row) => row.negativeNormalImpulseNs)),
    maxComplementarityJ: Math.max(0, ...rowResiduals.map((row) => row.complementarityJ)),
    maxStationaritySqrtJ: stationarity,
    maxLoadedTangentSpeedMps: Math.max(0, ...rowResiduals.filter((_, i) => lambda[i] > 0).map((row) => row.tangentSpeedMps)),
    zeroTangentFeasible: false
  };
  certificate.zeroTangentFeasible = certificate.maxLoadedTangentSpeedMps <= 1e-10;
  need(certificate.maxClosingNormalSpeedMps <= 1e-10 && certificate.maxNegativeNormalImpulseNs <= 1e-10 && certificate.maxComplementarityJ <= 1e-10 && certificate.maxStationaritySqrtJ <= 1e-10, "final certificate");
  s.finalActiveRows = active.length;
  return {
    ok: true,
    status: "SOLVED_NORMAL_ONLY",
    bodies,
    normalImpulsesNs: [...lambda],
    rowResiduals,
    certificate,
    stats: { ...s },
    reason: null
  };
}
function solveNormalContacts(problem) {
  const s = stats();
  let input = null;
  try {
    input = read(problem);
    const m = model(input, s);
    let current = Array(m.free.length).fill(0), active = null;
    for (; ; ) {
      take(s, "outerIterations");
      const qr = factor(m.a, active ?? m.a.map((_, i) => i), s);
      if (active === null) s.qrRank = qr.rows.length;
      else need(qr.rows.length === active.length, "dependent working basis");
      active = [...qr.rows];
      const solved = equality(m, qr, s), direction2 = solved.target.map((value, i) => finite(value - current[i]));
      const directionNorm = Math.sqrt(dot2(direction2, direction2, s));
      let alpha = 1, blocker = null;
      if (directionNorm > 1e-12 * Math.max(1, Math.sqrt(dot2(m.free, m.free, s)))) {
        for (let i = 0; i < m.a.length; i++) {
          take(s, "constraintTests");
          if (active.includes(i)) continue;
          const margin = dot2(m.a[i], current, s), slope = dot2(m.a[i], direction2, s);
          need(margin >= -1e-10, "lost feasible iterate");
          if (slope < -1e-12) {
            const step = finite(Math.max(0, margin) / -slope);
            if (step < alpha || step === alpha && step < 1 && (blocker === null || i < blocker)) {
              alpha = step;
              blocker = i;
            }
          }
        }
      }
      if (blocker !== null && alpha < 1) {
        axpy(current, direction2, alpha, s);
        take(s, "activeChanges");
        active.push(blocker);
        continue;
      }
      current = solved.target;
      let leaving = null;
      for (let i = 0; i < active.length; i++) if (solved.lambda[i] < -1e-10 && (leaving === null || active[i] < active[leaving])) leaving = i;
      if (leaving !== null) {
        take(s, "activeChanges");
        active.splice(leaving, 1);
        continue;
      }
      return finish(m, current, active, solved.lambda, s);
    }
  } catch (error2) {
    if (!(error2 instanceof Stop)) throw error2;
    return {
      ok: false,
      status: error2.status,
      bodies: input?.bodies.map(copyBody2) ?? [],
      normalImpulsesNs: null,
      rowResiduals: null,
      certificate: null,
      stats: { ...s },
      reason: error2.message
    };
  }
}

// packages/barocss-physics/src/stack/signed-sat.ts
var FEATURE_INPUT_MESSAGE2 = "signed position reference requires admitted raw boxes";
var AXIS_MESSAGE = "signed position reference requires a fresh supported pre-SAT axis";
var DIAGNOSTIC_TIE_TOLERANCE_M2 = 1e-12;
function denseFinite(value, size, bound) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === size && Reflect.ownKeys(value).length === size + 1 && Array.from({ length: size }, (_, i) => i).every((i) => Object.hasOwn(value, i) && typeof value[i] === "number" && Number.isFinite(value[i]) && Math.abs(value[i]) <= bound);
}
function admittedRawBox(body) {
  return body !== null && typeof body === "object" && typeof body.id === "string" && ID.test(body.id) && (body.kind === "dynamic" || body.kind === "static") && body.shape?.kind === "box" && denseFinite(body.shape.halfExtentsM, 3, 1e3) && body.shape.halfExtentsM.every((v) => v >= 1e-4) && denseFinite(body.positionM, 3, 1e4) && denseFinite(body.velocityMps, 3, 1e3) && denseFinite(body.angularVelocityRadps, 3, 1e3) && denseFinite(body.orientation, 4, 1) && Math.abs(Math.hypot(...body.orientation) - 1) <= 1e-9 && typeof body.inverseMass === "number" && Number.isFinite(body.inverseMass) && (body.kind === "static" ? body.inverseMass === 0 : body.inverseMass >= 1e-6 && body.inverseMass <= 1e6);
}
function boxAxes3(body) {
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => rotate(body.orientation, axis));
}
function boxSupport3(body, direction2) {
  const axes = boxAxes3(body);
  const extents2 = body.shape.halfExtentsM;
  return add(body.positionM, axes.reduce((result, axis, index) => {
    const projection = dot(axis, direction2);
    const offset = Math.abs(projection) <= 1e-12 ? 0 : projection > 0 ? extents2[index] : -extents2[index];
    return add(result, scale(axis, offset));
  }, [0, 0, 0]));
}
function featureAt2(candidateIndex) {
  if (candidateIndex < 3) return { kind: "face-a", axisA: candidateIndex };
  if (candidateIndex < 6) return { kind: "face-b", axisB: candidateIndex - 3 };
  const crossIndex = candidateIndex - 6;
  return { kind: "edge-cross", axisA: Math.floor(crossIndex / 3), axisB: crossIndex % 3 };
}
function featureLabel2(feature) {
  if (feature.kind === "face-a") return `A.face.${feature.axisA}`;
  if (feature.kind === "face-b") return `B.face.${feature.axisB}`;
  return `A.edge.${feature.axisA}xB.edge.${feature.axisB}`;
}
function inspectSignedBoxSAT(a, b) {
  if (!admittedRawBox(a) || !admittedRawBox(b)) {
    error("INVALID_CONFIG", FEATURE_INPUT_MESSAGE2);
  }
  const axesA = boxAxes3(a), axesB = boxAxes3(b);
  const extentA = a.shape.halfExtentsM, extentB = b.shape.halfExtentsM;
  const delta = sub(b.positionM, a.positionM);
  let bestAxis = [1, 0, 0], bestOverlap = Infinity;
  let bestCandidateIndex = 0, bestRawLength = 0;
  const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => cross(axisA, axisB)))];
  const diagnostics = [];
  for (const [candidateIndex, candidate] of candidates.entries()) {
    const length = Math.hypot(...candidate);
    const feature2 = featureAt2(candidateIndex);
    const diagnostic = {
      candidateIndex,
      label: featureLabel2(feature2),
      feature: feature2,
      rawAxisLength: length,
      skippedByOriginalCutoff: length < 1e-12,
      signedDistanceM: null,
      overlapM: null,
      axis: null,
      orientedNormal: null,
      radiusAM: null,
      radiusBM: null
    };
    diagnostics.push(diagnostic);
    if (length < 1e-12) continue;
    const axis = scale(candidate, 1 / length);
    const radiusA = axesA.reduce((sum, basis2, index) => sum + extentA[index] * Math.abs(dot(basis2, axis)), 0);
    const radiusB = axesB.reduce((sum, basis2, index) => sum + extentB[index] * Math.abs(dot(basis2, axis)), 0);
    const signedDistance = dot(delta, axis);
    const overlap = radiusA + radiusB - Math.abs(signedDistance);
    diagnostic.signedDistanceM = signedDistance;
    diagnostic.overlapM = overlap;
    diagnostic.axis = [...axis];
    diagnostic.orientedNormal = scale(axis, signedDistance < 0 ? -1 : 1);
    diagnostic.radiusAM = radiusA;
    diagnostic.radiusBM = radiusB;
    if (overlap < bestOverlap) {
      bestOverlap = overlap;
      bestAxis = scale(axis, signedDistance < 0 ? -1 : 1);
      bestCandidateIndex = candidateIndex;
      bestRawLength = length;
    }
  }
  if (!Number.isFinite(bestOverlap) || !Number.isFinite(bestRawLength) || bestRawLength < 1e-12) error("NUMERIC_LIMIT", AXIS_MESSAGE);
  const aPoint = boxSupport3(a, bestAxis);
  const bPoint = boxSupport3(b, scale(bestAxis, -1));
  const pointM = scale(add(aPoint, bPoint), 0.5);
  const feature = featureAt2(bestCandidateIndex);
  return {
    normal: [...bestAxis],
    boundM: bestOverlap,
    pointM: [...pointM],
    feature,
    label: featureLabel2(feature),
    candidateIndex: bestCandidateIndex,
    rawAxisLength: bestRawLength,
    candidates: diagnostics,
    ambiguity: {
      exactMinimumCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && candidate.overlapM === bestOverlap).map((candidate) => candidate.candidateIndex),
      withinDiagnosticTieToleranceCandidateIndices: diagnostics.filter((candidate) => candidate.overlapM !== null && Math.abs(candidate.overlapM - bestOverlap) <= DIAGNOSTIC_TIE_TOLERANCE_M2).map((candidate) => candidate.candidateIndex),
      skippedCandidateIndices: diagnostics.filter((candidate) => candidate.skippedByOriginalCutoff).map((candidate) => candidate.candidateIndex),
      diagnosticTieToleranceM: DIAGNOSTIC_TIE_TOLERANCE_M2,
      uniquePhysicalFeatureClaimed: false
    }
  };
}

// packages/barocss-physics/src/stack/full-pair-input.mjs
var MESSAGES = Object.freeze({
  input: "full-pair position reference input is invalid",
  limit: "full-pair position reference admits at most nine bodies and thirty-six rows",
  empty: "full-pair position reference requires at least one body",
  ids: "full-pair position reference body IDs must be nonempty and unique",
  mass: "full-pair position reference inverse mass is invalid",
  endpoints: "full-pair position reference row endpoints are invalid",
  normal: "full-pair position reference normal must be finite and unit length",
  bound: "full-pair position reference bound must be finite and between minus ten and ten metres",
  result: "full-pair position reference result is invalid",
  workLimits: "full-pair position reference work limits are invalid"
});
var FullPairPositionReferenceError = class extends Error {
  constructor(code, message) {
    super(message);
    this.name = "FullPairPositionReferenceError";
    this.code = code;
  }
};
var DEFAULT_LIMITS = Object.freeze({
  iterations: 1024,
  activeChanges: 1024,
  rankChecks: 2048,
  linearSolves: 2048,
  constraintTests: 262144,
  exactIntegerOperations: 1e6,
  reducedRationalBits: 8192,
  intermediateIntegerBits: 16385
});
var COUNTER_KEYS = Object.freeze(["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "factorizations", "blockRightHandSides", "exactIntegerOperations", "exactPeakBits"]);
function zeroFullPairCounters() {
  return Object.fromEntries(COUNTER_KEYS.map((k) => [k, 0]));
}
function requireFull(condition, key = "input", code = "INVALID_INPUT") {
  if (!condition) throw new FullPairPositionReferenceError(code, MESSAGES[key]);
}
function dataRecord(value, keys) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return null;
  const own = Reflect.ownKeys(value);
  if (own.length !== keys.length || own.some((k) => typeof k !== "string" || !keys.includes(k))) return null;
  const copy2 = {};
  for (const k of keys) {
    const d = Object.getOwnPropertyDescriptor(value, k);
    if (!d || !Object.hasOwn(d, "value")) return null;
    Object.defineProperty(copy2, k, { value: d.value, enumerable: true, writable: true, configurable: true });
  }
  return copy2;
}
function dataArray(value, size) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) return null;
  const length = Object.getOwnPropertyDescriptor(value, "length");
  if (!length || !Object.hasOwn(length, "value") || !Number.isSafeInteger(length.value) || length.value < 0) return null;
  const n = length.value;
  if (size !== void 0 && n !== size) return null;
  const own = Reflect.ownKeys(value);
  if (own.length !== n + 1) return null;
  const copy2 = [];
  for (let i = 0; i < n; i++) {
    const d = Object.getOwnPropertyDescriptor(value, String(i));
    if (!d || !Object.hasOwn(d, "value")) return null;
    copy2.push(d.value);
  }
  return copy2;
}
function dataFiniteVector(value, size) {
  const a = dataArray(value, size);
  return a && a.every((v) => typeof v === "number" && Number.isFinite(v)) ? a : null;
}
function validateFullPairProblem(value) {
  const p = dataRecord(value, ["bodies", "rows"]);
  requireFull(p !== null);
  const bodies = dataArray(p.bodies), rows = dataArray(p.rows);
  requireFull(bodies !== null && rows !== null);
  requireFull(bodies.length <= 9 && rows.length <= 36, "limit", "PROFILE_LIMIT");
  requireFull(bodies.length > 0, "empty");
  const checkedBodies = [], ids = /* @__PURE__ */ new Set();
  for (const raw of bodies) {
    const b = dataRecord(raw, ["id", "inverseMass"]);
    requireFull(b !== null);
    requireFull(typeof b.id === "string" && b.id.length > 0 && !ids.has(b.id), "ids");
    ids.add(b.id);
    requireFull(typeof b.inverseMass === "number" && Number.isFinite(b.inverseMass) && (b.inverseMass === 0 || b.inverseMass >= 1e-6 && b.inverseMass <= 1e6), "mass");
    checkedBodies.push({ id: b.id, inverseMass: b.inverseMass });
  }
  const checkedRows = [];
  for (const raw of rows) {
    const row = dataRecord(raw, ["aId", "bId", "normal", "boundM"]);
    requireFull(row !== null);
    requireFull(ids.has(row.aId) && ids.has(row.bId) && row.aId !== row.bId, "endpoints");
    const normal = dataFiniteVector(row.normal, 3);
    requireFull(normal !== null && Math.abs(Math.hypot(...normal) - 1) <= 1e-12, "normal");
    requireFull(typeof row.boundM === "number" && Number.isFinite(row.boundM) && row.boundM >= -10 && row.boundM <= 10, "bound");
    checkedRows.push({ aId: row.aId, bId: row.bId, normal: [...normal], boundM: row.boundM });
  }
  return { bodies: checkedBodies, rows: checkedRows };
}
function validateWorkLimits(value) {
  const limits = dataRecord(value, Object.keys(DEFAULT_LIMITS));
  requireFull(limits !== null, "workLimits");
  for (const k of Object.keys(DEFAULT_LIMITS)) requireFull(Number.isSafeInteger(limits[k]) && limits[k] >= 0 && limits[k] <= DEFAULT_LIMITS[k], "workLimits");
  return { ...limits };
}
var CoreStop = class extends Error {
  constructor(status, reason) {
    super(reason);
    this.name = "FullPairCoreStop";
    this.status = status;
    this.reason = reason;
  }
};
function unsafe(reason) {
  throw new CoreStop("NUMERIC_UNSAFE", reason);
}
function finite2(value) {
  if (!Number.isFinite(value)) unsafe("nonfinite");
  return value;
}
function createMeter(limits = DEFAULT_LIMITS) {
  const selected = validateWorkLimits(limits), counters = zeroFullPairCounters();
  return {
    limits: selected,
    counters,
    take(key, amount = 1) {
      const next = counters[key] + amount;
      if (!Number.isSafeInteger(next) || next > selected[key]) throw new CoreStop("WORK_LIMIT", "budget:" + key);
      counters[key] = next;
    },
    bits(value, reduced = false) {
      const size = value === 0n ? 0 : (value < 0n ? -value : value).toString(2).length;
      const key = reduced ? "reducedRationalBits" : "intermediateIntegerBits";
      if (size > selected[key]) throw new CoreStop("WORK_LIMIT", "budget:" + key);
      counters.exactPeakBits = Math.max(counters.exactPeakBits, size);
      return size;
    },
    plannedBits(size) {
      if (size > selected.intermediateIntegerBits) throw new CoreStop("WORK_LIMIT", "budget:intermediateIntegerBits");
    }
  };
}

// packages/barocss-physics/src/stack/full-pair-linear.mjs
var EPS = 1e-12;
var PIVOT = 1e-14;
var normInfVector = (v) => Math.max(0, ...v.map(Math.abs));
var normInfMatrix = (m) => Math.max(0, ...m.map((row) => row.reduce((s, v) => finite2(s + Math.abs(v)), 0)));
function dot3(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum = finite2(sum + finite2(a[i] * b[i]));
  return sum;
}
function prepareModel(problem) {
  const offsets = [], D = [];
  for (const body of problem.bodies) {
    if (body.inverseMass === 0) offsets.push(null);
    else {
      offsets.push(D.length);
      D.push(body.inverseMass, body.inverseMass, body.inverseMass);
    }
  }
  const locations = new Map(problem.bodies.map((b2, i) => [b2.id, i]));
  const A = problem.rows.map((row) => {
    const a = Array(D.length).fill(0), ia = offsets[locations.get(row.aId)], ib = offsets[locations.get(row.bId)];
    for (let k = 0; k < 3; k++) {
      if (ia !== null) a[ia + k] = -row.normal[k];
      if (ib !== null) a[ib + k] = row.normal[k];
    }
    return a;
  });
  const b = problem.rows.map((row) => row.boundM), G = A.map((left) => A.map((right) => {
    let sum = 0;
    for (let k = 0; k < D.length; k++) sum = finite2(sum + finite2(finite2(left[k] * D[k]) * right[k]));
    return sum;
  }));
  return { problem, A, b, D, G, offsets, dynamicDof: D.length };
}
function reconstruct(model2, lambda) {
  return model2.D.map((inverseMass, k) => {
    let sum = 0;
    for (let i = 0; i < model2.A.length; i++) sum = finite2(sum + finite2(model2.A[i][k] * lambda[i]));
    return finite2(inverseMass * sum);
  });
}
function margins(model2, u, meter) {
  return model2.A.map((row, i) => {
    meter?.take("constraintTests");
    return finite2(dot3(row, u) - model2.b[i]);
  });
}
function translations(model2, u) {
  return model2.problem.bodies.map((body, i) => ({ id: body.id, u: model2.offsets[i] === null ? [0, 0, 0] : u.slice(model2.offsets[i], model2.offsets[i] + 3) }));
}
function fullCertificate(model2, u, lambda, meter) {
  const primalMarginsM = margins(model2, u, meter);
  let stationarityKgM = 0;
  for (let k = 0; k < u.length; k++) {
    let sum = 0;
    for (let i = 0; i < lambda.length; i++) sum = finite2(sum + finite2(model2.A[i][k] * lambda[i]));
    stationarityKgM = Math.max(stationarityKgM, Math.abs(finite2(u[k] / model2.D[k] - sum)));
  }
  const certificate = {
    primalViolationM: Math.max(0, ...primalMarginsM.map((v) => -v)),
    negativeMultiplierKgM: Math.max(0, ...lambda.map((v) => -v)),
    complementarityKgM2: Math.max(0, ...lambda.map((v, i) => Math.abs(finite2(v * primalMarginsM[i])))),
    stationarityKgM
  };
  let objectiveKgM2 = 0;
  for (let i = 0; i < model2.problem.bodies.length; i++) {
    const start = model2.offsets[i];
    if (start === null) continue;
    let square = 0;
    for (let k = 0; k < 3; k++) square = finite2(square + finite2(u[start + k] * u[start + k]));
    objectiveKgM2 = finite2(objectiveKgM2 + finite2(square / model2.problem.bodies[i].inverseMass / 2));
  }
  return { primalMarginsM, certificate, objectiveKgM2 };
}
function checkIterate(model2, u, lambda, W, pending, meter) {
  if (u.some((v) => !Number.isFinite(v)) || lambda.some((v) => !Number.isFinite(v))) unsafe("nonfinite");
  if (lambda.some((v) => v < 0)) unsafe("negative-multiplier");
  const allowed = new Set(W);
  if (pending !== null) allowed.add(pending);
  if (lambda.some((v, i) => v !== 0 && !allowed.has(i))) unsafe("iterate-certificate");
  for (const i of W) {
    meter.take("constraintTests");
    if (Math.abs(finite2(dot3(model2.A[i], u) - model2.b[i])) > EPS) unsafe("iterate-certificate");
  }
  for (let k = 0; k < u.length; k++) {
    let sum = 0;
    for (let i = 0; i < lambda.length; i++) sum = finite2(sum + finite2(model2.A[i][k] * lambda[i]));
    if (Math.abs(finite2(u[k] / model2.D[k] - sum)) > EPS) unsafe("iterate-certificate");
  }
}
function solveBasis(matrix, rhs, meter) {
  const n = rhs.length;
  if (n === 0) return { r: [], inverse: [], condition: null };
  meter.take("linearSolves");
  meter.counters.factorizations++;
  meter.counters.blockRightHandSides += 1 + n;
  const scale2 = Math.max(1, ...matrix.flat().map(Math.abs)), aug = matrix.map((row, i) => [...row, rhs[i], ...Array.from({ length: n }, (_, j) => i === j ? 1 : 0)]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let row = col + 1; row < n; row++) if (Math.abs(aug[row][col]) > Math.abs(aug[pivot][col])) pivot = row;
    if (!Number.isFinite(aug[pivot][col])) unsafe("nonfinite");
    if (Math.abs(aug[pivot][col]) <= PIVOT * scale2) unsafe("pivot");
    [aug[pivot], aug[col]] = [aug[col], aug[pivot]];
    for (let row = col + 1; row < n; row++) {
      const ratio = finite2(aug[row][col] / aug[col][col]);
      for (let k = col; k < 2 * n + 1; k++) aug[row][k] = finite2(aug[row][k] - finite2(ratio * aug[col][k]));
    }
  }
  const solved = Array.from({ length: n }, () => Array(n + 1).fill(0));
  for (let row = n - 1; row >= 0; row--) for (let k = 0; k < n + 1; k++) {
    let value = aug[row][n + k];
    for (let col = row + 1; col < n; col++) value = finite2(value - finite2(aug[row][col] * solved[col][k]));
    solved[row][k] = finite2(value / aug[row][row]);
  }
  const r = solved.map((row) => row[0]), inverse2 = solved.map((row) => row.slice(1));
  const normG = normInfMatrix(matrix), condition = finite2(normG * normInfMatrix(inverse2));
  if (condition > 1e12) unsafe("condition");
  const residual = normInfVector(matrix.map((row, i) => finite2(dot3(row, r) - rhs[i]))), denominator = finite2(Math.max(1, finite2(normG * normInfVector(r)) + normInfVector(rhs)));
  if (finite2(residual / denominator) > EPS) unsafe("factor-residual");
  const product = matrix.map((row, i) => Array.from({ length: n }, (_, j) => finite2(dot3(row, inverse2.map((x) => x[j])) - (i === j ? 1 : 0))));
  if (normInfMatrix(product) > EPS) unsafe("factor-residual");
  return { r, inverse: inverse2, condition };
}
function direction(model2, W, p, r, meter) {
  const z = model2.D.map((inv, k) => {
    let projection = 0;
    for (let j = 0; j < W.length; j++) projection = finite2(projection + finite2(model2.A[W[j]][k] * r[j]));
    return finite2(inv * finite2(model2.A[p][k] - projection));
  });
  meter.take("rankChecks");
  const delta = dot3(model2.A[p], z), scale2 = Math.max(1, model2.G[p][p]);
  let zMz = 0;
  for (let k = 0; k < z.length; k++) zMz = finite2(zMz + finite2(finite2(z[k] * z[k]) / model2.D[k]));
  const orthogonal = normInfVector(W.map((i) => dot3(model2.A[i], z))), orthScale = Math.max(1, ...W.map((i) => Math.abs(model2.G[i][p])), ...W.map((i) => {
    let sum = 0;
    for (let j = 0; j < W.length; j++) sum = finite2(sum + Math.abs(finite2(model2.G[i][W[j]] * r[j])));
    return sum;
  }));
  if (finite2(orthogonal / orthScale) > EPS || finite2(Math.abs(finite2(delta - zMz)) / Math.max(1, Math.abs(delta), Math.abs(zMz), Math.abs(model2.G[p][p]))) > EPS) unsafe("direction-residual");
  if (delta < -PIVOT * scale2) unsafe("direction-residual");
  return { z, delta, near: Math.abs(delta) <= PIVOT * scale2 || W.length + 1 > model2.dynamicDof };
}

// packages/barocss-physics/src/stack/full-pair-exact.mjs
var ZERO2 = Object.freeze({ n: 0n, d: 1n });
var ONE = Object.freeze({ n: 1n, d: 1n });
var bits = (x) => x === 0n ? 0 : (x < 0n ? -x : x).toString(2).length;
function operation(meter, estimate, fn) {
  meter.plannedBits(estimate);
  meter.take("exactIntegerOperations");
  const x = fn();
  meter.bits(x);
  return x;
}
var addI = (a, b, m) => operation(m, Math.max(bits(a), bits(b)) + 1, () => a + b);
var subI = (a, b, m) => operation(m, Math.max(bits(a), bits(b)) + 1, () => a - b);
var mulI = (a, b, m) => operation(m, bits(a) + bits(b), () => a * b);
var divI = (a, b, m) => operation(m, bits(a), () => a / b);
var remI = (a, b, m) => operation(m, bits(a), () => a % b);
var shiftI = (a, k, m) => operation(m, bits(a) + k, () => a << BigInt(k));
function absI(a, m) {
  return a < 0n ? subI(0n, a, m) : a;
}
function gcd(a, b, m) {
  a = absI(a, m);
  b = absI(b, m);
  while (b !== 0n) {
    const next = remI(a, b, m);
    a = b;
    b = next;
  }
  return a;
}
function checked(q, m) {
  m.bits(q.n, true);
  m.bits(q.d, true);
  return q;
}
function rational(n, d, m) {
  if (d === 0n) unsafe("uncertified-infeasibility");
  if (d < 0n) {
    n = subI(0n, n, m);
    d = subI(0n, d, m);
  }
  if (n === 0n) return checked(ZERO2, m);
  const g = gcd(n, d, m);
  return checked({ n: divI(n, g, m), d: divI(d, g, m) }, m);
}
function addQ(a, b, m) {
  if (a.n === 0n) return checked(b, m);
  if (b.n === 0n) return checked(a, m);
  return rational(addI(mulI(a.n, b.d, m), mulI(b.n, a.d, m), m), mulI(a.d, b.d, m), m);
}
function negQ(a, m) {
  return a.n === 0n ? checked(ZERO2, m) : checked({ n: subI(0n, a.n, m), d: a.d }, m);
}
function subQ(a, b, m) {
  return addQ(a, negQ(b, m), m);
}
function mulQ(a, b, m) {
  if (a.n === 0n || b.n === 0n) return checked(ZERO2, m);
  return rational(mulI(a.n, b.n, m), mulI(a.d, b.d, m), m);
}
function divQ(a, b, m) {
  if (b.n === 0n) unsafe("uncertified-infeasibility");
  if (a.n === 0n) return checked(ZERO2, m);
  return rational(mulI(a.n, b.d, m), mulI(a.d, b.n, m), m);
}
var text = (q) => `${q.n}/${q.d}`;
function fromNumber(value, m) {
  if (!Number.isFinite(value)) unsafe("nonfinite");
  if (value === 0) return checked(ZERO2, m);
  const view = new DataView(new ArrayBuffer(8));
  view.setFloat64(0, value, false);
  const raw = view.getBigUint64(0, false);
  const sign = raw >> 63n, exponent = Number(raw >> 52n & 2047n), fraction = raw & (1n << 52n) - 1n;
  let n = exponent === 0 ? fraction : addI(1n << 52n, fraction, m), d = 1n;
  const shift = exponent === 0 ? -1074 : exponent - 1023 - 52;
  if (shift >= 0) n = shiftI(n, shift, m);
  else d = shiftI(d, -shift, m);
  if (sign) n = subI(0n, n, m);
  return rational(n, d, m);
}
function toNumber(q, m) {
  if (q.n === 0n) return 0;
  const negative = q.n < 0n, n = absI(q.n, m), d = q.d;
  let exponent = bits(n) - bits(d);
  if (exponent >= 0) {
    if (n < shiftI(d, exponent, m)) exponent--;
  } else if (shiftI(n, -exponent, m) < d) exponent--;
  if (exponent > 1023) unsafe("dependency-conversion");
  const quantum = Math.max(exponent - 52, -1074), numerator = quantum < 0 ? shiftI(n, -quantum, m) : n, denominator = quantum > 0 ? shiftI(d, quantum, m) : d;
  let significand = divI(numerator, denominator, m);
  const remainder = remI(numerator, denominator, m), twice = mulI(remainder, 2n, m);
  if (twice > denominator || twice === denominator && remI(significand, 2n, m) !== 0n) significand = addI(significand, 1n, m);
  const result = (negative ? -1 : 1) * Number(significand) * 2 ** quantum;
  if (!Number.isFinite(result) || result === 0 || result < 0 !== negative) unsafe("dependency-conversion");
  return result;
}
function makeExactSystem(model2, meter) {
  const A = model2.A.map((row) => row.map((x) => fromNumber(x, meter))), D = model2.D.map((x) => fromNumber(x, meter)), b = model2.b.map((x) => fromNumber(x, meter)), cache = /* @__PURE__ */ new Map();
  return { A, D, b, gram(i, j) {
    const key = i + ":" + j;
    if (cache.has(key)) return cache.get(key);
    let sum = checked(ZERO2, meter);
    for (let k = 0; k < D.length; k++) if (A[i][k].n !== 0n && A[j][k].n !== 0n) sum = addQ(sum, mulQ(mulQ(A[i][k], D[k], meter), A[j][k], meter), meter);
    cache.set(key, sum);
    return sum;
  } };
}
function solveExact(matrix, rhs, m) {
  const n = rhs.length;
  if (n === 0) return [];
  m.take("linearSolves");
  m.counters.factorizations++;
  m.counters.blockRightHandSides++;
  const a = matrix.map((row, i) => [...row, rhs[i]]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    while (pivot < n && a[pivot][col].n === 0n) pivot++;
    if (pivot === n) unsafe("dependent-basis");
    [a[col], a[pivot]] = [a[pivot], a[col]];
    for (let row = col + 1; row < n; row++) {
      if (a[row][col].n === 0n) continue;
      const ratio = divQ(a[row][col], a[col][col], m);
      for (let k = col; k <= n; k++) a[row][k] = subQ(a[row][k], mulQ(ratio, a[col][k], m), m);
    }
  }
  const x = Array(n).fill(ZERO2);
  for (let row = n - 1; row >= 0; row--) {
    let value = a[row][n];
    for (let col = row + 1; col < n; col++) value = subQ(value, mulQ(a[row][col], x[col], m), m);
    x[row] = divQ(value, a[row][row], m);
  }
  return x;
}
function exactDependency(system, W, p, meter) {
  const rExact = solveExact(W.map((i) => W.map((j) => system.gram(i, j))), W.map((i) => system.gram(i, p)), meter);
  for (let k = 0; k < system.D.length; k++) {
    let projection = checked(ZERO2, meter);
    for (let j = 0; j < W.length; j++) projection = addQ(projection, mulQ(system.A[W[j]][k], rExact[j], meter), meter);
    if (subQ(system.A[p][k], projection, meter).n !== 0n) return { dependent: false, rExact: [], r: [] };
  }
  return { dependent: true, rExact };
}
function dependencyNumbers(rExact, meter) {
  return rExact.map((x) => toNumber(x, meter));
}
function verifyWeights(system, weights, meter) {
  if (weights.length !== system.b.length || weights.some((w) => w.n < 0n)) return null;
  let sum = checked(ZERO2, meter);
  for (const w of weights) sum = addQ(sum, w, meter);
  if (sum.n !== sum.d) return null;
  const dynamicDot = [];
  for (let k = 0; k < system.D.length; k++) {
    let dot4 = checked(ZERO2, meter);
    for (let i = 0; i < weights.length; i++) dot4 = addQ(dot4, mulQ(system.A[i][k], weights[i], meter), meter);
    if (dot4.n !== 0n) return null;
    dynamicDot.push(text(dot4));
  }
  let boundDot = checked(ZERO2, meter);
  for (let i = 0; i < weights.length; i++) boundDot = addQ(boundDot, mulQ(system.b[i], weights[i], meter), meter);
  if (boundDot.n <= 0n) return null;
  return { weights: weights.map(text), sumWeights: "1/1", dynamicDot, boundDotM: text(boundDot) };
}
function makeInfeasibilityCertificate(system, W, p, rExact, meter) {
  const weights = Array(system.b.length).fill(ZERO2);
  weights[p] = checked(ONE, meter);
  for (let j = 0; j < W.length; j++) weights[W[j]] = negQ(rExact[j], meter);
  if (weights.some((w) => w.n < 0n)) unsafe("uncertified-infeasibility");
  let sum = checked(ZERO2, meter);
  for (const w of weights) sum = addQ(sum, w, meter);
  if (sum.n <= 0n) unsafe("uncertified-infeasibility");
  const normalized = weights.map((w) => divQ(w, sum, meter)), proof = verifyWeights(system, normalized, meter);
  if (proof === null) unsafe("uncertified-infeasibility");
  return proof;
}
function parseCanonical(value, meter) {
  if (typeof value !== "string" || value.length > 4937 || !/^(?:0|-?[1-9][0-9]*)\/[1-9][0-9]*$/.test(value)) return null;
  const [ns, ds] = value.split("/");
  if (ns.replace("-", "").length > 2467 || ds.length > 2467) return null;
  meter.take("exactIntegerOperations");
  const n = BigInt(ns);
  meter.bits(n, true);
  meter.take("exactIntegerOperations");
  const d = BigInt(ds);
  meter.bits(d, true);
  const q = rational(n, d, meter);
  return text(q) === value ? q : null;
}
function verifyInfeasibilityCertificate(problem, certificate, meter = createMeter()) {
  const model2 = prepareModel(problem), system = makeExactSystem(model2, meter), weights = [];
  for (const value of certificate.weights) {
    const q = parseCanonical(value, meter);
    if (q === null) return false;
    weights.push(q);
  }
  const checkedProof = verifyWeights(system, weights, meter);
  if (checkedProof === null) return false;
  return certificate.sumWeights === "1/1" && certificate.boundDotM === checkedProof.boundDotM && certificate.dynamicDot.length === checkedProof.dynamicDot.length && certificate.dynamicDot.every((x, i) => x === checkedProof.dynamicDot[i]);
}

// packages/barocss-physics/src/stack/full-pair-core.mjs
var copySafe = (s) => ({ uDynamic: [...s.u], lambdaKgM: [...s.lambda], pendingRow: s.pending, pendingLambdaKgM: s.pending === null ? 0 : s.lambda[s.pending], basisRows: [...s.W] });
function ieeeState(s) {
  const view = new DataView(new ArrayBuffer(8));
  const encode = (x) => {
    view.setFloat64(0, x, false);
    return view.getBigUint64(0, false).toString(16);
  };
  return s.W.join(",") + "|" + String(s.pending) + "|" + s.u.map(encode).join(",") + "|" + s.lambda.map(encode).join(",");
}
function context(state, meter) {
  return { iteration: meter.counters.iterations, enteringRow: state.pending, basisBefore: [...state.W], basisAfter: [...state.W], blocker: null, stepKgM: null, schurInverseKg: null, condition: null, exactDependent: null };
}
function traceEntry(ctx, action, state) {
  return { ...ctx, basisBefore: [...ctx.basisBefore], basisAfter: [...state.W], action };
}
function runFullPairCore(rawProblem, limits = DEFAULT_LIMITS) {
  const problem = validateFullPairProblem(rawProblem), meter = createMeter(limits), model2 = prepareModel(problem), n = problem.rows.length;
  let state = { u: Array(model2.dynamicDof).fill(0), lambda: Array(n).fill(0), W: [], pending: null }, ctx = context(state, meter), exact = null;
  const trace = [], seen = /* @__PURE__ */ new Set();
  const getExact = () => exact ?? (exact = makeExactSystem(model2, meter));
  const common = () => ({ basisRows: [...state.W], basisRank: state.W.length, dynamicDof: model2.dynamicDof, counters: { ...meter.counters }, trace: trace.map((x) => ({ ...x, basisBefore: [...x.basisBefore], basisAfter: [...x.basisAfter] })), lastSafeIterate: copySafe(state), worldStepped: false });
  const refused = (status, reason, proof = null) => ({ ok: false, status, ...common(), translations: null, lambdaKgM: null, primalMarginsM: null, objectiveKgM2: null, certificate: null, infeasibilityCertificate: proof, reason });
  try {
    for (let i = 0; i < n; i++) {
      meter.take("constraintTests");
      if (model2.A[i].every((x) => x === 0) && model2.b[i] > 0) {
        const proof = makeInfeasibilityCertificate(getExact(), [], i, [], meter);
        ctx.exactDependent = true;
        trace.push(traceEntry(ctx, "infeasible", state));
        return refused("INFEASIBLE", null, proof);
      }
    }
    while (true) {
      if (state.pending === null) {
        ctx = context(state, meter);
        const allMargins = margins(model2, state.u, meter);
        if (state.W.some((i) => Math.abs(allMargins[i]) > EPS)) unsafe("iterate-certificate");
        const p2 = allMargins.findIndex((v, i) => v < -EPS && !state.W.includes(i));
        if (p2 < 0) {
          const u2 = reconstruct(model2, state.lambda), checked2 = fullCertificate(model2, u2, state.lambda, meter), bodyTranslations = translations(model2, u2);
          if (Object.values(checked2.certificate).some((v) => !Number.isFinite(v) || v > EPS) || checked2.objectiveKgM2 < 0) unsafe("result-certificate");
          if (bodyTranslations.some((t) => Math.hypot(...t.u) > 10)) unsafe("translation-bound");
          state = { ...state, u: u2 };
          return { ok: true, status: "SOLVED", ...common(), translations: bodyTranslations, lambdaKgM: [...state.lambda], primalMarginsM: [...checked2.primalMarginsM], objectiveKgM2: checked2.objectiveKgM2, certificate: { ...checked2.certificate }, infeasibilityCertificate: null, reason: null };
        }
        state = { ...state, pending: p2 };
      }
      ctx = context(state, meter);
      meter.take("iterations");
      ctx.iteration = meter.counters.iterations;
      const key = ieeeState(state);
      if (seen.has(key)) throw new CoreStop("WORK_LIMIT", "cycle");
      seen.add(key);
      const p = state.pending, W = state.W, solved = solveBasis(W.map((i) => W.map((j) => model2.G[i][j])), W.map((i) => model2.G[i][p]), meter);
      ctx.condition = solved.condition;
      let r = solved.r;
      const projected = direction(model2, W, p, r, meter);
      ctx.schurInverseKg = projected.delta;
      let dependent = false;
      if (projected.near) {
        meter.take("rankChecks");
        const relation = exactDependency(getExact(), W, p, meter);
        ctx.exactDependent = relation.dependent;
        if (!relation.dependent) unsafe("near-dependent-independent");
        dependent = true;
        if (!relation.rExact.some((x) => x.n > 0n)) {
          const proof = makeInfeasibilityCertificate(getExact(), W, p, relation.rExact, meter);
          trace.push(traceEntry(ctx, "infeasible", state));
          return refused("INFEASIBLE", null, proof);
        }
        r = dependencyNumbers(relation.rExact, meter);
      }
      let dualStep = Infinity, blocker = null;
      for (let j = 0; j < W.length; j++) if (r[j] > 0) {
        const step2 = finite2(state.lambda[W[j]] / r[j]);
        if (step2 < 0) unsafe("negative-step");
        if (step2 < dualStep || step2 === dualStep && (blocker === null || W[j] < blocker)) {
          dualStep = step2;
          blocker = W[j];
        }
      }
      let primalStep = Infinity;
      if (!dependent) {
        meter.take("constraintTests");
        const deficit = finite2(model2.b[p] - dot3(model2.A[p], state.u));
        primalStep = finite2(deficit / projected.delta);
        if (primalStep < 0) unsafe("negative-step");
      }
      const drop = dualStep <= primalStep, step = drop ? dualStep : primalStep;
      if (!Number.isFinite(step)) unsafe("uncertified-infeasibility");
      ctx.stepKgM = step;
      ctx.blocker = drop ? blocker : null;
      if (drop && blocker === null) unsafe("uncertified-infeasibility");
      const lambda = [...state.lambda];
      for (let j = 0; j < W.length; j++) lambda[W[j]] = finite2(lambda[W[j]] - finite2(step * r[j]));
      lambda[p] = finite2(lambda[p] + step);
      if (drop) lambda[blocker] = 0;
      const nextW = drop ? W.filter((i) => i !== blocker) : [...W, p].sort((a, b) => a - b), pending = drop ? p : null, u = reconstruct(model2, lambda);
      checkIterate(model2, u, lambda, nextW, pending, meter);
      meter.take("activeChanges");
      state = { u, lambda, W: nextW, pending };
      trace.push(traceEntry(ctx, drop ? dependent ? "dependent-drop" : "drop" : "add", state));
    }
  } catch (error2) {
    if (!(error2 instanceof CoreStop)) throw error2;
    ctx.iteration = meter.counters.iterations;
    trace.push(traceEntry(ctx, error2.status === "WORK_LIMIT" ? "work-limit" : "unsafe", state));
    return refused(error2.status, error2.reason);
  }
}

// packages/barocss-physics/src/stack/full-pair-solver.mjs
var RESULT_KEYS = ["ok", "status", "basisRows", "basisRank", "dynamicDof", "counters", "trace", "lastSafeIterate", "translations", "lambdaKgM", "primalMarginsM", "objectiveKgM2", "certificate", "infeasibilityCertificate", "reason", "worldStepped"];
var CERT_KEYS = ["primalViolationM", "negativeMultiplierKgM", "complementarityKgM2", "stationarityKgM"];
var TRACE_KEYS = ["iteration", "enteringRow", "basisBefore", "basisAfter", "action", "blocker", "stepKgM", "schurInverseKg", "condition", "exactDependent"];
var UNSAFE_REASONS = ["nonfinite", "negative-step", "negative-multiplier", "pivot", "condition", "factor-residual", "direction-residual", "near-dependent-independent", "dependent-basis", "dependency-conversion", "uncertified-infeasibility", "iterate-certificate", "result-certificate", "translation-bound"];
var WORK_REASONS = [...Object.keys(DEFAULT_LIMITS).map((k) => "budget:" + k), "cycle"];
var fail = (condition) => requireFull(condition, "result", "NUMERIC_LIMIT");
var finiteNumber = (x) => typeof x === "number" && Number.isFinite(x);
var integer = (x) => Number.isSafeInteger(x) && x >= 0;
var sameVector = (a, b) => a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
function checkedArithmetic(fn) {
  try {
    return fn();
  } catch (error2) {
    if (error2 instanceof CoreStop) requireFull(false, "result", "NUMERIC_LIMIT");
    throw error2;
  }
}
function indices(raw, n, d) {
  const a = dataArray(raw);
  fail(a !== null && a.length <= d && a.every((v, i) => integer(v) && v < n && (i === 0 || v > a[i - 1])));
  return a;
}
function numberVector(raw, size) {
  const a = dataFiniteVector(raw, size);
  fail(a !== null);
  return a;
}
function indexOrNull(value, n) {
  fail(value === null || integer(value) && value < n);
  return value;
}
function checkedCounters(raw, d, n) {
  const c = dataRecord(raw, COUNTER_KEYS);
  fail(c !== null && COUNTER_KEYS.every((k) => integer(c[k])));
  for (const k of ["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "exactIntegerOperations"]) fail(c[k] <= DEFAULT_LIMITS[k]);
  fail(c.exactPeakBits <= DEFAULT_LIMITS.intermediateIntegerBits && c.activeChanges <= c.iterations && c.rankChecks <= 2 * c.iterations && c.linearSolves <= 2 * c.iterations);
  fail(c.factorizations <= c.linearSolves && c.blockRightHandSides >= c.factorizations && c.blockRightHandSides <= (Math.min(d, n) + 1) * c.factorizations);
  if (n === 0) fail(["iterations", "activeChanges", "rankChecks", "linearSolves", "constraintTests", "factorizations", "blockRightHandSides", "exactIntegerOperations", "exactPeakBits"].every((k) => c[k] === 0));
  return { ...c };
}
function checkedTrace(raw, n, d, counters, basisRows) {
  const entries = dataArray(raw);
  fail(entries !== null && entries.length <= counters.iterations + 1);
  const trace = [];
  let previous = [], iteration = 0, changes = 0;
  for (const rawEntry of entries) {
    const e = dataRecord(rawEntry, TRACE_KEYS);
    fail(e !== null && integer(e.iteration) && e.iteration >= iteration && e.iteration <= counters.iterations);
    const before = indices(e.basisBefore, n, d), after = indices(e.basisAfter, n, d);
    fail(sameVector(before, previous));
    const enteringRow = indexOrNull(e.enteringRow, n), blocker = indexOrNull(e.blocker, n);
    fail(["add", "drop", "dependent-drop", "infeasible", "unsafe", "work-limit"].includes(e.action) && (e.exactDependent === null || typeof e.exactDependent === "boolean"));
    fail(e.stepKgM === null || finiteNumber(e.stepKgM) && e.stepKgM >= 0);
    fail(e.schurInverseKg === null || finiteNumber(e.schurInverseKg));
    fail(e.condition === null || finiteNumber(e.condition) && e.condition >= 0);
    if (e.action === "add") {
      fail(e.iteration > 0 && enteringRow !== null && !before.includes(enteringRow) && blocker === null && e.stepKgM !== null && e.exactDependent !== true);
      fail(sameVector(after, [...before, enteringRow].sort((a, b) => a - b)));
      changes++;
    } else if (e.action === "drop" || e.action === "dependent-drop") {
      fail(e.iteration > 0 && enteringRow !== null && !before.includes(enteringRow) && blocker !== null && before.includes(blocker) && e.stepKgM !== null);
      fail((e.action === "dependent-drop" ? e.exactDependent === true : e.exactDependent !== true) && sameVector(after, before.filter((i) => i !== blocker)));
      changes++;
    } else fail(sameVector(before, after));
    trace.push({ ...e, basisBefore: [...before], basisAfter: [...after] });
    previous = after;
    iteration = e.iteration;
  }
  fail(changes === counters.activeChanges && sameVector(previous, basisRows));
  return trace;
}
function checkedSafe(raw, model2, basisRows) {
  const s = dataRecord(raw, ["uDynamic", "lambdaKgM", "pendingRow", "pendingLambdaKgM", "basisRows"]);
  fail(s !== null);
  const u = numberVector(s.uDynamic, model2.dynamicDof), lambda = numberVector(s.lambdaKgM, model2.A.length), basis2 = indices(s.basisRows, model2.A.length, model2.dynamicDof), pending = indexOrNull(s.pendingRow, model2.A.length);
  fail(sameVector(basis2, basisRows) && finiteNumber(s.pendingLambdaKgM) && s.pendingLambdaKgM >= 0 && lambda.every((v) => v >= 0));
  fail(pending === null ? s.pendingLambdaKgM === 0 : !basis2.includes(pending) && Object.is(s.pendingLambdaKgM, lambda[pending]));
  const expected = checkedArithmetic(() => reconstruct(model2, lambda));
  fail(u.every((v, k) => Math.abs(v - expected[k]) <= EPS));
  checkedArithmetic(() => checkIterate(model2, u, lambda, basis2, pending, createMeter()));
  return { uDynamic: [...u], lambdaKgM: [...lambda], pendingRow: pending, pendingLambdaKgM: s.pendingLambdaKgM, basisRows: [...basis2] };
}
function checkedInfeasibility(problem, model2, raw) {
  const proof = dataRecord(raw, ["weights", "sumWeights", "dynamicDot", "boundDotM"]);
  fail(proof !== null);
  const weights = dataArray(proof.weights, problem.rows.length), dynamicDot = dataArray(proof.dynamicDot, model2.dynamicDof);
  fail(weights !== null && weights.every((v) => typeof v === "string") && dynamicDot !== null && dynamicDot.every((v) => v === "0/1") && proof.sumWeights === "1/1" && typeof proof.boundDotM === "string");
  const copied = { weights: [...weights], sumWeights: "1/1", dynamicDot: [...dynamicDot], boundDotM: proof.boundDotM };
  fail(checkedArithmetic(() => verifyInfeasibilityCertificate(problem, copied, createMeter())));
  return copied;
}
function validateFullPairResult(rawProblem, rawResult) {
  const problem = validateFullPairProblem(rawProblem);
  try {
    const model2 = checkedArithmetic(() => prepareModel(problem)), r = dataRecord(rawResult, RESULT_KEYS);
    fail(r !== null);
    fail(typeof r.ok === "boolean" && ["SOLVED", "INFEASIBLE", "NUMERIC_UNSAFE", "WORK_LIMIT"].includes(r.status) && r.worldStepped === false);
    const basisRows = indices(r.basisRows, problem.rows.length, model2.dynamicDof);
    fail(integer(r.basisRank) && r.basisRank === basisRows.length && r.dynamicDof === model2.dynamicDof);
    const counters = checkedCounters(r.counters, model2.dynamicDof, problem.rows.length), trace = checkedTrace(r.trace, problem.rows.length, model2.dynamicDof, counters, basisRows), lastSafeIterate = checkedSafe(r.lastSafeIterate, model2, basisRows);
    const common = { basisRows: [...basisRows], basisRank: basisRows.length, dynamicDof: model2.dynamicDof, counters, trace, lastSafeIterate, worldStepped: false };
    if (r.status === "SOLVED") {
      fail(r.ok === true && r.reason === null && r.infeasibilityCertificate === null && lastSafeIterate.pendingRow === null);
      const ts = dataArray(r.translations, problem.bodies.length);
      fail(ts !== null);
      const translations2 = [];
      for (let i = 0; i < ts.length; i++) {
        const t = dataRecord(ts[i], ["id", "u"]);
        fail(t !== null && t.id === problem.bodies[i].id);
        const u2 = numberVector(t.u, 3);
        fail(Math.hypot(...u2) <= 10);
        if (problem.bodies[i].inverseMass === 0) fail(u2.every((v) => Object.is(v, 0)));
        translations2.push({ id: t.id, u: [...u2] });
      }
      const lambdaKgM = numberVector(r.lambdaKgM, problem.rows.length), primalMarginsM = numberVector(r.primalMarginsM, problem.rows.length), certificate = dataRecord(r.certificate, CERT_KEYS);
      fail(certificate !== null && CERT_KEYS.every((k) => finiteNumber(certificate[k]) && certificate[k] >= 0 && certificate[k] <= EPS) && finiteNumber(r.objectiveKgM2) && r.objectiveKgM2 >= 0);
      fail(sameVector(lambdaKgM, lastSafeIterate.lambdaKgM));
      const u = translations2.flatMap((t, i) => model2.offsets[i] === null ? [] : t.u);
      fail(sameVector(u, lastSafeIterate.uDynamic));
      const actual = checkedArithmetic(() => fullCertificate(model2, u, lambdaKgM, createMeter()));
      fail(actual.primalMarginsM.every((v, i) => v >= -EPS && Math.abs(v - primalMarginsM[i]) <= EPS) && Math.abs(actual.objectiveKgM2 - r.objectiveKgM2) <= EPS);
      fail(CERT_KEYS.every((k) => actual.certificate[k] <= EPS && Math.abs(actual.certificate[k] - certificate[k]) <= EPS));
      return { ok: true, status: "SOLVED", ...common, translations: translations2, lambdaKgM: [...lambdaKgM], primalMarginsM: [...primalMarginsM], objectiveKgM2: r.objectiveKgM2, certificate: { ...certificate }, infeasibilityCertificate: null, reason: null };
    }
    fail(r.ok === false && ["translations", "lambdaKgM", "primalMarginsM", "objectiveKgM2", "certificate"].every((k) => r[k] === null));
    let infeasibilityCertificate = null;
    if (r.status === "INFEASIBLE") {
      fail(r.reason === null);
      infeasibilityCertificate = checkedInfeasibility(problem, model2, r.infeasibilityCertificate);
    } else {
      fail(r.infeasibilityCertificate === null);
      fail((r.status === "NUMERIC_UNSAFE" ? UNSAFE_REASONS : WORK_REASONS).includes(r.reason));
    }
    return { ok: false, status: r.status, ...common, translations: null, lambdaKgM: null, primalMarginsM: null, objectiveKgM2: null, certificate: null, infeasibilityCertificate, reason: r.reason };
  } catch (error2) {
    throw error2;
  }
}
function solveFullPairPosition(problem) {
  return validateFullPairResult(problem, runFullPairCore(problem, DEFAULT_LIMITS));
}

// packages/barocss-physics/src/stack/full-pair-rows.ts
var FULL_PAIR_ERRORS = {
  INPUT: "private full-pair position input is invalid",
  PROFILE: "private full-pair position profile is unsupported",
  RANGE: "private full-pair position signed bound exceeds the admitted range",
  GEOMETRY: "private full-pair position requires fresh matching box geometry",
  INFEASIBLE: "private full-pair position constraints are infeasible",
  NUMERIC_UNSAFE: "private full-pair position solve is numerically unsafe",
  WORK_LIMIT: "private full-pair position solve exceeded its work limit",
  RESULT: "private full-pair position result is invalid",
  NONPENETRATION: "private full-pair position result left an overlapping pair"
};
function refuse(key) {
  throw new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS[key]);
}
function mapFullPairError(error2) {
  try {
    if (error2 instanceof FullPairPositionReferenceError) {
      if (error2.code === "PROFILE_LIMIT" && error2.message === MESSAGES.limit) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.PROFILE);
      }
      if (error2.code === "INVALID_INPUT" && [
        MESSAGES.input,
        MESSAGES.empty,
        MESSAGES.ids,
        MESSAGES.mass,
        MESSAGES.endpoints,
        MESSAGES.normal,
        MESSAGES.bound,
        MESSAGES.workLimits
      ].includes(error2.message)) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.INPUT);
      }
      if (error2.code === "NUMERIC_LIMIT" && error2.message === MESSAGES.result) {
        return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.RESULT);
      }
    }
    if (error2 instanceof PhysicsError && (error2.code === "INVALID_CONFIG" && error2.message === FEATURE_INPUT_MESSAGE2 || error2.code === "NUMERIC_LIMIT" && error2.message === AXIS_MESSAGE)) {
      return new PhysicsError("NUMERIC_LIMIT", FULL_PAIR_ERRORS.GEOMETRY);
    }
  } catch {
  }
  return error2;
}
function ordinaryDense(value, size) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && (size === void 0 || value.length === size) && Reflect.ownKeys(value).length === value.length + 1 && Array.from({ length: value.length }, (_, i) => i).every((i) => {
    const descriptor = Object.getOwnPropertyDescriptor(value, i);
    return descriptor !== void 0 && "value" in descriptor;
  });
}
function finiteVector(value, size, bound = Infinity) {
  return ordinaryDense(value, size) && value.every((v) => typeof v === "number" && Number.isFinite(v) && Math.abs(v) <= bound);
}
function record(value) {
  return value !== null && typeof value === "object";
}
function checkedFullPairInputs(bodies, pairs) {
  if (!ordinaryDense(bodies) || !ordinaryDense(pairs) || bodies.length === 0) refuse("INPUT");
  if (bodies.length > 9 || pairs.length > 36) refuse("PROFILE");
  const ids = /* @__PURE__ */ new Set();
  for (const body of bodies) {
    if (!record(body) || typeof body.id !== "string" || !ID.test(body.id) || ids.has(body.id) || !finiteVector(body.positionM, 3) || !finiteVector(body.velocityMps, 3) || !finiteVector(body.orientation, 4) || !finiteVector(body.angularVelocityRadps, 3) || typeof body.inverseMass !== "number" || !Number.isFinite(body.inverseMass)) refuse("INPUT");
    ids.add(body.id);
    if (body.kind !== "dynamic" && body.kind !== "static" || body.shape?.kind !== "box" || body.sensor || body.ccd || body.collisionFilter || !finiteVector(body.shape.halfExtentsM, 3, 1e3) || body.shape.halfExtentsM.some((v) => v < 1e-4) || body.restitution !== 0 || !finiteVector(body.inverseInertiaLocal, 3) || body.inverseInertiaLocal.some((v) => v < 0) || (body.kind === "static" ? body.inverseMass !== 0 : body.inverseMass < 1e-6 || body.inverseMass > 1e6)) {
      refuse("PROFILE");
    }
  }
  validateResult(bodies, []);
  const expected = [];
  for (let a = 0; a < bodies.length; a++) for (let b = a + 1; b < bodies.length; b++) {
    if (bodies[a].inverseMass !== 0 || bodies[b].inverseMass !== 0) {
      expected.push(bodies[a].id < bodies[b].id ? [a, b] : [b, a]);
    }
  }
  expected.sort((l, r) => bodies[l[0]].id < bodies[r[0]].id ? -1 : bodies[l[0]].id > bodies[r[0]].id ? 1 : bodies[l[1]].id < bodies[r[1]].id ? -1 : 1);
  if (pairs.length !== expected.length || pairs.some((p, i) => !ordinaryDense(p, 2) || p[0] !== expected[i][0] || p[1] !== expected[i][1])) refuse("INPUT");
}
function pairKey(bodies, a, b) {
  return `${bodies[a].id}\0${bodies[b].id}`;
}
function compactSelection(full) {
  return {
    normal: [...full.normal],
    boundM: full.boundM,
    candidateIndex: full.candidateIndex,
    pointM: [...full.pointM],
    rawAxisLength: full.rawAxisLength,
    label: full.label,
    feature: { ...full.feature }
  };
}
function freshSelection(a, b) {
  return compactSelection(inspectSignedBoxSAT(a, b));
}
function buildFullPairProblem(bodies, pairs, capture) {
  checkedFullPairInputs(bodies, pairs);
  const result = capture ?? {
    problem: { bodies: bodies.map((b) => ({ id: b.id, inverseMass: b.inverseMass })), rows: [] },
    rowSources: [],
    initialDetections: [],
    pairObservations: [],
    tests: 0,
    hits: 0,
    signedPreQueries: 0
  };
  for (const [aIndex, bIndex] of pairs) {
    const a = bodies[aIndex], b = bodies[bIndex], key = pairKey(bodies, aIndex, bIndex);
    result.tests++;
    const hit = detect(a, b);
    result.initialDetections.push({ pairKey: key, aIndex, bIndex, hit: hit ? structuredClone(hit) : null });
    if (hit !== null) result.hits++;
    result.signedPreQueries++;
    const selection = freshSelection(a, b);
    result.pairObservations.push({ pairKey: key, aIndex, bIndex, selection });
    if (hit !== null && (!hit.normal.every((v, d) => v === selection.normal[d]) || Math.max(0, selection.boundM) !== hit.penetration)) refuse("GEOMETRY");
    result.rowSources.push({
      rowIndex: result.problem.rows.length,
      pairKey: key,
      aIndex,
      bIndex,
      selection: structuredClone(selection)
    });
    result.problem.rows.push({
      aId: a.id,
      bId: b.id,
      normal: [...selection.normal],
      boundM: selection.boundM
    });
  }
  if (result.pairObservations.some((p) => p.selection.boundM < -10 || p.selection.boundM > 10)) refuse("RANGE");
  return result;
}
function inspectFullPairHypothesis(bodies, pairs, capture = [], progress) {
  for (const [aIndex, bIndex] of pairs) {
    if (progress) progress.postPairTests++;
    capture.push({
      pairKey: pairKey(bodies, aIndex, bIndex),
      aIndex,
      bIndex,
      selection: freshSelection(bodies[aIndex], bodies[bIndex])
    });
  }
  return capture;
}

// packages/barocss-physics/src/stack/full-pair-apply.ts
function same(a, b) {
  if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return Object.is(a, b);
  const ka = Reflect.ownKeys(a), kb = Reflect.ownKeys(b);
  return ka.length === kb.length && ka.every((k) => kb.includes(k) && same(Reflect.get(a, k), Reflect.get(b, k)));
}
function vector(value, size) {
  return ordinaryDense(value, size) && value.every((x) => typeof x === "number" && Number.isFinite(x));
}
function applyFullPairTranslationsOnce(preBodies, problem, result) {
  try {
    const checked2 = validateFullPairResult(problem, result);
    if (checked2.status !== "SOLVED" || checked2.ok !== true || !ordinaryDense(preBodies) || preBodies.length < 1 || preBodies.length > 9 || problem.bodies.length !== preBodies.length) refuse("RESULT");
    for (let i = 0; i < preBodies.length; i++) {
      const body = preBodies[i];
      if (!body || body.id !== problem.bodies[i].id || body.inverseMass !== problem.bodies[i].inverseMass || !vector(body.positionM, 3) || !vector(body.velocityMps, 3) || !vector(body.orientation, 4) || !vector(body.angularVelocityRadps, 3)) refuse("RESULT");
    }
    validateResult(preBodies, []);
    const bodies = preBodies.map(copyBody), rounding = [];
    for (let i = 0; i < preBodies.length; i++) {
      const before = preBodies[i], body = bodies[i], u = checked2.translations[i].u;
      if (Math.hypot(...u) > 10 || before.inverseMass === 0 && !u.every((v) => v === 0)) refuse("RESULT");
      const roundedFinalM = before.inverseMass === 0 ? [...before.positionM] : before.positionM.map((v, j) => v + u[j]);
      if (!roundedFinalM.every(Number.isFinite)) refuse("RESULT");
      body.positionM = roundedFinalM;
      const actualDeltaM = body.positionM.map((v, j) => v - before.positionM[j]);
      if (before.inverseMass === 0 && (!u.every((v) => v === 0) || !same(body, before))) refuse("RESULT");
      if (!same({ ...body, positionM: before.positionM }, before)) refuse("RESULT");
      rounding.push({
        id: body.id,
        nominalTranslationM: [...u],
        roundedFinalM: [...roundedFinalM],
        actualDeltaM,
        nominalActualDeltaDifferenceM: actualDeltaM.map((v, j) => v - u[j]),
        exactRoundedFinalMatch: true,
        staticPositionAdditionPerformed: false,
        dynamicPositionAdditionPerformed: before.inverseMass > 0
      });
    }
    validateResult(bodies, []);
    return {
      bodies: bodies.map(copyBody),
      rounding: structuredClone(rounding),
      applications: 1,
      worldCreated: false,
      worldStepped: false
    };
  } catch (error2) {
    throw mapFullPairError(error2);
  }
}

// packages/barocss-physics/src/stack/full-pair-phase.ts
var PositionPhaseFailure = class extends PhysicsError {
  stats;
  attempt;
  constructor(reason, stats2, attempt) {
    super(reason.code, reason.message);
    this.stats = structuredClone(stats2);
    this.attempt = structuredClone(attempt);
  }
};
function zeroFullPairPositionStats() {
  return {
    tests: 0,
    hits: 0,
    rows: 0,
    signedPreQueries: 0,
    solverCalls: 0,
    postPairTests: 0,
    maxTranslationM: 0,
    workingApplicationCount: 0,
    solverCounters: {
      iterations: 0,
      activeChanges: 0,
      rankChecks: 0,
      linearSolves: 0,
      constraintTests: 0,
      factorizations: 0,
      blockRightHandSides: 0,
      exactIntegerOperations: 0,
      exactPeakBits: 0
    },
    certificate: null
  };
}
function errorRecord(error2) {
  let result = {
    kind: "unexpected-error",
    name: "ThrownValue",
    message: "Unexpected non-Error exception"
  };
  try {
    if (error2 instanceof Error) result = { kind: "unexpected-error", name: error2.name, message: error2.message };
    if (error2 instanceof PhysicsError) {
      result = { kind: "typed-refusal", name: error2.name, code: error2.code, message: error2.message };
    }
  } catch {
  }
  return result;
}
function runFullPairPositionPhase(workingBodies, sortedPairs) {
  const stats2 = zeroFullPairPositionStats();
  const attempt = {
    preBodies: [],
    pairs: [],
    initialDetections: [],
    pairObservations: [],
    problem: null,
    rowSources: [],
    result: null,
    hypotheticalBodies: null,
    rounding: null,
    finalPairObservations: [],
    failurePair: null,
    workingApplicationCount: 0,
    error: null
  };
  const capture = {
    problem: { bodies: [], rows: [] },
    rowSources: attempt.rowSources,
    initialDetections: attempt.initialDetections,
    pairObservations: attempt.pairObservations,
    tests: 0,
    hits: 0,
    signedPreQueries: 0
  };
  const updatePreStats = () => {
    stats2.tests = capture.tests;
    stats2.hits = capture.hits;
    stats2.rows = capture.problem.rows.length;
    stats2.signedPreQueries = capture.signedPreQueries;
  };
  try {
    checkedFullPairInputs(workingBodies, sortedPairs);
    attempt.preBodies = workingBodies.map(copyBody);
    attempt.pairs = sortedPairs.map(([a, b]) => [a, b]);
    capture.problem.bodies = attempt.preBodies.map((b) => ({ id: b.id, inverseMass: b.inverseMass }));
    attempt.problem = capture.problem;
    buildFullPairProblem(attempt.preBodies, attempt.pairs, capture);
    updatePreStats();
    const problem = validateFullPairProblem(capture.problem);
    stats2.solverCalls++;
    const raw = solveFullPairPosition(structuredClone(problem));
    const checked2 = validateFullPairResult(problem, raw);
    attempt.result = checked2;
    stats2.solverCounters = structuredClone(checked2.counters);
    if (checked2.status === "INFEASIBLE") refuse("INFEASIBLE");
    if (checked2.status === "NUMERIC_UNSAFE") refuse("NUMERIC_UNSAFE");
    if (checked2.status === "WORK_LIMIT") refuse("WORK_LIMIT");
    if (checked2.status !== "SOLVED" || checked2.ok !== true) refuse("RESULT");
    stats2.maxTranslationM = Math.max(0, ...checked2.translations.map((t) => Math.hypot(...t.u)));
    stats2.certificate = structuredClone(checked2.certificate);
    const applied = applyFullPairTranslationsOnce(attempt.preBodies, problem, checked2);
    attempt.hypotheticalBodies = applied.bodies;
    attempt.rounding = applied.rounding;
    inspectFullPairHypothesis(applied.bodies, attempt.pairs, attempt.finalPairObservations, stats2);
    attempt.failurePair = attempt.finalPairObservations.find((p) => p.selection.boundM > 1e-12)?.pairKey ?? null;
    if (attempt.failurePair !== null) refuse("NONPENETRATION");
  } catch (caught) {
    updatePreStats();
    const error2 = mapFullPairError(caught);
    const record2 = errorRecord(error2);
    if (attempt.failurePair === null && record2.kind === "typed-refusal" && record2.code === "NUMERIC_LIMIT" && record2.message === FULL_PAIR_ERRORS.RANGE) {
      attempt.failurePair = attempt.pairObservations.find((p) => p.selection.boundM < -10 || p.selection.boundM > 10)?.pairKey ?? null;
    }
    attempt.error = record2;
    if (error2 instanceof PhysicsError) throw new PositionPhaseFailure(error2, stats2, attempt);
    throw error2;
  }
  for (let i = 0; i < workingBodies.length; i++) if (workingBodies[i].inverseMass > 0) {
    workingBodies[i].positionM = [...attempt.hypotheticalBodies[i].positionM];
  }
  attempt.workingApplicationCount = 1;
  stats2.workingApplicationCount = 1;
  return { stats: structuredClone(stats2), attempt: structuredClone(attempt) };
}

// packages/barocss-physics/src/stack/frictionless-island.ts
var FrictionlessIslandFailure = class extends PhysicsError {
  diagnostics;
  constructor(reason, diagnostics) {
    super(reason.code, reason.message);
    this.diagnostics = structuredClone(diagnostics);
  }
};
var SI = 1e-10;
function need2(ok, message) {
  if (!ok) throw new PhysicsError("NUMERIC_LIMIT", "frictionless island: " + message);
}
function finite3(value) {
  need2(Number.isFinite(value), "finite validation arithmetic");
  return value;
}
function maximum(values) {
  return values.reduce((value, next) => Math.max(value, Math.abs(finite3(next))), 0);
}
function pairKey2(a, b) {
  return a.id + "\0" + b.id;
}
function velocityAt(body, point2) {
  return add(body.velocityMps, cross(body.angularVelocityRadps, sub(point2, body.positionM)));
}
function worldInverse(body) {
  if (body.inverseMass === 0) return [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  const local = body.inverseInertiaLocal;
  if (local[0] === local[1] && local[1] === local[2]) {
    const c = local[0];
    return [[c, 0, 0], [0, c, 0], [0, 0, c]];
  }
  const columns = [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => inverseInertia(body, axis));
  return [
    [columns[0][0], columns[1][0], columns[2][0]],
    [columns[0][1], columns[1][1], columns[2][1]],
    [columns[0][2], columns[1][2], columns[2][2]]
  ];
}
function normalBody(body) {
  return {
    id: body.id,
    positionM: [...body.positionM],
    velocityMps: [...body.velocityMps],
    angularVelocityRadps: [...body.angularVelocityRadps],
    inverseMass: body.inverseMass,
    inverseInertiaWorld: worldInverse(body)
  };
}
function validationFactor(matrix) {
  const lower = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  const magnitude = Math.max(1, ...matrix.flat().map(Math.abs));
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++)
    need2(matrix[i][j] === matrix[j][i], "actual inverse inertia symmetry");
  for (let i = 0; i < 3; i++) for (let j = 0; j <= i; j++) {
    let value = matrix[i][j];
    for (let k = 0; k < j; k++) value = finite3(value - finite3(lower[i][k] * lower[j][k]));
    if (i === j) {
      need2(value > 1e-12 * magnitude, "actual inverse inertia positive definite");
      lower[i][j] = Math.sqrt(value);
    } else lower[i][j] = finite3(value / lower[j][j]);
  }
  return lower;
}
function whiten(factor2, angularVelocity) {
  const out = [];
  for (let i = 0; i < 3; i++) {
    let value = angularVelocity[i];
    for (let j = 0; j < i; j++) value = finite3(value - finite3(factor2[i][j] * out[j]));
    out.push(finite3(value / factor2[i][i]));
  }
  return out;
}
function validateApplied(free, applied, problem, solved, applications) {
  need2(solved.ok && solved.normalImpulsesNs && solved.bodies.length === free.length, "complete normal solve");
  const result = {
    maxClosingNormalSpeedMps: 0,
    maxComplementarityJ: 0,
    maxStationaritySqrtJ: 0,
    maxSolverVelocityDifference: 0,
    maxLinearMomentumResidualNs: 0,
    maxAngularMomentumResidualNms: 0,
    postValidationCholeskyFactorizations: 0
  };
  const linear = free.map(() => [0, 0, 0]), angular = free.map(() => [0, 0, 0]);
  for (const entry of applications) {
    const application = entry.contribution.applications[0];
    need2(application && entry.contribution.applications.length === 1, "one actual point application");
    for (const [index, side2] of [[entry.aIndex, application.onA], [entry.bIndex, application.onB]]) {
      linear[index] = add(linear[index], side2.linearImpulseNs);
      angular[index] = add(angular[index], side2.armTorqueNms);
    }
  }
  const ids = new Map(free.map((body, index) => [body.id, index]));
  for (let i = 0; i < free.length; i++) {
    need2(applied[i].id === free[i].id && solved.bodies[i].id === free[i].id, "body order retained");
    if (free[i].inverseMass === 0) continue;
    const factor2 = validationFactor(problem.bodies[i].inverseInertiaWorld);
    result.postValidationCholeskyFactorizations++;
    const rootMass = Math.sqrt(free[i].inverseMass);
    const oldAngular = whiten(factor2, free[i].angularVelocityRadps);
    const newAngular = whiten(factor2, applied[i].angularVelocityRadps);
    const reaction = [0, 0, 0, 0, 0, 0];
    for (let p = 0; p < problem.points.length; p++) {
      const point2 = problem.points[p], lambda = solved.normalImpulsesNs[p];
      const sign = point2.aId === free[i].id ? -1 : point2.bId === free[i].id ? 1 : 0;
      if (!sign) continue;
      const n = [...point2.normalAtoB];
      const torque = cross(sub([...point2.pointM], free[i].positionM), n);
      for (let k = 0; k < 3; k++) {
        reaction[k] = finite3(reaction[k] + finite3(finite3(sign * n[k] * rootMass) * lambda));
        let coefficient = 0;
        for (let j = 0; j < 3; j++) coefficient = finite3(coefficient + finite3(torque[j] * factor2[j][k]));
        reaction[k + 3] = finite3(reaction[k + 3] + finite3(finite3(sign * coefficient) * lambda));
      }
    }
    const residual = [0, 1, 2].map((k) => finite3(applied[i].velocityMps[k] / rootMass - free[i].velocityMps[k] / rootMass - reaction[k]));
    for (let k = 0; k < 3; k++) residual.push(finite3(newAngular[k] - oldAngular[k] - reaction[k + 3]));
    result.maxStationaritySqrtJ = Math.max(result.maxStationaritySqrtJ, maximum(residual));
    result.maxSolverVelocityDifference = Math.max(
      result.maxSolverVelocityDifference,
      maximum(sub(applied[i].velocityMps, [...solved.bodies[i].velocityMps])),
      maximum(sub(applied[i].angularVelocityRadps, [...solved.bodies[i].angularVelocityRadps]))
    );
    result.maxLinearMomentumResidualNs = Math.max(
      result.maxLinearMomentumResidualNs,
      maximum(sub(scale(sub(applied[i].velocityMps, free[i].velocityMps), 1 / free[i].inverseMass), linear[i]))
    );
    result.maxAngularMomentumResidualNms = Math.max(
      result.maxAngularMomentumResidualNms,
      maximum(sub(inertia(free[i], sub(applied[i].angularVelocityRadps, free[i].angularVelocityRadps)), angular[i]))
    );
  }
  for (let p = 0; p < problem.points.length; p++) {
    const point2 = problem.points[p], a = ids.get(point2.aId), b = ids.get(point2.bId);
    need2(a !== void 0 && b !== void 0, "normal endpoints retained");
    const relative = sub(velocityAt(applied[b], [...point2.pointM]), velocityAt(applied[a], [...point2.pointM]));
    const speed = finite3(dot(relative, [...point2.normalAtoB]));
    result.maxClosingNormalSpeedMps = Math.max(result.maxClosingNormalSpeedMps, -speed);
    result.maxComplementarityJ = Math.max(result.maxComplementarityJ, Math.abs(finite3(speed * solved.normalImpulsesNs[p])));
  }
  for (const key of [
    "maxClosingNormalSpeedMps",
    "maxComplementarityJ",
    "maxStationaritySqrtJ",
    "maxSolverVelocityDifference",
    "maxLinearMomentumResidualNs",
    "maxAngularMomentumResidualNms"
  ])
    need2(Number.isFinite(result[key]) && result[key] <= SI, "actual applied normal certificate: " + key);
  return result;
}
function representative(a, b, geometry) {
  const mean = scale(geometry.points.reduce((sum, point2) => add(sum, point2.midpointM), [0, 0, 0]), 1 / geometry.points.length);
  const exact = new StrictLineContext(a, b, geometry.planeNormalAtoB);
  need2(exact.check(mean), "post representative strict line");
  if (geometry.family === "face") {
    const reference = geometry.reference;
    need2(reference, "post face selectors");
    const ref = { axis: reference.axis, side: reference.side };
    const inc = { axis: reference.incidentAxis, side: reference.incidentSide };
    const faceA = reference.body === "a" ? ref : inc, faceB = reference.body === "a" ? inc : ref;
    need2(
      exact.selectedFaceBounds(mean, faceA, faceB) && exact.onFace(0, faceA, mean) && exact.onFace(1, faceB, mean),
      "post representative finite boundary faces"
    );
  }
  return mean;
}
function prepareFrictionlessIsland(freeBodies, pairs, context2) {
  const diagnostics = {
    freeBodies: [],
    pairs: [],
    freeGeometry: [],
    normalProblem: null,
    normalResult: null,
    applications: [],
    velocityBodies: null,
    appliedNormalCertificate: null,
    positionAttempt: null,
    positionStats: null,
    postGeometry: [],
    pairContributions: [],
    normalSolverCalls: 0,
    positionPhaseCalls: 0,
    positionSolverCalls: 0
  };
  try {
    need2(context2 && context2.jointCount === 0, "no joints");
    need2(Array.isArray(freeBodies) && freeBodies.length >= 1 && freeBodies.length <= 4 && freeBodies.every((body) => body !== null && typeof body === "object") && freeBodies.some((body) => body.kind === "dynamic"), "existing persistent body bound");
    checkedFullPairInputs(freeBodies, pairs);
    for (const body of freeBodies) need2(
      body.frictionStatic === 0 && body.frictionDynamic === 0 && body.restitution === 0 && !body.sleeping && !body.sensor && !body.ccd && !body.collisionFilter,
      "zero-friction zero-restitution unfiltered awake boxes"
    );
    for (const body of freeBodies) if (body.kind === "static")
      need2(body.inverseInertiaLocal.every((value) => value === 0), "prescribed static inverse inertia");
    const working = freeBodies.map(copyBody);
    diagnostics.freeBodies = working.map(copyBody);
    diagnostics.pairs = pairs.map(([a, b]) => [a, b]);
    const points = [];
    for (const [aIndex, bIndex] of pairs) {
      const a = working[aIndex], b = working[bIndex], hit = detect(a, b);
      if (!hit) continue;
      const geometry = featureContact(a, b);
      need2(geometry && geometry.points.length > 0, "actual free contact geometry");
      const key = pairKey2(a, b);
      diagnostics.freeGeometry.push({
        aIndex,
        bIndex,
        aId: a.id,
        bId: b.id,
        pairKey: key,
        hit: structuredClone(hit),
        geometry
      });
      for (const point2 of geometry.points) points.push({
        id: JSON.stringify([key, point2.key]),
        aId: a.id,
        bId: b.id,
        pointM: [...point2.midpointM],
        normalAtoB: [...geometry.planeNormalAtoB]
      });
    }
    need2(points.length <= 32, "existing normal point bound");
    const problem = { bodies: working.map(normalBody), points };
    diagnostics.normalProblem = problem;
    diagnostics.normalSolverCalls++;
    const solved = solveNormalContacts(problem);
    diagnostics.normalResult = solved;
    if (!solved.ok) throw new PhysicsError(
      solved.status === "ITERATION_LIMIT" ? "ITERATION_LIMIT" : "NUMERIC_LIMIT",
      "frictionless island normal: " + solved.reason
    );
    need2(
      solved.status === "SOLVED_NORMAL_ONLY" && solved.normalImpulsesNs && solved.normalImpulsesNs.length === points.length,
      "complete global normal solve"
    );
    const totals = new ContactPairAccumulator(), byId = new Map(working.map((body, index) => [body.id, index]));
    let pointIndex = 0;
    for (const patch of diagnostics.freeGeometry) for (const point2 of patch.geometry.points) {
      const a = working[patch.aIndex], b = working[patch.bIndex], lambda = solved.normalImpulsesNs[pointIndex];
      need2(
        Number.isFinite(lambda) && lambda >= 0 && problem.points[pointIndex].id === JSON.stringify([patch.pairKey, point2.key]),
        "nonnegative actual point impulse/link"
      );
      const n = [...patch.geometry.planeNormalAtoB];
      const pointM = [...point2.midpointM], onB = scale(n, lambda);
      const armA = sub(pointM, a.positionM), armB = sub(pointM, b.positionM);
      const contribution = contactApplication(a.positionM, b.positionM, armA, armB, onB);
      const actual = contribution.applications[0];
      diagnostics.applications.push({
        id: problem.points[pointIndex].id,
        aIndex: patch.aIndex,
        bIndex: patch.bIndex,
        pairKey: patch.pairKey,
        pointKey: point2.key,
        pointM,
        normalAtoB: n,
        normalImpulseNs: lambda,
        contribution
      });
      totals.add(a.id, b.id, contribution);
      if (lambda !== 0) {
        for (const [body, side2] of [[a, actual.onA], [b, actual.onB]]) if (body.inverseMass !== 0) {
          body.velocityMps = add(body.velocityMps, scale(side2.linearImpulseNs, body.inverseMass));
          body.angularVelocityRadps = add(body.angularVelocityRadps, inverseInertia(body, side2.armTorqueNms));
        }
      }
      pointIndex++;
    }
    need2(pointIndex === points.length, "every normal point applied exactly once");
    diagnostics.pairContributions = totals.finish();
    diagnostics.velocityBodies = working.map(copyBody);
    validateResult(working, []);
    diagnostics.appliedNormalCertificate = validateApplied(diagnostics.freeBodies, working, problem, solved, diagnostics.applications);
    diagnostics.positionPhaseCalls++;
    diagnostics.positionSolverCalls = null;
    try {
      const position = runFullPairPositionPhase(working, pairs);
      diagnostics.positionAttempt = position.attempt;
      diagnostics.positionStats = position.stats;
      diagnostics.positionSolverCalls = position.stats.solverCalls;
    } catch (error2) {
      if (error2 instanceof PositionPhaseFailure) {
        diagnostics.positionAttempt = error2.attempt;
        diagnostics.positionStats = error2.stats;
        diagnostics.positionSolverCalls = error2.stats.solverCalls;
      }
      throw error2;
    }
    const impulseTotals = /* @__PURE__ */ new Map();
    for (const application of diagnostics.applications)
      impulseTotals.set(application.pairKey, finite3((impulseTotals.get(application.pairKey) ?? 0) + application.normalImpulseNs));
    const freePenetrations = new Map(diagnostics.freeGeometry.map((patch) => [patch.pairKey, patch.hit?.penetration ?? 0]));
    const contacts = [], retained = /* @__PURE__ */ new Set();
    for (const [aIndex, bIndex] of pairs) {
      const a = working[aIndex], b = working[bIndex], key = pairKey2(a, b);
      const geometry = featureContact(a, b);
      if (!geometry) {
        need2((impulseTotals.get(key) ?? 0) === 0, "applied pair needs fresh post witness");
        continue;
      }
      diagnostics.postGeometry.push({
        aIndex,
        bIndex,
        aId: a.id,
        bId: b.id,
        pairKey: key,
        hit: detect(a, b),
        geometry
      });
      for (const point2 of geometry.points) {
        const speed = finite3(dot(sub(velocityAt(b, point2.midpointM), velocityAt(a, point2.midpointM)), geometry.planeNormalAtoB));
        need2(speed >= -SI, "fresh post contact normal feasibility");
      }
      const mean = representative(a, b, geometry);
      contacts.push({
        aId: a.id,
        bId: b.id,
        normalAtoB: [...geometry.planeNormalAtoB],
        pointM: mean,
        penetrationM: freePenetrations.get(key) ?? 0,
        impulseNs: impulseTotals.get(key) ?? 0,
        tangentImpulseNs: [0, 0, 0]
      });
      retained.add(key);
    }
    for (const [key, impulse] of impulseTotals) need2(impulse === 0 || retained.has(key), "all applied pair summaries retained");
    need2(byId.size === working.length, "body identity retained");
    validateResult(working, contacts);
    return {
      candidateBodies: working.map(copyBody),
      contacts,
      pairStats: {
        eligiblePairs: pairs.length,
        candidatePairs: pairs.length,
        aabbTests: 0
      },
      pairContributions: structuredClone(diagnostics.pairContributions),
      diagnostics: structuredClone(diagnostics)
    };
  } catch (caught) {
    if (caught instanceof StrictLineFailure) throw new FrictionlessIslandFailure(
      new PhysicsError("NUMERIC_LIMIT", "frictionless island post representative strict-line refusal"),
      diagnostics
    );
    if (caught instanceof PhysicsError) throw new FrictionlessIslandFailure(caught, diagnostics);
    throw caught;
  }
}
export {
  FrictionlessIslandFailure,
  prepareFrictionlessIsland
};
