"""Check supplied exact KKT by matrix-vector identities and independent Hamilton wrench."""
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

PATH = Path(__file__).with_name('oracle.py')
if hashlib.sha256(PATH.read_bytes()).hexdigest() != '65d26e05a8f0971005104437403d075ad044252f7137edfe2df85e799aa47a6a':
    raise RuntimeError('IMMUTABLE_PHYSICAL_PRIMITIVES_PIN')
SPEC = importlib.util.spec_from_file_location('independent_coherence_physical_primitives', PATH)
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)
q, vec, add, sub, scale, dot, mv = P.q, P.vec, P.add, P.sub, P.scale, P.dot, P.mv
SI, GEOM = P.SI, P.GEOM


def ratio(value):
    P.need(type(value) is dict and set(value) == {'n', 'd'}, 'canonical ratio fields')
    n, d = value['n'], value['d']
    P.need(type(n) is str and type(d) is str and 1 <= len(n) <= 5000 and 1 <= len(d) <= 5000,
           'bounded ratio text')
    def decimal_integer(text):
        negative = text.startswith('-')
        digits = text[1:] if negative else text
        P.need(digits and all('0' <= c <= '9' for c in digits) and
               (digits == '0' or digits[0] != '0') and not (negative and digits == '0'), 'canonical ratio decimal')
        number = 0
        for at in range(0, len(digits), 9):
            block = digits[at:at+9]
            number = number*10**len(block)+int(block)
            P.need(number.bit_length() <= 16384, 'ratio bit bound')
        return -number if negative else number
    numerator, denominator = decimal_integer(n), decimal_integer(d)
    P.need(denominator > 0, 'positive ratio denominator')
    result = P.checked(F(numerator, denominator))
    P.need(result.numerator == numerator and result.denominator == denominator, 'reduced ratio')
    return result


def ratios(value, length):
    P.need(type(value) is list and len(value) == length, 'ratio vector population')
    return [ratio(x) for x in value]


def cross_float(x, y):
    # Explicit binary64 operand provenance only. Physical torque below uses exact Hamilton.
    return [x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0]]


def same(x, y):
    return x == y and P.words(x) == P.words(y)


def verify(data):
    P.need(set(data) == {'caseId', 'input', 'candidate'} and data['caseId'] in ('support1', 'impact27', 'tilted490'), 'fixed actual input bank')
    before, result = data['input'], data['candidate']
    free, pairs = before['freeBodies'], before['pairs']
    P.need(before['context'] == {'jointCount': 0} and len(free) == 4 and len(pairs) == 6, 'fixed full-pair input')
    diagnostic = result['diagnostics']
    P.need(same(diagnostic['integratedFreeBodies'], free) and same(diagnostic['pairs'], pairs), 'actual FREE word authority')
    actual = diagnostic['normalInputBodies']
    P.need(same(actual, diagnostic['positionCandidateBodies']) and same(diagnostic['positionAttempt']['preBodies'], free) and
           same(actual, diagnostic['positionAttempt']['hypotheticalBodies']), 'projected normal input authority')
    P.need(diagnostic['normalSolverCalls'] == diagnostic['positionPhaseCalls'] == diagnostic['positionSolverCalls'] == diagnostic['exactRefinementCalls'] == 1,
           'one QR proposal position and exact reconstruction')
    ids = [body['id'] for body in actual]
    P.need(len(set(ids)) == 4, 'unique actual IDs')
    offsets = {index: 6*k for k, index in enumerate(i for i, body in enumerate(actual) if q(body['inverseMass']) > 0)}
    size = 6*len(offsets)
    P.need(0 < size <= 24, 'dynamic bound')
    problem, proposal, exact = diagnostic['normalProblem'], diagnostic['qrSupportProposal'], diagnostic['exactNormalResult']
    P.need(proposal['ok'] is True and proposal['status'] == 'SOLVED_NORMAL_ONLY', 'actual QR proposal only')
    P.need(exact['ok'] is True and exact['status'] == 'EXACT_KKT_PHYSICAL_AGGREGATE', 'distinct exact result')
    P.need(result['reportingSemantics'] == exact['roundedReporting']['semantics'] == 'ROUNDED_REPORT_ONLY_NOT_BODY_MUTATION', 'honest rounded-report labeling')
    P.need(same(exact['appliedBodies'], result['candidateBodies']) and same(result['candidateBodies'], diagnostic['impulseAppliedBodies']), 'actual final physical application frame')
    final = result['candidateBodies']
    points, rows = problem['points'], []
    count = len(points)
    P.need(len(problem['bodies']) == len(final) == len(exact['roundedReporting']['qpBodies']) == 4 and
           len({point['id'] for point in points}) == count, 'complete unique normal body/point schema')
    P.need(count <= 32 and len(exact['representedRows']) == count and len(exact['exactApplications']) == count,
           'all original point/row/application populations')
    metric = [[F(0)]*size for _ in range(size)]
    physical_inverse, physical_inertia = {}, {}
    free_motion, actual_motion = [], []
    violations, maxima = [], {}

    def gate(name, residual, limit=SI, **details):
        value = abs(residual)
        maxima[name] = max(maxima.get(name, F(0)), value)
        if value > limit and len(violations) < 32:
            violations.append({'gate': name, 'residual': float(value), 'limit': float(limit), **details})

    def exact_gate(name, condition, **details):
        if not condition and len(violations) < 32:
            violations.append({'gate': name, **details})

    for index, (body, previous, out, normal) in enumerate(zip(actual, free, final, problem['bodies'])):
        P.need(body['id'] == out['id'] == normal['id'] == ids[index], 'complete body order')
        P.need(same({k:v for k,v in previous.items() if k != 'positionM'}, {k:v for k,v in body.items() if k != 'positionM'}), 'position changes only position')
        P.need(same({k:v for k,v in out.items() if k not in ('velocityMps', 'angularVelocityRadps')},
                    {k:v for k,v in body.items() if k not in ('velocityMps', 'angularVelocityRadps')}), 'application changes only motion')
        for key in ('positionM', 'velocityMps', 'angularVelocityRadps', 'inverseMass'):
            P.need(same(normal[key], body[key]), 'normal projected body operand '+key)
        if index not in offsets:
            P.need(same(body, previous) and same(body, out), 'whole static word retention')
            P.need(all(value == 0 for row in normal['inverseInertiaWorld'] for value in vec(row)), 'static zero represented metric')
            continue
        offset = offsets[index]
        inverse = [vec(row) for row in normal['inverseInertiaWorld']]
        physical_inverse[index], physical_inertia[index] = P.physical_tensor(body), P.physical_tensor(body, False)
        for r in range(3):
            metric[offset+r][offset+r] = q(body['inverseMass'])
            for c in range(3):
                P.need(inverse[r][c] == inverse[c][r], 'exact represented tensor symmetry')
                metric[offset+3+r][offset+3+c] = inverse[r][c]
                gate('physicalRepresentedTensorDifference', inverse[r][c]-physical_inverse[index][r][c])
        minor2 = P.s(P.m(inverse[0][0], inverse[1][1]), P.m(inverse[0][1], inverse[0][1]))
        determinant = dot(inverse[0], P.commutator(inverse[1], inverse[2]))
        P.need(inverse[0][0] > 0 and minor2 > 0 and determinant > 0, 'positive represented metric')
        free_motion += vec(body['velocityMps'])+vec(body['angularVelocityRadps'])
        actual_motion += vec(out['velocityMps'])+vec(out['angularVelocityRadps'])
    for p, point in enumerate(points):
        gate('normalUnitSquared', dot(vec(point['normalAtoB']), vec(point['normalAtoB']))-1, GEOM)
        row = [0.0]*size
        for bid, sign in ((point['aId'], -1), (point['bId'], 1)):
            index = ids.index(bid)
            if index not in offsets:
                continue
            offset = offsets[index]
            arm = [P.number(x)-P.number(c) for x, c in zip(point['pointM'], actual[index]['positionM'])]
            torque = cross_float(arm, point['normalAtoB'])
            row[offset:offset+6] = [sign*P.number(x) for x in point['normalAtoB']]+[sign*x for x in torque]
        P.need(same(row, exact['representedRows'][p]), 'actual unwhitened IEEE J coefficient words')
        rows.append(vec(row, size))
    lam = ratios(exact['lambdaNs'], count)
    target, reported_margins = ratios(exact['qpVelocity'], size), ratios(exact['marginsMps'], count)
    gradients = [mv(metric, row) for row in rows]
    reaction = [F(0)]*size
    for gradient, multiplier in zip(gradients, lam):
        reaction = add(reaction, scale(gradient, multiplier))
    exact_gate('exactFullStationarity', add(free_motion, reaction) == target)
    margins = [dot(row, target) for row in rows]
    exact_gate('exactMarginProvenance', margins == reported_margins)
    for p, (multiplier, margin) in enumerate(zip(lam, margins)):
        exact_gate('exactNonnegativeDual', multiplier >= 0, pointIndex=p)
        exact_gate('exactAllRowPrimal', margin >= 0, pointIndex=p)
        exact_gate('exactComplementarity', multiplier*margin == 0, pointIndex=p)
    support = exact['certificate']['supportRows']
    P.need(type(support) is list and all(P.number(i).is_integer() and 0 <= i < count for i in support), 'support schema')
    P.need([int(i) for i in support] == [i for i,x in enumerate(proposal['normalImpulsesNs']) if q(x) > 0], 'proposed support source')
    P.need(exact['certificate']['exactKkt'] is True, 'true exact certificate flag')
    for key, limit in (('rationalOperations', 200000), ('integerOperations', 2000000), ('peakIntegerBits', 16384)):
        value = P.number(exact['stats'][key]); P.need(value.is_integer() and 0 <= value <= limit, 'honest bounded exact counter '+key)
    impulses, torques = {i:[F(0)]*3 for i in range(4)}, {i:[F(0)]*3 for i in range(4)}
    pair_impulses = {}
    for p, (point, application) in enumerate(zip(points, exact['exactApplications'])):
        ai, bi = ids.index(point['aId']), ids.index(point['bId'])
        P.need(application['id'] == point['id'] and application['aIndex'] == ai and application['bIndex'] == bi,
               'exact application actual point endpoints')
        P.need(ratios(application['pointM'], 3) == vec(point['pointM']) and ratios(application['normalAtoB'], 3) == vec(point['normalAtoB']) and
               ratio(application['lambdaNs']) == lam[p], 'exact application source ratios')
        pair_key = (point['aId'], point['bId'])
        pair_impulses[pair_key] = P.a(pair_impulses.get(pair_key, F(0)), lam[p])
        for index, sign, side_name in ((ai, F(-1), 'onA'), (bi, F(1), 'onB')):
            side = application[side_name]
            arm = sub(vec(point['pointM']), vec(actual[index]['positionM']))
            impulse = scale(vec(point['normalAtoB']), P.m(sign, lam[p]))
            torque = P.commutator(arm, impulse)
            exact_gate('exactPointCom', ratios(side['comM'], 3) == vec(actual[index]['positionM']), pointIndex=p)
            exact_gate('exactPointArm', ratios(side['armM'], 3) == arm, pointIndex=p)
            exact_gate('exactPointImpulse', ratios(side['linearImpulseNs'], 3) == impulse, pointIndex=p)
            exact_gate('exactHamiltonPointTorque', ratios(side['armTorqueNms'], 3) == torque, pointIndex=p)
            impulses[index], torques[index] = add(impulses[index], impulse), add(torques[index], torque)
    aggregates = {entry['id']:entry for entry in exact['bodyAggregates']}
    P.need(set(aggregates) == {ids[i] for i in offsets} and len(aggregates) == len(exact['bodyAggregates']), 'all unique dynamic aggregates')
    exact_stationary = []
    for index, offset in offsets.items():
        body, out, record = actual[index], final[index], aggregates[ids[index]]
        dv, dw = scale(impulses[index], q(body['inverseMass'])), mv(physical_inverse[index], torques[index])
        v, w = add(vec(body['velocityMps']), dv), add(vec(body['angularVelocityRadps']), dw)
        for field, expected in (('linearImpulseNs', impulses[index]), ('armTorqueNms', torques[index]),
                                ('linearActionMps', dv), ('angularActionRadps', dw), ('velocityMps', v), ('angularVelocityRadps', w)):
            exact_gate('exactAggregate_'+field, ratios(record[field], 3) == expected, bodyId=ids[index])
        for field, values, action in (('velocityMps', v, dv), ('angularVelocityRadps', w, dw)):
            for k in range(3):
                expected = P.number(body[field][k]) if action[k] == 0 else float(values[k])
                exact_gate('singleRnePhysicalBodyWord', P.word(out[field][k]) == P.word(expected), bodyId=ids[index], field=field, component=k)
        for actual_value, expected in zip(mv(physical_inertia[index], dw), torques[index]):
            exact_gate('exactPhysicalAngularMomentum', actual_value == expected, bodyId=ids[index])
        for k, physical in enumerate(v+w):
            gate('physicalVersusRepresentedQpVelocity', physical-target[offset+k], bodyId=ids[index])
        if all(value == 0 for value in v+w):
            exact_stationary.append(ids[index])
    for p, point in enumerate(points):
        velocities = [P.add(vec(final[ids.index(bid)]['velocityMps']), P.commutator(vec(final[ids.index(bid)]['angularVelocityRadps']),
                      P.sub(vec(point['pointM']), vec(actual[ids.index(bid)]['positionM'])))) for bid in (point['aId'], point['bId'])]
        speed = dot(sub(velocities[1], velocities[0]), vec(point['normalAtoB']))
        gate('roundedPhysicalPrimalMps', max(F(0), -speed), pointIndex=p)
        gate('roundedPhysicalComplementarityJ', lam[p]*speed, pointIndex=p)
        exact_gate('roundedLambdaReportRne', P.word(exact['roundedReporting']['normalImpulsesNs'][p]) == P.word(float(lam[p])), pointIndex=p)
    normal_geometry, post_geometry = diagnostic['normalGeometry'], diagnostic['postGeometry']
    P.need(len(normal_geometry) == len(post_geometry), 'complete final patch set')
    flattened = [(patch, point) for patch in normal_geometry for point in patch['geometry']['points']]
    P.need(len(flattened) == count, 'complete final geometry point population')
    for row, (patch, geometric) in zip(points, flattened):
        P.need(row['aId'] == ids[int(patch['aIndex'])] and row['bId'] == ids[int(patch['bIndex'])] and
               same(row['pointM'], geometric['midpointM']) and same(row['normalAtoB'], patch['geometry']['planeNormalAtoB']),
               'actual point and final geometry word links')
    for pre, post in zip(normal_geometry, post_geometry):
        P.need(pre['aIndex'] == post['aIndex'] and pre['bIndex'] == post['bIndex'] and same(pre['geometry'], post['geometry']), 'unchanged final row geometry words')
    contacts = {(c['aId'], c['bId']):c for c in result['contacts']}
    P.need(len(contacts) == len(result['contacts']) == len(post_geometry), 'all unique final contact summaries')
    for patch in post_geometry:
        ai, bi = int(patch['aIndex']), int(patch['bIndex'])
        geometry = patch['geometry']; contact = contacts[(ids[ai], ids[bi])]
        gate('roundedPairImpulseApproximationNs', q(contact['impulseNs'])-pair_impulses[(ids[ai], ids[bi])])
        for point in [p['midpointM'] for p in geometry['points']]+[contact['pointM']]:
            for index in (ai, bi):
                local = P.rotate(actual[index], sub(vec(point), vec(actual[index]['positionM'])), True)
                half = vec(actual[index]['shape']['halfExtentsM'])
                for value, extent in zip(local, half):
                    gate('physicalPointBoundsM', max(F(0), abs(value)-extent), GEOM)
                if geometry['family'] == 'face':
                    reference = geometry['reference']; is_ref = (index == ai) == (reference['body'] == 'a')
                    axis = int(reference['axis'] if is_ref else reference['incidentAxis'])
                    side = q(reference['side'] if is_ref else reference['incidentSide'])
                    gate('physicalSelectedFaceM', local[axis]-side*half[axis], GEOM)
    position = diagnostic['positionAttempt']
    position_result, position_problem = position['result'], position['problem']
    P.need(position_result['ok'] is True and position_result['status'] == 'SOLVED' and len(position_problem['rows']) == 6,
           'complete original solved all-pair position problem')
    translations = {entry['id']:vec(entry['u']) for entry in position_result['translations']}
    position_lambda = vec(position_result['lambdaKgM'], 6)
    pos_reaction = {bid:[F(0)]*3 for bid in ids}
    for row, multiplier in zip(position_problem['rows'], position_lambda):
        margin = dot(vec(row['normal']), sub(translations[row['bId']], translations[row['aId']]))-q(row['boundM'])
        gate('positionPrimalM', max(F(0), -margin), GEOM)
        gate('positionComplementarityKgM2', multiplier*margin, GEOM)
        exact_gate('positionNonnegativeMultiplier', multiplier >= 0)
        for bid, sign in ((row['aId'], F(-1)), (row['bId'], F(1))):
            pos_reaction[bid] = add(pos_reaction[bid], scale(vec(row['normal']), sign*multiplier))
    for index in offsets:
        for axis in range(3):
            delta = translations[ids[index]][axis]
            expected = P.number(free[index]['positionM'][axis])+float(delta)
            exact_gate('positionOnceRoundedWord', P.word(actual[index]['positionM'][axis]) == P.word(expected))
            gate('positionStationarityKgM', delta/q(free[index]['inverseMass'])-pos_reaction[ids[index]][axis], GEOM)
    if data['caseId'] == 'support1':
        exact_gate('firstSupportHasEquationDerivedStationarity', len(exact_stationary) >= 1)
    if data['caseId'] == 'tilted490':
        exact_gate('tiltedPhysicalOptimumNotForcedToRest', any(abs(value) > SI for value in target))
    return {'ok': not violations, 'resolved': True, 'executionFailure': False,
            'status': 'EXACT_NORMAL_KKT_AND_PHYSICAL_AGGREGATE_CONFIRMED' if not violations else 'PHYSICAL_NO_GO',
            'violations': violations, 'metrics': {key:float(value) for key,value in maxima.items()},
            'certificate': {'fullExactKkt': not any(v['gate'].startswith('exactFull') or v['gate'].startswith('exactAll') or v['gate'] in ('exactNonnegativeDual','exactComplementarity') for v in violations),
                            'equationDerivedExactlyStationaryDynamicIds': exact_stationary, 'independentHamiltonWrench': True,
                            'singleRoundingFromAggregate': True, 'roundedReportOnly': True,
                            'points': count, 'dynamicDof': size, 'restSnap': False, 'worldCalls': 0, 'candidateImports': 0},
            'referenceOperations': P.operations, 'referencePeakBits': P.peak_bits}


def main():
    try:
        raw = sys.stdin.buffer.readline(P.LINE+1)
        P.need(0 < len(raw) <= P.LINE and raw.endswith(b'\n') and sys.stdin.buffer.read(1) == b'', 'one bounded request+EOF')
        packet = json.loads(raw)
        P.need(packet['format'] == 'coherence-exact-private-v1', 'exact private wire')
        response = verify(P.restore(packet['data'], packet['numericWordsF64leHex']))
    except P.Unproved as error:
        response = {'ok': False, 'resolved': False, 'executionFailure': False, 'status': 'REFERENCE_LIMIT', 'reason':str(error), 'violations':[]}
    except (P.Invalid, KeyError, TypeError, ValueError, IndexError, OverflowError, ZeroDivisionError) as error:
        response = {'ok': False, 'resolved': False, 'executionFailure': True, 'status': 'INVALID_INPUT', 'reason':str(error), 'violations':[]}
    encoded = json.dumps(response, separators=(',', ':'), allow_nan=False)
    P.need(len(encoded.encode()) <= 65536, '64KiB reply')
    print(encoded)


if __name__ == '__main__':
    main()
