// examples/physics-stack-stationary-witness-2276/controls.test.mts
import test, { after } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";

// packages/barocss-physics/src/stack/stationary-normal.ts
var STATIONARY_LIMITS = Object.freeze({ rationalOperations: 2e5, integerOperations: 2e6, integerBits: 16384, triangleTrials: 32 });
var ZERO = { n: 0n, d: 1n };
var Stop = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "StationaryNormalFailure";
  }
};
function need(ok, status, message) {
  if (!ok) throw new Stop(status, message);
}
var Exact = class {
  stats = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0, triangleTrials: 0, interfacesProcessed: 0 };
  ieee = new DataView(new ArrayBuffer(8));
  op() {
    if (++this.stats.rationalOperations > STATIONARY_LIMITS.rationalOperations)
      throw new Stop("RESOURCE_LIMIT", "rational work limit");
  }
  tick() {
    if (++this.stats.integerOperations > STATIONARY_LIMITS.integerOperations)
      throw new Stop("RESOURCE_LIMIT", "integer work limit");
  }
  check(n) {
    const h = (n < 0n ? -n : n).toString(16), c = h.charCodeAt(0);
    const bits = 4 * (h.length - 1) + (c <= 49 ? 1 : c <= 51 ? 2 : c <= 55 ? 3 : 4);
    this.stats.peakIntegerBits = Math.max(this.stats.peakIntegerBits, bits);
    need(bits <= STATIONARY_LIMITS.integerBits, "RESOURCE_LIMIT", "integer bit limit");
    return n;
  }
  addI(a, b) {
    this.tick();
    return this.check(a + b);
  }
  mulI(a, b) {
    this.tick();
    return this.check(a * b);
  }
  divI(a, b) {
    this.tick();
    need(b !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a / b);
  }
  modI(a, b) {
    this.tick();
    need(b !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a % b);
  }
  negI(a) {
    this.tick();
    return this.check(-a);
  }
  shift(a, b) {
    this.tick();
    return this.check(a << BigInt(b));
  }
  normalized(n, d) {
    this.check(n);
    this.check(d);
    need(d !== 0n, "NUMERIC_LIMIT", "zero rational denominator");
    if (n === 0n) return ZERO;
    if (d < 0n) {
      n = this.negI(n);
      d = this.negI(d);
    }
    let a = n < 0n ? this.negI(n) : n, b = d;
    while (b !== 0n) {
      const t = this.modI(a, b);
      a = b;
      b = t;
    }
    return { n: this.divI(n, a), d: this.divI(d, a) };
  }
  make(n, d = 1n) {
    this.op();
    return this.normalized(n, d);
  }
  from(value) {
    this.op();
    need(Number.isFinite(value), "INVALID_INPUT", "nonfinite exact operand");
    this.ieee.setFloat64(0, value, false);
    const bits = this.ieee.getBigUint64(0, false), e = Number(bits >> 52n & 2047n);
    const f = bits & (1n << 52n) - 1n, s = e === 0 ? f : f + (1n << 52n);
    const p = e === 0 ? -1074 : e - 1075, n = bits >> 63n !== 0n ? -s : s;
    return p >= 0 ? this.normalized(this.shift(n, p), 1n) : this.normalized(n, this.shift(1n, -p));
  }
  add(a, b) {
    this.op();
    return this.normalized(this.addI(this.mulI(a.n, b.d), this.mulI(b.n, a.d)), this.mulI(a.d, b.d));
  }
  neg(a) {
    this.op();
    return a.n === 0n ? ZERO : { n: this.negI(a.n), d: a.d };
  }
  sub(a, b) {
    return this.add(a, this.neg(b));
  }
  mul(a, b) {
    this.op();
    return this.normalized(this.mulI(a.n, b.n), this.mulI(a.d, b.d));
  }
  div(a, b) {
    this.op();
    return this.normalized(this.mulI(a.n, b.d), this.mulI(a.d, b.n));
  }
  number(a) {
    this.op();
    if (a.n === 0n) return 0;
    const negative = a.n < 0n, n = negative ? this.negI(a.n) : a.n, d = a.d;
    let e = n.toString(2).length - d.toString(2).length;
    if (e >= 0 ? n < this.shift(d, e) : this.shift(n, -e) < d) e--;
    const unit = Math.max(-1074, e - 52);
    const nn = unit < 0 ? this.shift(n, -unit) : n, dd = unit > 0 ? this.shift(d, unit) : d;
    let q2 = this.divI(nn, dd);
    const rem = this.modI(nn, dd), twice = this.shift(rem, 1);
    if (twice > dd || twice === dd && (q2 & 1n) !== 0n) q2 = this.addI(q2, 1n);
    const out = Number(q2) * Math.pow(2, unit);
    need(Number.isFinite(out), "NUMERIC_LIMIT", "rounded impulse overflow");
    return negative ? -out : out;
  }
};
var ratio = (q2) => ({ n: q2.n.toString(), d: q2.d.toString() });
function word(n) {
  const d = new DataView(new ArrayBuffer(8));
  d.setFloat64(0, n, false);
  return d.getBigUint64(0, false).toString(16).padStart(16, "0");
}
function data(input, depth = 0, meter = { nodes: 0 }) {
  need(++meter.nodes <= 8192 && depth <= 12, "INVALID_INPUT", "input size or depth");
  if (input === null || typeof input === "string" || typeof input === "boolean" || typeof input === "number" && Number.isFinite(input)) return input;
  need(input && typeof input === "object", "INVALID_INPUT", "finite plain data required");
  const ds = Object.getOwnPropertyDescriptors(input), keys = Reflect.ownKeys(input), array = Array.isArray(input);
  need(Object.getPrototypeOf(input) === (array ? Array.prototype : Object.prototype), "INVALID_INPUT", "plain data required");
  if (array) {
    need(input.length <= 64 && keys.length === input.length + 1, "INVALID_INPUT", "dense bounded array");
    return Array.from({ length: input.length }, (_, i) => {
      need(ds[i]?.enumerable && "value" in ds[i], "INVALID_INPUT", "dense data array");
      return data(ds[i].value, depth + 1, meter);
    });
  }
  need(keys.length <= 12 && keys.every((k) => typeof k === "string" && ds[k].enumerable && "value" in ds[k]), "INVALID_INPUT", "data fields required");
  return Object.fromEntries(keys.map((k) => [k, data(ds[k].value, depth + 1, meter)]));
}
function fields(value, keys) {
  need(value !== null && typeof value === "object" && !Array.isArray(value), "INVALID_INPUT", "record required");
  const o = value;
  need(Object.keys(o).length === keys.length && keys.every((k) => Object.hasOwn(o, k)), "INVALID_INPUT", "exact fields required");
  return o;
}
function vec(value, n = 3, bound = 1e4) {
  need(Array.isArray(value) && value.length === n && value.every((x) => typeof x === "number" && Number.isFinite(x) && Math.abs(x) <= bound), "INVALID_INPUT", "finite bounded vector required");
  return value;
}
function coefficients(body2, p, sign) {
  const r = p.pointM.map((x, i) => x - body2.positionM[i]);
  need(r.every((x) => Number.isFinite(x) && Math.abs(x) <= 10), "UNSUPPORTED_PROFILE", "contact arm bound");
  const n = p.normalAtoB;
  const t = [r[1] * n[2] - r[2] * n[1], r[2] * n[0] - r[0] * n[2], r[0] * n[1] - r[1] * n[0]];
  return [...n.map((x) => sign * x), ...t.map((x) => sign * x)];
}
function det(m, c) {
  return m.add(
    m.sub(
      m.mul(c[0][0], m.sub(m.mul(c[1][1], c[2][2]), m.mul(c[1][2], c[2][1]))),
      m.mul(c[1][0], m.sub(m.mul(c[0][1], c[2][2]), m.mul(c[0][2], c[2][1])))
    ),
    m.mul(c[2][0], m.sub(m.mul(c[0][1], c[1][2]), m.mul(c[0][2], c[1][1])))
  );
}
function triangle(m, columns, rhs) {
  if (rhs.every((q2) => q2.n === 0n)) return [ZERO, ZERO, ZERO, ZERO];
  for (const ids of [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]]) {
    need(++m.stats.triangleTrials <= STATIONARY_LIMITS.triangleTrials, "RESOURCE_LIMIT", "triangle work limit");
    const c = ids.map((i) => columns[i]), d = det(m, c);
    if (d.n === 0n) continue;
    const values = c.map((_, j) => m.div(det(m, c.map((v, k) => k === j ? rhs : v)), d));
    if (values.some((v) => v.n < 0n)) continue;
    const out = [ZERO, ZERO, ZERO, ZERO];
    ids.forEach((id, j) => out[id] = values[j]);
    return out;
  }
  return null;
}
function solveCore(raw, count) {
  const m = new Exact();
  let input = null;
  try {
    const root = fields(data(raw), ["bodies", "points"]);
    need(Array.isArray(root.bodies) && Array.isArray(root.points), "INVALID_INPUT", "body and point lists required");
    need(root.bodies.length === count + 1 && root.points.length === 4 * count, "UNSUPPORTED_PROFILE", "stationary population");
    input = root;
    const ids = /* @__PURE__ */ new Map();
    let floor = -1, dynamics = 0;
    for (const [i, b] of input.bodies.entries()) {
      fields(b, ["id", "positionM", "velocityMps", "angularVelocityRadps", "inverseMass", "inverseInertiaWorld"]);
      need(typeof b.id === "string" && /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/.test(b.id) && !ids.has(b.id), "INVALID_INPUT", "body identity");
      ids.set(b.id, i);
      vec(b.positionM);
      vec(b.velocityMps, 3, 1e3);
      vec(b.angularVelocityRadps, 3, 1e3);
      need(Array.isArray(b.inverseInertiaWorld) && b.inverseInertiaWorld.length === 3, "INVALID_INPUT", "inertia matrix");
      b.inverseInertiaWorld.forEach((x) => vec(x, 3, 1e6));
      const fixed = b.inverseMass === 0;
      need(fixed || b.inverseMass === 1, "UNSUPPORTED_PROFILE", "unit dynamic mass");
      need(b.inverseInertiaWorld.every((r, i2) => r.every((v2, j) => v2 === (fixed ? 0 : i2 === j ? 24 : 0))), "UNSUPPORTED_PROFILE", "isotropic24 inertia");
      need(b.angularVelocityRadps.every((x) => x === 0) && b.velocityMps[0] === 0 && b.velocityMps[2] === 0 && b.velocityMps[1] <= 0 && -b.velocityMps[1] <= 1, "UNSUPPORTED_PROFILE", "stationary free motion");
      if (fixed) {
        need(floor === -1 && b.velocityMps[1] === 0, "UNSUPPORTED_PROFILE", "one fixed floor");
        floor = i;
      } else dynamics++;
    }
    need(floor >= 0 && dynamics === count, "UNSUPPORTED_PROFILE", "one floor and complete dynamics");
    const seen = /* @__PURE__ */ new Set(), rows = [], edges = /* @__PURE__ */ new Map();
    for (const [index, p] of input.points.entries()) {
      fields(p, ["id", "aId", "bId", "pointM", "normalAtoB"]);
      need(typeof p.id === "string" && p.id.length > 0 && p.id.length <= 4096 && !seen.has(p.id) && ids.has(p.aId) && ids.has(p.bId) && p.aId !== p.bId, "INVALID_INPUT", "point identity");
      seen.add(p.id);
      vec(p.pointM);
      vec(p.normalAtoB, 3, 1);
      need(p.normalAtoB[0] === 0 && p.normalAtoB[2] === 0 && Math.abs(p.normalAtoB[1]) === 1, "UNSUPPORTED_PROFILE", "exact vertical normal");
      const a = ids.get(p.aId), b = ids.get(p.bId);
      const ca = coefficients(input.bodies[a], p, -1), cb = coefficients(input.bodies[b], p, 1);
      need([ca, cb].every((c) => c[0] === 0 && c[2] === 0 && c[4] === 0), "UNSUPPORTED_PROFILE", "other Jacobian dofs must be zero");
      rows.push({ a, b, ca, cb, qa: ca.map((x) => m.from(x)), qb: cb.map((x) => m.from(x)) });
      const lower = ca[1] === -1 ? a : b, upper = lower === a ? b : a, key = lower + "\0" + upper;
      let edge = edges.get(key);
      if (!edge) {
        edge = { lower, upper, rows: [] };
        edges.set(key, edge);
      }
      edge.rows.push(index);
    }
    need(edges.size === count && [...edges.values()].every((e) => e.rows.length === 4), "UNSUPPORTED_PROFILE", "four points per chain interface");
    const above = /* @__PURE__ */ new Map(), below = /* @__PURE__ */ new Map();
    for (const e of edges.values()) {
      need(!above.has(e.lower) && !below.has(e.upper) && e.upper !== floor, "UNSUPPORTED_PROFILE", "unbranched directed chain");
      above.set(e.lower, e);
      below.set(e.upper, e);
    }
    const chain = [floor];
    while (above.has(chain[chain.length - 1])) {
      const next = above.get(chain[chain.length - 1]).upper;
      need(!chain.includes(next), "UNSUPPORTED_PROFILE", "acyclic chain");
      chain.push(next);
    }
    need(chain.length === count + 1, "UNSUPPORTED_PROFILE", "connected floor-to-top chain");
    const incoming = input.bodies.map(() => [ZERO, ZERO, ZERO]), lambda = rows.map(() => ZERO);
    for (let k = chain.length - 1; k > 0; k--) {
      const body2 = chain[k], edge = below.get(body2);
      const rhs = [
        m.sub(m.neg(m.from(input.bodies[body2].velocityMps[1])), incoming[body2][0]),
        m.neg(incoming[body2][1]),
        m.neg(incoming[body2][2])
      ];
      const columns = edge.rows.map((i) => {
        const row = rows[i], c = row.a === body2 ? row.qa : row.qb;
        return [c[1], c[3], c[5]];
      });
      const chosen = triangle(m, columns, rhs);
      need(chosen, "NO_WITNESS", "greedy support triangle not found");
      for (let j = 0; j < 4; j++) {
        const index = edge.rows[j], row = rows[index], q2 = chosen[j], c = row.a === edge.lower ? row.qa : row.qb;
        lambda[index] = q2;
        for (let d = 0; d < 3; d++) incoming[edge.lower][d] = m.add(incoming[edge.lower][d], m.mul(c[[1, 3, 5][d]], q2));
      }
      m.stats.interfacesProcessed++;
    }
    const balances = input.bodies.map((b) => [...b.velocityMps.map((x) => m.from(x)), ZERO, ZERO, ZERO]);
    for (let i = 0; i < rows.length; i++) {
      need(lambda[i].n >= 0n, "NUMERIC_LIMIT", "negative exact multiplier");
      for (const [body2, c] of [[rows[i].a, rows[i].qa], [rows[i].b, rows[i].qb]]) {
        if (body2 === floor) continue;
        for (let d = 0; d < 6; d++) balances[body2][d] = m.add(balances[body2][d], m.mul(c[d], lambda[i]));
      }
    }
    for (let i = 0; i < input.bodies.length; i++) {
      if (i !== floor) need(balances[i].every((q2) => q2.n === 0n), "NUMERIC_LIMIT", "global exact stationarity failed");
    }
    for (const row of rows) {
      let primal = ZERO;
      for (let d = 0; d < 6; d++) primal = m.add(primal, m.add(m.mul(row.qa[d], ZERO), m.mul(row.qb[d], ZERO)));
      need(primal.n === 0n, "NUMERIC_LIMIT", "global exact primal failed");
    }
    const rounded = lambda.map((q2) => m.number(q2));
    const bodies = input.bodies.map((b, i) => ({
      ...b,
      positionM: [...b.positionM],
      velocityMps: i === floor ? [...b.velocityMps] : [0, 0, 0],
      angularVelocityRadps: i === floor ? [...b.angularVelocityRadps] : [0, 0, 0],
      inverseInertiaWorld: b.inverseInertiaWorld.map((r) => [...r])
    }));
    const applied = input.bodies.map(() => [0, 0, 0, 0, 0, 0]);
    for (let i = 0; i < rows.length; i++) {
      for (const [body2, c] of [[rows[i].a, rows[i].ca], [rows[i].b, rows[i].cb]]) {
        for (let d = 0; d < 6; d++) applied[body2][d] += c[d] * rounded[i];
      }
    }
    let v = 0, w = 0, stationarity = 0;
    for (const [i, b] of input.bodies.entries()) if (i !== floor) {
      for (let d = 0; d < 3; d++) {
        const dv = b.velocityMps[d] + applied[i][d], dw = 24 * applied[i][d + 3];
        v = Math.max(v, Math.abs(dv));
        w = Math.max(w, Math.abs(dw));
        stationarity = Math.max(stationarity, Math.abs(dv), Math.abs(dw) / Math.sqrt(24));
      }
    }
    need([v, w, stationarity, ...rounded].every(Number.isFinite), "NUMERIC_LIMIT", "nonfinite rounded diagnostic");
    return {
      ok: true,
      status: "SOLVED_STATIONARY_WITNESS",
      reason: null,
      bodies,
      normalImpulsesNs: rounded,
      exactApplied: {
        format: "STATIONARY_FLOAT_J_RATIOS_V1",
        points: input.points.map((p, i) => ({
          id: p.id,
          a: { bodyId: p.aId, coefficients: rows[i].ca, words: rows[i].ca.map(word) },
          b: { bodyId: p.bId, coefficients: rows[i].cb, words: rows[i].cb.map(word) },
          lambda: ratio(lambda[i]),
          roundedWord: word(rounded[i])
        })),
        dynamicResiduals: input.bodies.flatMap((b, i) => i === floor ? [] : [{ bodyId: b.id, values: balances[i].map(ratio) }]),
        allRowsPrimalZero: true,
        allRowsComplementarityZero: true,
        nonnegative: true
      },
      roundedReconstruction: { maxVelocityErrorMps: v, maxAngularVelocityErrorRadps: w, maxUnscaledMassWeightedResidualSqrtJ: stationarity },
      stats: { ...m.stats }
    };
  } catch (e) {
    if (!(e instanceof Stop)) throw e;
    return {
      ok: false,
      status: e.status,
      reason: e.message,
      bodies: input?.bodies ?? [],
      normalImpulsesNs: null,
      exactApplied: null,
      roundedReconstruction: null,
      stats: { ...m.stats }
    };
  }
}
function solveStationaryNormal(problem2) {
  return solveCore(problem2, 8);
}

// examples/physics-stack-stationary-witness-2276/unit-source.ts
var STATIONARY_LIMITS2 = Object.freeze({ rationalOperations: 2e5, integerOperations: 2e6, integerBits: 16384, triangleTrials: 32 });
var ZERO2 = { n: 0n, d: 1n };
var Stop2 = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "StationaryNormalFailure";
  }
};
function need2(ok, status, message) {
  if (!ok) throw new Stop2(status, message);
}
var Exact2 = class {
  stats = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0, triangleTrials: 0, interfacesProcessed: 0 };
  ieee = new DataView(new ArrayBuffer(8));
  op() {
    if (++this.stats.rationalOperations > STATIONARY_LIMITS2.rationalOperations)
      throw new Stop2("RESOURCE_LIMIT", "rational work limit");
  }
  tick() {
    if (++this.stats.integerOperations > STATIONARY_LIMITS2.integerOperations)
      throw new Stop2("RESOURCE_LIMIT", "integer work limit");
  }
  check(n) {
    const h = (n < 0n ? -n : n).toString(16), c = h.charCodeAt(0);
    const bits = 4 * (h.length - 1) + (c <= 49 ? 1 : c <= 51 ? 2 : c <= 55 ? 3 : 4);
    this.stats.peakIntegerBits = Math.max(this.stats.peakIntegerBits, bits);
    need2(bits <= STATIONARY_LIMITS2.integerBits, "RESOURCE_LIMIT", "integer bit limit");
    return n;
  }
  addI(a, b) {
    this.tick();
    return this.check(a + b);
  }
  mulI(a, b) {
    this.tick();
    return this.check(a * b);
  }
  divI(a, b) {
    this.tick();
    need2(b !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a / b);
  }
  modI(a, b) {
    this.tick();
    need2(b !== 0n, "NUMERIC_LIMIT", "zero integer divisor");
    return this.check(a % b);
  }
  negI(a) {
    this.tick();
    return this.check(-a);
  }
  shift(a, b) {
    this.tick();
    return this.check(a << BigInt(b));
  }
  normalized(n, d) {
    this.check(n);
    this.check(d);
    need2(d !== 0n, "NUMERIC_LIMIT", "zero rational denominator");
    if (n === 0n) return ZERO2;
    if (d < 0n) {
      n = this.negI(n);
      d = this.negI(d);
    }
    let a = n < 0n ? this.negI(n) : n, b = d;
    while (b !== 0n) {
      const t = this.modI(a, b);
      a = b;
      b = t;
    }
    return { n: this.divI(n, a), d: this.divI(d, a) };
  }
  make(n, d = 1n) {
    this.op();
    return this.normalized(n, d);
  }
  from(value) {
    this.op();
    need2(Number.isFinite(value), "INVALID_INPUT", "nonfinite exact operand");
    this.ieee.setFloat64(0, value, false);
    const bits = this.ieee.getBigUint64(0, false), e = Number(bits >> 52n & 2047n);
    const f = bits & (1n << 52n) - 1n, s = e === 0 ? f : f + (1n << 52n);
    const p = e === 0 ? -1074 : e - 1075, n = bits >> 63n !== 0n ? -s : s;
    return p >= 0 ? this.normalized(this.shift(n, p), 1n) : this.normalized(n, this.shift(1n, -p));
  }
  add(a, b) {
    this.op();
    return this.normalized(this.addI(this.mulI(a.n, b.d), this.mulI(b.n, a.d)), this.mulI(a.d, b.d));
  }
  neg(a) {
    this.op();
    return a.n === 0n ? ZERO2 : { n: this.negI(a.n), d: a.d };
  }
  sub(a, b) {
    return this.add(a, this.neg(b));
  }
  mul(a, b) {
    this.op();
    return this.normalized(this.mulI(a.n, b.n), this.mulI(a.d, b.d));
  }
  div(a, b) {
    this.op();
    return this.normalized(this.mulI(a.n, b.d), this.mulI(a.d, b.n));
  }
  number(a) {
    this.op();
    if (a.n === 0n) return 0;
    const negative = a.n < 0n, n = negative ? this.negI(a.n) : a.n, d = a.d;
    let e = n.toString(2).length - d.toString(2).length;
    if (e >= 0 ? n < this.shift(d, e) : this.shift(n, -e) < d) e--;
    const unit = Math.max(-1074, e - 52);
    const nn = unit < 0 ? this.shift(n, -unit) : n, dd = unit > 0 ? this.shift(d, unit) : d;
    let q2 = this.divI(nn, dd);
    const rem = this.modI(nn, dd), twice = this.shift(rem, 1);
    if (twice > dd || twice === dd && (q2 & 1n) !== 0n) q2 = this.addI(q2, 1n);
    const out = Number(q2) * Math.pow(2, unit);
    need2(Number.isFinite(out), "NUMERIC_LIMIT", "rounded impulse overflow");
    return negative ? -out : out;
  }
};
var ratio2 = (q2) => ({ n: q2.n.toString(), d: q2.d.toString() });
function word2(n) {
  const d = new DataView(new ArrayBuffer(8));
  d.setFloat64(0, n, false);
  return d.getBigUint64(0, false).toString(16).padStart(16, "0");
}
function data2(input, depth = 0, meter = { nodes: 0 }) {
  need2(++meter.nodes <= 8192 && depth <= 12, "INVALID_INPUT", "input size or depth");
  if (input === null || typeof input === "string" || typeof input === "boolean" || typeof input === "number" && Number.isFinite(input)) return input;
  need2(input && typeof input === "object", "INVALID_INPUT", "finite plain data required");
  const ds = Object.getOwnPropertyDescriptors(input), keys = Reflect.ownKeys(input), array = Array.isArray(input);
  need2(Object.getPrototypeOf(input) === (array ? Array.prototype : Object.prototype), "INVALID_INPUT", "plain data required");
  if (array) {
    need2(input.length <= 64 && keys.length === input.length + 1, "INVALID_INPUT", "dense bounded array");
    return Array.from({ length: input.length }, (_, i) => {
      need2(ds[i]?.enumerable && "value" in ds[i], "INVALID_INPUT", "dense data array");
      return data2(ds[i].value, depth + 1, meter);
    });
  }
  need2(keys.length <= 12 && keys.every((k) => typeof k === "string" && ds[k].enumerable && "value" in ds[k]), "INVALID_INPUT", "data fields required");
  return Object.fromEntries(keys.map((k) => [k, data2(ds[k].value, depth + 1, meter)]));
}
function fields2(value, keys) {
  need2(value !== null && typeof value === "object" && !Array.isArray(value), "INVALID_INPUT", "record required");
  const o = value;
  need2(Object.keys(o).length === keys.length && keys.every((k) => Object.hasOwn(o, k)), "INVALID_INPUT", "exact fields required");
  return o;
}
function vec2(value, n = 3, bound = 1e4) {
  need2(Array.isArray(value) && value.length === n && value.every((x) => typeof x === "number" && Number.isFinite(x) && Math.abs(x) <= bound), "INVALID_INPUT", "finite bounded vector required");
  return value;
}
function coefficients2(body2, p, sign) {
  const r = p.pointM.map((x, i) => x - body2.positionM[i]);
  need2(r.every((x) => Number.isFinite(x) && Math.abs(x) <= 10), "UNSUPPORTED_PROFILE", "contact arm bound");
  const n = p.normalAtoB;
  const t = [r[1] * n[2] - r[2] * n[1], r[2] * n[0] - r[0] * n[2], r[0] * n[1] - r[1] * n[0]];
  return [...n.map((x) => sign * x), ...t.map((x) => sign * x)];
}
function det2(m, c) {
  return m.add(
    m.sub(
      m.mul(c[0][0], m.sub(m.mul(c[1][1], c[2][2]), m.mul(c[1][2], c[2][1]))),
      m.mul(c[1][0], m.sub(m.mul(c[0][1], c[2][2]), m.mul(c[0][2], c[2][1])))
    ),
    m.mul(c[2][0], m.sub(m.mul(c[0][1], c[1][2]), m.mul(c[0][2], c[1][1])))
  );
}
function triangle2(m, columns, rhs) {
  if (rhs.every((q2) => q2.n === 0n)) return [ZERO2, ZERO2, ZERO2, ZERO2];
  for (const ids of [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]]) {
    need2(++m.stats.triangleTrials <= STATIONARY_LIMITS2.triangleTrials, "RESOURCE_LIMIT", "triangle work limit");
    const c = ids.map((i) => columns[i]), d = det2(m, c);
    if (d.n === 0n) continue;
    const values = c.map((_, j) => m.div(det2(m, c.map((v, k) => k === j ? rhs : v)), d));
    if (values.some((v) => v.n < 0n)) continue;
    const out = [ZERO2, ZERO2, ZERO2, ZERO2];
    ids.forEach((id, j) => out[id] = values[j]);
    return out;
  }
  return null;
}
function solveCore2(raw, count) {
  const m = new Exact2();
  let input = null;
  try {
    const root = fields2(data2(raw), ["bodies", "points"]);
    need2(Array.isArray(root.bodies) && Array.isArray(root.points), "INVALID_INPUT", "body and point lists required");
    need2(root.bodies.length === count + 1 && root.points.length === 4 * count, "UNSUPPORTED_PROFILE", "stationary population");
    input = root;
    const ids = /* @__PURE__ */ new Map();
    let floor = -1, dynamics = 0;
    for (const [i, b] of input.bodies.entries()) {
      fields2(b, ["id", "positionM", "velocityMps", "angularVelocityRadps", "inverseMass", "inverseInertiaWorld"]);
      need2(typeof b.id === "string" && /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/.test(b.id) && !ids.has(b.id), "INVALID_INPUT", "body identity");
      ids.set(b.id, i);
      vec2(b.positionM);
      vec2(b.velocityMps, 3, 1e3);
      vec2(b.angularVelocityRadps, 3, 1e3);
      need2(Array.isArray(b.inverseInertiaWorld) && b.inverseInertiaWorld.length === 3, "INVALID_INPUT", "inertia matrix");
      b.inverseInertiaWorld.forEach((x) => vec2(x, 3, 1e6));
      const fixed = b.inverseMass === 0;
      need2(fixed || b.inverseMass === 1, "UNSUPPORTED_PROFILE", "unit dynamic mass");
      need2(b.inverseInertiaWorld.every((r, i2) => r.every((v2, j) => v2 === (fixed ? 0 : i2 === j ? 24 : 0))), "UNSUPPORTED_PROFILE", "isotropic24 inertia");
      need2(b.angularVelocityRadps.every((x) => x === 0) && b.velocityMps[0] === 0 && b.velocityMps[2] === 0 && b.velocityMps[1] <= 0 && -b.velocityMps[1] <= 1, "UNSUPPORTED_PROFILE", "stationary free motion");
      if (fixed) {
        need2(floor === -1 && b.velocityMps[1] === 0, "UNSUPPORTED_PROFILE", "one fixed floor");
        floor = i;
      } else dynamics++;
    }
    need2(floor >= 0 && dynamics === count, "UNSUPPORTED_PROFILE", "one floor and complete dynamics");
    const seen = /* @__PURE__ */ new Set(), rows = [], edges = /* @__PURE__ */ new Map();
    for (const [index, p] of input.points.entries()) {
      fields2(p, ["id", "aId", "bId", "pointM", "normalAtoB"]);
      need2(typeof p.id === "string" && p.id.length > 0 && p.id.length <= 4096 && !seen.has(p.id) && ids.has(p.aId) && ids.has(p.bId) && p.aId !== p.bId, "INVALID_INPUT", "point identity");
      seen.add(p.id);
      vec2(p.pointM);
      vec2(p.normalAtoB, 3, 1);
      need2(p.normalAtoB[0] === 0 && p.normalAtoB[2] === 0 && Math.abs(p.normalAtoB[1]) === 1, "UNSUPPORTED_PROFILE", "exact vertical normal");
      const a = ids.get(p.aId), b = ids.get(p.bId);
      const ca = coefficients2(input.bodies[a], p, -1), cb = coefficients2(input.bodies[b], p, 1);
      need2([ca, cb].every((c) => c[0] === 0 && c[2] === 0 && c[4] === 0), "UNSUPPORTED_PROFILE", "other Jacobian dofs must be zero");
      rows.push({ a, b, ca, cb, qa: ca.map((x) => m.from(x)), qb: cb.map((x) => m.from(x)) });
      const lower = ca[1] === -1 ? a : b, upper = lower === a ? b : a, key = lower + "\0" + upper;
      let edge = edges.get(key);
      if (!edge) {
        edge = { lower, upper, rows: [] };
        edges.set(key, edge);
      }
      edge.rows.push(index);
    }
    need2(edges.size === count && [...edges.values()].every((e) => e.rows.length === 4), "UNSUPPORTED_PROFILE", "four points per chain interface");
    const above = /* @__PURE__ */ new Map(), below = /* @__PURE__ */ new Map();
    for (const e of edges.values()) {
      need2(!above.has(e.lower) && !below.has(e.upper) && e.upper !== floor, "UNSUPPORTED_PROFILE", "unbranched directed chain");
      above.set(e.lower, e);
      below.set(e.upper, e);
    }
    const chain = [floor];
    while (above.has(chain[chain.length - 1])) {
      const next = above.get(chain[chain.length - 1]).upper;
      need2(!chain.includes(next), "UNSUPPORTED_PROFILE", "acyclic chain");
      chain.push(next);
    }
    need2(chain.length === count + 1, "UNSUPPORTED_PROFILE", "connected floor-to-top chain");
    const incoming = input.bodies.map(() => [ZERO2, ZERO2, ZERO2]), lambda = rows.map(() => ZERO2);
    for (let k = chain.length - 1; k > 0; k--) {
      const body2 = chain[k], edge = below.get(body2);
      const rhs = [
        m.sub(m.neg(m.from(input.bodies[body2].velocityMps[1])), incoming[body2][0]),
        m.neg(incoming[body2][1]),
        m.neg(incoming[body2][2])
      ];
      const columns = edge.rows.map((i) => {
        const row = rows[i], c = row.a === body2 ? row.qa : row.qb;
        return [c[1], c[3], c[5]];
      });
      const chosen = triangle2(m, columns, rhs);
      need2(chosen, "NO_WITNESS", "greedy support triangle not found");
      for (let j = 0; j < 4; j++) {
        const index = edge.rows[j], row = rows[index], q2 = chosen[j], c = row.a === edge.lower ? row.qa : row.qb;
        lambda[index] = q2;
        for (let d = 0; d < 3; d++) incoming[edge.lower][d] = m.add(incoming[edge.lower][d], m.mul(c[[1, 3, 5][d]], q2));
      }
      m.stats.interfacesProcessed++;
    }
    const balances = input.bodies.map((b) => [...b.velocityMps.map((x) => m.from(x)), ZERO2, ZERO2, ZERO2]);
    for (let i = 0; i < rows.length; i++) {
      need2(lambda[i].n >= 0n, "NUMERIC_LIMIT", "negative exact multiplier");
      for (const [body2, c] of [[rows[i].a, rows[i].qa], [rows[i].b, rows[i].qb]]) {
        if (body2 === floor) continue;
        for (let d = 0; d < 6; d++) balances[body2][d] = m.add(balances[body2][d], m.mul(c[d], lambda[i]));
      }
    }
    for (let i = 0; i < input.bodies.length; i++) {
      if (i !== floor) need2(balances[i].every((q2) => q2.n === 0n), "NUMERIC_LIMIT", "global exact stationarity failed");
    }
    for (const row of rows) {
      let primal = ZERO2;
      for (let d = 0; d < 6; d++) primal = m.add(primal, m.add(m.mul(row.qa[d], ZERO2), m.mul(row.qb[d], ZERO2)));
      need2(primal.n === 0n, "NUMERIC_LIMIT", "global exact primal failed");
    }
    const rounded = lambda.map((q2) => m.number(q2));
    const bodies = input.bodies.map((b, i) => ({
      ...b,
      positionM: [...b.positionM],
      velocityMps: i === floor ? [...b.velocityMps] : [0, 0, 0],
      angularVelocityRadps: i === floor ? [...b.angularVelocityRadps] : [0, 0, 0],
      inverseInertiaWorld: b.inverseInertiaWorld.map((r) => [...r])
    }));
    const applied = input.bodies.map(() => [0, 0, 0, 0, 0, 0]);
    for (let i = 0; i < rows.length; i++) {
      for (const [body2, c] of [[rows[i].a, rows[i].ca], [rows[i].b, rows[i].cb]]) {
        for (let d = 0; d < 6; d++) applied[body2][d] += c[d] * rounded[i];
      }
    }
    let v = 0, w = 0, stationarity = 0;
    for (const [i, b] of input.bodies.entries()) if (i !== floor) {
      for (let d = 0; d < 3; d++) {
        const dv = b.velocityMps[d] + applied[i][d], dw = 24 * applied[i][d + 3];
        v = Math.max(v, Math.abs(dv));
        w = Math.max(w, Math.abs(dw));
        stationarity = Math.max(stationarity, Math.abs(dv), Math.abs(dw) / Math.sqrt(24));
      }
    }
    need2([v, w, stationarity, ...rounded].every(Number.isFinite), "NUMERIC_LIMIT", "nonfinite rounded diagnostic");
    return {
      ok: true,
      status: "SOLVED_STATIONARY_WITNESS",
      reason: null,
      bodies,
      normalImpulsesNs: rounded,
      exactApplied: {
        format: "STATIONARY_FLOAT_J_RATIOS_V1",
        points: input.points.map((p, i) => ({
          id: p.id,
          a: { bodyId: p.aId, coefficients: rows[i].ca, words: rows[i].ca.map(word2) },
          b: { bodyId: p.bId, coefficients: rows[i].cb, words: rows[i].cb.map(word2) },
          lambda: ratio2(lambda[i]),
          roundedWord: word2(rounded[i])
        })),
        dynamicResiduals: input.bodies.flatMap((b, i) => i === floor ? [] : [{ bodyId: b.id, values: balances[i].map(ratio2) }]),
        allRowsPrimalZero: true,
        allRowsComplementarityZero: true,
        nonnegative: true
      },
      roundedReconstruction: { maxVelocityErrorMps: v, maxAngularVelocityErrorRadps: w, maxUnscaledMassWeightedResidualSqrtJ: stationarity },
      stats: { ...m.stats }
    };
  } catch (e) {
    if (!(e instanceof Stop2)) throw e;
    return {
      ok: false,
      status: e.status,
      reason: e.message,
      bodies: input?.bodies ?? [],
      normalImpulsesNs: null,
      exactApplied: null,
      roundedReconstruction: null,
      stats: { ...m.stats }
    };
  }
}

// examples/physics-stack-stationary-witness-2276/adapter.ts
function verifierView(p, r) {
  if (!r.ok) return { ok: false, status: r.status, bodies: r.bodies, normalImpulsesNs: null, rowResiduals: null, certificate: null, stationaryStats: r.stats };
  const ids = new Map(p.bodies.map((b, i) => [b.id, i])), sum2 = p.bodies.map(() => [0, 0, 0, 0, 0, 0]), root = Math.sqrt(24);
  for (let i = 0; i < p.points.length; i++) {
    const point = p.points[i], lambda = r.normalImpulsesNs[i];
    for (const [id, sign] of [[point.aId, -1], [point.bId, 1]]) {
      const index = ids.get(id), b = p.bodies[index];
      if (b.inverseMass === 0) continue;
      const a = point.pointM.map((v, k) => v - b.positionM[k]), n = point.normalAtoB, t = [a[1] * n[2] - a[2] * n[1], a[2] * n[0] - a[0] * n[2], a[0] * n[1] - a[1] * n[0]];
      for (let k = 0; k < 3; k++) {
        sum2[index][k] += sign * n[k] * lambda;
        let angular = 0;
        for (let j = 0; j < 3; j++) angular += t[j] * (j === k ? root : 0);
        sum2[index][k + 3] += sign * angular * lambda;
      }
    }
  }
  let stationarity = 0;
  for (const [i, b] of p.bodies.entries()) if (b.inverseMass !== 0) for (let k = 0; k < 6; k++) stationarity = Math.max(stationarity, Math.abs(-(k < 3 ? b.velocityMps[k] : 0) - sum2[i][k]));
  return { ok: true, status: "SOLVED_NORMAL_ONLY", bodies: r.bodies, normalImpulsesNs: r.normalImpulsesNs, rowResiduals: p.points.map((x) => ({ id: x.id, normalSpeedMps: 0, negativeNormalImpulseNs: 0, complementarityJ: 0, tangentSpeedMps: 0 })), certificate: { maxClosingNormalSpeedMps: 0, maxNegativeNormalImpulseNs: 0, maxComplementarityJ: 0, maxStationaritySqrtJ: stationarity, maxLoadedTangentSpeedMps: 0, zeroTangentFeasible: true }, stationaryStats: r.stats };
}

// examples/physics-stack-solver-2276/verification.ts
var VERIFICATION_GATE = 1e-10;
var zero = () => [0, 0, 0];
var sum = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
var minus = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
var times = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
var dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
var cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
var mv = (m, v) => [dot(m[0], v), dot(m[1], v), dot(m[2], v)];
var componentError = (a, b) => Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1]), Math.abs(a[2] - b[2]));
function requireData(condition, label) {
  if (!condition) throw new RangeError(`Invalid verification data: ${label}`);
}
function finite(value, label) {
  requireData(typeof value === "number" && Number.isFinite(value), label);
}
function vector(value, label) {
  requireData(Array.isArray(value) && value.length === 3 && [0, 1, 2].every((i) => Object.hasOwn(value, i)), label);
  for (const component of value) finite(component, label);
}
function identity(value, label) {
  requireData(typeof value === "string" && value.length > 0, label);
}
function inertia(body2) {
  const a = body2.inverseInertiaWorld;
  requireData(Array.isArray(a) && a.length === 3, "inertia matrix");
  for (const row of a) vector(row, "inertia row");
  requireData(Math.abs(a[0][1] - a[1][0]) <= VERIFICATION_GATE && Math.abs(a[0][2] - a[2][0]) <= VERIFICATION_GATE && Math.abs(a[1][2] - a[2][1]) <= VERIFICATION_GATE, "symmetric inertia");
  if (body2.inverseMass === 0) {
    requireData(a.every((row) => row.every((value) => value === 0)), "static inverse inertia");
    return null;
  }
  const c0 = cross(a[1], a[2]), c1 = cross(a[2], a[0]), c2 = cross(a[0], a[1]);
  const determinant = dot(a[0], c0);
  requireData(a[0][0] > 0 && a[0][0] * a[1][1] - a[0][1] * a[1][0] > 0 && Number.isFinite(determinant) && determinant > 0, "positive definite inverse inertia");
  return [
    [c0[0] / determinant, c1[0] / determinant, c2[0] / determinant],
    [c0[1] / determinant, c1[1] / determinant, c2[1] / determinant],
    [c0[2] / determinant, c1[2] / determinant, c2[2] / determinant]
  ];
}
function bodyData(body2) {
  requireData(body2 !== null && typeof body2 === "object", "body");
  identity(body2.id, "body id");
  vector(body2.positionM, "body position");
  vector(body2.velocityMps, "body velocity");
  vector(body2.angularVelocityRadps, "body angular velocity");
  finite(body2.inverseMass, "inverse mass");
  requireData(body2.inverseMass >= 0, "nonnegative inverse mass");
}
function pointVelocity(v, w, arm) {
  return sum(v, cross(w, arm));
}
function kinetic(body2, moment, v, w) {
  return body2.inverseMass === 0 ? 0 : dot(v, v) / (2 * body2.inverseMass) + dot(w, mv(moment, w)) / 2;
}
function verifyWithOptionalOracle(problem2, candidate, oracle) {
  requireData(Array.isArray(problem2.bodies) && problem2.bodies.length >= 1 && problem2.bodies.length <= 9, "1..9 bodies");
  requireData(Array.isArray(problem2.points) && problem2.points.length >= 1 && problem2.points.length <= 32, "1..32 points");
  if (oracle !== void 0) {
    requireData(Array.isArray(oracle.bodies) && oracle.bodies.length === problem2.bodies.length, "oracle body count");
    if (oracle.sourceReceiptSha256 !== void 0) requireData(/^[0-9a-f]{64}$/.test(oracle.sourceReceiptSha256), "oracle source hash");
  }
  const input = /* @__PURE__ */ new Map(), moments = /* @__PURE__ */ new Map();
  const impulses = /* @__PURE__ */ new Map(), torques = /* @__PURE__ */ new Map();
  for (const body2 of problem2.bodies) {
    bodyData(body2);
    requireData(!input.has(body2.id), "unique body ids");
    input.set(body2.id, body2);
    moments.set(body2.id, inertia(body2));
    impulses.set(body2.id, zero());
    torques.set(body2.id, zero());
  }
  const pointIds = /* @__PURE__ */ new Set();
  for (const point of problem2.points) {
    identity(point.id, "point id");
    requireData(!pointIds.has(point.id), "unique point ids");
    pointIds.add(point.id);
    requireData(input.has(point.aId) && input.has(point.bId) && point.aId !== point.bId, "directed point endpoints");
    vector(point.pointM, "point position");
    vector(point.normalAtoB, "point normal");
    requireData(Math.abs(Math.hypot(...point.normalAtoB) - 1) <= VERIFICATION_GATE, "unit normal");
  }
  const expected = /* @__PURE__ */ new Map();
  for (const body2 of oracle?.bodies ?? []) {
    identity(body2.id, "oracle id");
    requireData(input.has(body2.id) && !expected.has(body2.id), "oracle identity");
    vector(body2.velocityMps, "oracle velocity");
    vector(body2.angularVelocityRadps, "oracle angular velocity");
    vector(body2.netImpulseNs, "oracle net impulse");
    vector(body2.netTorqueNms, "oracle net torque");
    expected.set(body2.id, body2);
  }
  const report = {
    passed: false,
    normalKktPassed: false,
    zeroTangentFrictionFeasible: false,
    oracleMatched: false,
    candidateReportsMatched: false,
    sourceReceiptSha256: oracle?.sourceReceiptSha256 ?? null,
    bodies: [],
    rows: [],
    maxima: {
      closingNormalSpeedMps: 0,
      negativeNormalImpulseNs: 0,
      complementarityJ: 0,
      loadedTangentSpeedMps: 0,
      reportedVelocityErrorMps: 0,
      reportedAngularVelocityErrorRadps: 0,
      oracleVelocityErrorMps: 0,
      oracleAngularVelocityErrorRadps: 0,
      oracleNetImpulseErrorNs: 0,
      oracleNetTorqueErrorNms: 0,
      reportedResidualError: 0,
      impulseWorkErrorJ: 0
    },
    energy: { freeKineticJ: 0, finalKineticJ: 0, normalImpulseWorkJ: 0 },
    violations: []
  };
  if (candidate.ok !== true || candidate.status !== "SOLVED_NORMAL_ONLY" || candidate.normalImpulsesNs === null || candidate.rowResiduals === null || candidate.certificate === null) {
    report.violations.push("candidate did not return a solved normal problem");
    return report;
  }
  requireData(Array.isArray(candidate.bodies) && candidate.bodies.length === input.size, "candidate body count");
  requireData(Array.isArray(candidate.normalImpulsesNs) && candidate.normalImpulsesNs.length === problem2.points.length, "candidate impulse count");
  requireData(Array.isArray(candidate.rowResiduals) && candidate.rowResiduals.length === problem2.points.length, "candidate row count");
  const returned = /* @__PURE__ */ new Map();
  for (const body2 of candidate.bodies) {
    bodyData(body2);
    requireData(input.has(body2.id) && !returned.has(body2.id), "candidate body identity");
    inertia(body2);
    returned.set(body2.id, body2);
    const original = input.get(body2.id);
    if (componentError(body2.positionM, original.positionM) !== 0 || body2.inverseMass !== original.inverseMass || body2.inverseInertiaWorld.some((row, i) => componentError(row, original.inverseInertiaWorld[i]) !== 0)) {
      report.violations.push(`candidate changed fixed model data: ${body2.id}`);
    }
  }
  for (let i = 0; i < problem2.points.length; i++) {
    const point = problem2.points[i], lambda = candidate.normalImpulsesNs[i];
    finite(lambda, "normal impulse");
    for (const [id, sign] of [[point.aId, -1], [point.bId, 1]]) {
      const impulse = times(point.normalAtoB, sign * lambda), arm = minus(point.pointM, input.get(id).positionM);
      impulses.set(id, sum(impulses.get(id), impulse));
      torques.set(id, sum(torques.get(id), cross(arm, impulse)));
    }
  }
  const reconstructed = /* @__PURE__ */ new Map();
  for (const body2 of problem2.bodies) {
    const netImpulseNs = impulses.get(body2.id), netTorqueNms = torques.get(body2.id);
    const velocityMps = sum(body2.velocityMps, times(netImpulseNs, body2.inverseMass));
    const angularVelocityRadps = sum(body2.angularVelocityRadps, mv(body2.inverseInertiaWorld, netTorqueNms));
    vector(velocityMps, "reconstructed finite velocity");
    vector(angularVelocityRadps, "reconstructed finite angular velocity");
    const actual2 = returned.get(body2.id), wanted = expected.get(body2.id);
    const m2 = report.maxima;
    m2.reportedVelocityErrorMps = Math.max(m2.reportedVelocityErrorMps, componentError(actual2.velocityMps, velocityMps));
    m2.reportedAngularVelocityErrorRadps = Math.max(m2.reportedAngularVelocityErrorRadps, componentError(actual2.angularVelocityRadps, angularVelocityRadps));
    if (wanted !== void 0) {
      m2.oracleVelocityErrorMps = Math.max(m2.oracleVelocityErrorMps, componentError(velocityMps, wanted.velocityMps));
      m2.oracleAngularVelocityErrorRadps = Math.max(m2.oracleAngularVelocityErrorRadps, componentError(angularVelocityRadps, wanted.angularVelocityRadps));
      m2.oracleNetImpulseErrorNs = Math.max(m2.oracleNetImpulseErrorNs, componentError(netImpulseNs, wanted.netImpulseNs));
      m2.oracleNetTorqueErrorNms = Math.max(m2.oracleNetTorqueErrorNms, componentError(netTorqueNms, wanted.netTorqueNms));
    }
    const independent = { id: body2.id, velocityMps, angularVelocityRadps, netImpulseNs, netTorqueNms };
    reconstructed.set(body2.id, independent);
    report.bodies.push(independent);
    report.energy.freeKineticJ += kinetic(body2, moments.get(body2.id), body2.velocityMps, body2.angularVelocityRadps);
    report.energy.finalKineticJ += kinetic(body2, moments.get(body2.id), velocityMps, angularVelocityRadps);
  }
  for (let i = 0; i < problem2.points.length; i++) {
    const point = problem2.points[i], lambda = candidate.normalImpulsesNs[i];
    const a = input.get(point.aId), b = input.get(point.bId);
    const finalA = reconstructed.get(point.aId), finalB = reconstructed.get(point.bId);
    const armA = minus(point.pointM, a.positionM), armB = minus(point.pointM, b.positionM);
    const relative = minus(
      pointVelocity(finalB.velocityMps, finalB.angularVelocityRadps, armB),
      pointVelocity(finalA.velocityMps, finalA.angularVelocityRadps, armA)
    );
    const normalSpeedMps = dot(point.normalAtoB, relative);
    const tangentSpeedMps = Math.hypot(...minus(relative, times(point.normalAtoB, normalSpeedMps)));
    const row = {
      id: point.id,
      normalImpulseNs: lambda,
      normalSpeedMps,
      negativeNormalImpulseNs: Math.max(0, -lambda),
      complementarityJ: Math.abs(lambda * normalSpeedMps),
      tangentSpeedMps
    };
    report.rows.push(row);
    const m2 = report.maxima;
    m2.closingNormalSpeedMps = Math.max(m2.closingNormalSpeedMps, -normalSpeedMps);
    m2.negativeNormalImpulseNs = Math.max(m2.negativeNormalImpulseNs, row.negativeNormalImpulseNs);
    m2.complementarityJ = Math.max(m2.complementarityJ, row.complementarityJ);
    if (lambda > 0) m2.loadedTangentSpeedMps = Math.max(m2.loadedTangentSpeedMps, tangentSpeedMps);
    const claimed = candidate.rowResiduals[i];
    requireData(claimed.id === point.id, "candidate residual row identity/order");
    for (const field of ["normalSpeedMps", "negativeNormalImpulseNs", "complementarityJ", "tangentSpeedMps"]) {
      finite(claimed[field], "candidate residual");
      m2.reportedResidualError = Math.max(m2.reportedResidualError, Math.abs(row[field] - claimed[field]));
    }
    const freeRelative = minus(
      pointVelocity(b.velocityMps, b.angularVelocityRadps, armB),
      pointVelocity(a.velocityMps, a.angularVelocityRadps, armA)
    );
    report.energy.normalImpulseWorkJ += lambda * (dot(point.normalAtoB, freeRelative) + normalSpeedMps) / 2;
  }
  const c = candidate.certificate, m = report.maxima;
  for (const [field, actual2] of [
    ["maxClosingNormalSpeedMps", m.closingNormalSpeedMps],
    ["maxNegativeNormalImpulseNs", m.negativeNormalImpulseNs],
    ["maxComplementarityJ", m.complementarityJ],
    ["maxLoadedTangentSpeedMps", m.loadedTangentSpeedMps]
  ]) {
    finite(c[field], "candidate certificate");
    m.reportedResidualError = Math.max(m.reportedResidualError, Math.abs(c[field] - actual2));
  }
  finite(c.maxStationaritySqrtJ, "candidate stationarity");
  requireData(typeof c.zeroTangentFeasible === "boolean", "candidate friction flag");
  m.impulseWorkErrorJ = Math.abs(report.energy.finalKineticJ - report.energy.freeKineticJ - report.energy.normalImpulseWorkJ);
  const gate = VERIFICATION_GATE;
  report.normalKktPassed = m.closingNormalSpeedMps <= gate && m.negativeNormalImpulseNs <= gate && m.complementarityJ <= gate;
  report.zeroTangentFrictionFeasible = report.normalKktPassed && m.loadedTangentSpeedMps <= gate;
  report.oracleMatched = oracle !== void 0 && m.oracleVelocityErrorMps <= gate && m.oracleAngularVelocityErrorRadps <= gate && m.oracleNetImpulseErrorNs <= gate && m.oracleNetTorqueErrorNms <= gate;
  report.candidateReportsMatched = m.reportedVelocityErrorMps <= gate && m.reportedAngularVelocityErrorRadps <= gate && m.reportedResidualError <= gate && c.maxStationaritySqrtJ >= 0 && c.maxStationaritySqrtJ <= gate && c.zeroTangentFeasible === m.loadedTangentSpeedMps <= gate;
  if (!report.normalKktPassed) report.violations.push("independent normal complementarity failed");
  if (!report.zeroTangentFrictionFeasible) report.violations.push("zero tangent impulse is not friction-qualified on loaded rows");
  if (oracle !== void 0 && !report.oracleMatched) report.violations.push("independent Fraction body/load oracle differs");
  if (!report.candidateReportsMatched) report.violations.push("candidate state or residual report differs from signed-impulse reconstruction");
  if (!(m.impulseWorkErrorJ <= gate)) report.violations.push("independent normal impulse work balance failed");
  report.passed = report.violations.length === 0;
  return report;
}
function verifyNormalSolution(problem2, candidate, oracle) {
  requireData(oracle !== void 0 && oracle !== null, "oracle required");
  return verifyWithOptionalOracle(problem2, candidate, oracle);
}

// examples/physics-stack-stationary-witness-2276/controls.test.mts
var receipts = [];
var q = (n, d = 1n) => ({ n, d });
var zero2 = q(0n);
function body(id, y, fixed = false, x = 0, z = 0) {
  return { id, positionM: [x, y, z], velocityMps: [0, fixed ? 0 : -0.5, 0], angularVelocityRadps: [0, 0, 0], inverseMass: fixed ? 0 : 1, inverseInertiaWorld: [[fixed ? 0 : 24, 0, 0], [0, fixed ? 0 : 24, 0], [0, 0, fixed ? 0 : 24]] };
}
function problem(count) {
  const bodies = [body("floor", 0, true), body("one", 1), ...count === 2 ? [body("two", 2)] : []], points = [];
  for (let k = 0; k < count; k++) for (const [j, [x, z]] of [[-1, -1], [1, -1], [1, 1], [-1, 1]].entries()) points.push({ id: "row-" + k + "-" + j, aId: bodies[k].id, bId: bodies[k + 1].id, pointM: [x, k + 0.5, z], normalAtoB: [0, 1, 0] });
  return { bodies, points };
}
function successful(p, count) {
  const before = structuredClone(p), result = solveCore2(p, count);
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.deepEqual(p, before);
  assert.ok(result.exactApplied);
  assert.equal(result.exactApplied.points.length, 4 * count);
  assert.equal(result.stats.interfacesProcessed, count);
  assert.ok(result.stats.triangleTrials <= 4 * count);
  assert.ok(result.bodies.filter((b) => b.inverseMass === 1).every((b) => [...b.velocityMps, ...b.angularVelocityRadps].every((v) => Object.is(v, 0))));
  receipts.push({ problem: p, result, unitDynamicCount: count });
  return result;
}
function changed(f, status) {
  const p = problem(1);
  f(p);
  const before = structuredClone(p), r = solveCore2(p, 1);
  assert.equal(r.status, status, r.reason ?? "");
  assert.equal(r.ok, false);
  assert.equal(r.exactApplied, null);
  assert.equal(r.normalImpulsesNs, null);
  assert.deepEqual(p, before);
}
test("01 centered literal quarter loads retain four rows", () => {
  const r = successful(problem(1), 1);
  assert.deepEqual(r.exactApplied.points.map((p) => p.lambda), [{ n: "1", d: "4" }, { n: "0", d: "1" }, { n: "1", d: "4" }, { n: "0", d: "1" }]);
});
test("02 offset COM literal eighth eighth quarter loads", () => {
  const p = problem(1);
  p.bodies[1].positionM = [0.5, 1, 0];
  assert.deepEqual(successful(p, 1).exactApplied.points.map((p2) => p2.lambda), [{ n: "1", d: "8" }, { n: "1", d: "8" }, { n: "1", d: "4" }, { n: "0", d: "1" }]);
});
test("03 vertex retains exact zero weights", () => {
  const p = problem(1);
  p.bodies[1].positionM = [-1, 1, -1];
  assert.deepEqual(successful(p, 1).exactApplied.points.map((p2) => p2.lambda), [{ n: "1", d: "2" }, { n: "0", d: "1" }, { n: "0", d: "1" }, { n: "0", d: "1" }]);
});
test("04 edge retains zero complementarity rows", () => {
  const p = problem(1);
  p.bodies[1].positionM = [0, 1, -1];
  assert.deepEqual(successful(p, 1).exactApplied.points.map((p2) => p2.lambda), [{ n: "1", d: "4" }, { n: "1", d: "4" }, { n: "0", d: "1" }, { n: "0", d: "1" }]);
});
test("05 outside polygon is NO_WITNESS never infeasible", () => changed((p) => p.bodies[1].positionM = [2, 1, 0], "NO_WITNESS"));
test("06 reversed endpoint order retains directed load", () => {
  const p = problem(1);
  for (const point of p.points) {
    [point.aId, point.bId] = [point.bId, point.aId];
    point.normalAtoB = [0, -1, 0];
  }
  successful(p, 1);
});
test("07 two-body incoming load propagates exact ratios", () => {
  const r = successful(problem(2), 2);
  assert.deepEqual(r.exactApplied.points.map((p) => p.lambda), [{ n: "1", d: "2" }, { n: "0", d: "1" }, { n: "1", d: "2" }, { n: "0", d: "1" }, { n: "1", d: "4" }, { n: "0", d: "1" }, { n: "1", d: "4" }, { n: "0", d: "1" }]);
});
test("08 body array ordering and opaque IDs do not define chain", () => {
  const p = problem(2);
  p.bodies = [p.bodies[2], p.bodies[0], p.bodies[1]];
  successful(p, 2);
});
test("09 point permutation retains original row identities", () => {
  const p = problem(1);
  p.points = [p.points[3], p.points[1], p.points[0], p.points[2]];
  const r = successful(p, 1);
  assert.deepEqual(r.exactApplied.points.map((x) => x.id), p.points.map((x) => x.id));
});
test("10 zero load and signed-zero static metadata retain exact words", () => {
  const p = problem(1);
  p.bodies[1].velocityMps = [0, 0, 0];
  p.bodies[0].positionM = [-0, 0, -0];
  p.bodies[0].velocityMps = [-0, 0, -0];
  p.bodies[0].angularVelocityRadps = [0, -0, 0];
  p.bodies[0].inverseInertiaWorld = [[-0, 0, 0], [0, -0, 0], [0, 0, -0]];
  const result = successful(p, 1);
  assert.ok(result.exactApplied.points.every((p2) => p2.lambda.n === "0" && p2.lambda.d === "1"));
  assert.ok(Object.is(result.bodies[0].velocityMps[0], -0));
  assert.ok(Object.is(result.bodies[0].angularVelocityRadps[1], -0));
  assert.ok(Object.is(result.bodies[0].positionM[2], -0));
  assert.ok(Object.is(result.bodies[0].inverseInertiaWorld[0][0], -0));
});
test("11 branch profile refuses without solving", () => {
  const p = problem(2);
  for (const point of p.points.slice(4)) point.aId = "floor";
  assert.equal(solveCore2(p, 2).status, "UNSUPPORTED_PROFILE");
});
test("12 cycle disconnected from floor refuses", () => {
  const p = problem(2);
  for (const point of p.points.slice(0, 4)) point.aId = "two";
  assert.equal(solveCore2(p, 2).status, "UNSUPPORTED_PROFILE");
});
test("13 nonzero subnormal horizontal normal is not snapped", () => changed((p) => p.points[0].normalAtoB = [Number.MIN_VALUE, 1, 0], "UNSUPPORTED_PROFILE"));
test("14 near-unit vertical normal is not normalized", () => changed((p) => p.points[0].normalAtoB = [0, 1 - Number.EPSILON, 0], "UNSUPPORTED_PROFILE"));
test("15 nonzero horizontal free motion refuses", () => changed((p) => p.bodies[1].velocityMps = [Number.MIN_VALUE, -0.5, 0], "UNSUPPORTED_PROFILE"));
test("16 nonzero spin refuses", () => changed((p) => p.bodies[1].angularVelocityRadps = [Number.MIN_VALUE, 0, 0], "UNSUPPORTED_PROFILE"));
test("17 positive free vertical motion refuses", () => changed((p) => p.bodies[1].velocityMps = [0, Number.MIN_VALUE, 0], "UNSUPPORTED_PROFILE"));
test("18 nonunit inverse mass refuses", () => changed((p) => p.bodies[1].inverseMass = 0.5, "UNSUPPORTED_PROFILE"));
test("19 duplicate identity invalid", () => changed((p) => p.bodies[1].id = "floor", "INVALID_INPUT"));
test("20 unresolved endpoint invalid", () => changed((p) => p.points[0].aId = "missing", "INVALID_INPUT"));
test("21 accessor invalid without invoking getter", () => {
  const p = problem(1);
  let calls = 0;
  Object.defineProperty(p.bodies[1], "inverseMass", { enumerable: true, get() {
    calls++;
    return 1;
  } });
  assert.equal(solveCore2(p, 1).status, "INVALID_INPUT");
  assert.equal(calls, 0);
});
test("22 sole production entry never admits unit-core population", () => {
  assert.equal(solveStationaryNormal(problem(1)).status, "UNSUPPORTED_PROFILE");
  assert.equal(solveStationaryNormal(problem(2)).status, "UNSUPPORTED_PROFILE");
});
test("23 literal algebraic greedy trap is not global infeasibility", () => {
  const m = new Exact2(), upper = [[q(1n), q(1n), q(-1n)], [q(1n), q(1n), q(1n)], [q(1n), q(-1n), q(1n)], [q(1n), q(-1n), q(-1n)]], eps = q(1n, 1n << 53n), lower = [[q(1n), zero2, q(-1n)], [q(1n), eps, q(-1n)], [q(1n), zero2, q(1n)], [q(1n), eps, q(1n)]];
  assert.deepEqual(triangle2(m, upper, [q(1n), zero2, zero2]), [q(1n, 2n), zero2, q(1n, 2n), zero2]);
  assert.equal(triangle2(m, lower, [q(2n), q(-1n, 1n << 54n), zero2]), null);
  assert.ok(triangle2(m, lower, [q(2n), zero2, zero2]));
});
test("24 negative required support never yields negative multiplier success", () => {
  const m = new Exact2(), c = [[q(1n), zero2, zero2], [q(1n), q(1n), zero2], [q(1n), zero2, q(1n)], [q(1n), q(1n), q(1n)]];
  assert.equal(triangle2(m, c, [q(-1n), zero2, zero2]), null);
  assert.equal(m.stats.triangleTrials, 4);
});
test("25 exact singular triangles do not use epsilon pivot", () => {
  const m = new Exact2();
  assert.equal(triangle2(m, Array.from({ length: 4 }, () => [q(1n), zero2, zero2]), [q(1n), q(1n), zero2]), null);
  assert.equal(m.stats.triangleTrials, 4);
});
test("26 independent RNE and signed subnormal literal words", () => {
  const m = new Exact2(), D = 1n << 53n, word3 = (n) => {
    const b = Buffer.alloc(8);
    b.writeDoubleBE(n);
    return b.toString("hex");
  };
  for (const [n, d, w] of [[D + 1n, D, "3ff0000000000000"], [D + 3n, D, "3ff0000000000002"], [1n, 1n << 1074n, "0000000000000001"], [-1n, 1n << 1075n, "8000000000000000"], [1n, 1n << 1075n, "0000000000000000"]]) assert.equal(word3(m.number(m.make(n, d))), w);
});
test("27 actual oversized integer refuses before normalization", () => {
  const m = new Exact2();
  assert.throws(() => m.make(1n << 16384n), /integer bit limit/);
  assert.equal(m.stats.peakIntegerBits, 16385);
});
test("28 actual rational exhaustion without counter writes", () => {
  const m = new Exact2();
  for (let i = 0; i < 2e5; i++) m.neg(zero2);
  assert.throws(() => m.neg(zero2), /rational work limit/);
  assert.equal(m.stats.rationalOperations, 200001);
});
test("29 actual integer exhaustion without counter writes", () => {
  const m = new Exact2();
  for (let i = 0; i < 2e6; i++) m.addI(0n, 0n);
  assert.throws(() => m.addI(0n, 0n), /integer work limit/);
  assert.equal(m.stats.integerOperations, 2000001);
});
test("30 asymmetric rounded endpoint levers propagate independently", () => {
  const p = problem(2);
  p.bodies[1].positionM = [0.4, 1, 0];
  p.bodies[2].positionM = [0.2, 2, 0];
  for (const point of p.points) point.pointM = [point.pointM[0] < 0 ? 0.1 : 1.1, point.pointM[1], point.pointM[2]];
  const r = successful(p, 2), edge = r.exactApplied.points[4];
  assert.notEqual(edge.a.coefficients[5] + edge.b.coefficients[5], 0.4 - 0.2);
});
var actual = null;
var fixture;
test("31 identical authenticated original ALIGNED32 and old independent oracle", () => {
  assert.ok(process.env.STATIONARY_FIXTURE);
  const bytes = readFileSync(process.env.STATIONARY_FIXTURE);
  assert.equal(createHash("sha256").update(bytes).digest("hex"), "da088aeff200bdcfe27927f11286e8a9f6a63f772c6f5558ae11feb2e9d769eb");
  fixture = JSON.parse(bytes.toString());
  const before = structuredClone(fixture.problem);
  actual = solveStationaryNormal(fixture.problem);
  assert.equal(actual.ok, true, JSON.stringify(actual));
  assert.deepEqual(fixture.problem, before);
  const verification = verifyNormalSolution(fixture.problem, verifierView(fixture.problem, actual), fixture.oracle);
  assert.equal(verification.passed, true, JSON.stringify(verification));
  assert.equal(actual.normalImpulsesNs.length, 32);
  receipts.push({ problem: fixture.problem, result: actual, originalVerification: verification });
});
test("32 actual original32 deterministic repeated result and unchanged fixed caps", () => {
  assert.ok(actual);
  assert.deepEqual(solveStationaryNormal(fixture.problem), actual);
  assert.deepEqual(STATIONARY_LIMITS, { rationalOperations: 2e5, integerOperations: 2e6, integerBits: 16384, triangleTrials: 32 });
});
function numericWords(value) {
  const words = [];
  function walk(v) {
    if (typeof v === "number") {
      assert.ok(Number.isFinite(v));
      const b = Buffer.alloc(8);
      b.writeDoubleLE(v);
      words.push(b);
    } else if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === "object") Object.values(v).forEach(walk);
  }
  walk(value);
  assert.ok(words.length <= 16384);
  return Buffer.concat(words).toString("hex");
}
after(() => {
  assert.ok(process.env.STATIONARY_RECEIPTS);
  const rows = receipts.map((x) => {
    const r = x;
    return { ...r, problemWordsF64leHex: numericWords(r.problem), resultWordsF64leHex: numericWords(r.result) };
  });
  const text = rows.map((x) => JSON.stringify(x) + "\n").join("");
  assert.ok(Buffer.byteLength(text) <= 2 ** 21);
  writeFileSync(process.env.STATIONARY_RECEIPTS, text, { flag: "wx" });
});
