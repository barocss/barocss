"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCharacterCore = createCharacterCore;
const capsule_query_js_1 = require("../capsule-query.js");
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
const math_js_1 = require("./math.js");
const admission_js_1 = require("./admission.js");
const state_js_1 = require("./state.js");
const query_js_1 = require("./query.js");
const slide_js_1 = require("./slide.js");
const ground_js_1 = require("./ground.js");
const step_assist_js_1 = require("./step-assist.js");
/** Private direct harness entry. The public facade uses this same core with capture disabled. */
function createCharacterCore(scene, positionM, diagnostic = {}, options = {}) {
    const admitted = (0, admission_js_1.admitConfig)({ version: 1, profile: profile_js_1.PROFILE, scene, positionM });
    const query = (0, capsule_query_js_1.createUprightCapsuleQuery)(admitted.scene);
    let state;
    try {
        const snapshot = query.getSnapshot();
        query.sweep({ revision: snapshot.revision, centerM: [...admitted.positionM], displacementM: [0, 0, 0], excludeId: null });
        state = (0, state_js_1.initialState)(admitted.positionM, snapshot.revision);
    }
    catch (error) {
        query.dispose();
        throw error;
    }
    const capture = options.capture ?? true;
    let lastRejected = null, disposed = false;
    function live() { if (disposed)
        throw new capsule_query_error_js_1.PhysicsError('DISPOSED', 'Capsule controller is disposed'); }
    return {
        getState() { live(); return (0, math_js_1.clone)(state); },
        getLastRejected() { return (0, math_js_1.clone)(lastRejected); },
        step(dt, velocity, revision = state.sceneRevision) {
            live();
            let attempted = null;
            try {
                const request = (0, admission_js_1.admitCoreCommand)(dt, velocity, revision, state.sceneRevision, state.stepIndex);
                const next = (0, math_js_1.clone)(state);
                attempted = next;
                next.queryCount = 0;
                next.lastQueries = [];
                next.lastSegments = [];
                next.blocked = false;
                const assisted = !!state.assist, speed = Math.hypot(request[0], request[2]);
                if (assisted && (speed === 0 || Math.abs(request[0] / speed - state.assist.directionXZ[0]) > 1e-12 ||
                    Math.abs(request[2] / speed - state.assist.directionXZ[1]) > 1e-12)) {
                    throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller assist request changed');
                }
                const predicted = state.grounded || assisted ? 0 : state.fallVelocityYMps + profile_js_1.GRAVITY * profile_js_1.DT;
                next.fallVelocityYMps = predicted;
                next.gravityPrediction = capture ? {
                    previousFallVelocityYMps: state.fallVelocityYMps, previousGrounded: state.grounded,
                    previousAssisted: assisted, predictedFallVelocityYMps: predicted, predictedDeltaYM: predicted * profile_js_1.DT,
                } : null;
                const context = (0, query_js_1.queryContext)(query, next, diagnostic, capture);
                const delta = [request[0] * profile_js_1.DT, predicted * profile_js_1.DT, request[2] * profile_js_1.DT];
                let p = (0, slide_js_1.move)(state.positionM, delta, next, context, diagnostic);
                p = (0, ground_js_1.snap)(p, next, context);
                (0, step_assist_js_1.validateAssist)(p, next, context, diagnostic);
                if (diagnostic.numericFault)
                    throw new capsule_query_error_js_1.PhysicsError('NUMERIC_LIMIT', 'Internal controller numeric fault');
                const actualVelocity = p.map((value, index) => (value - state.positionM[index]) / profile_js_1.DT);
                (0, state_js_1.validateState)(p, actualVelocity, request, state);
                next.positionM = p;
                next.velocityMps = actualVelocity;
                next.stepIndex++;
                next.timeSeconds = next.stepIndex * profile_js_1.DT;
                state = next;
                lastRejected = null;
                return (0, math_js_1.clone)(state);
            }
            catch (error) {
                if (capture)
                    lastRejected = { acceptedState: (0, math_js_1.clone)(state), attemptedState: (0, math_js_1.clone)(attempted), error: (0, state_js_1.errorRecord)(error) };
                throw error;
            }
        },
        dispose() { if (!disposed) {
            disposed = true;
            query.dispose();
        } },
    };
}
