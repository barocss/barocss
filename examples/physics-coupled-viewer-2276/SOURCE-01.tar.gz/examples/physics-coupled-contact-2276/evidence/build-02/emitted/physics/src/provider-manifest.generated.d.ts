export declare const providerManifest: {
    format: string;
    version: number;
    ancestorProviderBuild: {
        bytes: number;
        sha256: string;
    };
    sourceFiles: {
        "B/candidate.ts": {
            bytes: number;
            sha256: string;
        };
        "B/native.ts": {
            bytes: number;
            sha256: string;
        };
        "C/candidate.ts": {
            bytes: number;
            sha256: string;
        };
        "entry.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/broadphase.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-fluid-data.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-proxy-admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-proxy-pose.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-proxy-types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-proxy-validation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cad-proxy.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-contact.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query-error.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/geometry.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/profile.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/snapshot.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/sweep.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/capsule-query/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd-box.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd-pair.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd-rounded-box.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd-slab.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd-sphere-pair-exact.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/ccd.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character-controller.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/core.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/ground.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/math.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/profile.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/query.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/slide.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/state.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/step-assist.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/character/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/constraints.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/metrics.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/profile.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/solver.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/topology.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/cloth/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/collision.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/contact-manifold.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/contact-tangent.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/coupled-plan.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/errors.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/linear-solver.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/measure.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/pose.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/postcontact.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/projection.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/report.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/rows.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/stage.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/disjoint-hinge/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/domain/admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/domain/cloth-reference.generated.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/domain/cloth.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/domain/fluid.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/domain/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/dynamic-anchor-pair.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/dynamic-fixed-joint.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/dynamic-hinge-joint.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/boundary.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/constants.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/diagnostics.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/kernel.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/neighbors.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/pbf.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/static-box.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/fluid/visual-viscosity.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/generate-provider.mjs": {
            bytes: number;
            sha256: string;
        };
        "physics/src/identity.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/index.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/internal-types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/joint-motor.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/joints.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/limits.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/math.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/model-admission.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/persistent-box-contact.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/phase-hit.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/private-phase.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/producer.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/recording-owner.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/replay-compare.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/replay-json.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/replay-validation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/replay.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/rigid-forced-rotation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/rigid-free-rotation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/rotation-validation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/scene-profile.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/sleep.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/types.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/validation.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/warm-transport.ts": {
            bytes: number;
            sha256: string;
        };
        "physics/src/world.ts": {
            bytes: number;
            sha256: string;
        };
    };
    scope: string;
    slots: string;
};
