/** Private cold island candidate. No integration, World, cache, fixture or expected-state imports. */
import { PhysicsError, type Body, type Hit, type PhysicsContact, type PhysicsPairStats, type Vec3 } from '../internal-types.js';
import type { CompletedContactPair, ContactContribution } from '../contact-contribution.js';
import type { ContactGeometry } from './contact-types.js';
import type { NormalProblem, NormalSolverResult } from './normal-solver.js';
import type { FullPairPositionAttempt, FullPairPositionStats, PositionPair } from './world-types.js';
export interface IslandGeometry {
    aIndex: number;
    bIndex: number;
    pairKey: string;
    aId: string;
    bId: string;
    hit: Hit | null;
    geometry: ContactGeometry;
}
export interface IslandApplication {
    id: string;
    aIndex: number;
    bIndex: number;
    pairKey: string;
    pointKey: string;
    pointM: Vec3;
    normalAtoB: Vec3;
    normalImpulseNs: number;
    contribution: ContactContribution;
}
export interface AppliedNormalCertificate {
    maxClosingNormalSpeedMps: number;
    maxComplementarityJ: number;
    maxStationaritySqrtJ: number;
    maxSolverVelocityDifference: number;
    maxLinearMomentumResidualNs: number;
    maxAngularMomentumResidualNms: number;
    postValidationCholeskyFactorizations: number;
}
export interface FrictionlessIslandDiagnostics {
    freeBodies: Body[];
    pairs: PositionPair[];
    freeGeometry: IslandGeometry[];
    normalProblem: NormalProblem | null;
    normalResult: NormalSolverResult | null;
    applications: IslandApplication[];
    velocityBodies: Body[] | null;
    appliedNormalCertificate: AppliedNormalCertificate | null;
    positionAttempt: FullPairPositionAttempt | null;
    positionStats: FullPairPositionStats | null;
    postGeometry: IslandGeometry[];
    pairContributions: readonly CompletedContactPair[];
    normalSolverCalls: number;
    positionPhaseCalls: number;
    positionSolverCalls: number | null;
}
export interface PreparedFrictionlessIsland {
    candidateBodies: Body[];
    contacts: PhysicsContact[];
    pairStats: PhysicsPairStats;
    pairContributions: readonly CompletedContactPair[];
    diagnostics: FrictionlessIslandDiagnostics;
}
export declare class FrictionlessIslandFailure extends PhysicsError {
    readonly diagnostics: FrictionlessIslandDiagnostics;
    constructor(reason: PhysicsError, diagnostics: FrictionlessIslandDiagnostics);
}
/** Caller supplies actual post-integration FREE bodies and every sorted eligible pair. */
export declare function prepareFrictionlessIsland(freeBodies: readonly Body[], pairs: readonly PositionPair[], context: {
    jointCount: number;
}): PreparedFrictionlessIsland;
