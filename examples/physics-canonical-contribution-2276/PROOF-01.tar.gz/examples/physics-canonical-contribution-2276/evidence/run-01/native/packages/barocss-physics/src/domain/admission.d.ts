/** Complete pure-data P5 admission. Runtime buffers and initialization belong to World. */
import type { PhysicsModel, WorldOptions } from '../types.js';
import type { DomainModelData } from './types.js';
/** Caller has passed common copyData/header validation. No initializer is invoked. */
export declare function admitDomainModel(model: PhysicsModel, options: WorldOptions): DomainModelData | null;
