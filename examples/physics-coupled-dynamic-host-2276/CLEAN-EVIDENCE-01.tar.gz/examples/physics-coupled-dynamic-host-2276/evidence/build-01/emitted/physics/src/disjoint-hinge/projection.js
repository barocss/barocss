"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectHingePoseVelocity = projectHingePoseVelocity;
const validation_js_1 = require("../validation.js");
const collision_js_1 = require("../collision.js");
const math_js_1 = require("../math.js");
const pose_js_1 = require("./pose.js");
const errors_js_1 = require("./errors.js");
const measure_js_1 = require("./measure.js");
const rows_js_1 = require("./rows.js");
const linear_solver_js_1 = require("./linear-solver.js");
function projectHingePoseVelocity(input) {
    const beforeBodies = input.bodies.map(validation_js_1.copyBody);
    const originalOriginM = [...input.pair.originM];
    // Targets are original input metrics, not old pose output diagnostics.
    const before = (0, measure_js_1.measureBodies)(beforeBodies, input.pair.joint, originalOriginM);
    const pose = (0, pose_js_1.projectCoupledHinge)(input);
    const bodies = pose.bodies.map(validation_js_1.copyBody), rows = (0, rows_js_1.makeRows)(beforeBodies, bodies, input.pair.joint, before, originalOriginM, pose.poseReport.targetAngleRad);
    const result = (0, linear_solver_js_1.solveDimensionlessVelocity)(rows.problem);
    if (!result.identity) {
        for (let i = 0; i < 2; i++) {
            bodies[i].velocityMps = result.y.slice(i * 6, i * 6 + 3).map((value, j) => value * rows.columnScales[i * 6 + j]);
            bodies[i].angularVelocityRadps = result.y.slice(i * 6 + 3, i * 6 + 6).map((value, j) => value * rows.columnScales[i * 6 + 3 + j]);
        }
    }
    // Preserve the original canonical bounds before checking new output fields.
    (0, collision_js_1.validateResult)(bodies, []);
    const after = (0, measure_js_1.measureBodies)(bodies, input.pair.joint, originalOriginM);
    const velocityCorrections = { linearMps: bodies.map((body, i) => (0, math_js_1.sub)(body.velocityMps, beforeBodies[i].velocityMps)), angularRadps: bodies.map((body, i) => (0, math_js_1.sub)(body.angularVelocityRadps, beforeBodies[i].angularVelocityRadps)) };
    const changedComponents = bodies.map((body, i) => [...body.velocityMps, ...body.angularVelocityRadps].map((value, j) => !Object.is(value, [...beforeBodies[i].velocityMps, ...beforeBodies[i].angularVelocityRadps][j])));
    const identityVelocityBitsPreserved = result.identity && changedComponents.every(row => row.every(changed => !changed));
    const finalX = bodies.flatMap(body => [...body.velocityMps, ...body.angularVelocityRadps]);
    let sum = 0;
    for (let j = 0; j < 12; j++) {
        const delta = finalX[j] - rows.physicalX0[j];
        sum += rows.physicalH[j] * (delta * delta);
    }
    const objectiveJ = .5 * sum;
    const physicalLambda = result.lambda.map((value, i) => 1 * value / (i === 11 ? 10 : rows.rowDivisors[i]));
    const projection = { dofOrder: rows.dofOrder, rowIds: result.activeStop ? [...rows.rowIds, `stop.${rows.stopKind}`] : rows.rowIds,
        physicalA: rows.physicalA, physicalB: rows.physicalB, physicalH: rows.physicalH, physicalX0: rows.physicalX0, columnScales: rows.columnScales, rowDivisors: rows.rowDivisors,
        dimensionlessA: rows.dimensionlessA, dimensionlessB: rows.dimensionlessB, dimensionlessH: rows.dimensionlessH, dimensionlessX0: rows.dimensionlessX0,
        centerOfMassOriginM: rows.centerOfMassOriginM, originalOriginM: rows.originalOriginM, stopKind: rows.stopKind, physicalStopRow: rows.physicalStopRow, dimensionlessStopRow: rows.dimensionlessStopRow,
        result, physicalLambda, objectiveJ, rankSufficientMarginKgM2: rows.rankSufficientMarginKgM2 };
    const diagnostics = { poseStage: pose.diagnostics, before, after, velocityCorrections, projection, changedComponents, identityVelocityBitsPreserved, poseLawEvaluations: 1, sourceStepIndex: input.sourceStepIndex, sourceTimeSeconds: input.sourceTimeSeconds };
    if (!(0, errors_js_1.finiteData)(diagnostics) || !(0, errors_js_1.finiteData)(pose.poseReport) || objectiveJ < 0 || result.identity && !identityVelocityBitsPreserved)
        (0, errors_js_1.fail)('result');
    return { bodies: bodies.map(validation_js_1.copyBody), poseReport: structuredClone(pose.poseReport), diagnostics: structuredClone(diagnostics) };
}
