"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.solveStaticTangent = solveStaticTangent;
const math_js_1 = require("./math.js");
const validation_js_1 = require("./validation.js");
function unsafeTangent() {
    return (0, validation_js_1.error)('NUMERIC_LIMIT', 'unsafe static tangent response');
}
/** Solve the two physical tangent constraints; the caller owns the Coulomb branch. */
function solveStaticTangent(a, b, armA, armB, normal, direction, speed, tangentMass) {
    const perpendicular = (0, math_js_1.cross)(normal, direction);
    const length = Math.hypot(...perpendicular);
    if (!(length > 0) || !Number.isFinite(length))
        unsafeTangent();
    const second = (0, math_js_1.scale)(perpendicular, 1 / length);
    const firstAxisA = (0, math_js_1.cross)(armA, direction), firstAxisB = (0, math_js_1.cross)(armB, direction);
    const secondAxisA = (0, math_js_1.cross)(armA, second), secondAxisB = (0, math_js_1.cross)(armB, second);
    const secondResponseA = (0, math_js_1.inverseInertia)(a, secondAxisA);
    const secondResponseB = (0, math_js_1.inverseInertia)(b, secondAxisB);
    const coupledMass = (0, math_js_1.dot)(firstAxisA, secondResponseA) + (0, math_js_1.dot)(firstAxisB, secondResponseB);
    const secondMass = a.inverseMass + b.inverseMass
        + (0, math_js_1.dot)(secondAxisA, secondResponseA) + (0, math_js_1.dot)(secondAxisB, secondResponseB);
    if (![tangentMass, coupledMass, secondMass].every(Number.isFinite)
        || !(tangentMass > 0) || !(secondMass > 0))
        unsafeTangent();
    let firstImpulse, secondImpulse;
    if (coupledMass === 0) {
        // Keep the scalar arithmetic for uncoupled contacts, including exact
        // representable sphere static/dynamic boundaries.
        firstImpulse = -speed / tangentMass;
        secondImpulse = 0;
    }
    else if (tangentMass >= secondMass) {
        const ratio = coupledMass / tangentMass;
        const schur = secondMass - coupledMass * ratio;
        if (!Number.isFinite(ratio) || !(schur > 0) || !Number.isFinite(schur))
            unsafeTangent();
        secondImpulse = speed * ratio / schur;
        firstImpulse = (-speed - coupledMass * secondImpulse) / tangentMass;
    }
    else {
        const ratio = coupledMass / secondMass;
        const schur = tangentMass - coupledMass * ratio;
        if (!Number.isFinite(ratio) || !(schur > 0) || !Number.isFinite(schur))
            unsafeTangent();
        firstImpulse = -speed / schur;
        secondImpulse = -ratio * firstImpulse;
    }
    const magnitudeNs = coupledMass === 0 ? Math.abs(firstImpulse)
        : Math.hypot(firstImpulse, secondImpulse);
    const impulseNs = coupledMass === 0 ? (0, math_js_1.scale)(direction, firstImpulse)
        : (0, math_js_1.add)((0, math_js_1.scale)(direction, firstImpulse), (0, math_js_1.scale)(second, secondImpulse));
    if (!Number.isFinite(magnitudeNs) || ![firstImpulse, secondImpulse, ...impulseNs].every(Number.isFinite)) {
        unsafeTangent();
    }
    return { impulseNs, magnitudeNs };
}
