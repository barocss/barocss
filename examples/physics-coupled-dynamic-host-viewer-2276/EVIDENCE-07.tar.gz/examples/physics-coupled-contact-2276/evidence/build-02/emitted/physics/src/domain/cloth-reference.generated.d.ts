import type { Cloth } from '../types.js';
export declare const nativeClothReference: Cloth;
