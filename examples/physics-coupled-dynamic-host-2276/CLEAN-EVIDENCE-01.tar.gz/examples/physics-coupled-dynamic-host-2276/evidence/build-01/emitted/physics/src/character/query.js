"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryContext = queryContext;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const profile_js_1 = require("./profile.js");
const math_js_1 = require("./math.js");
const state_js_1 = require("./state.js");
function queryContext(query, candidate, diagnostic, capture) {
    function raw(position, delta, kind, preview, excludeId = null) {
        if (candidate.queryCount >= (diagnostic.queryBudget ?? profile_js_1.QUERY_CAP)) {
            throw new capsule_query_error_js_1.PhysicsError('WORLD_LIMIT', 'Controller per-step query limit exhausted');
        }
        const input = {
            revision: candidate.sceneRevision, centerM: [...position], displacementM: [...delta], excludeId,
        };
        const index = candidate.queryCount;
        candidate.queryCount++;
        let hit;
        try {
            hit = query.sweep(input);
        }
        catch (error) {
            if (capture)
                candidate.lastQueries.push({ kind, preview, input: (0, math_js_1.clone)(input), hit: null, error: (0, state_js_1.errorRecord)(error) });
            throw error;
        }
        if (capture)
            candidate.lastQueries.push({ kind, preview, input: (0, math_js_1.clone)(input), hit: (0, math_js_1.clone)(hit), error: null });
        return { hit, indices: [index] };
    }
    function sweep(position, delta, kind, preview = false) {
        const first = raw(position, delta, kind, preview);
        if (first.hit?.toiFraction === 0 && (0, math_js_1.dot)(first.hit.normalFixtureToCapsule, delta) >= -1e-12) {
            const second = raw(position, delta, kind + '-fresh-touch-departure', preview, first.hit.bodyId);
            if (second.hit?.toiFraction === 0)
                throw new capsule_query_error_js_1.PhysicsError('INVALID_COMMAND', 'Controller second fresh touch is unresolved');
            return { hit: second.hit, indices: [...first.indices, ...second.indices] };
        }
        return first;
    }
    function commit(position, delta, kind, indices) {
        const target = position.map((value, index) => value + delta[index]);
        if (capture)
            candidate.lastSegments.push({
                kind, fromM: [...position], displacementM: [...delta], toM: [...target], queryIndices: [...indices],
            });
        return target;
    }
    return { sweep, commit };
}
