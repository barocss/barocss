import type { Vec3 } from './internal-types.js';
/** Actual application operands. These are not geometric boundary witnesses. */
export interface ContactApplicationSide {
    readonly comM: Vec3;
    readonly armM: Vec3;
    readonly linearImpulseNs: Vec3;
    readonly armTorqueNms: Vec3;
}
export interface ContactApplication {
    readonly onA: ContactApplicationSide;
    readonly onB: ContactApplicationSide;
    /** Present only for the original normal-axis/scalar angular mutation. */
    readonly normalOperands?: {
        readonly direction: Vec3;
        readonly torqueAxisA: Vec3;
        readonly torqueAxisB: Vec3;
        readonly scalarNs: number;
    };
}
export interface ContactContribution {
    readonly applications: readonly ContactApplication[];
}
interface BodyTotal {
    linearImpulseNs: Vec3;
    angularImpulseAboutWorldOriginNms: Vec3;
}
export interface CompletedContactPair {
    readonly aId: string;
    readonly bId: string;
    readonly anyNonzero: boolean;
    readonly onA: BodyTotal;
    readonly onB: BodyTotal;
}
export declare function emptyContactContribution(): ContactContribution;
/** Capture before mutation. Keep each body's actual COM and arm separately. */
export declare function contactApplication(comA: Vec3, comB: Vec3, armA: Vec3, armB: Vec3, impulseOnB: Vec3): ContactContribution;
/** Record cross(arm,normal)*scalar, exactly the original normal operands. */
export declare function normalContactApplication(comA: Vec3, comB: Vec3, armA: Vec3, armB: Vec3, direction: Vec3, torqueAxisA: Vec3, torqueAxisB: Vec3, scalarNs: number): ContactContribution;
export declare function combineContactContributions(a: ContactContribution, b: ContactContribution): ContactContribution;
/** Step-local storage: at most one bucket per existing solver pair, no trace. */
export declare class ContactPairAccumulator {
    private readonly pairs;
    add(aId: string, bId: string, contribution: ContactContribution): void;
    /** Validate the complete candidate ledger before World's existing commit. */
    finish(): readonly CompletedContactPair[];
}
export {};
