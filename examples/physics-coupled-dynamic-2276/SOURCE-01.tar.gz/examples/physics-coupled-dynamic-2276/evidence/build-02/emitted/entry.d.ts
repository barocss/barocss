export { coupledContactTarget } from './physics-coupled-dynamic-2276/candidate.js';
export type { CoupledInput, CoupledResult } from './physics-coupled-dynamic-2276/candidate.js';
export { coupledStaticTarget } from './physics-coupled-contact-2276/candidate.js';
