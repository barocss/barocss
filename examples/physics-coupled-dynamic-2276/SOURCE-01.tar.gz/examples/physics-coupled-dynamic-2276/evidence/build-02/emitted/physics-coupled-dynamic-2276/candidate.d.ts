/** Private cold single-point contact target. No runtime/geometry solver imports. */
import { type StaticInput, type StaticResult, type StaticCertificate, type Counts as StaticCounts, type Vec } from '../physics-coupled-contact-2276/candidate.js';
export interface CoupledInput extends StaticInput {
    muDynamicA: number;
    muDynamicB: number;
    /** Actual represented query normal. Never used for exact branch/root selection. */
    reportedNormal: Vec;
}
export interface DynamicCounts {
    rationalOps: number;
    integerOps: number;
    gcdSteps: number;
    peakBits: number;
    subdivisions: number;
    maxDyadicExponent: number;
}
export interface RootCertificate {
    lower: string;
    upper: string;
    openRootCount: number;
    exactRationalRoot: boolean;
    hRange: [string, string];
    disposition: 'ADMISSIBLE' | 'NEGATIVE_NORMAL';
}
export interface DynamicCertificate {
    staticPriority: StaticCertificate;
    nativeUnitNormal: string[];
    nativeTangentAxes: string[][];
    effectiveDynamicCoefficient: string;
    dynamicCoefficientSquared: string;
    k: string;
    c: string[];
    dBlock: string[][];
    schurA: string[][];
    schurB: string[];
    polynomialAscending: string[];
    sturmAscending: string[][];
    roots: RootCertificate[];
    selectedRoot: number;
    idealParameter: [string, string];
    idealNormalNs: [string, string];
    idealTangentNs: [string, string][];
    idealWorldImpulseNs: [string, string][];
    idealSlipMps: [string, string][];
    worldPresentationErrorNs: [string, string][];
    cacheNormalPresentationErrorNs: [string, string];
    cacheTangentPresentationErrorNs: [string, string][];
    representedNormalNs: string;
    representedTangentNs: string[];
    representedContactVelocityMps: string[];
    residualBounds: Record<string, [string, string]>;
    staticCounts: StaticCounts;
    dynamicCounts: DynamicCounts;
    cumulativeRationalOps: number;
    cumulativeGcdSteps: number;
}
type StaticTerminal = Extract<StaticResult, {
    status: 'UNRESOLVED';
}> | (Extract<StaticResult, {
    status: 'STATIC_TARGET';
}> & {
    dynamicAdmissionCounts: DynamicCounts;
    cumulativeRationalOps: number;
    cumulativeGcdSteps: number;
});
export type CoupledResult = StaticTerminal | {
    status: 'DYNAMIC_TARGET';
    worldImpulseNs: Vec;
    normalNs: number;
    tangentNs: Vec;
    certificate: DynamicCertificate;
} | {
    status: 'UNRESOLVED';
    reason: string;
    stage: 'dynamic';
    staticCounts: StaticCounts;
    dynamicCounts: DynamicCounts;
};
/** Static J/N/T and its complete certificate remain unchanged after common eligibility. */
export declare function coupledContactTarget(input: CoupledInput): CoupledResult;
export {};
