"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unknownMarker = exports.phaseLimits = void 0;
exports.bodyWords = bodyWords;
exports.phaseWorld = phaseWorld;
exports.phaseInitial = phaseInitial;
exports.phaseBegin = phaseBegin;
exports.phaseBodies = phaseBodies;
exports.phaseBody = phaseBody;
exports.phasePass = phasePass;
exports.phaseQuery = phaseQuery;
exports.phaseCacheInit = phaseCacheInit;
exports.phasePoint = phasePoint;
exports.phaseKind = phaseKind;
exports.phaseApplyBefore = phaseApplyBefore;
exports.phaseApplyAfter = phaseApplyAfter;
exports.phaseNoNormal = phaseNoNormal;
exports.phaseCorrectionBefore = phaseCorrectionBefore;
exports.phaseCorrectionAfter = phaseCorrectionAfter;
exports.phasePrepare = phasePrepare;
exports.phasePrivateSnapshot = phasePrivateSnapshot;
exports.phaseFault = phaseFault;
exports.phaseHistory = phaseHistory;
exports.phaseProducerBucket = phaseProducerBucket;
exports.phaseCoupledPlan = phaseCoupledPlan;
exports.phaseReserveLifecycle = phaseReserveLifecycle;
exports.phaseLifecycleBudget = phaseLifecycleBudget;
// @ts-nocheck
// This module is copied into the private staged graph. It is not a public API.
const types_js_1 = require("./types.js");
const candidate_js_1 = require("../../B/candidate.js");
const phase_hit_js_1 = require("./phase-hit.js");
const clone = x => structuredClone(x);
exports.phaseLimits = { worlds: 4, attempts: 8, records: 8192, applications: 4352, queries: 72, queryPoints: 288, anchorChecks: 7776, bytes: 16 * 1024 * 1024 - 65536 };
const contexts = [];
let active = null, records = 0, applications = 0, queries = 0, queryPoints = 0, anchorChecks = 0, traceBytes = 0, attempts = 0, lifecycleBytes = 0;
exports.unknownMarker = new Error('PRIVATE_PHASE_AFTER_ACTUAL_CANDIDATE_IMPULSE');
function refuse(message) { throw new types_js_1.PhysicsError('NUMERIC_LIMIT', message); }
function bodyWords(b) { return clone({ id: b.id, kind: b.kind, shape: b.shape, positionM: b.positionM, orientationXYZW: b.orientation, velocityMps: b.velocityMps, angularVelocityRadps: b.angularVelocityRadps, inertiaKgM2: b.inertiaKgM2 ?? null, inertiaDiagonalKgM2: b.inertiaDiagonalKgM2 ?? null, inverseMass: b.inverseMass }); }
function emit(kind, data) { if (!active)
    throw Error('No private phase attempt'); const record = { kind, world: active.id, attempt: active.current.attempt, stepIndex: active.current.stepIndex, owner: active.current.attempt === 0 ? 'creation' : 'step', outerPass: active.current.pass, ...clone(data) }; const size = new TextEncoder().encode(JSON.stringify(record)).length; if (records + 1 > exports.phaseLimits.records || traceBytes + lifecycleBytes + size > exports.phaseLimits.bytes)
    refuse('PRIVATE_PHASE_TRACE_RESOURCE'); active.current.records.push(record); records++; traceBytes += size; return record; }
function phaseWorld(read) { if (contexts.length >= exports.phaseLimits.worlds)
    refuse('PRIVATE_PHASE_WORLD_CAP'); const c = { id: contexts.length + 1, read, accepted: { cursor: 0, stepIndex: 0, cacheFrames: {} }, current: null, history: [], fault: null }; contexts.push(c); return c; }
function phaseInitial(c, prepare) { const previous = active; active = c; c.creation = { attempt: 0, stepIndex: 0, pass: -1, records: [], cacheFrames: {}, cacheOrigins: {}, point: null, kind: null, fault: null }; c.current = c.creation; try {
    const value = prepare();
    c.accepted = { ...c.accepted, cursor: c.creation.records.length };
    return value;
}
finally {
    c.current = null;
    active = previous;
} }
function phaseBegin(c, stepIndex, bodies) { if (++attempts > exports.phaseLimits.attempts)
    refuse('PRIVATE_PHASE_ATTEMPT_CAP'); active = c; c.current = { attempt: attempts, stepIndex, pass: -1, records: [], cacheFrames: {}, cacheOrigins: {}, point: null, kind: null, fault: c.fault }; c.history.push(c.current); emit('attempt-start', { acceptedCursor: c.accepted.cursor, bodies: bodies.map(bodyWords) }); }
function phaseBodies(kind, bodies, extra = {}) { emit(kind, { bodies: bodies.map(bodyWords), ...extra }); }
function phaseBody(kind, before, after, extra = {}) { emit(kind, { before, after: bodyWords(after), ...extra }); }
function phasePass(pass) { active.current.pass = pass; }
function box(b) { return { id: b.id, positionM: [...b.positionM], orientationXYZW: [...b.orientation], halfExtentsM: [...b.shape.halfExtentsM] }; }
function phaseQuery(a, b, final = false) {
    if (!final && active.current.fault === 'known')
        refuse('PRIVATE_B_FAULT_BEFORE_APPLICATION');
    if (queries + 1 > exports.phaseLimits.queries)
        refuse('PRIVATE_B_QUERY_CAP');
    const pair = { id: `w${active.id}-a${active.current.attempt}-q${queries + 1}`, a: box(a), b: box(b) };
    const result = (0, candidate_js_1.quantizedContact)(pair);
    queries++;
    queryPoints += result.points?.length ?? 0;
    anchorChecks += result.counts?.anchorChecks ?? 0;
    if (queryPoints > exports.phaseLimits.queryPoints || anchorChecks > exports.phaseLimits.anchorChecks)
        refuse('PRIVATE_B_POINT_ANCHOR_CAP');
    const projectedDepthM = result.status === 'HIT' ? Math.max(0, ...result.points.map(p => -p.bPointM.reduce((s, v, i) => s + (v - p.aPointM[i]) * result.normal[i], 0))) : null;
    const record = emit('geometry-query', { queryId: queries, final, pair, result, projectedDepthM, depthMapping: 'SAMPLED_PATCH_DEPTH', bodyA: bodyWords(a), bodyB: bodyWords(b) });
    if (result.status === 'UNRESOLVED')
        refuse('PRIVATE_B_UNRESOLVED:' + result.reason);
    if (result.status === 'MISS')
        return null;
    if (result.status !== 'HIT' || !['FACE', 'EDGE'].includes(result.feature?.kind) || !result.points.length || result.points.length > 4)
        refuse('PRIVATE_B_UNSUPPORTED_POINT_LIST');
    const n = result.normal;
    const penetration = projectedDepthM;
    return (0, phase_hit_js_1.checkedPhaseHit)([...n], penetration, [...result.points[0].pointM], record.queryId, result, pair);
}
function phaseCacheInit(key, point, normal, hit, impulse, prior) { const old = active.accepted.cacheFrames[key] ?? null; active.current.cacheOrigins[key] = prior ? 'prior-step' : 'cold'; emit('cache-init', { key, pointId: point.id, queryId: hit._phase.queryId, feature: hit._phase.result.feature, normal, prior: prior ?? null, producingFrame: old, actualCache: impulse }); }
function phasePoint(key, point, normal, hit, impulse, iteration, order) { active.current.point = { key, pointId: point.id, queryId: hit._phase.queryId, feature: clone(hit._phase.result.feature), queryPair: clone(hit._phase.pair), native: clone(point.exact), aPointM: clone(point.aPointM), bPointM: clone(point.bPointM), normal: clone(normal), iteration, order, cacheOrigin: active.current.cacheOrigins[key] ?? 'current-pass', producingFrame: clone(active.current.cacheFrames[key] ?? active.accepted.cacheFrames[key] ?? null), cacheBefore: clone(impulse), impulse }; }
function phaseKind(kind, branch = {}) { active.current.kind = kind; active.current.branch = clone(branch); }
function phaseApplyBefore(a, b, p, j) { if (applications + 1 > exports.phaseLimits.applications)
    refuse('PRIVATE_APPLY_CAP'); return { pointM: clone(p), anchorOnAM: clone(p), anchorOnBM: clone(p), impulseOnANs: j.map(v => -v), impulseOnBNs: clone(j), bodyABefore: bodyWords(a), bodyBBefore: bodyWords(b) }; }
function phaseApplyAfter(token, a, b) { applications++; const point = active.current.point; if (!point)
    throw Error('Missing actual point/cache context'); const { impulse, queryPair, ...metadata } = point; emit('impulse-application', { ...metadata, eventKind: active.current.kind, branch: active.current.branch, ...token, bodyAAfter: bodyWords(a), bodyBAfter: bodyWords(b), cacheAfter: clone(impulse) }); active.current.cacheFrames[point.key] = { normal: clone(point.normal), feature: clone(point.feature), pointId: point.pointId, native: clone(point.native), pair: clone(queryPair), queryId: point.queryId }; point.cacheBefore = clone(impulse); point.producingFrame = clone(active.current.cacheFrames[point.key]); }
function phaseNoNormal() { emit('normal-zero-no-call', { key: active.current.point?.key, normal: active.current.point?.normal }); }
function phaseCorrectionBefore(a, b, n, depth) { return { queryId: active.current.point.queryId, feature: clone(active.current.point.feature), bodyABefore: bodyWords(a), bodyBBefore: bodyWords(b), normal: clone(n), penetration: depth }; }
function phaseCorrectionAfter(token, a, b) { emit('pose-correction', { ...token, bodyAAfter: bodyWords(a), bodyBAfter: bodyWords(b) }); }
function phasePrepare(c, cache) { const prepared = { cursor: c.accepted.cursor + c.current.records.length, stepIndex: c.current.stepIndex, cacheFrames: clone(c.current.cacheFrames), actualCache: clone([...cache]) }; emit('attempt-prepared', { candidateAcceptedCursor: prepared.cursor, cache: prepared.actualCache }); prepared.cursor++; return prepared; }
function phasePrivateSnapshot(worldId) { const c = contexts[worldId - 1]; return clone({ accepted: c.accepted, world: c.read() }); }
function phaseFault(worldId, mode) { contexts[worldId - 1].fault = mode; }
function phaseHistory() { return clone({ counts: { worlds: contexts.length, attempts, records, applications, queries, queryPoints, anchorChecks, traceBytes }, worlds: contexts.map(c => ({ id: c.id, accepted: c.accepted, creation: c.creation ? (({ point, ...rest }) => rest)(c.creation) : null, history: c.history.map(({ point, ...rest }) => rest) })) }); }
function phaseProducerBucket(key, map, contribution) { if (active.current.fault === 'unknown' && contribution.nonzero) {
    const bucket = map.get(key);
    if (!bucket)
        throw Error('Unknown fault must follow actual producer bucket mutation');
    emit('producer-bucket-mutated-before-unknown', { key, contributionNonzero: true, bucket: clone(bucket) });
    throw exports.unknownMarker;
} }
function phaseCoupledPlan(data) { emit('coupled-plan', data); }
function phaseReserveLifecycle(bytes) { if (!Number.isSafeInteger(bytes) || bytes < 0 || traceBytes + lifecycleBytes + bytes > exports.phaseLimits.bytes)
    return false; lifecycleBytes += bytes; return true; }
function phaseLifecycleBudget() { return { traceBytes, lifecycleBytes, limitBytes: exports.phaseLimits.bytes }; }
