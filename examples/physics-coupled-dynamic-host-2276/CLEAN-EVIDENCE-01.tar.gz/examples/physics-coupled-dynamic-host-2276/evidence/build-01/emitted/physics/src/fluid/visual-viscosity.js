"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blendVisualViscosity = blendVisualViscosity;
const constants_js_1 = require("./constants.js");
const kernel_js_1 = require("./kernel.js");
/** Simultaneous neighbour velocity blend for the opt-in visual profile. */
function blendVisualViscosity(positions, velocities, grid, output, coefficient) {
    grid.rebuild(positions);
    for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
        const offset = index * 3;
        let weightSum = 0;
        let vx = 0, vy = 0, vz = 0;
        grid.each(index, (other, _rx, _ry, _rz, distanceSquared) => {
            const weight = (0, kernel_js_1.densityKernel)(distanceSquared);
            const otherOffset = other * 3;
            weightSum += weight;
            vx += weight * velocities[otherOffset];
            vy += weight * velocities[otherOffset + 1];
            vz += weight * velocities[otherOffset + 2];
        });
        const blend = weightSum > 0 ? coefficient / weightSum : 0;
        output[offset] = velocities[offset] + blend * (vx - weightSum * velocities[offset]);
        output[offset + 1] = velocities[offset + 1] + blend * (vy - weightSum * velocities[offset + 1]);
        output[offset + 2] = velocities[offset + 2] + blend * (vz - weightSum * velocities[offset + 2]);
    }
    velocities.set(output);
}
