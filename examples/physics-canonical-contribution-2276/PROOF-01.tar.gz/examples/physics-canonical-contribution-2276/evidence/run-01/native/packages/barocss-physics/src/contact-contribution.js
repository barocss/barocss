import { PhysicsError } from './types.js';
import { add, cross, scale } from './math.js';
const zero = () => ({ linearImpulseNs: [0, 0, 0], angularImpulseAboutWorldOriginNms: [0, 0, 0] });
const copy = (v) => [...v];
function check(v) {
    if (v.length !== 3 || v.some(value => !Number.isFinite(value))) {
        throw new PhysicsError('NUMERIC_LIMIT', 'unsafe actual contact contribution');
    }
}
function side(com, arm, impulse, torque) {
    for (const v of [com, arm, impulse, torque])
        check(v);
    return { comM: copy(com), armM: copy(arm), linearImpulseNs: copy(impulse), armTorqueNms: copy(torque) };
}
export function emptyContactContribution() { return { applications: [] }; }
/** Capture before mutation. Keep each body's actual COM and arm separately. */
export function contactApplication(comA, comB, armA, armB, impulseOnB) {
    const impulseOnA = scale(impulseOnB, -1);
    return { applications: [{ onA: side(comA, armA, impulseOnA, scale(cross(armA, impulseOnB), -1)),
                onB: side(comB, armB, impulseOnB, cross(armB, impulseOnB)) }] };
}
/** Record cross(arm,normal)*scalar, exactly the original normal operands. */
export function normalContactApplication(comA, comB, armA, armB, direction, torqueAxisA, torqueAxisB, scalarNs) {
    const impulseOnB = scale(direction, scalarNs);
    const contribution = { applications: [{
                onA: side(comA, armA, scale(impulseOnB, -1), scale(scale(torqueAxisA, scalarNs), -1)),
                onB: side(comB, armB, impulseOnB, scale(torqueAxisB, scalarNs)),
                normalOperands: { direction: copy(direction), torqueAxisA: copy(torqueAxisA),
                    torqueAxisB: copy(torqueAxisB), scalarNs },
            }] };
    return contribution;
}
export function combineContactContributions(a, b) {
    return { applications: [...a.applications, ...b.applications] };
}
/** Step-local storage: at most one bucket per existing solver pair, no trace. */
export class ContactPairAccumulator {
    pairs = new Map();
    add(aId, bId, contribution) {
        if (contribution.applications.length === 0)
            return;
        const key = aId + '\u0000' + bId;
        let pair = this.pairs.get(key);
        if (!pair) {
            pair = { aId, bId, anyNonzero: false, onA: zero(), onB: zero() };
            this.pairs.set(key, pair);
        }
        for (const application of contribution.applications) {
            for (const owner of ['onA', 'onB']) {
                const applied = application[owner];
                for (const v of [applied.comM, applied.armM, applied.linearImpulseNs, applied.armTorqueNms])
                    check(v);
                pair.anyNonzero ||= applied.linearImpulseNs.some(value => value !== 0)
                    || applied.armTorqueNms.some(value => value !== 0);
                const moment = add(cross(applied.comM, applied.linearImpulseNs), applied.armTorqueNms);
                pair[owner].linearImpulseNs = add(pair[owner].linearImpulseNs, applied.linearImpulseNs);
                pair[owner].angularImpulseAboutWorldOriginNms = add(pair[owner].angularImpulseAboutWorldOriginNms, moment);
            }
        }
    }
    /** Validate the complete candidate ledger before World's existing commit. */
    finish() {
        for (const pair of this.pairs.values())
            for (const owner of ['onA', 'onB']) {
                check(pair[owner].linearImpulseNs);
                check(pair[owner].angularImpulseAboutWorldOriginNms);
            }
        return [...this.pairs.values()].map(pair => ({ aId: pair.aId, bId: pair.bId,
            anyNonzero: pair.anyNonzero, onA: { linearImpulseNs: copy(pair.onA.linearImpulseNs),
                angularImpulseAboutWorldOriginNms: copy(pair.onA.angularImpulseAboutWorldOriginNms) },
            onB: { linearImpulseNs: copy(pair.onB.linearImpulseNs),
                angularImpulseAboutWorldOriginNms: copy(pair.onB.angularImpulseAboutWorldOriginNms) } }));
    }
}
