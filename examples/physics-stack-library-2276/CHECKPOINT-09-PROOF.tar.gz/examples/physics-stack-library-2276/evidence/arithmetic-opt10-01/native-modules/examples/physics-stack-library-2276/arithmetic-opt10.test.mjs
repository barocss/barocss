// Fixed32 independent integer-projection controls; no production hooks/counter writes.
import assert from 'node:assert/strict';
import test from 'node:test';
import { pathToFileURL } from 'node:url';
import { parseBody } from '../../packages/barocss-physics/src/validation.js';
import { StrictLineContext, StrictLineFailure, STRICT_LINE_LIMITS } from './candidate-strict-line-opt10.js';
const current = { StrictLineContext, StrictLineFailure, STRICT_LINE_LIMITS }, r = (n, d = 1n) => ({ n, d }), Z = r(0n);
const identity = [[r(1n), Z, Z], [Z, r(1n), Z], [Z, Z, r(1n)]];
const anchor = [[r(2n, 15n), r(-2n, 3n), r(11n, 15n)], [r(14n, 15n), r(1n, 3n), r(2n, 15n)], [r(-1n, 3n), r(2n, 3n), r(2n, 3n)]];
const vector = [r(1n, 2n), r(-1n, 4n), r(3n, 8n)];
async function baseline() { assert.ok(process.env.STRICT_LINE_BASELINE_MODULE); return import(pathToFileURL(process.env.STRICT_LINE_BASELINE_MODULE).href); }
function box(id, q = [0, 0, 0, 1], p = [0, 0, 0]) { const b = parseBody({ id, kind: 'dynamic', shape: { kind: 'box', halfExtentsM: [1, 1, 1] }, positionM: p, orientation: [0, 0, 0, 1], velocityMps: [0, 0, 0], massKg: 1, restitution: 0 }); b.orientation = [...q]; return b; }
function context(api, q = [0, 0, 0, 1], p = [0, 0, 0]) { return new api.StrictLineContext(box('a', q, p), box('b'), [0, 1, 0]); }
function probe(c) { return c; }
function arithmetic(api) { const seed = probe(context(api)).m, Constructor = Object.getPrototypeOf(seed).constructor, m = new Constructor(); assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 }); return m; }
function refusal(api, call, message) { assert.throws(call, (e) => e instanceof api.StrictLineFailure && e.message === message); }
function project(m, candidate, matrix, v) { return candidate ? m.localProjection(m.prepareRotation(matrix), v) : [0, 1, 2].map(j => m.dot(matrix.map(row => row[j]), v)); }
async function exact(matrix, v, expected) { const old = await baseline(), results = []; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api), before = structuredClone([matrix, v]), out = project(m, candidate, matrix, v);
    assert.deepEqual(out, expected);
    assert.deepEqual([matrix, v], before);
    results.push(out);
} assert.deepEqual(results[0], results[1]); }
function word(v) { const b = Buffer.alloc(8); b.writeDoubleBE(v); return b.toString('hex'); }
test('01 identity representation reuses actual numerators without arithmetic', async () => { const m = arithmetic(current); assert.deepEqual(m.prepareRotation(identity), { denominator: 1n, columns: [[1n, 0n, 0n], [0n, 1n, 0n], [0n, 0n, 1n]] }); assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 }); await exact(identity, [r(2n), r(-3n), Z], [r(2n), r(-3n), Z]); });
test('02 synthetic dyadic denominators use exact max denominator', async () => { const matrix = [[r(1n, 2n), Z, Z], [Z, r(1n, 4n), Z], [Z, Z, r(1n, 8n)]], m = arithmetic(current); assert.deepEqual(m.prepareRotation(matrix), { denominator: 8n, columns: [[4n, 0n, 0n], [0n, 2n, 0n], [0n, 0n, 1n]] }); await exact(matrix, vector, [r(1n, 4n), r(-1n, 16n), r(3n, 64n)]); });
test('03 independent LCM6 10 15 is30 and columns are5 3 2', async () => { const matrix = [[r(1n, 6n), r(1n, 10n), r(1n, 15n)], [Z, Z, Z], [Z, Z, Z]], m = arithmetic(current); assert.deepEqual(m.prepareRotation(matrix), { denominator: 30n, columns: [[5n, 0n, 0n], [3n, 0n, 0n], [2n, 0n, 0n]] }); await exact(matrix, [r(1n, 2n), Z, Z], [r(1n, 12n), r(1n, 20n), r(1n, 30n)]); });
test('04 repeated nonbinary denominators retain exact scale', async () => { const matrix = Array.from({ length: 3 }, () => [r(1n, 3n), r(1n, 3n), r(1n, 3n)]), m = arithmetic(current); assert.deepEqual(m.prepareRotation(matrix), { denominator: 3n, columns: [[1n, 1n, 1n], [1n, 1n, 1n], [1n, 1n, 1n]] }); await exact(matrix, [r(1n, 2n), r(1n, 4n), r(1n, 4n)], [r(1n, 3n), r(1n, 3n), r(1n, 3n)]); });
test('05 literal quaternion anchor matrix scales by15', () => { const m = arithmetic(current); assert.deepEqual(m.prepareRotation(anchor), { denominator: 15n, columns: [[2n, 14n, -5n], [-10n, 5n, 10n], [11n, 2n, 10n]] }); });
test('06 independent anchor projection equals minus7over24 minus1over6 7over12', async () => { await exact(anchor, vector, [r(-7n, 24n), r(-1n, 6n), r(7n, 12n)]); });
test('07 signed cancellation normalizes once to canonical zero', async () => { await exact([[r(1n), Z, Z], [r(1n), Z, Z], [r(1n), Z, Z]], [r(1n, 2n), r(-1n, 4n), r(-1n, 4n)], [Z, Z, Z]); });
test('08 quarter-turn column order is local transpose order', async () => { await exact([[Z, r(-1n), Z], [r(1n), Z, Z], [Z, Z, r(1n)]], vector, [r(-1n, 4n), r(-1n, 2n), r(3n, 8n)]); });
test('09 zero vector canonicalizes all nonbinary axes', async () => { await exact(anchor, [Z, Z, Z], [Z, Z, Z]); });
test('10 signed float zeros retain canonical rational zero words', async () => { const old = await baseline(); for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api), v = [m.from(-0), m.from(0), m.from(-0)], out = project(m, candidate, anchor, v);
    assert.deepEqual(out, [Z, Z, Z]);
    assert.deepEqual(out.map(x => word(m.number(x))), ['0000000000000000', '0000000000000000', '0000000000000000']);
} });
for (const [name, q] of [['11 actual quaternion proportional to1 2 3 4', [.25, .5, .75, 1]], ['12 negated quaternion same exact matrix', [-.25, -.5, -.75, -1]], ['13 dyadic scaled quaternion same exact matrix', [.125, .25, .375, .5]]])
    test(name, async () => { const old = await baseline(); for (const api of [current, old]) {
        const c = probe(context(api, [...q]));
        assert.deepEqual(c.boxes[0].rotation, anchor);
        assert.deepEqual(c.local(c.boxes[0], vector, true), [r(-7n, 24n), r(-1n, 6n), r(7n, 12n)]);
    } });
test('14 unchanged relative subtraction precedes integer projection', async () => { const old = await baseline(); for (const api of [current, old]) {
    const c = probe(context(api, [.25, .5, .75, 1], [1, 2, 3]));
    assert.deepEqual(c.local(c.boxes[0], [1.5, 1.75, 3.375].map(n => c.m.from(n))), [r(-7n, 24n), r(-1n, 6n), r(7n, 12n)]);
} });
test('15 invalid first zero quaternion precedes later invalid box', async () => { const old = await baseline(); for (const api of [current, old]) {
    const a = box('a', [0, 0, 0, 0]), b = box('b');
    b.shape = { kind: 'sphere', radiusM: 1 };
    refusal(api, () => new api.StrictLineContext(a, b, [0, 1, 0]), 'zero quaternion');
} });
test('16 second box invalid priority precedes any new LCM preparation', async () => { const old = await baseline(); for (const api of [current, old])
    refusal(api, () => new api.StrictLineContext(box('a', [.25, .5, .75, 1]), box('b', [0, 0, 0, 0]), [0, 1, 0]), 'zero quaternion'); });
test('17 nonfinite orientation retains original decode refusal', async () => { const old = await baseline(); for (const api of [current, old])
    refusal(api, () => context(api, [NaN, 0, 0, 1]), 'nonfinite exact operand'); });
test('18 invalid extent retains original constructor refusal', async () => { const old = await baseline(); for (const api of [current, old]) {
    const a = box('a');
    a.shape = { kind: 'box', halfExtentsM: [-1, 1, 1] };
    refusal(api, () => new api.StrictLineContext(a, box('b'), [0, 1, 0]), 'positive extents required');
} });
test('19 world decode refusal still precedes new stale-context guard', async () => { const old = await baseline(); for (const api of [current, old]) {
    const c = probe(context(api));
    refusal(api, () => c.m.checked(1n << 16384n), 'integer bit limit');
    refusal(api, () => c.local(c.boxes[0], [NaN, 0, 0].map(x => c.m.from(x))), 'nonfinite exact operand');
} });
test('20 synthetic half-scale subnormal and signed underflow words', async () => { const old = await baseline(), matrix = [[r(1n, 2n), Z, Z], [Z, r(1n), Z], [Z, Z, r(1n)]]; for (const n of [1n, -1n])
    for (const [candidate, api] of [[true, current], [false, old]]) {
        const m = arithmetic(api), out = project(m, candidate, matrix, [r(n, 1n << 1074n), r(n, 1n << 1074n), Z]);
        assert.equal(word(m.number(out[0])), n > 0n ? '0000000000000000' : '8000000000000000');
        assert.equal(word(m.number(out[1])), n > 0n ? '0000000000000001' : '8000000000000001');
    } });
test('21 independent nearest-even dyadic tie words', async () => { const old = await baseline(), D = 1n << 53n; for (const [n, expected] of [[D + 1n, '3ff0000000000000'], [D + 3n, '3ff0000000000002']])
    for (const [candidate, api] of [[true, current], [false, old]]) {
        const m = arithmetic(api), out = project(m, candidate, identity, [r(n, D), Z, Z]);
        assert.equal(word(m.number(out[0])), expected);
    } });
test('22 maximum finite and overflowing exact relative value', async () => { const old = await baseline(), K = 9007199254740991n << 971n; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api), out = project(m, candidate, identity, [r(K), r(2n * K), Z]);
    assert.equal(word(m.number(out[0])), '7fefffffffffffff');
    refusal(api, () => m.number(out[1]), 'rounded witness overflow');
} });
test('23 actual extreme quaternion and dyadic relative retain analytic identities', async () => { const old = await baseline(), D = 1n << 1074n, K = 9007199254740991n << 971n, N = D * D + 1n, results = []; for (const api of [current, old]) {
    const c = probe(context(api, [Number.MIN_VALUE, 0, 0, 1])), out = c.local(c.boxes[0], [Z, r(K), r(1n, D)], true);
    assert.equal(out[0].n, 0n);
    assert.equal(out[1].n * N, (K * (D * D - 1n) + 2n) * out[1].d);
    assert.equal(out[2].n * (D * N), (D * D - 1n - 2n * D * D * K) * out[2].d);
    assert.ok(c.m.counters.peakIntegerBits <= 16384);
    results.push(out);
} assert.deepEqual(results[0], results[1]); });
test('24 identity stale-bit counterexample is refused before new kernel work', async () => { const old = await baseline(); for (const api of [current, old]) {
    const c = probe(context(api));
    refusal(api, () => c.m.checked(1n << 16384n), 'integer bit limit');
    const before = { ...c.m.counters };
    refusal(api, () => c.local(c.boxes[0], [r(1n), r(1n, 2n), Z], true), 'integer bit limit');
    if (api === current)
        assert.deepEqual(c.m.counters, before);
} });
for (const [name, v] of [['25 old zero stale resume now explicitly refused', [Z, Z, Z]], ['26 old nonunit stale resume now explicitly refused', [r(1n, 2n), r(1n, 2n), r(1n, 2n)]]])
    test(name, async () => { const old = await baseline(), a = probe(context(current)), b = probe(context(old)); for (const [api, c] of [[current, a], [old, b]])
        refusal(api, () => c.m.checked(1n << 16384n), 'integer bit limit'); const before = { ...a.m.counters }; refusal(current, () => a.local(a.boxes[0], [...v], true), 'integer bit limit'); assert.deepEqual(a.m.counters, before); assert.deepEqual(b.local(b.boxes[0], [...v], true), [...v]); });
test('27 actual rational exhaustion is stopped by new entry guard', () => { const m = arithmetic(current), p = m.prepareRotation(identity); for (let i = 0; i < 200000; i++)
    m.neg(Z); refusal(current, () => m.neg(Z), 'rational work limit'); const before = { ...m.counters }; refusal(current, () => m.localProjection(p, [Z, Z, Z]), 'rational work limit'); assert.deepEqual(m.counters, before); });
test('28 actual integer exhaustion is stopped by new entry guard', () => { const m = arithmetic(current), p = m.prepareRotation(identity); for (let i = 0; i < 142857; i++)
    m.make(55n, 89n); refusal(current, () => m.make(55n, 89n), 'integer work limit'); const before = { ...m.counters }; refusal(current, () => m.localProjection(p, [Z, Z, Z]), 'integer work limit'); assert.deepEqual(m.counters, before); });
test('29 new nonunit preparation consumes actual bounded work', () => { const m = arithmetic(current); for (let i = 0; i < 142857; i++)
    m.make(55n, 89n); m.neg(Z); m.neg(Z); assert.equal(m.counters.integerOperations, 2000000); assert.deepEqual(m.prepareRotation(identity), { denominator: 1n, columns: [[1n, 0n, 0n], [0n, 1n, 0n], [0n, 0n, 1n]] }); refusal(current, () => m.prepareRotation([[r(1n, 6n), Z, Z], [Z, Z, Z], [Z, Z, Z]]), 'integer work limit'); assert.equal(m.counters.integerOperations, 2000001); });
test('30 three actual rational results fit where old multiple dots exhaust', async (t) => { const old = await baseline(), receipts = []; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api);
    for (let i = 0; i < 199997; i++)
        m.neg(Z);
    if (candidate)
        assert.deepEqual(project(m, true, identity, [r(1n), r(2n), r(3n)]), [r(1n), r(2n), r(3n)]);
    else
        refusal(api, () => project(m, false, identity, [r(1n), r(2n), r(3n)]), 'rational work limit');
    assert.equal(m.counters.rationalOperations, candidate ? 200000 : 200001);
    receipts.push({ ...m.counters });
} t.diagnostic(JSON.stringify({ newRationalResultsPerLocal: 3, unchangedCap: 200000, actualAdmission: receipts })); });
test('31 exactly22 new integer ticks fit while old identity dots exhaust', async (t) => { const old = await baseline(), receipts = []; for (const [candidate, api] of [[true, current], [false, old]]) {
    const m = arithmetic(api);
    for (let i = 0; i < 142855; i++)
        m.make(55n, 89n);
    for (let i = 0; i < 8; i++)
        m.neg(Z);
    assert.equal(m.counters.integerOperations, 1999978);
    if (candidate)
        assert.deepEqual(project(m, true, identity, [r(1n), r(2n), r(3n)]), [r(1n), r(2n), r(3n)]);
    else
        refusal(api, () => project(m, false, identity, [r(1n), r(2n), r(3n)]), 'integer work limit');
    assert.equal(m.counters.integerOperations, candidate ? 2000000 : 2000001);
    assert.equal(m.counters.rationalOperations, candidate ? 11 : 23);
    receipts.push({ ...m.counters });
} t.diagnostic(JSON.stringify({ newIdentityLocalTicks: 22, unchangedCap: 2000000, actualAdmission: receipts })); });
test('32 synthetic LCM and divisor products retain16384 raw-bit checks', () => { const m = arithmetic(current), D = 1n << 16383n, p = m.prepareRotation([[r(1n, D), Z, Z], [Z, Z, Z], [Z, Z, Z]]); assert.equal(p.denominator, D); assert.deepEqual(m.localProjection(p, [r(1n), Z, Z]), [r(1n, D), Z, Z]); assert.equal(m.counters.peakIntegerBits, 16384); refusal(current, () => m.localProjection(p, [r(1n, 2n), Z, Z]), 'integer bit limit'); assert.equal(m.counters.peakIntegerBits, 16385); const other = arithmetic(current), Q = 1n << 8192n; refusal(current, () => other.prepareRotation([[r(1n, Q), r(1n, Q + 1n), Z], [Z, Z, Z], [Z, Z, Z]]), 'integer bit limit'); assert.equal(other.counters.peakIntegerBits, 16385); });
