"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPhysicsWorld = createPhysicsWorld;
const lifecycle_capture_js_1 = require("./lifecycle-capture.js");
const private_phase_js_1 = require("./private-phase.js");
const coupled_plan_js_1 = require("./coupled-plan.js");
const producer_js_1 = require("./producer.js");
const private_phase_js_2 = require("./private-phase.js");
// @ts-nocheck
const private_phase_js_3 = require("./private-phase.js");
const types_js_1 = require("./types.js");
const model_admission_js_1 = require("./model-admission.js");
const identity_js_1 = require("./identity.js");
const recording_owner_js_1 = require("./recording-owner.js");
const provider_manifest_generated_js_1 = require("./provider-manifest.generated.js");
const limits_js_1 = require("./limits.js");
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
const joints_js_1 = require("./joints.js");
const joint_motor_js_1 = require("./joint-motor.js");
const dynamic_hinge_joint_js_1 = require("./dynamic-hinge-joint.js");
const collision_js_1 = require("./collision.js");
const contact_manifold_js_1 = require("./contact-manifold.js");
const persistent_box_contact_js_1 = require("./persistent-box-contact.js");
const ccd_js_1 = require("./ccd.js");
const ccd_pair_js_1 = require("./ccd-pair.js");
const ccd_box_js_1 = require("./ccd-box.js");
const broadphase_js_1 = require("./broadphase.js");
const stage_js_1 = require("./disjoint-hinge/stage.js");
const rotation_validation_js_1 = require("./rotation-validation.js");
const rigid_free_rotation_js_1 = require("./rigid-free-rotation.js");
const rigid_forced_rotation_js_1 = require("./rigid-forced-rotation.js");
const phase_hit_js_1 = require("./phase-hit.js");
function publicState(bodies, contacts, events, joints, ccdHits, pairStats, stepIndex, dt, identity, colliderIds, pairWrenches) {
    return {
        schemaVersion: 2, identity: { ...identity }, stepIndex, timeSeconds: stepIndex * dt,
        bodies: bodies.map((body) => ({ id: body.id, kind: body.kind, positionM: [...body.positionM],
            orientationXYZW: [...body.orientation], velocityMps: [...body.velocityMps],
            angularVelocityRadps: [...body.angularVelocityRadps], sleeping: body.sleeping ?? false })),
        contacts: (0, identity_js_1.copyData)(contacts), pairWrenches: (0, identity_js_1.copyData)(pairWrenches),
        events: events.map((event) => ({ colliderAId: colliderIds.get(event.aId),
            colliderBId: colliderIds.get(event.bId), kind: event.kind, phase: event.phase })),
        joints: joints.map((joint) => ({ id: joint.id, bodyAId: joint.aId, bodyBId: joint.bId,
            linearImpulseOnBNs: [...joint.linearImpulseNs], angularImpulseOnBNms: [...joint.angularImpulseNms],
            angleRad: joint.angleRad ?? null, motorImpulseNms: joint.motorImpulseNms ?? null })),
        ccdHits: ccdHits.map((hit) => ({ bodyId: hit.bodyId, colliderId: colliderIds.get(hit.fixtureId),
            toiFraction: hit.toiFraction, normalFixtureToBody: [...hit.normalFixtureToBody] })),
        cloths: [], fluids: [], pairStats: { ...pairStats },
    };
}
function createPhysicsWorld(model, options) {
    const admitted = (0, model_admission_js_1.admitModel)(model, options);
    if (admitted.domain || admitted.options.profile !== 'rigid-persistent-box-v1' || admitted.bodies.length !== 2 || admitted.bodies.some(b => b.shape.kind !== 'box' || b.sensor || b.ccd) || admitted.joints.length)
        (0, validation_js_1.error)('INVALID_CONFIG', 'private STATE2 producer qualifies only the frozen two-box persistent profile');
    const dt = admitted.options.fixedStepSeconds;
    const stepLimit = limits_js_1.MAX_STEPS;
    const gravity = [...admitted.model.gravityMps2];
    const useAabb = admitted.options.broadPhase === 'aabb';
    const usePersistentBox = admitted.options.profile === 'rigid-persistent-box-v1';
    let bodies = admitted.bodies;
    let joints = admitted.joints;
    let disjointHinges = admitted.disjointHinges;
    let modelCopy = admitted.model;
    let optionsCopy = admitted.options;
    const colliderIds = new Map(admitted.model.colliders.map((collider) => [collider.bodyId, collider.id]));
    const identity = { modelRevision: admitted.model.revision,
        modelDigest: (0, identity_js_1.digest)(admitted.model), configurationDigest: (0, identity_js_1.digest)(admitted.options),
        providerDigest: (0, identity_js_1.digest)(provider_manifest_generated_js_1.providerManifest), profile: admitted.options.profile,
        frameId: admitted.model.frame.id, fixedStepSeconds: dt };
    let dynamicHinge = joints.find((joint) => joint.kind === 'hinge' &&
        bodies[joint.aIndex].kind === 'dynamic');
    if (dynamicHinge && !disjointHinges)
        (0, dynamic_hinge_joint_js_1.admitDynamicHingeScene)(dynamicHinge, bodies, gravity);
    let ccd = (0, ccd_js_1.admitCcd)(bodies, joints.length, gravity);
    if (ccd.kind === 'box-pair' && usePersistentBox) {
        (0, validation_js_1.error)('INVALID_CONFIG', 'box CCD excludes persistent-box-v1');
    }
    const disabledPairs = new Set(joints.map((joint) => [bodies[joint.aIndex].id, bodies[joint.bIndex].id].sort().join('\u0000')));
    const pairs = [];
    for (let a = 0; a < bodies.length; a++)
        for (let b = a + 1; b < bodies.length; b++) {
            if (bodies[a].inverseMass !== 0 || bodies[b].inverseMass !== 0) {
                if (disabledPairs.has([bodies[a].id, bodies[b].id].sort().join('\u0000')))
                    continue;
                pairs.push(bodies[a].id < bodies[b].id ? [a, b] : [b, a]);
            }
        }
    pairs.sort((left, right) => bodies[left[0]].id < bodies[right[0]].id ? -1 :
        bodies[left[0]].id > bodies[right[0]].id ? 1 :
            bodies[left[1]].id < bodies[right[1]].id ? -1 : 1);
    let contacts = [];
    let pairWrenches = [];
    let events = [];
    let ccdHits = [];
    let pairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
    let jointStates = joints.map((joint) => ({ id: joint.id, kind: joint.kind,
        aId: bodies[joint.aIndex].id, bId: bodies[joint.bIndex].id,
        linearImpulseNs: [0, 0, 0], angularImpulseNms: [0, 0, 0],
        ...(joint.kind === 'hinge' ? { angleRad: 0 } : {}),
        ...(joint.motor ? { motorImpulseNms: 0 } : {}) }));
    let activePairs = new Map();
    let persistentPoints = new Map();
    let sleepFrames = bodies.map(() => 0);
    let stepIndex = 0;
    const phaseContext = (0, private_phase_js_3.phaseWorld)(() => ({ bodies: bodies.map(private_phase_js_3.bodyWords), persistentPoints: [...persistentPoints], contacts: (0, identity_js_1.copyData)(contacts), pairWrenches: (0, identity_js_1.copyData)(pairWrenches), activePairs: [...activePairs], sleepFrames: [...sleepFrames], stepIndex }));
    let disposed = false;
    let owner = null;
    let advancingOwner = null;
    const ensureActive = () => { if (disposed)
        (0, validation_js_1.error)('DISPOSED', 'world is disposed'); };
    contacts = (0, private_phase_js_2.phaseInitial)(phaseContext, () => (0, producer_js_1.acceptedGeometry)(bodies, pairs, colliderIds, (_a, _b, hit) => { if (hit)
        throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Initial contact must be cold separated MISS'); }));
    activePairs = (0, producer_js_1.acceptedMembership)(contacts);
    const world = {
        getModel() { ensureActive(); return (0, identity_js_1.copyData)(modelCopy); },
        getState() {
            ensureActive();
            return publicState(bodies, contacts, events, jointStates, ccdHits, pairStats, stepIndex, dt, identity, colliderIds, pairWrenches);
        },
        step(commands = []) {
            ensureActive();
            if (owner !== advancingOwner)
                (0, validation_js_1.error)('WORLD_OWNED', 'World has an exclusive recorder');
            if (stepIndex >= stepLimit)
                (0, validation_js_1.error)('WORLD_LIMIT', 'world step limit reached');
            if (owner && (owner.recording.frames.length >= 512 ||
                (Array.isArray(commands) && owner.commandCount + commands.length > 4096))) {
                (0, validation_js_1.error)('WORLD_LIMIT', 'recording frame or command limit reached');
            }
            let admittedCommands;
            try {
                admittedCommands = (0, identity_js_1.copyData)(commands);
            }
            catch (failure) {
                if (failure instanceof types_js_1.PhysicsError && failure.code === 'INVALID_CONFIG')
                    (0, validation_js_1.error)('INVALID_COMMAND', failure.message);
                throw failure;
            }
            if (owner && Array.isArray(admittedCommands) && owner.commandCount + admittedCommands.length > 4096) {
                (0, validation_js_1.error)('WORLD_LIMIT', 'recording command limit reached');
            }
            const actions = (0, validation_js_1.parseCommands)(admittedCommands, bodies);
            if (stepIndex !== 0 || persistentPoints.size !== 0 || admittedCommands.length !== 0 || pairs.length !== 1 || gravity.some(v => v !== 0))
                throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Only one first cold interval without commands/gravity is supported');
            if (disjointHinges)
                (0, stage_js_1.admitDisjointHingeCommands)(disjointHinges, bodies, actions, admittedCommands.length);
            else if (dynamicHinge)
                (0, dynamic_hinge_joint_js_1.admitDynamicHingeCommands)(dynamicHinge, bodies, actions);
            if (ccd.kind === 'box-pair')
                (0, ccd_box_js_1.rejectAngularBoxCommand)(actions.get(bodies[ccd.boxIndex].id));
            const preparedFrames = owner ? owner.prepareFrames(admittedCommands, stepIndex + 1) : null;
            (0, private_phase_js_3.phaseBegin)(phaseContext, stepIndex + 1, bodies);
            const next = bodies.map(validation_js_1.copyBody);
            const motorImpulses = joints.map(() => 0);
            const nextSleepFrames = sleepFrames.slice();
            for (const body of next) {
                if (body.kind !== 'dynamic')
                    continue;
                const action = actions.get(body.id);
                body.angularVelocityRadps = (0, math_js_1.add)(body.angularVelocityRadps, (0, math_js_1.inverseInertia)(body, action?.angularImpulseNms ?? [0, 0, 0]));
            }
            if (disjointHinges)
                (0, stage_js_1.driveDisjointHingeMotors)(disjointHinges, next, jointStates, motorImpulses);
            else
                for (let index = 0; index < joints.length; index++) {
                    const joint = joints[index];
                    if (!joint.motor)
                        continue;
                    motorImpulses[index] = next[joint.aIndex].kind === 'dynamic'
                        ? (0, joint_motor_js_1.driveDynamicHingeMotor)(joint, next[joint.aIndex], next[joint.bIndex], jointStates[index].angleRad)
                        : (0, joint_motor_js_1.driveHingeMotor)(joint, next[joint.bIndex], jointStates[index].angleRad);
                }
            for (let bodyIndex = 0; bodyIndex < next.length; bodyIndex++) {
                const body = next[bodyIndex];
                const action = actions.get(body.id);
                if (body.kind === 'kinematic') {
                    const target = action?.positionM ?? body.positionM;
                    const delta = target.map((value, index) => value - body.positionM[index]);
                    if (Math.hypot(...delta) > limits_js_1.MAX_STEP_DISPLACEMENT_M ||
                        delta.some((value) => Math.abs(value / dt) > 1000)) {
                        (0, validation_js_1.error)('NUMERIC_LIMIT', `${body.id} exceeded kinematic movement limit`);
                    }
                    body.velocityMps = delta.map((value) => value / dt);
                    body.positionM = [...target];
                }
                else if (body.kind === 'dynamic') {
                    if (body.angularVelocityRadps.some((value) => !Number.isFinite(value) || Math.abs(value) > 1000) ||
                        Math.hypot(...body.angularVelocityRadps) * dt > 10) {
                        (0, validation_js_1.error)('NUMERIC_LIMIT', `${body.id} exceeded angular movement limit`);
                    }
                    const traceRotation = (0, private_phase_js_3.bodyWords)(body);
                    const preparedRotation = (0, rigid_forced_rotation_js_1.prepareForcedRotation)(body, dt, action?.torqueNm ?? [0, 0, 0]) ??
                        (0, rigid_free_rotation_js_1.prepareFreeRotation)(body, dt) ?? {
                        orientation: (0, math_js_1.advanceOrientation)(body.orientation, body.angularVelocityRadps, dt),
                        angularVelocityRadps: [...body.angularVelocityRadps],
                    };
                    (0, rotation_validation_js_1.validateRotationResult)(preparedRotation, dt);
                    body.angularVelocityRadps = preparedRotation.angularVelocityRadps;
                    body.orientation = preparedRotation.orientation;
                    (0, private_phase_js_3.phaseBody)('rotation', traceRotation, body);
                    const traceKick = (0, private_phase_js_3.bodyWords)(body);
                    for (let i = 0; i < 3; i++) {
                        body.velocityMps[i] += (action?.impulseNs?.[i] ?? 0) * body.inverseMass;
                        body.velocityMps[i] += (gravity[i] + (action?.forceN?.[i] ?? 0) * body.inverseMass) * dt;
                    }
                    (0, private_phase_js_3.phaseBody)('gravity-kick', traceKick, body, { gravity, dt });
                    const traceDrift = (0, private_phase_js_3.bodyWords)(body);
                    if (Math.hypot(...body.velocityMps) * dt > limits_js_1.MAX_STEP_DISPLACEMENT_M) {
                        (0, validation_js_1.error)('NUMERIC_LIMIT', `${body.id} exceeded step displacement limit`);
                    }
                    for (let i = 0; i < 3; i++)
                        body.positionM[i] += body.velocityMps[i] * dt;
                    (0, private_phase_js_3.phaseBody)('drift', traceDrift, body, { dt });
                }
            }
            const hit = ccd.kind === 'static-boxes'
                ? (0, ccd_js_1.sweepSphere)(bodies[ccd.sphereIndex], next[ccd.sphereIndex], ccd.fixtures)
                : ccd.kind === 'sphere-pair'
                    ? (0, ccd_pair_js_1.sweepSpherePair)(bodies[ccd.sphereIndex], next[ccd.sphereIndex], bodies[ccd.otherIndex], next[ccd.otherIndex])
                    : ccd.kind === 'box-pair'
                        ? (0, ccd_box_js_1.sweepDynamicBox)(bodies[ccd.boxIndex], next[ccd.boxIndex], next[ccd.fixtureIndex]) : null;
            const nextCcdHits = hit ? [hit] : [];
            const nextPairStats = { eligiblePairs: 0, candidatePairs: 0, aabbTests: 0 };
            const found = new Set();
            const stepPairWrenches = new Map();
            const nextPersistentPoints = new Map();
            const persistentNormalTargets = new Map();
            const coupledPlans = new Map();
            const sensed = new Map();
            const nextJoints = jointStates.map((joint, index) => ({ ...joint,
                linearImpulseNs: [0, 0, 0], angularImpulseNms: [0, 0, 0],
                ...(joint.motorImpulseNms === undefined ? {} :
                    { motorImpulseNms: motorImpulses[index] }) }));
            const bounds = useAabb ? next.map(broadphase_js_1.bodyBounds) : null;
            for (let pass = 0; pass < limits_js_1.SOLVER_PASSES; pass++) {
                (0, private_phase_js_3.phasePass)(pass);
                if (bounds && pass > 0)
                    for (let index = 0; index < next.length; index++) {
                        if (next[index].kind !== 'static')
                            bounds[index] = (0, broadphase_js_1.bodyBounds)(next[index]);
                    }
                for (const [aIndex, bIndex] of pairs) {
                    nextPairStats.eligiblePairs++;
                    if (bounds) {
                        nextPairStats.aabbTests++;
                        if (!(0, broadphase_js_1.boundsOverlap)(bounds[aIndex], bounds[bIndex]))
                            continue;
                    }
                    nextPairStats.candidatePairs++;
                    const a = next[aIndex], b = next[bIndex];
                    const hit = usePersistentBox && a.shape.kind === 'box' && b.shape.kind === 'box' ? (0, private_phase_js_3.phaseQuery)(a, b) : (0, collision_js_1.detect)(a, b);
                    if (!hit)
                        continue;
                    if (hit.penetration > limits_js_1.MAX_STEP_DISPLACEMENT_M)
                        (0, validation_js_1.error)('NUMERIC_LIMIT', 'contact penetration exceeded limit');
                    const key = `${a.id}\u0000${b.id}`;
                    if (a.sensor || b.sensor) {
                        sensed.set(key, { aId: a.id, bId: b.id, kind: 'sensor' });
                        continue;
                    }
                    found.add(key);
                    const manifold = (0, phase_hit_js_1.isPhaseHit)(hit) ? hit._phase.result.points : usePersistentBox ? (0, contact_manifold_js_1.boxFaceManifold)(a, b, hit) : null;
                    if (manifold) {
                        if (!(0, phase_hit_js_1.isPhaseHit)(hit) || manifold.length !== 1)
                            throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Exactly one actual native point is required before any application');
                        const coupledPoint = hit._phase.result.points[0];
                        const coupledKey = key + '\u0000' + coupledPoint.id;
                        let coupledPlan = coupledPlans.get(coupledKey);
                        if (!coupledPlan) {
                            if (coupledPlans.size !== 0 || pass !== 0 || persistentPoints.size !== 0)
                                throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Cold single point must be eligible in first force pass');
                            coupledPlan = (0, coupled_plan_js_1.prepareCoupledPlan)(coupledKey, stepIndex + 1, a, b, hit, coupledPoint);
                            coupledPlans.set(coupledKey, coupledPlan);
                        }
                        (0, coupled_plan_js_1.guardCoupledPlan)(coupledPlan, coupledKey, stepIndex + 1, a, b, hit, coupledPoint);
                        // Capture every point before this pair's first warm start. Targets
                        // remain fixed through this step's passes and never enter the cache.
                        const restitution = Math.min(a.restitution, b.restitution);
                        for (const point of manifold) {
                            const pointKey = `${key}\u0000${point.id}`;
                            if (persistentNormalTargets.has(pointKey))
                                continue;
                            let target = 0;
                            if (restitution !== 0) {
                                const velocityA = (0, math_js_1.add)(a.velocityMps, (0, math_js_1.cross)(a.angularVelocityRadps, (0, math_js_1.sub)(point.pointM, a.positionM)));
                                const velocityB = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.cross)(b.angularVelocityRadps, (0, math_js_1.sub)(point.pointM, b.positionM)));
                                const speed = (0, math_js_1.dot)(hit.normal, (0, math_js_1.sub)(velocityB, velocityA));
                                if (-speed > 0.5)
                                    target = -speed * restitution;
                            }
                            persistentNormalTargets.set(pointKey, target);
                        }
                        for (const point of manifold) {
                            const pointKey = `${key}\u0000${point.id}`;
                            let impulse = nextPersistentPoints.get(pointKey);
                            if (!impulse) {
                                const prior = persistentPoints.get(pointKey);
                                impulse = prior ? { normalNs: prior.normalNs, tangentNs: [...prior.tangentNs] }
                                    : { normalNs: 0, tangentNs: [0, 0, 0] };
                                nextPersistentPoints.set(pointKey, impulse);
                                (0, private_phase_js_3.phaseCacheInit)(pointKey, point, hit.normal, hit, impulse, prior);
                                if (prior) {
                                    (0, private_phase_js_3.phasePoint)(pointKey, point, hit.normal, hit, impulse, -1, -1);
                                    (0, producer_js_1.addPairContribution)(stepPairWrenches, a, b, colliderIds, (0, persistent_box_contact_js_1.warmStartPoint)(a, b, point.pointM, hit.normal, impulse));
                                }
                            }
                        }
                        for (let iteration = 0; iteration < 8; iteration++) {
                            const order = iteration % 2 ? [...manifold].reverse() : manifold;
                            for (const point of order) {
                                const pointKey = `${key}\u0000${point.id}`;
                                const impulse = nextPersistentPoints.get(pointKey);
                                (0, coupled_plan_js_1.guardCoupledPlan)(coupledPlan, pointKey, stepIndex + 1, a, b, hit, coupledPoint);
                                (0, private_phase_js_3.phasePoint)(pointKey, point, hit.normal, hit, impulse, iteration, order.indexOf(point));
                                (0, producer_js_1.addPairContribution)(stepPairWrenches, a, b, colliderIds, (0, persistent_box_contact_js_1.solvePersistentPoint)(a, b, point.pointM, hit.normal, impulse, persistentNormalTargets.get(pointKey), coupledPlan));
                            }
                        }
                        (0, persistent_box_contact_js_1.correctPersistentPair)(a, b, hit.normal, hit.penetration);
                    }
                    else {
                        (0, validation_js_1.error)('NUMERIC_LIMIT', 'private producer forbids unconverted scalar contact path');
                    }
                    if (bounds) {
                        bounds[aIndex] = (0, broadphase_js_1.bodyBounds)(a);
                        bounds[bIndex] = (0, broadphase_js_1.bodyBounds)(b);
                    }
                }
                if (!disjointHinges)
                    for (let index = 0; index < joints.length; index++) {
                        const reaction = (0, joints_js_1.projectJoint)(joints[index], next, bodies, dt);
                        nextJoints[index].linearImpulseNs = (0, math_js_1.add)(nextJoints[index].linearImpulseNs, reaction.linearImpulseNs);
                        nextJoints[index].angularImpulseNms = (0, math_js_1.add)(nextJoints[index].angularImpulseNms, reaction.angularImpulseNms);
                        if (reaction.angleRad !== undefined)
                            nextJoints[index].angleRad = reaction.angleRad;
                    }
            }
            if (disjointHinges) {
                if (found.size !== 0 || sensed.size !== 0) {
                    (0, validation_js_1.error)('NUMERIC_LIMIT', 'disjoint hinge contact profile is unsupported');
                }
                (0, stage_js_1.applyDisjointHingePostContact)(disjointHinges, next, nextJoints, motorImpulses, stepIndex, stepIndex * dt);
            }
            if (coupledPlans.size !== 1 || [...coupledPlans.values()].some(p => !p.applied || p.slots !== 64))
                throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'One frozen target and all original64slots are required');
            const nextContacts = (0, producer_js_1.acceptedGeometry)(next, pairs, colliderIds, (a, b, hit) => {
                if (!hit || hit._phase.result.points.length !== 1)
                    throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Final native geometry must retain one frozen point');
                const point = hit._phase.result.points[0], key = a.id + '\u0000' + b.id + '\u0000' + point.id, plan = coupledPlans.get(key);
                if (!plan)
                    throw new coupled_plan_js_1.CoupledContactError('COUPLED_PROFILE_UNSUPPORTED', 'Final point ownership changed');
                (0, coupled_plan_js_1.guardCoupledIdentity)(plan, key, stepIndex + 1, a, b, hit, point);
            });
            const nextPairWrenches = (0, producer_js_1.copyPairWrenches)(stepPairWrenches);
            const nextActive = (0, producer_js_1.acceptedMembership)(nextContacts);
            const nextEvents = [...new Set([...activePairs.keys(), ...nextActive.keys()])].sort().map((key) => {
                const current = nextActive.get(key);
                const previous = activePairs.get(key);
                return { ...(current ?? previous), phase: current ? previous ? 'stay' : 'begin' : 'end' };
            });
            (0, collision_js_1.validateResult)(next, []);
            if (ccd.kind === 'box-pair' && !(0, ccd_box_js_1.axisAlignedBox)(next[ccd.boxIndex])) {
                (0, validation_js_1.error)('NUMERIC_LIMIT', 'box CCD contact rotated outside the admitted profile');
            }
            if (nextJoints.some((joint) => [...joint.linearImpulseNs, ...joint.angularImpulseNms].some((value) => !Number.isFinite(value)) || (joint.angleRad !== undefined && !Number.isFinite(joint.angleRad)))) {
                (0, validation_js_1.error)('NUMERIC_LIMIT', 'unsafe joint reaction');
            }
            for (let index = 0; index < joints.length; index++) {
                const motor = joints[index].motor;
                if (motor && Math.hypot(...nextJoints[index].angularImpulseNms) > motor.maxReactionNms) {
                    (0, validation_js_1.error)('NUMERIC_LIMIT', `${joints[index].id} exceeded motor reaction limit`);
                }
            }
            const state = publicState(next, nextContacts, nextEvents, nextJoints, nextCcdHits, nextPairStats, stepIndex + 1, dt, identity, colliderIds, nextPairWrenches);
            const preparedPhase = (0, private_phase_js_3.phasePrepare)(phaseContext, nextPersistentPoints);
            // All candidate, output and recording allocations finish before shared commit.
            const preparedRecording = owner ? owner.prepare(preparedFrames, state) : null;
            const preparedCommandCount = owner ? owner.commandCount + admittedCommands.length : 0;
            // Shared commit: assignments only. No allocation or callback.
            bodies = next;
            contacts = nextContacts;
            pairWrenches = nextPairWrenches;
            events = nextEvents;
            jointStates = nextJoints;
            ccdHits = nextCcdHits;
            pairStats = nextPairStats;
            activePairs = nextActive;
            persistentPoints = nextPersistentPoints;
            phaseContext.accepted = preparedPhase;
            sleepFrames = nextSleepFrames;
            stepIndex++;
            if (owner) {
                owner.recording = preparedRecording;
                owner.commandCount = preparedCommandCount;
            }
            return state;
        },
        query(input) {
            ensureActive();
            const data = (0, validation_js_1.queryRecord)(input, ['kind', 'includeSensors'], ['centerM', 'radiusM', 'originM', 'direction', 'maxDistanceM']);
            const sensors = (0, validation_js_1.includeSensors)(data);
            if (data.kind === 'overlap-sphere') {
                const query = (0, validation_js_1.queryRecord)(data, ['kind', 'centerM', 'radiusM', 'includeSensors'], []);
                const center = (0, validation_js_1.queryVector)(query.centerM, 10000, 'centerM');
                const radius = (0, validation_js_1.queryNumber)(query.radiusM, 0.0001, 1000, 'radiusM');
                return { kind: 'overlap-sphere', colliderIds: bodies.filter((body) => (sensors || !body.sensor) && (0, collision_js_1.sphereOverlaps)(center, radius, body))
                        .map((body) => body.id).sort().map((id) => colliderIds.get(id)) };
            }
            if (data.kind !== 'raycast')
                (0, validation_js_1.error)('INVALID_QUERY', 'unsupported query kind');
            const query = (0, validation_js_1.queryRecord)(data, ['kind', 'originM', 'direction', 'maxDistanceM', 'includeSensors'], []);
            const origin = (0, validation_js_1.queryVector)(query.originM, 10000, 'originM');
            const direction = (0, validation_js_1.queryVector)(query.direction, 1 + 1e-9, 'direction');
            if (Math.abs(Math.hypot(...direction) - 1) > 1e-9)
                (0, validation_js_1.error)('INVALID_QUERY', 'direction must be a unit 3-vector');
            const limit = (0, validation_js_1.queryNumber)(query.maxDistanceM, 0.0001, 10000, 'maxDistanceM');
            let best = null;
            for (const body of bodies) {
                if (!sensors && body.sensor)
                    continue;
                const distance = (0, collision_js_1.rayDistance)(origin, direction, body);
                if (distance === null || distance > limit)
                    continue;
                if (best === null || distance < best.distanceM || (distance === best.distanceM && body.id < best.bodyId))
                    best = { bodyId: body.id, distanceM: distance };
            }
            return { kind: 'raycast', hit: best === null ? null : { ...best, colliderId: colliderIds.get(best.bodyId) } };
        },
        dispose() {
            disposed = true;
            if (owner) {
                owner.recording = null;
                owner.commandCount = 0;
                owner = null;
            }
            optionsCopy = null;
            advancingOwner = null;
            bodies = [];
            contacts = [];
            pairWrenches = [];
            events = [];
            ccdHits = [];
            activePairs.clear();
            persistentPoints.clear();
            sleepFrames = [];
            jointStates = [];
            joints = [];
            dynamicHinge = undefined;
            disjointHinges = null;
            ccd = { kind: 'none' };
            pairs.length = 0;
            colliderIds.clear();
            modelCopy = null;
        },
    };
    let running = false;
    function guarded(operation, action) {
        if (disposed)
            throw new types_js_1.PhysicsError('DISPOSED', 'world is disposed', {
                operation, phase: 'lifecycle', domain: 'world', entityIds: [], accepted: { stepIndex, timeSeconds: stepIndex * dt }
            });
        if (running)
            throw new types_js_1.PhysicsError('REENTRANT_CALL', 'World call is reentrant', {
                operation, phase: 'lifecycle', domain: 'world', entityIds: [], accepted: { stepIndex, timeSeconds: stepIndex * dt }
            });
        running = true;
        try {
            return action();
        }
        catch (failure) {
            if (!(failure instanceof types_js_1.PhysicsError))
                throw failure;
            const enriched = new types_js_1.PhysicsError(failure.code, failure.message, {
                operation, phase: ['DISPOSED', 'WORLD_OWNED', 'REENTRANT_CALL'].includes(failure.code) ? 'lifecycle' :
                    failure.code === 'WORLD_LIMIT' ? 'budget' : failure.code === 'NUMERIC_LIMIT' ? 'validation' : 'admission',
                domain: 'rigid', entityIds: failure.details.entityIds,
                accepted: { stepIndex, timeSeconds: stepIndex * dt }
            });
            enriched.stack = failure.stack;
            throw enriched;
        }
        finally {
            running = false;
        }
    }
    const getModel = world.getModel;
    const getState = world.getState;
    const step = world.step;
    const query = world.query;
    const dispose = world.dispose;
    world.getModel = () => guarded('read', getModel);
    world.getState = () => guarded('read', getState);
    world.step = (commands) => guarded('step', () => step(commands));
    world.query = (input) => guarded('query', () => query(input));
    world.dispose = () => {
        if (disposed)
            return;
        // Preserve original reentrant refusal without observing or changing cleanup.
        if (running) {
            guarded('read', dispose);
            return;
        }
        try {
            (0, lifecycle_capture_js_1.captureBeforeDispose)(phaseContext.id, {
                view: () => {
                    if (bodies.length > 2 || contacts.length > 1 || pairWrenches.length > 1 || persistentPoints.size > 1 || activePairs.size > 1 || (owner?.recording?.frames.length ?? 0) > 1)
                        throw new Error('Lifecycle shallow profile bound');
                    return { model: modelCopy, options: optionsCopy, identity,
                        publicStorage: { bodies, contacts, pairWrenches, events, jointStates, ccdHits, pairStats, stepIndex },
                        privateStorage: { accepted: phaseContext.accepted, bodies, contacts, pairWrenches, persistentPoints: [...persistentPoints], activePairs: [...activePairs], sleepFrames, stepIndex },
                        owner: owner ? { recording: owner.recording, commandCount: owner.commandCount } : null };
                },
                state: () => world.getState(), model: () => world.getModel(), private: () => (0, private_phase_js_1.phasePrivateSnapshot)(phaseContext.id),
                owner: () => owner ? { recording: owner.recording, commandCount: owner.commandCount } : null,
            });
        }
        catch { } // Diagnostic observation can never mask the original dispose/serializer result.
        guarded('read', dispose);
    };
    recording_owner_js_1.recordingWorlds.set(world, {
        attach: (prepare) => guarded('record', () => {
            if (owner)
                (0, validation_js_1.error)('WORLD_OWNED', 'World has an exclusive recorder');
            if (stepIndex !== 0)
                (0, validation_js_1.error)('INVALID_SNAPSHOT', 'recording must attach at step zero');
            const prepared = prepare({ model: (0, identity_js_1.copyData)(modelCopy), options: (0, identity_js_1.copyData)(optionsCopy), state: getState() });
            owner = prepared;
            return prepared;
        }),
        detach: (current) => {
            if (!disposed)
                guarded('record', () => {
                    if (owner === current)
                        owner = null;
                    current.recording = null;
                    current.commandCount = 0;
                });
        },
        read: (current) => guarded('record', () => {
            if (owner !== current)
                (0, validation_js_1.error)('DISPOSED', 'recorder is detached');
            return getState();
        }),
        step: (current, commands) => guarded('record', () => {
            if (owner !== current)
                (0, validation_js_1.error)('DISPOSED', 'recorder is detached');
            advancingOwner = current;
            try {
                return step(commands);
            }
            finally {
                advancingOwner = null;
            }
        }),
    });
    return world;
}
