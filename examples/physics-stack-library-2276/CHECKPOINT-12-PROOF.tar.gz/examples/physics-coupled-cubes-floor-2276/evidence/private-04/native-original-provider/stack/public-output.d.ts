/** Private public-observation mapping only. No integration, correction or solve. */
import type { PhysicsContact, PhysicsEvent, PhysicsPairStats } from '../internal-types.js';
import type { PreparedStackStep } from './prepare-step.js';
type PairEvent = Omit<PhysicsEvent, 'phase'>;
export declare function prepareStationaryOutput(prepared: PreparedStackStep, previous: ReadonlyMap<string, PairEvent>): {
    contacts: PhysicsContact[];
    events: PhysicsEvent[];
    activePairs: Map<string, PairEvent>;
    pairStats: PhysicsPairStats;
};
export {};
