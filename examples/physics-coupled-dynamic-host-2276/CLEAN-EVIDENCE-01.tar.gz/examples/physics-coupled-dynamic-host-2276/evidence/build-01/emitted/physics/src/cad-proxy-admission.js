"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.admitCadSurfaceProxy = admitCadSurfaceProxy;
exports.assertCadProxyCurrent = assertCadProxyCurrent;
const cad_1 = require("@barocss/cad");
const identity_js_1 = require("./identity.js");
const limits_js_1 = require("./limits.js");
const math_js_1 = require("./math.js");
const cad_proxy_validation_js_1 = require("./cad-proxy-validation.js");
const CAD_ID = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function requestValues(value) {
    const input = (0, cad_proxy_validation_js_1.proxyRecord)(value);
    (0, cad_proxy_validation_js_1.proxyFields)(input, ['sourceVersion', 'sourceRevision', 'modelId', 'surfaceId', 'kind', 'proxy',
        'massKg', 'initialOffsetM', 'minimumHalfExtentM']);
    if (input.sourceVersion !== 0)
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'CAD proxy requires sourceVersion 0');
    if (typeof input.sourceRevision !== 'string' || !limits_js_1.ID.test(input.sourceRevision)) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'invalid source revision');
    }
    if (typeof input.modelId !== 'string' || !CAD_ID.test(input.modelId) ||
        typeof input.surfaceId !== 'string' || !CAD_ID.test(input.surfaceId)) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'invalid native model or Surface ID');
    }
    if (input.kind !== 'dynamic' && input.kind !== 'static')
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'invalid proxy body kind');
    if (input.proxy !== 'sphere' && input.proxy !== 'box')
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'invalid proxy shape');
    if (input.kind === 'static' && (Object.hasOwn(input, 'massKg') || Object.hasOwn(input, 'initialOffsetM'))) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'static proxy cannot declare mass or offset');
    }
    if (input.kind === 'dynamic')
        (0, cad_proxy_validation_js_1.proxyFinite)(input.massKg, 0.000001, 1000000, 'massKg');
    if (input.proxy === 'sphere' && Object.hasOwn(input, 'minimumHalfExtentM')) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'sphere proxy cannot declare minimumHalfExtentM');
    }
    if (Object.hasOwn(input, 'minimumHalfExtentM')) {
        (0, cad_proxy_validation_js_1.proxyFinite)(input.minimumHalfExtentM, 0.0001, 1000, 'minimumHalfExtentM');
    }
    if (Object.hasOwn(input, 'initialOffsetM'))
        (0, cad_proxy_validation_js_1.proxyVector)(input.initialOffsetM, -1000, 1000, 'initialOffsetM');
    return input;
}
function controlBounds(points) {
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (const row of points)
        for (const point of row)
            for (let axis = 0; axis < 3; axis++) {
                min[axis] = Math.min(min[axis], point[axis]);
                max[axis] = Math.max(max[axis], point[axis]);
            }
    if ([...min, ...max].some((value) => !Number.isFinite(value))) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'native Surface has invalid control bounds');
    }
    return { min, max };
}
function admitCadSurfaceProxy(source, request) {
    if (typeof source !== 'string' || source.length < 1 || source.length > 65536) {
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'CAD source length must be 1..65536 characters');
    }
    const input = requestValues(request);
    const bodyId = `${input.kind === 'dynamic' ? 'part' : 'fixture'}:${input.modelId}.${input.surfaceId}`;
    if (!limits_js_1.ID.test(bodyId))
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'qualified Physics body ID exceeds bounds');
    const compiled = (0, cad_1.compileCadModel)(source, { sourceVersion: 0 });
    if (!compiled.ok)
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', `CAD source refused: ${compiled.diagnostics[0]?.code ?? 'unknown'}`);
    if (compiled.model.name !== input.modelId)
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'native model ID differs from selection');
    const native = compiled.model.objects.find((object) => object.id === input.surfaceId);
    if (!native || native.kind !== 'surface')
        (0, cad_proxy_validation_js_1.proxyError)('INVALID_CONFIG', 'selected native object is not a Surface');
    const sourceBoundsMM = controlBounds(native.controlPoints);
    const sourceCenterMM = sourceBoundsMM.min.map((low, axis) => (low + sourceBoundsMM.max[axis]) / 2);
    const halfSpanM = sourceBoundsMM.min.map((low, axis) => (sourceBoundsMM.max[axis] - low) / 2000);
    const centerM = sourceCenterMM.map((value) => value / 1000);
    const positionM = (0, math_js_1.add)(centerM, input.initialOffsetM ?? [0, 0, 0]);
    (0, cad_proxy_validation_js_1.proxyVector)(positionM, -10000, 10000, 'proxy positionM');
    const shape = input.proxy === 'sphere'
        ? { kind: 'sphere', radiusM: Math.max(0.0001, Math.hypot(...halfSpanM)) }
        : { kind: 'box', halfExtentsM: halfSpanM.map((value) => Math.max(value, input.minimumHalfExtentM ?? 0.0001)) };
    if (shape.kind === 'sphere')
        (0, cad_proxy_validation_js_1.proxyFinite)(shape.radiusM, 0.0001, 1000, 'proxy radiusM');
    else
        shape.halfExtentsM.forEach((value, axis) => (0, cad_proxy_validation_js_1.proxyFinite)(value, 0.0001, 1000, `proxy halfExtentsM[${axis}]`));
    const initial = { positionM, orientationXYZW: [0, 0, 0, 1] };
    const body = input.kind === 'dynamic'
        ? { id: bodyId, kind: 'dynamic', initial: { ...initial, velocityMps: [0, 0, 0],
                angularVelocityRadps: [0, 0, 0] }, massKg: input.massKg,
            inertia: { kind: 'primitive-com', about: 'com', frame: 'body-local' } }
        : { id: bodyId, kind: 'static', initial };
    const collider = { id: `collider:${(0, identity_js_1.digest)(bodyId).slice(7, 55)}`, bodyId, geometry: shape,
        local: { positionM: [0, 0, 0], orientationXYZW: [0, 0, 0, 1] },
        material: { restitution: 0, friction: { static: 0, dynamic: 0 } }, sensor: false, ccd: false,
        filter: { categoryBits: 1, maskBits: 65535 } };
    const lossLabel = input.proxy === 'sphere'
        ? 'Control-net enclosing sphere; native Surface geometry is not the collision shape.'
        : 'Control-net axis-aligned box with minimum thickness; native Surface geometry is not the collision shape.';
    const binding = { id: `source:${(0, identity_js_1.digest)(bodyId).slice(7, 55)}`, sourceRevision: input.sourceRevision,
        sourceDigest: (0, identity_js_1.digest)(source), modelId: input.modelId, occurrenceId: input.surfaceId,
        entityIds: [bodyId, collider.id],
        approximation: { kind: input.proxy === 'sphere' ? 'control-net-sphere' : 'control-net-box', lossLabel } };
    const admitted = { sourceSnapshot: source, sourceRevision: input.sourceRevision,
        modelId: input.modelId, surfaceId: input.surfaceId, bodyId,
        sourceCenterMM: [...sourceCenterMM],
        sourceBoundsMM: { min: [...sourceBoundsMM.min], max: [...sourceBoundsMM.max] },
        lossLabel, body, collider, binding };
    Object.freeze(admitted.sourceCenterMM);
    Object.freeze(admitted.sourceBoundsMM.min);
    Object.freeze(admitted.sourceBoundsMM.max);
    Object.freeze(admitted.sourceBoundsMM);
    Object.freeze(body.initial.positionM);
    Object.freeze(body.initial.orientationXYZW);
    if (body.kind === 'dynamic') {
        Object.freeze(body.initial.velocityMps);
        Object.freeze(body.initial.angularVelocityRadps);
        Object.freeze(body.inertia);
    }
    Object.freeze(body.initial);
    if (collider.geometry.kind === 'box')
        Object.freeze(collider.geometry.halfExtentsM);
    Object.freeze(collider.geometry);
    Object.freeze(collider.local.positionM);
    Object.freeze(collider.local.orientationXYZW);
    Object.freeze(collider.local);
    Object.freeze(collider.material.friction);
    Object.freeze(collider.material);
    Object.freeze(collider.filter);
    Object.freeze(collider);
    Object.freeze(binding.entityIds);
    Object.freeze(binding.approximation);
    Object.freeze(binding);
    Object.freeze(body);
    return Object.freeze(admitted);
}
function assertCadProxyCurrent(proxy, currentSource, currentRevision) {
    if (currentSource !== proxy.sourceSnapshot || currentRevision !== proxy.sourceRevision) {
        (0, cad_proxy_validation_js_1.proxyError)('STALE_SOURCE', 'CAD proxy source changed; explicit re-admission is required');
    }
}
