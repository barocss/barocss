# Private native box feature construction

The first actual build and construction/parity run passed, but the independent
observer failed on the third floating presentation. Exact native certificates
passed through that point. The complete first-failure files are preserved under
`evidence/first-failure-01/`. This remains NO_GO.

`AMENDMENT-01.md` freezes a correctly rounded rational-to-binary64 conversion
and exact certification of its single represented midpoint/normal line. The
amended candidate has not been built or executed by its author. An uncertified
presentation returns `UNRESOLVED` with its exact construction retained. No
neighbor search or geometric nudge is used.

`cases.json` has20 box pairs and32 original ALIGNED:1 expected points. The
candidate receives only `{id,a,b}`. Each box has `id`, `positionM`,
`orientationXYZW` and `halfExtentsM`. The parent observer can read the raw cases
without importing candidate code. Original expected points never seed geometry.

`candidate.ts` exports `boxContact(pair)`. Results are `MISS`, `HIT` or typed
`UNRESOLVED`. A hit carries the original floating SAT feature/index, native
normal direction, exact rational native endpoints and midpoint, plus binary64
presentation words. Its strict12-halfspace certificate is a candidate claim;
the independent line/box observer must verify it. No inward repair is used.

After parent review/freeze, use the existing180s heavy command guard for:

```sh
node examples/physics-box-contact-features-2276/build.mjs build-01
node examples/physics-box-contact-features-2276/run.mjs build-01 run-01
```

Build uses the already installed esbuild and strict TypeScript NodeNext tools.
The runner writes each input before the call and each output before checking.
It stops at the first failure and records Source/strict raw-word parity and
original point population/movement. Construction/parity PASS requires a
separate independent native geometry verdict. PRE overlap gap is not a
zero-gap accepted-contact claim. No result changes the public NO_GO or P4.
