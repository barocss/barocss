"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRotationResult = validateRotationResult;
const validation_js_1 = require("./validation.js");
/** Validate both prepared angular outputs before either candidate field is assigned. */
function validateRotationResult(result, dt) {
    if (result.angularVelocityRadps.some(value => !Number.isFinite(value) || Math.abs(value) > 1000) ||
        !Number.isFinite(dt) || dt <= 0 || Math.hypot(...result.angularVelocityRadps) * dt > 10) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'free rotation exceeded angular movement limit');
    }
    if (result.orientation.some(value => !Number.isFinite(value)) ||
        Math.abs(Math.hypot(...result.orientation) - 1) > 1e-12) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'free rotation orientation exceeded tolerance');
    }
}
