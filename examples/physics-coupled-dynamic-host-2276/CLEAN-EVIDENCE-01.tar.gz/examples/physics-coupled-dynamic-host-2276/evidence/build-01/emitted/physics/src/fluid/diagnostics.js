"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fluidDiagnostics = fluidDiagnostics;
const boundary_js_1 = require("./boundary.js");
const constants_js_1 = require("./constants.js");
const kernel_js_1 = require("./kernel.js");
const neighbors_js_1 = require("./neighbors.js");
const floor = (0, boundary_js_1.floorSamples)();
function fluidDiagnostics(positions, restDensity, boundaryHits) {
    const combined = new Float64Array(positions.length + floor.length);
    combined.set(positions);
    combined.set(floor, positions.length);
    const density = new Float64Array(constants_js_1.FLUID_COUNT);
    (0, kernel_js_1.densities)(combined, new neighbors_js_1.NeighborGrid(), density);
    let absoluteError = 0;
    const compressions = new Array(constants_js_1.FLUID_COUNT);
    for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
        const difference = density[index] / restDensity - 1;
        absoluteError += Math.abs(difference);
        compressions[index] = Math.max(0, difference);
    }
    compressions.sort((a, b) => a - b);
    return { meanAbsoluteDensityError: absoluteError / constants_js_1.FLUID_COUNT,
        p95Compression: compressions[Math.ceil(0.95 * constants_js_1.FLUID_COUNT) - 1], boundaryHits };
}
