import { createPhysicsWorld, PhysicsError } from './index.js';
import { admitPhysicsScene } from './replay-scene.js';
import { equivalentReplayIdentity, copyReplayJson, exactFields, replayError, encodeSnapshotData, decodeSnapshotData } from './replay-json.js';
import { equivalentReplayValue } from './replay-compare.js';
const MAX_FRAMES = 512;
const MAX_COMMANDS = 4096;
class RecordedPhysicsSession {
    scene;
    world;
    frames = [];
    commandCount = 0;
    constructor(input) {
        this.scene = admitPhysicsScene(input);
        this.world = createPhysicsWorld(this.scene.model, this.scene.options);
    }
    getScene() {
        this.world.getState();
        return copyReplayJson(this.scene, 'scene');
    }
    getState() { return this.world.getState(); }
    step(commands = []) {
        this.world.getState();
        if (this.frames.length >= MAX_FRAMES)
            replayError('WORLD_LIMIT', 'replay frame limit reached');
        const admitted = copyReplayJson(commands, 'commands');
        if (Array.isArray(admitted) && this.commandCount + admitted.length > MAX_COMMANDS) {
            replayError('WORLD_LIMIT', 'replay command limit reached');
        }
        if (!Array.isArray(admitted))
            replayError('INVALID_COMMAND', 'replay commands must be an array');
        const nextFrames = [...this.frames, { commands: admitted }];
        const nextCommandCount = this.commandCount + admitted.length;
        const state = this.world.step(admitted);
        this.frames = nextFrames;
        this.commandCount = nextCommandCount;
        return state;
    }
    saveSnapshot() {
        const snapshot = { format: 'barocss-physics-snapshot', version: 1,
            scene: this.getScene(), frames: copyReplayJson(this.frames, 'frames'),
            finalState: this.world.getState() };
        encodeSnapshotData(snapshot);
        return snapshot;
    }
    dispose() { this.world.dispose(); }
}
export function createPhysicsReplaySession(scene) {
    return new RecordedPhysicsSession(scene);
}
export function restorePhysicsReplaySession(snapshotInput, expectedSceneInput) {
    const expectedScene = admitPhysicsScene(expectedSceneInput);
    const snapshot = copyReplayJson(snapshotInput, 'snapshot');
    exactFields(snapshot, ['format', 'version', 'scene', 'frames', 'finalState'], 'snapshot');
    encodeSnapshotData(snapshot);
    if (snapshot.format !== 'barocss-physics-snapshot' || snapshot.version !== 1 ||
        !Array.isArray(snapshot.frames) ||
        snapshot.frames.length > MAX_FRAMES) {
        replayError('INVALID_SNAPSHOT', 'unsupported or oversized snapshot');
    }
    let savedScene;
    try {
        savedScene = admitPhysicsScene(snapshot.scene);
    }
    catch (error) {
        if (error instanceof PhysicsError && error.code === 'STALE_SNAPSHOT')
            throw error;
        replayError('INVALID_SNAPSHOT', 'snapshot scene is invalid');
    }
    if (!equivalentReplayIdentity(savedScene, expectedScene)) {
        replayError('STALE_SNAPSHOT', 'scene or source revision changed');
    }
    let commandsTotal = 0;
    for (const frame of snapshot.frames) {
        exactFields(frame, ['commands'], 'snapshot frame');
        if (!Array.isArray(frame.commands) || frame.commands.length > 64) {
            replayError('INVALID_SNAPSHOT', 'snapshot frame commands are invalid');
        }
        commandsTotal += frame.commands.length;
    }
    if (commandsTotal > MAX_COMMANDS)
        replayError('INVALID_SNAPSHOT', 'snapshot command limit exceeded');
    if (snapshot.finalState === null || typeof snapshot.finalState !== 'object' ||
        Array.isArray(snapshot.finalState) ||
        snapshot.finalState.stepIndex !== snapshot.frames.length ||
        snapshot.finalState.timeSeconds !== snapshot.frames.length * expectedScene.options.fixedStepSeconds) {
        replayError('INVALID_SNAPSHOT', 'snapshot step index or time differs from its command log');
    }
    const candidate = new RecordedPhysicsSession(expectedScene);
    try {
        for (const frame of snapshot.frames)
            candidate.step(frame.commands);
        if (!equivalentReplayValue(candidate.getState(), snapshot.finalState)) {
            replayError('INVALID_SNAPSHOT', 'snapshot final state differs from replay');
        }
        return candidate;
    }
    catch {
        candidate.dispose();
        replayError('INVALID_SNAPSHOT', 'snapshot command log or final state is invalid');
    }
}
export function serializePhysicsSnapshot(snapshot) {
    const session = restorePhysicsReplaySession(snapshot, snapshot.scene);
    try {
        return encodeSnapshotData(snapshot);
    }
    finally {
        session.dispose();
    }
}
export function deserializePhysicsSnapshot(bytes) {
    const snapshot = decodeSnapshotData(bytes);
    exactFields(snapshot, ['format', 'version', 'scene', 'frames', 'finalState'], 'snapshot');
    const scene = admitPhysicsScene(snapshot.scene);
    const session = restorePhysicsReplaySession(snapshot, scene);
    try {
        return copyReplayJson(snapshot, 'snapshot');
    }
    finally {
        session.dispose();
    }
}
