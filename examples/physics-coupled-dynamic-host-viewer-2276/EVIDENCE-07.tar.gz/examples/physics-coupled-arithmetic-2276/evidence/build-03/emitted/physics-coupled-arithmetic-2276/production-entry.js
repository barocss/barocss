export { coupledContactTarget } from './candidate.js';
export { coupledStaticTarget } from '../physics-coupled-contact-2276/candidate.js';
