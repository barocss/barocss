"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PbfSolver = void 0;
const boundary_js_1 = require("./boundary.js");
const constants_js_1 = require("./constants.js");
const kernel_js_1 = require("./kernel.js");
const neighbors_js_1 = require("./neighbors.js");
const static_box_js_1 = require("./static-box.js");
const visual_viscosity_js_1 = require("./visual-viscosity.js");
class PbfSolver {
    restDensity;
    visualViscosityCoefficient;
    staticBox;
    grid = new neighbors_js_1.NeighborGrid();
    predicted = new Float64Array(constants_js_1.FLUID_COUNT * 3);
    combined;
    density = new Float64Array(constants_js_1.FLUID_COUNT);
    lambda = new Float64Array(constants_js_1.FLUID_COUNT);
    corrections = new Float64Array(constants_js_1.FLUID_COUNT * 3);
    smoothedVelocities;
    obstacleHits = 0;
    constructor(restDensity, visualViscosityCoefficient, staticBox = null) {
        this.restDensity = restDensity;
        this.visualViscosityCoefficient = visualViscosityCoefficient;
        this.staticBox = staticBox;
        this.smoothedVelocities = visualViscosityCoefficient > 0
            ? new Float64Array(constants_js_1.FLUID_COUNT * 3) : null;
        const floor = (0, boundary_js_1.floorSamples)();
        this.combined = new Float64Array(this.predicted.length + floor.length);
        this.combined.set(floor, this.predicted.length);
    }
    projectDensity(velocities) {
        this.combined.set(this.predicted);
        (0, kernel_js_1.densities)(this.combined, this.grid, this.density);
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            const compression = Math.max(0, this.density[index] / this.restDensity - 1);
            if (compression === 0) {
                this.lambda[index] = 0;
                continue;
            }
            let ownX = 0, ownY = 0, ownZ = 0, gradientSum = 0;
            this.grid.each(index, (other, rx, ry, rz, distanceSquared) => {
                if (other === index)
                    return;
                const scale = (0, kernel_js_1.gradientScale)(distanceSquared) / this.restDensity;
                const gx = scale * rx, gy = scale * ry, gz = scale * rz;
                ownX += gx;
                ownY += gy;
                ownZ += gz;
                gradientSum += gx * gx + gy * gy + gz * gz;
            });
            gradientSum += ownX * ownX + ownY * ownY + ownZ * ownZ;
            this.lambda[index] = -compression / (gradientSum + 0.01);
        }
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            const offset = index * 3;
            let dx = 0, dy = 0, dz = 0;
            this.grid.each(index, (other, rx, ry, rz, distanceSquared) => {
                if (other === index)
                    return;
                const scale = (this.lambda[index] + (other < constants_js_1.FLUID_COUNT ? this.lambda[other] : 0))
                    * (0, kernel_js_1.gradientScale)(distanceSquared) / this.restDensity;
                dx += scale * rx;
                dy += scale * ry;
                dz += scale * rz;
            });
            const length = Math.hypot(dx, dy, dz);
            const limit = length > constants_js_1.FLUID_SPACING_M * 0.25 ? constants_js_1.FLUID_SPACING_M * 0.25 / length : 1;
            this.corrections[offset] = dx * limit;
            this.corrections[offset + 1] = dy * limit;
            this.corrections[offset + 2] = dz * limit;
        }
        let boundaryHits = 0;
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            const offset = index * 3;
            for (let axis = 0; axis < 3; axis++) {
                this.predicted[offset + axis] += this.corrections[offset + axis];
            }
            boundaryHits += (0, boundary_js_1.confine)(this.predicted, velocities, index);
            if (this.staticBox) {
                this.obstacleHits += (0, static_box_js_1.confineStaticBox)(this.predicted, velocities, index, this.staticBox);
            }
        }
        return boundaryHits;
    }
    step(positions, velocities) {
        let boundaryHits = 0;
        this.obstacleHits = 0;
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            const offset = index * 3;
            velocities[offset + 1] += constants_js_1.FLUID_STEP_SECONDS * constants_js_1.FLUID_GRAVITY_MPS2[1];
            for (let axis = 0; axis < 3; axis++) {
                velocities[offset + axis] *= 0.998;
                this.predicted[offset + axis] = positions[offset + axis]
                    + constants_js_1.FLUID_STEP_SECONDS * velocities[offset + axis];
            }
            boundaryHits += (0, boundary_js_1.confine)(this.predicted, velocities, index);
            if (this.staticBox) {
                this.obstacleHits += (0, static_box_js_1.confineStaticBox)(this.predicted, velocities, index, this.staticBox);
            }
        }
        for (let iteration = 0; iteration < 3; iteration++) {
            boundaryHits += this.projectDensity(velocities);
        }
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            const offset = index * 3;
            for (let axis = 0; axis < 3; axis++) {
                velocities[offset + axis] = (this.predicted[offset + axis] - positions[offset + axis])
                    / constants_js_1.FLUID_STEP_SECONDS;
                positions[offset + axis] = this.predicted[offset + axis];
            }
        }
        if (this.smoothedVelocities) {
            (0, visual_viscosity_js_1.blendVisualViscosity)(positions, velocities, this.grid, this.smoothedVelocities, this.visualViscosityCoefficient);
        }
        for (let index = 0; index < constants_js_1.FLUID_COUNT; index++) {
            (0, boundary_js_1.stopOutwardVelocity)(positions, velocities, index);
            if (this.staticBox)
                (0, static_box_js_1.stopIntoStaticBox)(positions, velocities, index, this.staticBox);
        }
        return { boundaryHits, obstacleHits: this.obstacleHits };
    }
}
exports.PbfSolver = PbfSolver;
