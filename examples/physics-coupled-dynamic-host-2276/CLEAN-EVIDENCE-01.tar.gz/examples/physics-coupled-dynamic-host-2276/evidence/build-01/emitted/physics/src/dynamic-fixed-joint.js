"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectDynamicFixedJoint = projectDynamicFixedJoint;
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
const dynamic_anchor_pair_js_1 = require("./dynamic-anchor-pair.js");
function orientationError(actual, desired) {
    const relative = (0, math_js_1.multiplyQuaternion)(actual, (0, math_js_1.inverse)(desired));
    const sign = relative[3] < 0 ? -1 : 1;
    const vector = (0, math_js_1.scale)([relative[0], relative[1], relative[2]], sign);
    const sine = Math.hypot(...vector);
    if (sine < 1e-12)
        return (0, math_js_1.scale)(vector, 2);
    return (0, math_js_1.scale)(vector, 2 * Math.atan2(sine, sign * relative[3]) / sine);
}
/** Symmetric, bounded projection for the one admitted two-sphere fixed pair. */
function projectDynamicFixedJoint(joint, bodies, dt) {
    const a = bodies[joint.aIndex], b = bodies[joint.bIndex];
    const beforeLinear = [...b.velocityMps];
    const beforeAngular = [...b.angularVelocityRadps];
    const desired = (0, math_js_1.multiplyQuaternion)(a.orientation, joint.referenceOrientation);
    const angularError = orientationError(b.orientation, desired);
    if (Math.hypot(...angularError) > 1) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic fixed joint relative orientation exceeds limit');
    }
    const basis = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    const angularColumns = basis.map((axis) => (0, math_js_1.add)((0, math_js_1.inverseInertia)(a, axis), (0, math_js_1.inverseInertia)(b, axis)));
    const angularImpulse = (0, dynamic_anchor_pair_js_1.solvePairMatrix)(angularColumns, (0, math_js_1.scale)(angularError, -1));
    (0, dynamic_anchor_pair_js_1.applyPairAngle)(a, (0, math_js_1.scale)((0, math_js_1.inverseInertia)(a, angularImpulse), -1), dt);
    (0, dynamic_anchor_pair_js_1.applyPairAngle)(b, (0, math_js_1.inverseInertia)(b, angularImpulse), dt);
    (0, dynamic_anchor_pair_js_1.projectDynamicPairAnchors)(a, b, joint.anchorALocalM, joint.anchorBLocalM, dt);
    return { id: joint.id, kind: joint.kind, aId: a.id, bId: b.id,
        linearImpulseNs: (0, math_js_1.scale)((0, math_js_1.sub)(b.velocityMps, beforeLinear), 1 / b.inverseMass),
        angularImpulseNms: (0, math_js_1.inertia)(b, (0, math_js_1.sub)(b.angularVelocityRadps, beforeAngular)) };
}
