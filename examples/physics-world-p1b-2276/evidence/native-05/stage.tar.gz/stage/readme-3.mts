import { createUprightCapsuleController } from '@barocss/physics';
const controller = createUprightCapsuleController({
  version: 1,
  profile: 'upright-capsule-controller-v1',
  scene: {
    version: 1, profile: 'upright-capsule-box-v1', revision: 'scene1',
    boxes: [{ id: 'floor', centerM: [0, -0.05, 0],
      halfExtentsM: [3, 0.05, 1], orientationXYZW: [0, 0, 0, 1] }],
  },
  positionM: [-1, 0.505, 0],
});
const state = controller.step({ dtSeconds: 1 / 120,
  sceneRevision: 'scene1', desiredVelocityMps: [1, 0, 0] });
controller.dispose();
