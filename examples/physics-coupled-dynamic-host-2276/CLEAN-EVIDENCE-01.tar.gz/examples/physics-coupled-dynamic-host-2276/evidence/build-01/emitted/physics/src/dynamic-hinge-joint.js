"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.admitDynamicHingeScene = admitDynamicHingeScene;
exports.admitDynamicHingeCommands = admitDynamicHingeCommands;
exports.projectDynamicHingeJoint = projectDynamicHingeJoint;
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
const dynamic_anchor_pair_js_1 = require("./dynamic-anchor-pair.js");
const magnitude = (vector) => Math.hypot(...vector);
const near = (a, b) => magnitude((0, math_js_1.sub)(a, b)) <= 1e-9;
function offsetFixture(joint, a, b) {
    return near(a.positionM, [-0.1, 0, 0]) && near(b.positionM, [0.1, 0, 0]) &&
        near(joint.anchorALocalM, [0.1, 0, 0]) && near(joint.anchorBLocalM, [-0.1, 0, 0]) &&
        near(joint.axisWorld, [0, 0, 1]) &&
        Math.abs(joint.limitRad[0] + 0.8) <= 1e-9 &&
        Math.abs(joint.limitRad[1] - 0.8) <= 1e-9 &&
        a.inverseMass === 1 && b.inverseMass === 1 &&
        a.shape.kind === 'sphere' && b.shape.kind === 'sphere' &&
        a.shape.radiusM === 0.1 && b.shape.radiusM === 0.1 &&
        joint.motor?.targetSpeedRadps === 0.5 &&
        joint.motor.maxImpulseNms === 0.0001 && joint.motor.maxReactionNms === 0.01;
}
function admitDynamicHingeScene(joint, bodies, gravity) {
    const a = bodies[joint.aIndex], b = bodies[joint.bIndex];
    const identity = [0, 0, 0, 1];
    const centred = near(a.positionM, b.positionM) &&
        magnitude(joint.anchorALocalM) === 0 && magnitude(joint.anchorBLocalM) === 0;
    if (magnitude(gravity) !== 0 || (!centred && !offsetFixture(joint, a, b)) ||
        [a, b].some((body) => magnitude(body.velocityMps) !== 0 ||
            magnitude(body.angularVelocityRadps) !== 0 ||
            body.orientation.some((value, index) => Math.abs(value - identity[index]) > 1e-12))) {
        (0, validation_js_1.error)('INVALID_CONFIG', 'dynamic hinge needs an admitted resting pair and zero gravity');
    }
}
function admitDynamicHingeCommands(joint, bodies, actions) {
    const axis = joint.axisWorld;
    for (const bodyIndex of [joint.aIndex, joint.bIndex]) {
        const action = actions.get(bodies[bodyIndex].id);
        if (!action)
            continue;
        if (action.forceN || action.impulseNs || [action.torqueNm, action.angularImpulseNms]
            .filter((vector) => vector !== undefined)
            .some((vector) => magnitude((0, math_js_1.sub)(vector, (0, math_js_1.scale)(axis, (0, math_js_1.dot)(vector, axis)))) > 1e-12)) {
            (0, validation_js_1.error)('INVALID_COMMAND', 'dynamic hinge admits axis-aligned angular commands only');
        }
    }
}
function projectDynamicHingeJoint(joint, bodies, dt) {
    const a = bodies[joint.aIndex], b = bodies[joint.bIndex];
    const axis = joint.axisWorld;
    const beforeLinear = [...b.velocityMps];
    const beforeAngular = [...b.angularVelocityRadps];
    const relative = (0, math_js_1.multiplyQuaternion)(b.orientation, (0, math_js_1.inverse)(a.orientation));
    const signed = (0, math_js_1.dot)([relative[0], relative[1], relative[2]], axis);
    if (magnitude((0, math_js_1.sub)([relative[0], relative[1], relative[2]], (0, math_js_1.scale)(axis, signed))) > 1e-8) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'dynamic hinge left its planar axis');
    }
    const raw = 2 * Math.atan2(signed, relative[3]);
    const wrapped = raw > Math.PI ? raw - 2 * Math.PI : raw < -Math.PI ? raw + 2 * Math.PI : raw;
    const angleRad = Math.max(joint.limitRad[0], Math.min(joint.limitRad[1], wrapped));
    const inverseA = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(a, axis));
    const inverseB = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(b, axis));
    const inverseSum = inverseA + inverseB;
    const excess = wrapped - angleRad;
    if (excess !== 0) {
        const angleA = excess * inverseA / inverseSum;
        const angleB = -excess * inverseB / inverseSum;
        a.orientation = (0, math_js_1.advanceOrientation)(a.orientation, (0, math_js_1.scale)(axis, angleA), 1);
        b.orientation = (0, math_js_1.advanceOrientation)(b.orientation, (0, math_js_1.scale)(axis, angleB), 1);
        a.angularVelocityRadps = (0, math_js_1.add)(a.angularVelocityRadps, (0, math_js_1.scale)(axis, angleA / dt));
        b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.scale)(axis, angleB / dt));
    }
    const relativeSpeed = (0, math_js_1.dot)((0, math_js_1.sub)(b.angularVelocityRadps, a.angularVelocityRadps), axis);
    if ((angleRad === joint.limitRad[0] && relativeSpeed < 0) ||
        (angleRad === joint.limitRad[1] && relativeSpeed > 0)) {
        const impulse = -relativeSpeed / inverseSum;
        a.angularVelocityRadps = (0, math_js_1.sub)(a.angularVelocityRadps, (0, math_js_1.inverseInertia)(a, (0, math_js_1.scale)(axis, impulse)));
        b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.inverseInertia)(b, (0, math_js_1.scale)(axis, impulse)));
    }
    (0, dynamic_anchor_pair_js_1.projectDynamicPairAnchors)(a, b, joint.anchorALocalM, joint.anchorBLocalM, dt);
    return { id: joint.id, kind: joint.kind, aId: a.id, bId: b.id,
        linearImpulseNs: (0, math_js_1.scale)((0, math_js_1.sub)(b.velocityMps, beforeLinear), 1 / b.inverseMass),
        angularImpulseNms: (0, math_js_1.inertia)(b, (0, math_js_1.sub)(b.angularVelocityRadps, beforeAngular)), angleRad };
}
