"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.admitCadFluidStaticData = admitCadFluidStaticData;
const identity_js_1 = require("./identity.js");
const model_admission_js_1 = require("./model-admission.js");
const cad_proxy_admission_js_1 = require("./cad-proxy-admission.js");
const validation_js_1 = require("./validation.js");
function admitCadFluidStaticData(basinModel, targetOptions, sourceText, request) {
    const options = (0, identity_js_1.copyData)(targetOptions);
    if (!options || typeof options !== 'object' || Array.isArray(options))
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid target options require a record');
    if (options.profile !== 'fluid-static-box-visual-v1')
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid data requires the static-box target profile');
    const base = (0, model_admission_js_1.admitModel)(basinModel, { ...options, profile: 'fluid-basin-visual-v1' });
    if (base.domain?.kind !== 'fluid')
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid data requires one admitted basin fluid');
    const selection = (0, identity_js_1.copyData)(request);
    if (!selection || typeof selection !== 'object' || Array.isArray(selection))
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid selection requires a record');
    if (selection.kind !== 'static' || selection.proxy !== 'box')
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid obstacle requires one static box proxy');
    const proxy = (0, cad_proxy_admission_js_1.admitCadSurfaceProxy)(sourceText, selection);
    if (proxy.body.kind !== 'static' || proxy.collider.geometry.kind !== 'box')
        (0, validation_js_1.error)('INVALID_CONFIG', 'CAD fluid obstacle must be a static box');
    const completed = {
        ...base.model,
        bodies: [...base.model.bodies, (0, identity_js_1.copyData)(proxy.body)],
        colliders: [...base.model.colliders, (0, identity_js_1.copyData)(proxy.collider)],
        fluids: base.model.fluids.map(fluid => ({ ...fluid, staticColliderIds: [...fluid.staticColliderIds, proxy.collider.id] })),
        sourceBindings: [...base.model.sourceBindings, (0, identity_js_1.copyData)(proxy.binding)],
    };
    // Final pure admission applies the original fluid margin/overlap laws and
    // global ID/reference rules. Its bounded scratch is never runtime state.
    // Return the actual frozen proxy token for explicit assertCadProxyCurrent.
    return { model: (0, model_admission_js_1.admitModel)(completed, options).model, proxy };
}
