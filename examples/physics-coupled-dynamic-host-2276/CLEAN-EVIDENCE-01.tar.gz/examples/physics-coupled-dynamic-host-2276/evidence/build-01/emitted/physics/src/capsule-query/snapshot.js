"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUprightCapsuleQuery = createUprightCapsuleQuery;
const capsule_query_error_js_1 = require("../capsule-query-error.js");
const admission_js_1 = require("./admission.js");
const profile_js_1 = require("./profile.js");
const sweep_js_1 = require("./sweep.js");
function copyBox(box) {
    return { id: box.id, centerM: [...box.centerM], halfExtentsM: [...box.halfExtentsM], orientationXYZW: [...box.orientationXYZW] };
}
function geometryKey(box) {
    const values = [...box.centerM, ...box.halfExtentsM, ...box.orientationXYZW];
    const bytes = new Uint8Array(80), view = new DataView(bytes.buffer);
    values.forEach((value, index) => view.setFloat64(index * 8, value, true));
    return Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
}
function groupBoxes(boxes) {
    const groups = new Map();
    for (const box of boxes) {
        const key = geometryKey(box), group = groups.get(key);
        if (group)
            group.ids.push(box.id);
        else
            groups.set(key, { representative: copyBox(box), ids: [box.id] });
    }
    return Array.from(groups.values());
}
function createUprightCapsuleQuery(input) {
    const scene = (0, admission_js_1.admitScene)(input), groups = groupBoxes(scene.boxes);
    let disposed = false;
    function live() { if (disposed)
        throw new capsule_query_error_js_1.PhysicsError('DISPOSED', 'Capsule query is disposed'); }
    return {
        sweep(input) {
            live();
            const query = (0, admission_js_1.admitSweep)(input, scene), hits = [];
            for (const group of groups) {
                let selectedId = null;
                for (const id of group.ids)
                    if (id !== query.excludeId && (selectedId === null || id < selectedId))
                        selectedId = id;
                if (selectedId === null)
                    continue;
                const hit = (0, sweep_js_1.sweepBox)(query.centerM, query.displacementM, group.representative);
                if (hit)
                    hits.push({ ...hit, bodyId: selectedId });
            }
            if (!hits.length)
                return null;
            const minimum = Math.min(...hits.map(hit => hit.toiFraction));
            return hits.filter(hit => hit.toiFraction <= minimum + profile_js_1.TIE_FRACTION)
                .sort((a, b) => a.bodyId < b.bodyId ? -1 : a.bodyId > b.bodyId ? 1 : 0)[0];
        },
        getSnapshot() { live(); return { version: 1, profile: scene.profile, revision: scene.revision, boxes: scene.boxes.map(copyBox) }; },
        dispose() { disposed = true; },
    };
}
