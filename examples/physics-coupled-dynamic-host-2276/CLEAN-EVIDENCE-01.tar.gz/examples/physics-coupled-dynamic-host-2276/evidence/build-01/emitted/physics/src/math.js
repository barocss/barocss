"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.worldPoint = exports.localPoint = exports.inverse = exports.cross = exports.dot = exports.scale = exports.sub = exports.add = void 0;
exports.multiplyQuaternion = multiplyQuaternion;
exports.advanceOrientation = advanceOrientation;
exports.rotate = rotate;
exports.inverseInertia = inverseInertia;
exports.inertia = inertia;
function multiplyQuaternion(a, b) {
    const [ax, ay, az, aw] = a, [bx, by, bz, bw] = b;
    return [aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz];
}
function advanceOrientation(orientation, angularVelocity, dt) {
    const speed = Math.hypot(...angularVelocity);
    if (speed === 0)
        return [...orientation];
    const halfAngle = speed * dt / 2;
    const scale = Math.sin(halfAngle) / speed;
    const delta = [angularVelocity[0] * scale, angularVelocity[1] * scale,
        angularVelocity[2] * scale, Math.cos(halfAngle)];
    const next = multiplyQuaternion(delta, orientation);
    const norm = Math.hypot(...next);
    return next.map((component) => component / norm);
}
const add = (a, b) => a.map((value, index) => value + b[index]);
exports.add = add;
const sub = (a, b) => a.map((value, index) => value - b[index]);
exports.sub = sub;
const scale = (a, value) => a.map((component) => component * value);
exports.scale = scale;
const dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);
exports.dot = dot;
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
exports.cross = cross;
const inverse = (q) => [-q[0], -q[1], -q[2], q[3]];
exports.inverse = inverse;
function rotate(q, v) {
    const axis = [q[0], q[1], q[2]];
    const t = (0, exports.scale)((0, exports.cross)(axis, v), 2);
    return (0, exports.add)(v, (0, exports.add)((0, exports.scale)(t, q[3]), (0, exports.cross)(axis, t)));
}
const localPoint = (body, point) => rotate((0, exports.inverse)(body.orientation), (0, exports.sub)(point, body.positionM));
exports.localPoint = localPoint;
const worldPoint = (body, point) => (0, exports.add)(body.positionM, rotate(body.orientation, point));
exports.worldPoint = worldPoint;
function inverseInertia(body, vector) {
    const local = rotate((0, exports.inverse)(body.orientation), vector);
    return rotate(body.orientation, local.map((value, index) => value * body.inverseInertiaLocal[index]));
}
function inertia(body, vector) {
    const local = rotate((0, exports.inverse)(body.orientation), vector);
    return rotate(body.orientation, local.map((value, index) => value / body.inverseInertiaLocal[index]));
}
