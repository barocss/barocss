// examples/physics-stack-library-2276/arithmetic-opt08.test.mts
import assert from "node:assert/strict";
import test from "node:test";
import { pathToFileURL } from "node:url";

// packages/barocss-physics/src/types.ts
var PhysicsError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.name = "PhysicsError";
    this.details = { code, reason: message, operation: "create", phase: "admission", domain: "world", entityIds: [], accepted: null, ...details };
  }
  details;
};

// packages/barocss-physics/src/limits.ts
var ID = /^[A-Za-z][A-Za-z0-9._:-]{0,63}$/;

// packages/barocss-physics/src/validation.ts
function error(code, message) {
  throw new PhysicsError(code, message);
}
function record(value, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) error("INVALID_CONFIG", `${label} must be an object`);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) error("INVALID_CONFIG", `${label} must be a plain object`);
  return value;
}
function fields(value, allowed, label) {
  if (Reflect.ownKeys(value).some((key) => typeof key !== "string" || !allowed.includes(key))) {
    error("INVALID_CONFIG", `${label} has an unsupported field`);
  }
}
function finite(value, min, max, label) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max) {
    error("INVALID_CONFIG", `${label} must be finite and in [${min}, ${max}]`);
  }
  return value;
}
function vector(value, min, max, label) {
  if (!Array.isArray(value) || value.length !== 3) error("INVALID_CONFIG", `${label} must be a 3-vector`);
  return [0, 1, 2].map((index) => finite(value[index], min, max, `${label}[${index}]`));
}
function angularVector(value) {
  if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 || ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "angularVelocityRadps must be a dense 3-vector");
  }
  return vector(value, -1e3, 1e3, "angularVelocityRadps");
}
function quaternion(value) {
  if (!Array.isArray(value) || value.length !== 4 || Reflect.ownKeys(value).length !== 5 || ![0, 1, 2, 3].every((index) => Object.hasOwn(value, index))) {
    error("INVALID_CONFIG", "orientation must be a dense [x,y,z,w] quaternion");
  }
  const values = value.map((component) => finite(component, -1, 1, "orientation"));
  const magnitude = Math.hypot(...values);
  if (Math.abs(magnitude - 1) > 1e-6) error("INVALID_CONFIG", "orientation must have unit norm");
  return values.map((component) => component / magnitude);
}
function shape(value) {
  const input = record(value, "shape");
  if (input.kind === "sphere") {
    fields(input, ["kind", "radiusM"], "sphere");
    return { kind: "sphere", radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM") };
  }
  if (input.kind === "box") {
    fields(input, ["kind", "halfExtentsM"], "box");
    return { kind: "box", halfExtentsM: vector(input.halfExtentsM, 1e-4, 1e3, "halfExtentsM") };
  }
  if (input.kind === "capsule") {
    fields(input, ["kind", "radiusM", "halfLengthM"], "capsule");
    return {
      kind: "capsule",
      radiusM: finite(input.radiusM, 1e-4, 1e3, "radiusM"),
      halfLengthM: finite(input.halfLengthM, 1e-4, 1e3, "halfLengthM")
    };
  }
  return error("INVALID_CONFIG", "unsupported collider shape");
}
function friction(value) {
  const input = record(value, "friction");
  fields(input, ["static", "dynamic"], "friction");
  const staticCoefficient = finite(input.static, 0, 2, "friction.static");
  const dynamicCoefficient = finite(input.dynamic, 0, staticCoefficient, "friction.dynamic");
  return { static: staticCoefficient, dynamic: dynamicCoefficient };
}
function collisionFilter(value) {
  const input = record(value, "collisionFilter");
  fields(input, ["categoryBits", "maskBits"], "collisionFilter");
  if (!Number.isInteger(input.categoryBits) || !Number.isInteger(input.maskBits)) {
    error("INVALID_CONFIG", "collision filter bits must be integers");
  }
  return {
    categoryBits: finite(input.categoryBits, 1, 65535, "categoryBits"),
    maskBits: finite(input.maskBits, 0, 65535, "maskBits")
  };
}
function parseBody(value, largeMode = false) {
  const input = record(value, "body");
  if (typeof input.id !== "string" || !ID.test(input.id)) error("INVALID_CONFIG", "invalid body ID");
  if (input.kind !== "dynamic" && input.kind !== "static" && input.kind !== "kinematic") {
    error("INVALID_CONFIG", "invalid body kind");
  }
  const kind = input.kind;
  fields(input, kind === "dynamic" ? [
    "id",
    "kind",
    "shape",
    "positionM",
    "velocityMps",
    "massKg",
    "restitution",
    "orientation",
    "angularVelocityRadps",
    "inertiaKgM2",
    "friction",
    "ccd",
    ...largeMode ? ["collisionFilter"] : []
  ] : [
    "id",
    "kind",
    "shape",
    "positionM",
    "restitution",
    "orientation",
    "sensor",
    "friction",
    ...largeMode ? ["collisionFilter"] : []
  ], "body");
  if (Object.hasOwn(input, "sensor") && input.sensor !== true) error("INVALID_CONFIG", "sensor must be true");
  const sensor = input.sensor === true;
  const parsedShape = shape(input.shape);
  if (Object.hasOwn(input, "ccd") && (input.ccd !== true || parsedShape.kind !== "sphere" && parsedShape.kind !== "box")) {
    error("INVALID_CONFIG", "ccd is supported for dynamic spheres or boxes only and must be true");
  }
  const positionM = vector(input.positionM, -1e4, 1e4, "positionM");
  const restitution = finite(input.restitution, 0, 1, "restitution");
  const material = Object.hasOwn(input, "friction") ? friction(input.friction) : { static: 0, dynamic: 0 };
  const filter = largeMode ? Object.hasOwn(input, "collisionFilter") ? collisionFilter(input.collisionFilter) : { categoryBits: 1, maskBits: 65535 } : void 0;
  const orientation = Object.hasOwn(input, "orientation") ? quaternion(input.orientation) : [0, 0, 0, 1];
  if (kind !== "dynamic") {
    return {
      id: input.id,
      kind,
      shape: parsedShape,
      positionM,
      velocityMps: [0, 0, 0],
      orientation,
      angularVelocityRadps: [0, 0, 0],
      inverseInertiaLocal: [0, 0, 0],
      sensor,
      inverseMass: 0,
      restitution,
      frictionStatic: material.static,
      frictionDynamic: material.dynamic,
      ...filter ? { collisionFilter: filter } : {}
    };
  }
  const massKg = finite(input.massKg, 1e-6, 1e6, "massKg");
  if (parsedShape.kind !== "sphere" && Object.hasOwn(input, "inertiaKgM2")) {
    error("INVALID_CONFIG", "inertiaKgM2 override is supported for spheres only");
  }
  const inertiaKgM2 = parsedShape.kind === "sphere" ? Object.hasOwn(input, "inertiaKgM2") ? finite(input.inertiaKgM2, 1e-12, 1e12, "inertiaKgM2") : 0.4 * massKg * parsedShape.radiusM ** 2 : void 0;
  const inertiaDiagonalKgM2 = parsedShape.kind === "box" ? [
    massKg / 3 * (parsedShape.halfExtentsM[1] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[2] ** 2),
    massKg / 3 * (parsedShape.halfExtentsM[0] ** 2 + parsedShape.halfExtentsM[1] ** 2)
  ] : parsedShape.kind === "capsule" ? capsuleMoments(massKg, parsedShape.radiusM, parsedShape.halfLengthM) : void 0;
  const inertia = inertiaDiagonalKgM2 ?? [inertiaKgM2, inertiaKgM2, inertiaKgM2];
  return {
    id: input.id,
    kind,
    shape: parsedShape,
    positionM,
    sensor,
    ...filter ? { collisionFilter: filter, sleeping: false } : {},
    ...input.ccd === true ? { ccd: true } : {},
    velocityMps: vector(input.velocityMps, -1e3, 1e3, "velocityMps"),
    orientation,
    angularVelocityRadps: Object.hasOwn(input, "angularVelocityRadps") ? angularVector(input.angularVelocityRadps) : [0, 0, 0],
    ...inertiaKgM2 === void 0 ? {} : { inertiaKgM2 },
    ...inertiaDiagonalKgM2 === void 0 ? {} : { inertiaDiagonalKgM2 },
    inverseInertiaLocal: inertia.map((value2) => 1 / value2),
    inverseMass: 1 / massKg,
    restitution,
    frictionStatic: material.static,
    frictionDynamic: material.dynamic
  };
}
function capsuleMoments(massKg, radiusM, halfLengthM) {
  const cylinderMass = massKg * (3 * halfLengthM) / (3 * halfLengthM + 2 * radiusM);
  const capMass = massKg - cylinderMass;
  const radiusSquared = radiusM * radiusM;
  const axial = cylinderMass * radiusSquared / 2 + capMass * 2 * radiusSquared / 5;
  const transverse = cylinderMass * (radiusSquared / 4 + halfLengthM * halfLengthM / 3) + capMass * (2 * radiusSquared / 5 + halfLengthM * halfLengthM + 3 * halfLengthM * radiusM / 4);
  return [transverse, axial, transverse];
}

// examples/physics-stack-library-2276/candidate-strict-line-opt08.ts
var STRICT_LINE_LIMITS = Object.freeze({
  rationalOperations: 2e5,
  integerOperations: 2e6,
  integerBits: 16384,
  roundingSteps: 16
});
var StrictLineFailure = class extends Error {
  constructor(message) {
    super(message);
    this.name = "StrictLineFailure";
  }
};
var ZERO = { n: 0n, d: 1n };
var ieee = new DataView(new ArrayBuffer(8));
var Arithmetic = class {
  counters = { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 };
  guardCached() {
    if (this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
    if (this.counters.peakIntegerBits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
  }
  tick(amount = 1) {
    this.counters.integerOperations += amount;
    if (this.counters.integerOperations > STRICT_LINE_LIMITS.integerOperations) throw new StrictLineFailure("integer work limit");
  }
  op() {
    if (++this.counters.rationalOperations > STRICT_LINE_LIMITS.rationalOperations) throw new StrictLineFailure("rational work limit");
  }
  checked(value) {
    const hex = (value < 0n ? -value : value).toString(16), first = hex.charCodeAt(0);
    const bits = 4 * (hex.length - 1) + (first <= 49 ? 1 : first <= 51 ? 2 : first <= 55 ? 3 : 4);
    this.counters.peakIntegerBits = Math.max(this.counters.peakIntegerBits, bits);
    if (bits > STRICT_LINE_LIMITS.integerBits) throw new StrictLineFailure("integer bit limit");
    return value;
  }
  multiply(a, b) {
    this.tick();
    return this.checked(a * b);
  }
  sum(a, b) {
    this.tick();
    return this.checked(a + b);
  }
  shifted(value, bits) {
    this.tick();
    return this.checked(value << BigInt(bits));
  }
  make(n, d = 1n) {
    this.checked(n);
    this.checked(d);
    return this.normalizeChecked(n, d);
  }
  /** Both operands have already passed checked in this call's evaluation order. */
  normalizeChecked(n, d) {
    if (d === 0n) throw new StrictLineFailure("zero rational denominator");
    if (n === 0n) return ZERO;
    if (d < 0n) {
      this.tick(2);
      n = -n;
      d = -d;
    }
    if (d === 1n) {
      this.guardCached();
      return { n, d };
    }
    let a = n < 0n ? -n : n, b = d;
    this.tick(2);
    if ((d & d - 1n) === 0n) {
      this.tick(2);
      const factor = a & -a, divisor = factor < d ? factor : d;
      this.tick(2);
      return { n: n / divisor, d: d / divisor };
    }
    while (b !== 0n) {
      this.tick();
      const remainder = a % b;
      a = b;
      b = remainder;
    }
    this.tick(2);
    return { n: n / a, d: d / a };
  }
  from(value) {
    this.op();
    if (!Number.isFinite(value)) throw new StrictLineFailure("nonfinite exact operand");
    ieee.setFloat64(0, value, false);
    const bits = ieee.getBigUint64(0, false), negative = bits >> 63n !== 0n;
    const exponent = Number(bits >> 52n & 2047n), fraction = bits & (1n << 52n) - 1n;
    const significand = exponent === 0 ? fraction : fraction + (1n << 52n);
    const power = exponent === 0 ? -1074 : exponent - 1023 - 52;
    const n = negative ? -significand : significand;
    return power >= 0 ? this.make(this.shifted(n, power)) : this.make(n, this.shifted(1n, -power));
  }
  add(a, b) {
    this.op();
    if (a.d === b.d) return this.make(this.sum(a.n, b.n), a.d);
    if (a.d > 0n && b.d > 0n) {
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(this.sum(a.n, this.multiply(b.n, ratio)), a.d);
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.sum(this.multiply(a.n, ratio), b.n), b.d);
      }
    }
    return this.normalizeChecked(this.sum(this.multiply(a.n, b.d), this.multiply(b.n, a.d)), this.multiply(a.d, b.d));
  }
  neg(a) {
    this.op();
    this.tick();
    return { n: -a.n, d: a.d };
  }
  sub(a, b) {
    return this.add(a, this.neg(b));
  }
  mul(a, b) {
    this.op();
    return this.normalizeChecked(this.multiply(a.n, b.n), this.multiply(a.d, b.d));
  }
  sumSquare(a, b) {
    const sum = this.add(a, b);
    this.op();
    const n = this.multiply(sum.n, sum.n), d = this.multiply(sum.d, sum.d);
    if (n === 0n) return ZERO;
    if (d === 1n) this.guardCached();
    return { n, d };
  }
  div(a, b) {
    this.op();
    if (a.d > 0n && b.d > 0n && b.n !== 0n) {
      this.guardCached();
      if (a.d === b.d) return this.make(a.n, b.n);
      this.tick();
      if (a.d % b.d === 0n) {
        this.tick();
        const ratio = this.checked(a.d / b.d);
        return this.make(a.n, this.multiply(ratio, b.n));
      }
      this.tick();
      if (b.d % a.d === 0n) {
        this.tick();
        const ratio = this.checked(b.d / a.d);
        return this.make(this.multiply(ratio, a.n), b.n);
      }
    }
    return this.normalizeChecked(this.multiply(a.n, b.d), this.multiply(a.d, b.n));
  }
  compare(a, b) {
    this.op();
    const difference = this.sum(this.multiply(a.n, b.d), -this.multiply(b.n, a.d));
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
  }
  abs(a) {
    return a.n < 0n ? this.neg(a) : a;
  }
  vec(value, length = 3) {
    if (value.length !== length || !Array.from({ length }, (_, i) => i).every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    return value.map((x) => this.from(x));
  }
  dot(a, b) {
    return a.reduce((value, x, i) => this.add(value, this.mul(x, b[i])), ZERO);
  }
  /** Correct nearest-even conversion, including subnormals; no Number(BigInt)/Number(BigInt). */
  number(value) {
    this.op();
    if (value.n === 0n) return 0;
    const negative = value.n < 0n, n = negative ? -value.n : value.n, d = value.d;
    let exponent = n.toString(2).length - d.toString(2).length;
    if (exponent >= 0 ? n < this.shifted(d, exponent) : this.shifted(n, -exponent) < d) exponent--;
    const unit = Math.max(-1074, exponent - 52);
    const numerator = unit < 0 ? this.shifted(n, -unit) : n;
    const denominator = unit > 0 ? this.shifted(d, unit) : d;
    this.tick(2);
    let quotient = numerator / denominator;
    const remainder = numerator % denominator;
    const twice = this.shifted(remainder, 1);
    if (twice > denominator || twice === denominator && (quotient & 1n) !== 0n) {
      this.tick();
      quotient++;
    }
    const result = Number(quotient) * Math.pow(2, unit);
    if (!Number.isFinite(result)) throw new StrictLineFailure("rounded witness overflow");
    return negative ? -result : result;
  }
};
var StrictLineContext = class {
  m = new Arithmetic();
  boxes;
  normal;
  tolerance;
  normalSquared;
  fourToleranceSquared;
  directions = [void 0, void 0];
  lastMidpoint;
  constructor(a, b, normal) {
    this.normal = this.m.vec(normal);
    if (this.normal.every((x) => x.n === 0n)) throw new StrictLineFailure("zero line direction");
    this.tolerance = this.m.from(1e-12);
    this.normalSquared = this.m.dot(this.normal, this.normal);
    this.fourToleranceSquared = this.m.mul(this.m.from(4), this.m.mul(this.tolerance, this.tolerance));
    this.boxes = [this.box(a), this.box(b)];
  }
  stats() {
    return { ...this.m.counters };
  }
  box(body) {
    if (body.shape.kind !== "box") throw new StrictLineFailure("box required");
    const m = this.m, [x, y, z, w] = m.vec(body.orientation, 4), norm2 = m.dot([x, y, z, w], [x, y, z, w]);
    if (norm2.n === 0n) throw new StrictLineFailure("zero quaternion");
    const two = m.from(2), square = (q) => m.mul(q, q);
    const twice = (a, b) => m.mul(two, m.mul(a, b));
    const diagonal = (a, b) => m.div(m.sub(norm2, m.mul(two, m.add(square(a), square(b)))), norm2);
    const entry = (a, b, c, d, sign) => m.div(sign === 1 ? m.add(twice(a, b), twice(c, d)) : m.sub(twice(a, b), twice(c, d)), norm2);
    const rotation = [
      [diagonal(y, z), entry(x, y, z, w, -1), entry(x, z, y, w, 1)],
      [entry(x, y, z, w, 1), diagonal(x, z), entry(y, z, x, w, -1)],
      [entry(x, z, y, w, -1), entry(y, z, x, w, 1), diagonal(x, y)]
    ];
    const extent = m.vec(body.shape.halfExtentsM);
    if (extent.some((value) => value.n <= 0n)) throw new StrictLineFailure("positive extents required");
    return { centre: m.vec(body.positionM), extent, rotation };
  }
  local(box2, world, direction = false) {
    const relative = direction ? world : world.map((value, i) => this.m.sub(value, box2.centre[i]));
    return [0, 1, 2].map((axis) => this.m.dot(box2.rotation.map((row) => row[axis]), relative));
  }
  direction(which) {
    const cached = this.directions[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], this.normal, true);
    this.directions[which] = value;
    return value;
  }
  midpoint(value) {
    if (!Array.isArray(value) || value.length !== 3 || ![0, 1, 2].every((i) => Object.hasOwn(value, i))) throw new StrictLineFailure("dense exact vector required");
    const key = [value[0], value[1], value[2]], cached = this.lastMidpoint;
    if (key.every(Number.isFinite) && cached !== void 0 && key.every((v, i) => Object.is(v, cached.key[i]))) {
      this.m.guardCached();
      return cached;
    }
    const point = this.m.vec(key);
    const entry = { key, point, local: [void 0, void 0], interval: [void 0, void 0] };
    this.lastMidpoint = entry;
    return entry;
  }
  localMidpoint(which, entry) {
    const cached = entry.local[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const value = this.local(this.boxes[which], entry.point);
    entry.local[which] = value;
    return value;
  }
  interval(which, entry) {
    const cached = entry.interval[which];
    if (cached !== void 0) {
      this.m.guardCached();
      return cached;
    }
    const result = this.computeInterval(which, entry);
    entry.interval[which] = result;
    return result;
  }
  computeInterval(which, entry) {
    const box2 = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which);
    let low = null, high = null;
    for (let i = 0; i < 3; i++) {
      if (d[i].n === 0n) {
        if (m.compare(m.abs(u[i]), box2.extent[i]) > 0) return null;
        continue;
      }
      const first = m.div(m.sub(m.neg(box2.extent[i]), u[i]), d[i]), second = m.div(m.sub(box2.extent[i], u[i]), d[i]);
      const lower = m.compare(first, second) <= 0 ? first : second, upper = lower === first ? second : first;
      if (low === null || m.compare(lower, low) > 0) low = lower;
      if (high === null || m.compare(upper, high) < 0) high = upper;
      if (low !== null && high !== null && m.compare(low, high) > 0) return null;
    }
    if (low === null || high === null) throw new StrictLineFailure("unbounded box line interval");
    return { low, high };
  }
  /** Strict closed slabs and the actual A-exit/B-entry surface midpoint. */
  check(midpoint) {
    const m = this.m, entry = this.midpoint(midpoint), a = this.interval(0, entry);
    if (a === null) return false;
    const b = this.interval(1, entry);
    if (b === null) return false;
    const fourDistanceSquared = m.mul(m.sumSquare(a.high, b.low), this.normalSquared);
    return m.compare(fourDistanceSquared, this.fourToleranceSquared) <= 0;
  }
  faceIsBoundary(which, entry, plane, bound, exit) {
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    const box2 = this.boxes[which], m = this.m, u = this.localMidpoint(which, entry), d = this.direction(which), axis = plane.axis;
    if (d[axis].n === 0n) return false;
    const side = m.from(plane.side), outwardDirection = m.mul(side, d[axis]);
    if (m.compare(outwardDirection, ZERO) !== (exit ? 1 : -1)) return false;
    const parameter = m.div(m.sub(m.mul(side, box2.extent[axis]), u[axis]), d[axis]);
    return m.compare(parameter, bound) === 0;
  }
  /** Named faces must be actual line bounds; closed edge/corner ties remain valid. */
  selectedFaceBounds(midpoint, faceA, faceB) {
    const entry = this.midpoint(midpoint), a = this.interval(0, entry);
    if (a === null) return false;
    const b = this.interval(1, entry);
    return b !== null && this.faceIsBoundary(0, entry, faceA, a.high, true) && this.faceIsBoundary(1, entry, faceB, b.low, false);
  }
  onFace(which, plane, witness) {
    const m = this.m, box2 = this.boxes[which], local = this.local(box2, m.vec(witness));
    if (!Number.isInteger(plane.axis) || plane.axis < 0 || plane.axis > 2 || Math.abs(plane.side) !== 1) throw new StrictLineFailure("face selector");
    if (local.some((value, i) => m.compare(m.sub(m.abs(value), box2.extent[i]), this.tolerance) > 0)) return false;
    return m.compare(m.abs(m.sub(local[plane.axis], m.mul(m.from(plane.side), box2.extent[plane.axis]))), this.tolerance) <= 0;
  }
  movementWithin(original, moved) {
    const m = this.m, a = m.vec(original), b = m.vec(moved), delta = a.map((value, i) => m.sub(b[i], value));
    return m.compare(m.dot(delta, delta), m.mul(this.tolerance, this.tolerance)) <= 0;
  }
  projectedPair(seed, faceA, faceB) {
    const m = this.m, p = m.vec(seed);
    return [faceA, faceB].map((face, which) => {
      if (!Number.isInteger(face.axis) || face.axis < 0 || face.axis > 2 || Math.abs(face.side) !== 1) throw new StrictLineFailure("face selector");
      const box2 = this.boxes[which], u = this.local(box2, p), d = this.direction(which), axis = face.axis;
      if (d[axis].n === 0n) throw new StrictLineFailure("line parallel to selected face");
      const t = m.div(m.sub(m.mul(m.from(face.side), box2.extent[axis]), u[axis]), d[axis]);
      return p.map((value, i) => m.number(m.add(value, m.mul(this.normal[i], t))));
    });
  }
};

// examples/physics-stack-library-2276/arithmetic-opt08.test.mts
var current = { StrictLineContext, StrictLineFailure, STRICT_LINE_LIMITS };
async function baseline() {
  assert.ok(process.env.STRICT_LINE_BASELINE_MODULE);
  return import(pathToFileURL(process.env.STRICT_LINE_BASELINE_MODULE).href);
}
function box(id) {
  return parseBody({ id, kind: "dynamic", shape: { kind: "box", halfExtentsM: [1, 1, 1] }, positionM: [0, 0, 0], orientation: [0, 0, 0, 1], velocityMps: [0, 0, 0], massKg: 1, restitution: 0 });
}
function arithmetic(api) {
  const seed = new api.StrictLineContext(box("a"), box("b"), [0, 1, 0]).m;
  const Constructor = Object.getPrototypeOf(seed).constructor, m = new Constructor();
  assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 0 });
  return m;
}
function refusal(api, call, message) {
  assert.throws(call, (e) => e instanceof api.StrictLineFailure && e.message === message);
}
function word(value) {
  const bytes = Buffer.alloc(8);
  bytes.writeDoubleBE(value);
  return bytes.toString("hex");
}
function verifyBits(api, value, bits) {
  const m = arithmetic(api);
  assert.equal(m.checked(value), value);
  assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: bits });
}
var nibbleWidths = [1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4];
for (let digit = 0; digit < 16; digit++) test(String(digit + 1).padStart(2, "0") + " literal leading nibble " + digit, async () => {
  const old = await baseline();
  assert.deepEqual(STRICT_LINE_LIMITS, old.STRICT_LINE_LIMITS);
  for (const q of [0, 1, 15, 255, 4095]) for (const api of [current, old]) {
    const value = BigInt(digit) << 4n * BigInt(q), bits = digit === 0 ? 1 : 4 * q + nibbleWidths[digit];
    verifyBits(api, value, bits);
    verifyBits(api, -value, bits);
    if (digit !== 0 && q !== 0) {
      const filled = value + ((1n << 4n * BigInt(q)) - 1n);
      verifyBits(api, filled, bits);
      verifyBits(api, -filled, bits);
    }
  }
});
test("17 power boundaries use analytic shift exponents", async () => {
  const old = await baseline();
  for (const k of [0, 1, 3, 4, 7, 8, 15, 16, 31, 32, 52, 53, 63, 64, 255, 256, 1023, 1024, 4095, 4096, 8191, 8192, 16382, 16383]) {
    const p = 1n << BigInt(k);
    for (const api of [current, old]) for (const sign of [1n, -1n]) {
      verifyBits(api, sign * p, k + 1);
      verifyBits(api, sign * (p - 1n), Math.max(1, k));
    }
  }
});
test("18 maximum legal positive and negative integers retain exact peak", async () => {
  const old = await baseline(), p = (1n << 16384n) - 1n;
  for (const api of [current, old]) {
    verifyBits(api, p, 16384);
    verifyBits(api, -p, 16384);
  }
});
for (const [name, value] of [["19 positive minimum oversized", 1n << 16384n], ["20 negative minimum oversized", -(1n << 16384n)], ["21 larger oversized exact peak", (1n << 20000n) + 7n]]) test(name, async () => {
  const old = await baseline(), bits = name.startsWith("21") ? 20001 : 16385, receipts = [];
  for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.checked(value), "integer bit limit");
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: bits });
    receipts.push({ ...m.counters });
  }
  assert.deepEqual(receipts[0], receipts[1]);
});
test("22 repeated checks keep monotonic peaks and do not tick", async () => {
  const old = await baseline();
  for (const api of [current, old]) {
    const m = arithmetic(api);
    for (const [n, peak] of [[0n, 1], [15n, 4], [-16n, 5], [1n, 5], [255n, 8], [-256n, 9], [0n, 9]]) {
      assert.equal(m.checked(n), n);
      assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: peak });
    }
  }
});
test("23 oversized numerator precedes zero denominator", async () => {
  const old = await baseline();
  for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.make(1n << 16384n, 0n), "integer bit limit");
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 16385 });
  }
});
test("24 oversized denominator precedes zero numerator shortcut", async () => {
  const old = await baseline();
  for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.make(0n, 1n << 16384n), "integer bit limit");
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 0, peakIntegerBits: 16385 });
  }
});
test("25 numerator product refusal precedes invalid denominator", async () => {
  const old = await baseline();
  for (const api of [current, old]) {
    const m = arithmetic(api), p = 1n << 8192n;
    refusal(api, () => m.mul({ n: p, d: 0n }, { n: p, d: 1n }), "integer bit limit");
    assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 1, peakIntegerBits: 16385 });
  }
});
test("26 signed raw normalization retains independent result and exact ticks", async () => {
  const old = await baseline();
  for (const api of [current, old]) {
    const m = arithmetic(api);
    assert.deepEqual(m.make(12n, -18n), { n: -2n, d: 3n });
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 9, peakIntegerBits: 5 });
  }
});
test("27 IEEE decode subnormals extrema and zero retain literal words", async () => {
  const old = await baseline();
  for (const [value, n, d, expected] of [[0, 0n, 1n, "0000000000000000"], [-0, 0n, 1n, "0000000000000000"], [Number.MIN_VALUE, 1n, 1n << 1074n, "0000000000000001"], [-Number.MIN_VALUE, -1n, 1n << 1074n, "8000000000000001"], [2 ** -1022, 1n, 1n << 1022n, "0010000000000000"], [Number.MAX_VALUE, 9007199254740991n << 971n, 1n, "7fefffffffffffff"]]) {
    const receipts = [];
    for (const api of [current, old]) {
      const m = arithmetic(api), r = m.from(value);
      assert.deepEqual(r, { n, d });
      assert.equal(word(m.number(r)), expected);
      receipts.push({ ...m.counters });
    }
    assert.deepEqual(receipts[0], receipts[1]);
  }
});
test("28 nearest-even midpoint and signed underflow words retain exact counters", async () => {
  const old = await baseline(), D = 1n << 53n;
  for (const [n, d, expected] of [[D + 1n, D, "3ff0000000000000"], [D + 3n, D, "3ff0000000000002"], [1n, 1n << 1075n, "0000000000000000"], [-1n, 1n << 1075n, "8000000000000000"]]) {
    const receipts = [];
    for (const api of [current, old]) {
      const m = arithmetic(api);
      assert.equal(word(m.number(m.make(n, d))), expected);
      receipts.push({ ...m.counters });
    }
    assert.deepEqual(receipts[0], receipts[1]);
  }
});
test("29 actual prior bit failure preserves old stale-context resume and guards", async () => {
  const old = await baseline(), receipts = [];
  for (const api of [current, old]) {
    const m = arithmetic(api);
    refusal(api, () => m.checked(1n << 16384n), "integer bit limit");
    assert.equal(m.checked(-1n), -1n);
    assert.deepEqual(m.make(0n), { n: 0n, d: 1n });
    refusal(api, () => m.make(1n), "integer bit limit");
    assert.deepEqual(m.make(1n, 3n), { n: 1n, d: 3n });
    assert.deepEqual(m.sumSquare({ n: 1n, d: 8n }, { n: 1n, d: 4n }), { n: 9n, d: 64n });
    assert.equal(m.counters.peakIntegerBits, 16385);
    receipts.push({ ...m.counters });
  }
  assert.deepEqual(receipts[0], receipts[1]);
});
test("30 actual rational exhaustion cannot be bypassed by changed encoding", async (t) => {
  const old = await baseline(), receipts = [];
  for (const api of [current, old]) {
    const m = arithmetic(api), zero = m.make(0n);
    let attempted = 0, error2 = null;
    for (; attempted < 200001; ) {
      attempted++;
      try {
        m.neg(zero);
      } catch (e) {
        error2 = e;
        break;
      }
    }
    assert.ok(error2 instanceof api.StrictLineFailure);
    assert.equal(error2.message, "rational work limit");
    assert.equal(attempted, 200001);
    refusal(api, () => m.from(1), "rational work limit");
    const before = { ...m.counters };
    assert.equal(m.checked(0n), 0n);
    assert.deepEqual(m.counters, before);
    receipts.push({ attempted, counters: { ...m.counters } });
  }
  assert.deepEqual(receipts[0], receipts[1]);
  t.diagnostic(JSON.stringify({ actualRationalExhaustion: receipts[0], noCounterMutation: true }));
});
test("31 actual integer exhaustion preserves checks and unit guard priority", async (t) => {
  const old = await baseline(), receipts = [];
  for (const api of [current, old]) {
    const m = arithmetic(api);
    let attempted = 0, error2 = null;
    for (; attempted < 200001; ) {
      attempted++;
      try {
        m.make(55n, 89n);
      } catch (e) {
        error2 = e;
        break;
      }
    }
    assert.ok(error2 instanceof api.StrictLineFailure);
    assert.equal(error2.message, "integer work limit");
    assert.equal(attempted, 142858);
    assert.deepEqual(m.counters, { rationalOperations: 0, integerOperations: 2000001, peakIntegerBits: 7 });
    const before = { ...m.counters };
    assert.equal(m.checked(0n), 0n);
    assert.deepEqual(m.counters, before);
    refusal(api, () => m.make(1n), "integer work limit");
    receipts.push({ attempted, counters: { ...m.counters } });
  }
  assert.deepEqual(receipts[0], receipts[1]);
  t.diagnostic(JSON.stringify({ actualIntegerExhaustion: receipts[0], noCounterMutation: true }));
});
test("32 real cap-boundary product passes then next product refuses identically", async (t) => {
  const old = await baseline(), receipts = [];
  for (const api of [current, old]) {
    const m = arithmetic(api);
    for (let i = 0; i < 142857; i++) assert.deepEqual(m.make(55n, 89n), { n: 55n, d: 89n });
    assert.equal(m.counters.integerOperations, 1999998);
    assert.deepEqual(m.mul({ n: 1n, d: 1n }, { n: 1n, d: 1n }), { n: 1n, d: 1n });
    assert.deepEqual(m.counters, { rationalOperations: 1, integerOperations: 2e6, peakIntegerBits: 7 });
    refusal(api, () => m.mul({ n: 1n, d: 1n }, { n: 1n, d: 1n }), "integer work limit");
    assert.deepEqual(m.counters, { rationalOperations: 2, integerOperations: 2000001, peakIntegerBits: 7 });
    receipts.push({ ...m.counters });
  }
  assert.deepEqual(receipts[0], receipts[1]);
  t.diagnostic(JSON.stringify({ sameActualWorkAdmission: receipts[0], noCounterMutation: true }));
});
