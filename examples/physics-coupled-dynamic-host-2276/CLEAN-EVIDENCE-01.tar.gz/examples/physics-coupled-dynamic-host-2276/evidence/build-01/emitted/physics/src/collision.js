"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.detect = detect;
exports.sphereOverlaps = sphereOverlaps;
exports.rayDistance = rayDistance;
exports.solve = solve;
exports.validateResult = validateResult;
const validation_js_1 = require("./validation.js");
const math_js_1 = require("./math.js");
const capsule_contact_js_1 = require("./capsule-contact.js");
const contact_tangent_js_1 = require("./contact-tangent.js");
function capsuleCenter(body, point) {
    const half = body.shape.halfLengthM;
    const local = (0, math_js_1.localPoint)(body, point);
    return (0, math_js_1.worldPoint)(body, [0, Math.max(-half, Math.min(half, local[1])), 0]);
}
function boxAxes(body) {
    return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((axis) => (0, math_js_1.rotate)(body.orientation, axis));
}
function boxSupport(body, direction) {
    const axes = boxAxes(body);
    const extents = body.shape.halfExtentsM;
    return (0, math_js_1.add)(body.positionM, axes.reduce((result, axis, index) => {
        const projection = (0, math_js_1.dot)(axis, direction);
        const offset = Math.abs(projection) <= 1e-12 ? 0
            : projection > 0 ? extents[index] : -extents[index];
        return (0, math_js_1.add)(result, (0, math_js_1.scale)(axis, offset));
    }, [0, 0, 0]));
}
function sphereSphere(a, b) {
    const aRadius = a.shape.radiusM;
    const bRadius = b.shape.radiusM;
    const delta = (0, math_js_1.sub)(b.positionM, a.positionM);
    const distance = Math.hypot(...delta);
    if (distance > aRadius + bRadius)
        return null;
    const normal = distance === 0 ? [1, 0, 0] : (0, math_js_1.scale)(delta, 1 / distance);
    const aSurface = (0, math_js_1.add)(a.positionM, (0, math_js_1.scale)(normal, aRadius));
    const bSurface = (0, math_js_1.sub)(b.positionM, (0, math_js_1.scale)(normal, bRadius));
    return { normal, penetration: Math.max(0, aRadius + bRadius - distance),
        pointM: (0, math_js_1.scale)((0, math_js_1.add)(aSurface, bSurface), 0.5) };
}
function sphereBox(sphere, box) {
    const radius = sphere.shape.radiusM;
    const extents = box.shape.halfExtentsM;
    const relative = (0, math_js_1.localPoint)(box, sphere.positionM);
    const nearest = relative.map((value, index) => Math.max(-extents[index], Math.min(extents[index], value)));
    const towardBox = (0, math_js_1.sub)(nearest, relative);
    const distance = Math.hypot(...towardBox);
    if (distance > radius)
        return null;
    if (distance > 0)
        return { normal: (0, math_js_1.rotate)(box.orientation, (0, math_js_1.scale)(towardBox, 1 / distance)),
            penetration: Math.max(0, radius - distance), pointM: (0, math_js_1.worldPoint)(box, nearest) };
    // Inside or on a face: axis X, Y, Z; negative face first on a tie.
    let axis = 0, side = -1, faceDistance = Infinity;
    for (let index = 0; index < 3; index++)
        for (const candidate of [-1, 1]) {
            const gap = extents[index] - candidate * relative[index];
            if (gap < faceDistance) {
                faceDistance = gap;
                axis = index;
                side = candidate;
            }
        }
    const localNormal = [0, 0, 0];
    localNormal[axis] = -side;
    nearest[axis] = side * extents[axis];
    return { normal: (0, math_js_1.rotate)(box.orientation, localNormal), penetration: radius + faceDistance,
        pointM: (0, math_js_1.worldPoint)(box, nearest) };
}
function capsuleSphere(capsule, sphere) {
    const center = capsuleCenter(capsule, sphere.positionM);
    const delta = (0, math_js_1.sub)(sphere.positionM, center);
    const distance = Math.hypot(...delta);
    const capsuleRadius = capsule.shape.radiusM;
    const sphereRadius = sphere.shape.radiusM;
    if (distance > capsuleRadius + sphereRadius)
        return null;
    const normal = distance === 0 ? [1, 0, 0] : (0, math_js_1.scale)(delta, 1 / distance);
    return { normal, penetration: Math.max(0, capsuleRadius + sphereRadius - distance),
        pointM: (0, math_js_1.scale)((0, math_js_1.add)((0, math_js_1.add)(center, (0, math_js_1.scale)(normal, capsuleRadius)), (0, math_js_1.sub)(sphere.positionM, (0, math_js_1.scale)(normal, sphereRadius))), 0.5) };
}
function boxBox(a, b) {
    const axesA = boxAxes(a), axesB = boxAxes(b);
    const extentA = a.shape.halfExtentsM, extentB = b.shape.halfExtentsM;
    const delta = (0, math_js_1.sub)(b.positionM, a.positionM);
    let bestAxis = [1, 0, 0], bestOverlap = Infinity;
    const candidates = [...axesA, ...axesB, ...axesA.flatMap((axisA) => axesB.map((axisB) => (0, math_js_1.cross)(axisA, axisB)))];
    for (const candidate of candidates) {
        const length = Math.hypot(...candidate);
        if (length < 1e-12)
            continue;
        const axis = (0, math_js_1.scale)(candidate, 1 / length);
        const radiusA = axesA.reduce((sum, basis, index) => sum + extentA[index] * Math.abs((0, math_js_1.dot)(basis, axis)), 0);
        const radiusB = axesB.reduce((sum, basis, index) => sum + extentB[index] * Math.abs((0, math_js_1.dot)(basis, axis)), 0);
        const signedDistance = (0, math_js_1.dot)(delta, axis);
        const overlap = radiusA + radiusB - Math.abs(signedDistance);
        if (overlap < -1e-12)
            return null;
        if (overlap < bestOverlap) {
            bestOverlap = overlap;
            bestAxis = (0, math_js_1.scale)(axis, signedDistance < 0 ? -1 : 1);
        }
    }
    const aPoint = boxSupport(a, bestAxis);
    const bPoint = boxSupport(b, (0, math_js_1.scale)(bestAxis, -1));
    return { normal: bestAxis, penetration: Math.max(0, bestOverlap), pointM: (0, math_js_1.scale)((0, math_js_1.add)(aPoint, bPoint), 0.5) };
}
function detect(a, b) {
    if (a.shape.kind === 'sphere' && b.shape.kind === 'sphere')
        return sphereSphere(a, b);
    if (a.shape.kind === 'sphere' && b.shape.kind === 'box')
        return sphereBox(a, b);
    if (a.shape.kind === 'box' && b.shape.kind === 'sphere') {
        const hit = sphereBox(b, a);
        return hit && { ...hit, normal: (0, math_js_1.scale)(hit.normal, -1) };
    }
    if (a.shape.kind === 'capsule' && b.shape.kind === 'sphere')
        return capsuleSphere(a, b);
    if (a.shape.kind === 'sphere' && b.shape.kind === 'capsule') {
        const hit = capsuleSphere(b, a);
        return hit && { ...hit, normal: (0, math_js_1.scale)(hit.normal, -1) };
    }
    if (a.shape.kind === 'box' && b.shape.kind === 'box')
        return boxBox(a, b);
    if (a.shape.kind === 'capsule' && b.shape.kind === 'box')
        return (0, capsule_contact_js_1.capsuleBox)(a, b);
    if (a.shape.kind === 'box' && b.shape.kind === 'capsule') {
        const hit = (0, capsule_contact_js_1.capsuleBox)(b, a);
        return hit && { ...hit, normal: (0, math_js_1.scale)(hit.normal, -1) };
    }
    if (a.shape.kind === 'capsule' && b.shape.kind === 'capsule')
        return (0, capsule_contact_js_1.capsuleCapsule)(a, b);
    return null;
}
function sphereOverlaps(center, radius, body) {
    if (body.shape.kind === 'sphere') {
        return Math.hypot(...(0, math_js_1.sub)(center, body.positionM)) <= radius + body.shape.radiusM;
    }
    if (body.shape.kind === 'capsule') {
        return Math.hypot(...(0, math_js_1.sub)(center, capsuleCenter(body, center))) <= radius + body.shape.radiusM;
    }
    const extents = body.shape.halfExtentsM;
    const local = (0, math_js_1.localPoint)(body, center);
    const delta = local.map((value, index) => Math.max(0, Math.abs(value) - extents[index]));
    return Math.hypot(...delta) <= radius;
}
function raySphere(origin, direction, center, radius) {
    const relative = (0, math_js_1.sub)(origin, center);
    const c = (0, math_js_1.dot)(relative, relative) - radius ** 2;
    if (c <= 0)
        return 0;
    const projection = (0, math_js_1.dot)(relative, direction);
    const discriminant = projection ** 2 - c;
    return projection > 0 || discriminant < 0 ? null : -projection - Math.sqrt(discriminant);
}
function rayDistance(origin, direction, body) {
    if (body.shape.kind === 'sphere')
        return raySphere(origin, direction, body.positionM, body.shape.radiusM);
    const localOrigin = (0, math_js_1.localPoint)(body, origin);
    const localDirection = (0, math_js_1.rotate)((0, math_js_1.inverse)(body.orientation), direction);
    if (body.shape.kind === 'capsule') {
        const { radiusM: radius, halfLengthM: half } = body.shape;
        const closest = [0, Math.max(-half, Math.min(half, localOrigin[1])), 0];
        if (Math.hypot(...(0, math_js_1.sub)(localOrigin, closest)) <= radius)
            return 0;
        const results = [];
        for (const y of [-half, half]) {
            const hit = raySphere(localOrigin, localDirection, [0, y, 0], radius);
            if (hit !== null)
                results.push(hit);
        }
        const a = localDirection[0] ** 2 + localDirection[2] ** 2;
        if (a > 1e-12) {
            const b = 2 * (localOrigin[0] * localDirection[0] + localOrigin[2] * localDirection[2]);
            const c = localOrigin[0] ** 2 + localOrigin[2] ** 2 - radius ** 2;
            const discriminant = b ** 2 - 4 * a * c;
            if (discriminant >= 0)
                for (const sign of [-1, 1]) {
                    const hit = (-b + sign * Math.sqrt(discriminant)) / (2 * a);
                    const y = localOrigin[1] + localDirection[1] * hit;
                    if (hit >= 0 && y >= -half && y <= half)
                        results.push(hit);
                }
        }
        return results.length ? Math.min(...results) : null;
    }
    let near = -Infinity, far = Infinity;
    for (let index = 0; index < 3; index++) {
        const lower = -body.shape.halfExtentsM[index];
        const upper = body.shape.halfExtentsM[index];
        const component = localDirection[index];
        if (Math.abs(component) < 1e-12) {
            if (localOrigin[index] < lower || localOrigin[index] > upper)
                return null;
            continue;
        }
        const first = (lower - localOrigin[index]) / component;
        const second = (upper - localOrigin[index]) / component;
        near = Math.max(near, Math.min(first, second));
        far = Math.min(far, Math.max(first, second));
        if (far < near)
            return null;
    }
    return far < 0 ? null : Math.max(0, near);
}
function solve(a, b, hit) {
    const inverseTotal = a.inverseMass + b.inverseMass;
    if (inverseTotal === 0)
        return { normalImpulseNs: 0, tangentImpulseNs: [0, 0, 0] };
    const armA = (0, math_js_1.sub)(hit.pointM, a.positionM), armB = (0, math_js_1.sub)(hit.pointM, b.positionM);
    const pointVelocityA = (0, math_js_1.add)(a.velocityMps, (0, math_js_1.cross)(a.angularVelocityRadps, armA));
    const pointVelocityB = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.cross)(b.angularVelocityRadps, armB));
    const relativeSpeed = (0, math_js_1.dot)(hit.normal, (0, math_js_1.sub)(pointVelocityB, pointVelocityA));
    const torqueAxisA = (0, math_js_1.cross)(armA, hit.normal), torqueAxisB = (0, math_js_1.cross)(armB, hit.normal);
    const effectiveMass = inverseTotal + (0, math_js_1.dot)(torqueAxisA, (0, math_js_1.inverseInertia)(a, torqueAxisA))
        + (0, math_js_1.dot)(torqueAxisB, (0, math_js_1.inverseInertia)(b, torqueAxisB));
    let impulse = 0;
    if (relativeSpeed < 0) {
        const bounce = -relativeSpeed > 0.5 ? Math.min(a.restitution, b.restitution) : 0;
        impulse = -(1 + bounce) * relativeSpeed / effectiveMass;
    }
    a.angularVelocityRadps = (0, math_js_1.sub)(a.angularVelocityRadps, (0, math_js_1.scale)((0, math_js_1.inverseInertia)(a, torqueAxisA), impulse));
    b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.scale)((0, math_js_1.inverseInertia)(b, torqueAxisB), impulse));
    for (let i = 0; i < 3; i++) {
        a.velocityMps[i] -= hit.normal[i] * impulse * a.inverseMass;
        b.velocityMps[i] += hit.normal[i] * impulse * b.inverseMass;
        a.positionM[i] -= hit.normal[i] * hit.penetration * a.inverseMass / inverseTotal;
        b.positionM[i] += hit.normal[i] * hit.penetration * b.inverseMass / inverseTotal;
    }
    const staticFriction = Math.sqrt(a.frictionStatic * b.frictionStatic);
    if (impulse === 0 || staticFriction === 0) {
        return { normalImpulseNs: impulse, tangentImpulseNs: [0, 0, 0] };
    }
    // A sphere against a fixed box acts at its radial surface. Reconstruct
    // that lever directly; subtracting projected coordinates can shorten it
    // by one representable word and change the exact Coulomb boundary.
    const frictionArmA = a.shape.kind === 'sphere' && b.kind === 'static' && b.shape.kind === 'box'
        ? (0, math_js_1.scale)(hit.normal, a.shape.radiusM) : (0, math_js_1.sub)(hit.pointM, a.positionM);
    const frictionArmB = b.shape.kind === 'sphere' && a.kind === 'static' && a.shape.kind === 'box'
        ? (0, math_js_1.scale)(hit.normal, -b.shape.radiusM) : (0, math_js_1.sub)(hit.pointM, b.positionM);
    const afterA = (0, math_js_1.add)(a.velocityMps, (0, math_js_1.cross)(a.angularVelocityRadps, frictionArmA));
    const afterB = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.cross)(b.angularVelocityRadps, frictionArmB));
    const relative = (0, math_js_1.sub)(afterB, afterA);
    const normalSquared = (0, math_js_1.dot)(hit.normal, hit.normal);
    if (!(normalSquared > 0) || !Number.isFinite(normalSquared)) {
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'unsafe tangent projection');
    }
    // Project onto the actual normal plane without assuming exact unit length.
    // Axial normal-only motion then produces exactly zero tangent.
    const tangent = (0, math_js_1.scale)((0, math_js_1.cross)((0, math_js_1.cross)(hit.normal, relative), hit.normal), 1 / normalSquared);
    const speed = Math.hypot(...tangent);
    if (speed === 0)
        return { normalImpulseNs: impulse, tangentImpulseNs: [0, 0, 0] };
    const direction = (0, math_js_1.scale)(tangent, 1 / speed);
    const tangentAxisA = (0, math_js_1.cross)(frictionArmA, direction), tangentAxisB = (0, math_js_1.cross)(frictionArmB, direction);
    const tangentMass = inverseTotal + (0, math_js_1.dot)(tangentAxisA, (0, math_js_1.inverseInertia)(a, tangentAxisA))
        + (0, math_js_1.dot)(tangentAxisB, (0, math_js_1.inverseInertia)(b, tangentAxisB));
    const required = speed / tangentMass;
    const sticking = (0, contact_tangent_js_1.solveStaticTangent)(a, b, frictionArmA, frictionArmB, hit.normal, direction, speed, tangentMass);
    const dynamicFriction = Math.sqrt(a.frictionDynamic * b.frictionDynamic);
    const tangentImpulse = sticking.magnitudeNs <= staticFriction * impulse
        ? sticking.impulseNs : (0, math_js_1.scale)(direction, -Math.min(required, dynamicFriction * impulse));
    a.velocityMps = (0, math_js_1.sub)(a.velocityMps, (0, math_js_1.scale)(tangentImpulse, a.inverseMass));
    b.velocityMps = (0, math_js_1.add)(b.velocityMps, (0, math_js_1.scale)(tangentImpulse, b.inverseMass));
    a.angularVelocityRadps = (0, math_js_1.sub)(a.angularVelocityRadps, (0, math_js_1.inverseInertia)(a, (0, math_js_1.cross)(frictionArmA, tangentImpulse)));
    b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.inverseInertia)(b, (0, math_js_1.cross)(frictionArmB, tangentImpulse)));
    return { normalImpulseNs: impulse, tangentImpulseNs: tangentImpulse };
}
function validateResult(bodies, contacts) {
    for (const body of bodies) {
        for (const [label, values, bound] of [['position', body.positionM, 10000], ['velocity', body.velocityMps, 1000],
            ['angularVelocity', body.angularVelocityRadps, 1000]]) {
            if (values.some((value) => !Number.isFinite(value) || Math.abs(value) > bound))
                (0, validation_js_1.error)('NUMERIC_LIMIT', `${body.id} ${label} exceeded bounds`);
        }
        if (body.orientation.some((value) => !Number.isFinite(value)) ||
            Math.abs(Math.hypot(...body.orientation) - 1) > 1e-12)
            (0, validation_js_1.error)('NUMERIC_LIMIT', `${body.id} orientation exceeded tolerance`);
    }
    if (contacts.some((contact) => !Number.isFinite(contact.impulseNs) || !Number.isFinite(contact.penetrationM) ||
        contact.normalAtoB.some((value) => !Number.isFinite(value)) ||
        contact.pointM.some((value) => !Number.isFinite(value)) ||
        contact.tangentImpulseNs.some((value) => !Number.isFinite(value))))
        (0, validation_js_1.error)('NUMERIC_LIMIT', 'unsafe contact result');
}
