"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proxyError = proxyError;
exports.proxyRecord = proxyRecord;
exports.proxyFields = proxyFields;
exports.proxyFinite = proxyFinite;
exports.proxyVector = proxyVector;
const index_js_1 = require("./index.js");
function proxyError(code, message) {
    throw new index_js_1.PhysicsError(code, message);
}
function proxyRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value) ||
        ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
        proxyError('INVALID_CONFIG', 'CAD proxy request must be a plain object');
    }
    return value;
}
function proxyFields(value, allowed) {
    if (Reflect.ownKeys(value).some((key) => typeof key !== 'string' || !allowed.includes(key))) {
        proxyError('INVALID_CONFIG', 'CAD proxy request has an unsupported field');
    }
}
function proxyFinite(value, min, max, label) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) {
        proxyError('INVALID_CONFIG', `${label} must be finite and in [${min}, ${max}]`);
    }
    return value;
}
function proxyVector(value, min, max, label) {
    if (!Array.isArray(value) || value.length !== 3 || Reflect.ownKeys(value).length !== 4 ||
        ![0, 1, 2].every((index) => Object.hasOwn(value, index))) {
        proxyError('INVALID_CONFIG', `${label} must be a dense 3-vector`);
    }
    return [0, 1, 2].map((index) => proxyFinite(value[index], min, max, `${label}[${index}]`));
}
