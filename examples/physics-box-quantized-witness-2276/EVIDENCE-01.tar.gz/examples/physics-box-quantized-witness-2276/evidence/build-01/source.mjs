// examples/physics-box-contact-features-2276/candidate.ts
var Unresolved = class extends Error {
};
var BIT_LIMIT = 16384;
var Z = { n: 0n, d: 1n };
var O = { n: 1n, d: 1n };
var bits = (x) => (x < 0n ? -x : x).toString(2).length;
function check(x) {
  if (bits(x) > BIT_LIMIT) throw new Unresolved("EXACT_BIT_LIMIT");
  return x;
}
function product(a, b) {
  if (a !== 0n && b !== 0n && bits(a) + bits(b) > BIT_LIMIT) throw new Unresolved("EXACT_PRODUCT_BIT_LIMIT");
  return check(a * b);
}
function q(n, d = 1n) {
  if (d === 0n) throw new Unresolved("ZERO_EXACT_DENOMINATOR");
  if (n === 0n) return Z;
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  check(n);
  check(d);
  let a = n < 0n ? -n : n, b = d;
  while (b !== 0n) {
    const next = a % b;
    a = b;
    b = next;
  }
  return { n: n / a, d: d / a };
}
var neg = (a) => ({ n: -a.n, d: a.d });
var plus = (a, b) => q(check(product(a.n, b.d) + product(b.n, a.d)), product(a.d, b.d));
var minus = (a, b) => plus(a, neg(b));
var times = (a, b) => q(product(a.n, b.n), product(a.d, b.d));
var over = (a, b) => q(product(a.n, b.d), product(a.d, b.n));
var compare = (a, b) => {
  const d = minus(a, b).n;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var absolute = (a) => a.n < 0n ? neg(a) : a;
function word(value) {
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_INPUT");
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false), e = Number(raw >> 52n & 2047n);
  const m = (raw & 0xfffffffffffffn | (e ? 0x10000000000000n : 0n)) * (raw >> 63n ? -1n : 1n);
  const power = e ? e - 1075 : -1074;
  return power < 0 ? q(m, 1n << BigInt(-power)) : q(m << BigInt(power));
}
function numeric(a) {
  const n = a.n < 0n ? -a.n : a.n;
  if (!n) return 0;
  let exponent = bits(n) - bits(a.d);
  const shift = (value2, count) => {
    if (bits(value2) + count > BIT_LIMIT) throw new Unresolved("PRESENTATION_SHIFT_BIT_LIMIT");
    return check(value2 << BigInt(count));
  };
  if (exponent >= 0 ? n < shift(a.d, exponent) : shift(n, -exponent) < a.d) exponent--;
  if (exponent > 1023) throw new Unresolved("NONFINITE_OUTPUT");
  const unit = Math.max(-1074, exponent - 52);
  const numerator = unit < 0 ? shift(n, -unit) : n;
  const denominator = unit > 0 ? shift(a.d, unit) : a.d;
  let significand = numerator / denominator;
  const remainder = numerator % denominator;
  const doubled = check(remainder + remainder);
  if (doubled > denominator || doubled === denominator && (significand & 1n) !== 0n) significand++;
  const value = Number(significand) * 2 ** unit;
  if (!Number.isFinite(value)) throw new Unresolved("NONFINITE_OUTPUT");
  return a.n < 0n ? -value : value;
}
var vector = (a) => a.map(word);
var vplus = (a, b) => a.map((x, i) => plus(x, b[i]));
var vminus = (a, b) => a.map((x, i) => minus(x, b[i]));
var vscale = (a, t) => a.map((x) => times(x, t));
var dot = (a, b) => a.reduce((s, x, i) => plus(s, times(x, b[i])), Z);
var cross = (a, b) => [
  minus(times(a[1], b[2]), times(a[2], b[1])),
  minus(times(a[2], b[0]), times(a[0], b[2])),
  minus(times(a[0], b[1]), times(a[1], b[0]))
];
var numberVector = (a) => a.map(numeric);
var same = (a, b) => a.every((x, i) => compare(x, b[i]) === 0);
function native(box) {
  if (box.positionM.length !== 3 || box.halfExtentsM.length !== 3 || box.orientationXYZW.length !== 4 || box.positionM.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1e4) || box.halfExtentsM.some((x2) => !Number.isFinite(x2) || x2 < 1e-4 || x2 > 1e3) || box.orientationXYZW.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1) || Math.abs(Math.hypot(...box.orientationXYZW) - 1) > 1e-9) throw new Unresolved("OUTSIDE_NATIVE_INPUT_PROFILE");
  const [x, y, z, w] = box.orientationXYZW.map(word);
  const s = plus(plus(times(x, x), times(y, y)), plus(times(z, z), times(w, w))), two = word(2);
  if (s.n === 0n) throw new Unresolved("ZERO_QUATERNION");
  const rows = [
    [minus(s, times(two, plus(times(y, y), times(z, z)))), times(two, minus(times(x, y), times(z, w))), times(two, plus(times(x, z), times(y, w)))],
    [times(two, plus(times(x, y), times(z, w))), minus(s, times(two, plus(times(x, x), times(z, z)))), times(two, minus(times(y, z), times(x, w)))],
    [times(two, minus(times(x, z), times(y, w))), times(two, plus(times(y, z), times(x, w))), minus(s, times(two, plus(times(x, x), times(y, y))))]
  ];
  return {
    box,
    centre: vector(box.positionM),
    half: vector(box.halfExtentsM),
    axes: [0, 1, 2].map((i) => rows.map((row) => over(row[i], s)))
  };
}
var addN = (a, b) => a.map((x, i) => x + b[i]);
var subN = (a, b) => a.map((x, i) => x - b[i]);
var scaleN = (a, s) => a.map((x) => x * s);
var dotN = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
var crossN = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
function rawAxes(box) {
  const axis = box.orientationXYZW.slice(0, 3), w = box.orientationXYZW[3];
  return [[1, 0, 0], [0, 1, 0], [0, 0, 1]].map((v) => {
    const t = scaleN(crossN(axis, v), 2);
    return addN(v, addN(scaleN(t, w), crossN(axis, t)));
  });
}
function select(pair, counts) {
  const aa = rawAxes(pair.a), bb = rawAxes(pair.b), delta = subN(pair.b.positionM, pair.a.positionM);
  const axes = [...aa, ...bb, ...aa.flatMap((a) => bb.map((b) => crossN(a, b)))];
  let selected = null;
  for (let index = 0; index < 15; index++) {
    counts.axisVisits++;
    const length = Math.hypot(...axes[index]);
    if (length < 1e-12) continue;
    const axis = scaleN(axes[index], 1 / length);
    const ra = aa.reduce((sum, basis, i) => sum + pair.a.halfExtentsM[i] * Math.abs(dotN(basis, axis)), 0);
    const rb = bb.reduce((sum, basis, i) => sum + pair.b.halfExtentsM[i] * Math.abs(dotN(basis, axis)), 0);
    const distance = dotN(delta, axis), overlap = ra + rb - Math.abs(distance);
    if (!Number.isFinite(overlap)) throw new Unresolved("NONFINITE_SAT");
    if (overlap < -1e-12) return null;
    if (!selected || overlap < selected.overlap) {
      const feature = index < 6 ? { kind: "FACE", owner: index < 3 ? "a" : "b", axis: index % 3, index } : { kind: "EDGE", axisA: Math.floor((index - 6) / 3), axisB: (index - 6) % 3, index };
      selected = { feature, overlap, normal: scaleN(axis, distance < 0 ? -1 : 1) };
    }
  }
  if (!selected) throw new Unresolved("NO_SAT_AXIS");
  return selected;
}
function inside(body, p) {
  const delta = vminus(p, body.centre);
  return body.axes.every((axis, i) => compare(absolute(dot(delta, axis)), body.half[i]) <= 0);
}
function certificate(a, b, p, r, normal) {
  if (!inside(a, p) || !inside(b, r)) throw new Unresolved("NATIVE_TWELVE_HALFSPACE_FAILURE");
  if (cross(vminus(r, p), normal).some((x) => x.n !== 0n)) throw new Unresolved("NONPARALLEL_NATIVE_WITNESSES");
  return { a: p, b: r, midpoint: vscale(vplus(p, r), over(O, word(2))) };
}
function nativeLineInterval(body, origin, direction) {
  const offset = vminus(origin, body.centre);
  let lo = null, hi = null;
  for (let axis = 0; axis < 3; axis++) {
    const start = dot(offset, body.axes[axis]), speed = dot(direction, body.axes[axis]);
    if (speed.n === 0n) {
      if (compare(absolute(start), body.half[axis]) > 0) return null;
      continue;
    }
    const first = over(minus(neg(body.half[axis]), start), speed);
    const second = over(minus(body.half[axis], start), speed);
    const lower = compare(first, second) <= 0 ? first : second;
    const upper = compare(first, second) <= 0 ? second : first;
    if (lo === null || compare(lower, lo) > 0) lo = lower;
    if (hi === null || compare(upper, hi) < 0) hi = upper;
    if (lo !== null && hi !== null && compare(lo, hi) > 0) return null;
  }
  return lo === null || hi === null ? null : { lo, hi };
}
function certifyPresentation(a, b, point, endpointA, endpointB, normal) {
  const p = vector(point), n = vector(normal);
  const ia = nativeLineInterval(a, p, n), ib = nativeLineInterval(b, p, n);
  if (!ia || !ib) throw new Unresolved("FLOAT_PRESENTATION_LINE_MISSES_NATIVE_BOX");
  const limitSquared = q(1n, 1000000000000000000000000n);
  for (const [endpoint, time] of [[endpointA, ia.hi], [endpointB, ib.lo]]) {
    const residual = vminus(vector(endpoint), vplus(p, vscale(n, time)));
    if (compare(dot(residual, residual), limitSquared) > 0) {
      throw new Unresolved("FLOAT_PRESENTATION_NATIVE_EXIT_RESIDUAL");
    }
  }
}
function clip(polygon, centre, axis, half) {
  const result = [];
  for (let i = 0; i < polygon.length; i++) {
    const current = polygon[i], next = polygon[(i + 1) % polygon.length];
    const a = minus(dot(vminus(current, centre), axis), half), b = minus(dot(vminus(next, centre), axis), half);
    if (a.n <= 0n) result.push(current);
    if (a.n <= 0n !== b.n <= 0n) {
      const t = over(a, minus(a, b));
      if (compare(t, Z) < 0 || compare(t, O) > 0) throw new Unresolved("CLIP_EXTRAPOLATION");
      result.push(vplus(current, vscale(vminus(next, current), t)));
    }
  }
  return result.filter((point, i) => result.findIndex((other) => same(point, other)) === i);
}
function face(a, b, selected, feature) {
  const reference = feature.owner === "a" ? a : b, incident = feature.owner === "a" ? b : a;
  const towardIncident = feature.owner === "a" ? selected.normal : scaleN(selected.normal, -1);
  const side = dotN(numberVector(reference.axes[feature.axis]), towardIncident) < 0 ? -1 : 1;
  const n = vscale(reference.axes[feature.axis], word(side));
  const normal = feature.owner === "a" ? n : vscale(n, word(-1));
  const centre = vplus(reference.centre, vscale(n, reference.half[feature.axis]));
  let incidentAxis = 0;
  for (let i = 1; i < 3; i++) if (compare(absolute(dot(incident.axes[i], n)), absolute(dot(incident.axes[incidentAxis], n))) > 0) incidentAxis = i;
  const incidentSide = dot(incident.axes[incidentAxis], n).n > 0n ? -1 : 1;
  const incidentCentre = vplus(incident.centre, vscale(incident.axes[incidentAxis], times(word(incidentSide), incident.half[incidentAxis])));
  const tangents = [0, 1, 2].filter((i) => i !== incidentAxis);
  let polygon = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => vplus(
    vplus(incidentCentre, vscale(incident.axes[tangents[0]], times(word(u), incident.half[tangents[0]]))),
    vscale(incident.axes[tangents[1]], times(word(v), incident.half[tangents[1]]))
  ));
  const referenceTangents = [0, 1, 2].filter((i) => i !== feature.axis);
  for (const i of referenceTangents) {
    polygon = clip(polygon, centre, reference.axes[i], reference.half[i]);
    polygon = clip(polygon, centre, vscale(reference.axes[i], word(-1)), reference.half[i]);
  }
  if (!polygon.length) throw new Unresolved("EMPTY_NATIVE_FACE_PATCH");
  const candidates = polygon.map((p) => ({ p, separation: dot(vminus(p, centre), n) }));
  const penetrating = candidates.filter((x) => x.separation.n <= 0n);
  const minimum = candidates.reduce((best, x) => compare(x.separation, best.separation) < 0 ? x : best);
  const active = penetrating.length ? penetrating : candidates.filter((x) => compare(x.separation, minimum.separation) === 0);
  let points = active.map(({ p, separation }) => {
    const referencePoint = vminus(p, vscale(n, separation));
    return feature.owner === "a" ? certificate(a, b, referencePoint, p, normal) : certificate(a, b, p, referencePoint, normal);
  });
  if (points.length > 4) points = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => points.reduce((best, point) => {
    const score = (x) => plus(
      times(word(u), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[0]])),
      times(word(v), dot(vminus(x.midpoint, centre), reference.axes[referenceTangents[1]]))
    );
    return compare(score(point), score(best)) > 0 ? point : best;
  }));
  points = points.filter((point, i) => points.findIndex((other) => same(point.midpoint, other.midpoint)) === i);
  points.sort((p, r) => compare(dot(p.midpoint, reference.axes[referenceTangents[0]]), dot(r.midpoint, reference.axes[referenceTangents[0]])) || compare(dot(p.midpoint, reference.axes[referenceTangents[1]]), dot(r.midpoint, reference.axes[referenceTangents[1]])));
  return { normal, points };
}
function supportEdge(body, axis, direction) {
  let centre = body.centre;
  for (let i = 0; i < 3; i++) if (i !== axis) {
    const sign = dot(body.axes[i], direction).n < 0n ? -1 : 1;
    centre = vplus(centre, vscale(body.axes[i], times(word(sign), body.half[i])));
  }
  const extent = vscale(body.axes[axis], body.half[axis]);
  return [vminus(centre, extent), vplus(centre, extent)];
}
var clamp = (x) => compare(x, Z) < 0 ? Z : compare(x, O) > 0 ? O : x;
function edge(a, b, selected, feature) {
  let normal = cross(a.axes[feature.axisA], b.axes[feature.axisB]);
  if (dot(normal, normal).n === 0n) throw new Unresolved("ZERO_NATIVE_EDGE_AXIS");
  if (dotN(numberVector(normal), selected.normal) < 0) normal = vscale(normal, word(-1));
  const [p, p1] = supportEdge(a, feature.axisA, normal), [r, r1] = supportEdge(b, feature.axisB, vscale(normal, word(-1)));
  const u = vminus(p1, p), v = vminus(r1, r), w = vminus(p, r);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v), dd = dot(u, w), ee = dot(v, w);
  const determinant = minus(times(aa, cc), times(bb, bb));
  const parameters = [];
  if (determinant.n > 0n) {
    const s = over(minus(times(bb, ee), times(cc, dd)), determinant);
    const t = over(minus(times(aa, ee), times(bb, dd)), determinant);
    if (compare(s, Z) >= 0 && compare(s, O) <= 0 && compare(t, Z) >= 0 && compare(t, O) <= 0) parameters.push([s, t]);
  }
  for (const s of [Z, O]) parameters.push([s, clamp(over(plus(ee, times(bb, s)), cc))]);
  for (const t of [Z, O]) parameters.push([clamp(over(minus(times(bb, t), dd), aa)), t]);
  const pairs = parameters.map(([s, t]) => ({ a: vplus(p, vscale(u, s)), b: vplus(r, vscale(v, t)) }));
  const best = pairs.reduce((old, x) => compare(dot(vminus(x.b, x.a), vminus(x.b, x.a)), dot(vminus(old.b, old.a), vminus(old.b, old.a))) < 0 ? x : old);
  return { normal, points: [certificate(a, b, best.a, best.b, normal)] };
}
var encoded = (a) => a.map((x) => `${x.n}/${x.d}`);
function boxContact(pair) {
  let selected = null;
  let construction = null;
  let presentationPointId = null;
  const counts = { axisVisits: 0 };
  try {
    const a = native(pair.a), b = native(pair.b);
    selected = select(pair, counts);
    if (!selected) return { status: "MISS", points: [], ...counts };
    const result = selected.feature.kind === "FACE" ? face(a, b, selected, selected.feature) : edge(a, b, selected, selected.feature);
    const normalWord = numberVector(result.normal), length = Math.hypot(...normalWord);
    if (!(length > 0) || !Number.isFinite(length)) throw new Unresolved("INVALID_NORMAL_OUTPUT");
    const normal = scaleN(normalWord, 1 / length);
    const points = result.points.map((p, i) => ({
      id: `${selected.feature.kind}:${selected.feature.index}:${i}`,
      pointM: numberVector(p.midpoint),
      aPointM: numberVector(p.a),
      bPointM: numberVector(p.b),
      exact: { a: encoded(p.a), b: encoded(p.b), midpoint: encoded(p.midpoint) },
      nativeHalfspacesCertified: 12
    }));
    construction = { exactNormalDirection: encoded(result.normal), normal, points };
    for (const point of points) {
      presentationPointId = point.id;
      certifyPresentation(a, b, point.pointM, point.aPointM, point.bPointM, normal);
    }
    presentationPointId = null;
    return {
      status: "HIT",
      feature: selected.feature,
      satNormal: selected.normal,
      satOverlap: selected.overlap,
      normal,
      exactNormalDirection: encoded(result.normal),
      points,
      ...counts,
      geometry: "EXACT_NORMALIZED_QUATERNION_NATIVE_ENDPOINTS",
      phase: "INPUT_POSES_ONLY"
    };
  } catch (error) {
    if (!(error instanceof Unresolved)) throw error;
    return {
      status: "UNRESOLVED",
      feature: selected?.feature ?? null,
      reason: error.message,
      points: [],
      ...counts,
      phase: "INPUT_POSES_ONLY",
      stage: construction ? "FLOAT_PRESENTATION" : "NATIVE_CONSTRUCTION",
      presentationPointId,
      construction
    };
  }
}

// examples/physics-box-quantized-witness-2276/candidate.ts
var Unresolved2 = class extends Error {
};
var BIT_LIMIT2 = 16384;
var Z2 = { n: 0n, d: 1n };
var O2 = { n: 1n, d: 1n };
var bits2 = (x) => (x < 0n ? -x : x).toString(2).length;
function check2(x) {
  if (bits2(x) > BIT_LIMIT2) throw new Unresolved2("EXACT_BIT_LIMIT");
  return x;
}
function product2(a, b) {
  if (a !== 0n && b !== 0n && bits2(a) + bits2(b) > BIT_LIMIT2) throw new Unresolved2("EXACT_PRODUCT_BIT_LIMIT");
  return check2(a * b);
}
function q2(n, d = 1n) {
  if (d === 0n) throw new Unresolved2("ZERO_EXACT_DENOMINATOR");
  if (n === 0n) return Z2;
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  check2(n);
  check2(d);
  let a = n < 0n ? -n : n, b = d;
  while (b !== 0n) {
    const next = a % b;
    a = b;
    b = next;
  }
  return { n: n / a, d: d / a };
}
var neg2 = (a) => ({ n: -a.n, d: a.d });
var plus2 = (a, b) => q2(check2(product2(a.n, b.d) + product2(b.n, a.d)), product2(a.d, b.d));
var minus2 = (a, b) => plus2(a, neg2(b));
var times2 = (a, b) => q2(product2(a.n, b.n), product2(a.d, b.d));
var over2 = (a, b) => q2(product2(a.n, b.d), product2(a.d, b.n));
var compare2 = (a, b) => {
  const d = minus2(a, b).n;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var absolute2 = (a) => a.n < 0n ? neg2(a) : a;
function word2(value) {
  if (!Number.isFinite(value)) throw new Unresolved2("NONFINITE_INPUT");
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false), e = Number(raw >> 52n & 2047n);
  const m = (raw & 0xfffffffffffffn | (e ? 0x10000000000000n : 0n)) * (raw >> 63n ? -1n : 1n);
  const power = e ? e - 1075 : -1074;
  return power < 0 ? q2(m, 1n << BigInt(-power)) : q2(m << BigInt(power));
}
function numeric2(a) {
  const n = a.n < 0n ? -a.n : a.n;
  if (!n) return 0;
  let exponent = bits2(n) - bits2(a.d);
  const shift = (value2, count) => {
    if (bits2(value2) + count > BIT_LIMIT2) throw new Unresolved2("PRESENTATION_SHIFT_BIT_LIMIT");
    return check2(value2 << BigInt(count));
  };
  if (exponent >= 0 ? n < shift(a.d, exponent) : shift(n, -exponent) < a.d) exponent--;
  if (exponent > 1023) throw new Unresolved2("NONFINITE_OUTPUT");
  const unit = Math.max(-1074, exponent - 52);
  const numerator = unit < 0 ? shift(n, -unit) : n;
  const denominator = unit > 0 ? shift(a.d, unit) : a.d;
  let significand = numerator / denominator;
  const remainder = numerator % denominator;
  const doubled = check2(remainder + remainder);
  if (doubled > denominator || doubled === denominator && (significand & 1n) !== 0n) significand++;
  const value = Number(significand) * 2 ** unit;
  if (!Number.isFinite(value)) throw new Unresolved2("NONFINITE_OUTPUT");
  return a.n < 0n ? -value : value;
}
var vector2 = (a) => a.map(word2);
var vplus2 = (a, b) => a.map((x, i) => plus2(x, b[i]));
var vminus2 = (a, b) => a.map((x, i) => minus2(x, b[i]));
var vscale2 = (a, t) => a.map((x) => times2(x, t));
var dot2 = (a, b) => a.reduce((s, x, i) => plus2(s, times2(x, b[i])), Z2);
var cross2 = (a, b) => [
  minus2(times2(a[1], b[2]), times2(a[2], b[1])),
  minus2(times2(a[2], b[0]), times2(a[0], b[2])),
  minus2(times2(a[0], b[1]), times2(a[1], b[0]))
];
var numberVector2 = (a) => a.map(numeric2);
var same2 = (a, b) => a.every((x, i) => compare2(x, b[i]) === 0);
function native2(box) {
  if (box.positionM.length !== 3 || box.halfExtentsM.length !== 3 || box.orientationXYZW.length !== 4 || box.positionM.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1e4) || box.halfExtentsM.some((x2) => !Number.isFinite(x2) || x2 < 1e-4 || x2 > 1e3) || box.orientationXYZW.some((x2) => !Number.isFinite(x2) || Math.abs(x2) > 1) || Math.abs(Math.hypot(...box.orientationXYZW) - 1) > 1e-9) throw new Unresolved2("OUTSIDE_NATIVE_INPUT_PROFILE");
  const [x, y, z, w] = box.orientationXYZW.map(word2);
  const s = plus2(plus2(times2(x, x), times2(y, y)), plus2(times2(z, z), times2(w, w))), two = word2(2);
  if (s.n === 0n) throw new Unresolved2("ZERO_QUATERNION");
  const rows = [
    [minus2(s, times2(two, plus2(times2(y, y), times2(z, z)))), times2(two, minus2(times2(x, y), times2(z, w))), times2(two, plus2(times2(x, z), times2(y, w)))],
    [times2(two, plus2(times2(x, y), times2(z, w))), minus2(s, times2(two, plus2(times2(x, x), times2(z, z)))), times2(two, minus2(times2(y, z), times2(x, w)))],
    [times2(two, minus2(times2(x, z), times2(y, w))), times2(two, plus2(times2(y, z), times2(x, w))), minus2(s, times2(two, plus2(times2(x, x), times2(y, y))))]
  ];
  return {
    box,
    centre: vector2(box.positionM),
    half: vector2(box.halfExtentsM),
    axes: [0, 1, 2].map((i) => rows.map((row) => over2(row[i], s)))
  };
}
var PRESENTATION_SQUARED = q2(1n, 1000000000000000000000000n);
var SURFACE = q2(1n, 1000000000n);
var NORM_GATE = q2(1n, 1000000000000n);
function rational(value) {
  const [n, d] = value.split("/");
  return q2(BigInt(n), d === void 0 ? 1n : BigInt(d));
}
var exactVector = (values) => values.map(rational);
var squaredDistance = (a, b) => {
  const delta = vminus2(a, b);
  return dot2(delta, delta);
};
var fractionString = (a) => `${a.n}/${a.d}`;
function hex(value) {
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  return data.getBigUint64(0, false).toString(16).padStart(16, "0");
}
function adjacent(value, direction) {
  if (value === 0) return direction * Number.MIN_VALUE;
  const data = new DataView(new ArrayBuffer(8));
  data.setFloat64(0, value, false);
  const raw = data.getBigUint64(0, false);
  data.setBigUint64(0, raw + BigInt(value > 0 ? direction : -direction), false);
  const result = data.getFloat64(0, false);
  if (!Number.isFinite(result)) throw new Unresolved2("NONFINITE_CELL_BOUND");
  return result === 0 ? 0 : result;
}
function interval(body, origin, direction) {
  const offset = vminus2(origin, body.centre);
  let lo = null, hi = null;
  for (let axis = 0; axis < 3; axis++) {
    const start = dot2(offset, body.axes[axis]), speed = dot2(direction, body.axes[axis]);
    if (speed.n === 0n) {
      if (compare2(absolute2(start), body.half[axis]) > 0) return null;
      continue;
    }
    const first = over2(minus2(neg2(body.half[axis]), start), speed), second = over2(minus2(body.half[axis], start), speed);
    const lower = compare2(first, second) <= 0 ? first : second, upper = compare2(first, second) <= 0 ? second : first;
    if (lo === null || compare2(lower, lo) > 0) lo = lower;
    if (hi === null || compare2(upper, hi) < 0) hi = upper;
    if (lo !== null && hi !== null && compare2(lo, hi) > 0) return null;
  }
  return lo === null || hi === null ? null : { lo, hi };
}
function surface(body, point, exact) {
  const local = body.axes.map((axis) => dot2(vminus2(point, body.centre), axis));
  const offsets = local.map((value, axis) => minus2(absolute2(value), body.half[axis]));
  if (exact) return offsets.every((x) => x.n <= 0n) && offsets.some((x) => x.n === 0n);
  return offsets.every((x) => compare2(x, SURFACE) <= 0) && offsets.some((x) => compare2(absolute2(x), SURFACE) <= 0);
}
function confirmNative(a, b, point, exactNormal) {
  const pa = exactVector(point.exact.a), pb = exactVector(point.exact.b), midpoint = exactVector(point.exact.midpoint);
  if (!surface(a, pa, true) || !surface(b, pb, true) || !same2(vscale2(vplus2(pa, pb), over2(O2, word2(2))), midpoint) || cross2(vminus2(pb, pa), exactNormal).some((x) => x.n !== 0n)) throw new Unresolved2("NATIVE_CERTIFICATE_FAILURE");
  const ia = interval(a, midpoint, exactNormal), ib = interval(b, midpoint, exactNormal);
  if (!ia || !ib || !same2(vplus2(midpoint, vscale2(exactNormal, ia.hi)), pa) || !same2(vplus2(midpoint, vscale2(exactNormal, ib.lo)), pb)) throw new Unresolved2("NATIVE_LINE_EXIT_FAILURE");
  return { pa, pb, midpoint };
}
function feasibility(a, b, anchor, midpoint, af, bf, normal, nearTouch) {
  if (compare2(squaredDistance(anchor, midpoint), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "MIDPOINT_DISTANCE" };
  const n2 = dot2(normal, normal);
  for (const endpoint of [af, bf]) {
    const delta = vminus2(endpoint, anchor), projected = vscale2(normal, over2(dot2(delta, normal), n2));
    if (compare2(dot2(vminus2(delta, projected), vminus2(delta, projected)), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NORMAL_LINE_DISTANCE" };
  }
  const ia = interval(a, anchor, normal), ib = interval(b, anchor, normal);
  if (!ia || !ib) return { feasible: false, reason: !ia ? "NATIVE_LINE_MISS_A" : "NATIVE_LINE_MISS_B" };
  if (compare2(squaredDistance(af, vplus2(anchor, vscale2(normal, ia.hi))), PRESENTATION_SQUARED) > 0 || compare2(squaredDistance(bf, vplus2(anchor, vscale2(normal, ib.lo))), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NATIVE_EXIT_DISTANCE" };
  if (nearTouch && compare2(times2(times2(minus2(ib.lo, ia.hi), minus2(ib.lo, ia.hi)), n2), PRESENTATION_SQUARED) > 0) return { feasible: false, reason: "NATIVE_PAIRED_GAP" };
  return { feasible: true, reason: "FEASIBLE", intervals: [ia, ib] };
}
function quantizedContact(pair) {
  const counts = { geometryCalls: 0, pointsAttempted: 0, anchorChecks: 0 };
  const completedPoints = [];
  let generated = null, currentCell = [];
  let geometryStatus = "", feature = null, pointId = null;
  try {
    counts.geometryCalls++;
    const base = boxContact(pair);
    geometryStatus = base.status;
    feature = base.feature ?? null;
    if (base.status === "MISS") return { status: "MISS", points: [], counts, sourceGeometryStatus: geometryStatus };
    generated = base.status === "HIT" ? base : base.stage === "FLOAT_PRESENTATION" ? base.construction ?? null : null;
    if (!generated) throw new Unresolved2("SOURCE_NATIVE_CONSTRUCTION_UNRESOLVED:" + base.reason);
    if (generated.points.length > 96) throw new Unresolved2("POINT_BUDGET");
    const a = native2(pair.a), b = native2(pair.b), exactNormal = exactVector(generated.exactNormalDirection), normal = vector2(generated.normal);
    if (compare2(absolute2(minus2(dot2(normal, normal), O2)), NORM_GATE) > 0) throw new Unresolved2("PUBLIC_NORMAL_NORM");
    for (const original of generated.points) {
      counts.pointsAttempted++;
      pointId = original.id;
      currentCell = [];
      const { pa, pb, midpoint } = confirmNative(a, b, original, exactNormal);
      const rounded = numberVector2(midpoint).map((x) => x === 0 ? 0 : x);
      const aPointM = numberVector2(pa), bPointM = numberVector2(pb), af = vector2(aPointM), bf = vector2(bPointM);
      if (compare2(squaredDistance(af, pa), PRESENTATION_SQUARED) > 0 || compare2(squaredDistance(bf, pb), PRESENTATION_SQUARED) > 0 || !surface(a, af, false) || !surface(b, bf, false)) throw new Unresolved2("FIXED_ENDPOINT_PRESENTATION");
      const nearTouch = compare2(squaredDistance(pa, pb), PRESENTATION_SQUARED) <= 0;
      const grid = rounded.map((x) => [adjacent(x, -1), x, adjacent(x, 1)]);
      let best = null;
      for (const x of grid[0]) for (const y of grid[1]) for (const z of grid[2]) {
        if (++counts.anchorChecks > 2592) throw new Unresolved2("ANCHOR_BUDGET");
        const anchor = [x, y, z], key = anchor.map(hex).join(":");
        const exactAnchor = vector2(anchor), score = squaredDistance(exactAnchor, midpoint);
        const check3 = feasibility(a, b, exactAnchor, midpoint, af, bf, normal, nearTouch);
        currentCell.push({ anchor, words: anchor.map(hex), feasible: check3.feasible, reason: check3.reason });
        if (check3.feasible && (!best || compare2(score, best.score) < 0 || compare2(score, best.score) === 0 && key < best.key)) {
          best = { anchor, key, score, intervals: check3.intervals };
        }
      }
      if (!best) throw new Unresolved2("CELL_INFEASIBLE");
      completedPoints.push({
        id: original.id,
        pointM: best.anchor,
        aPointM,
        bPointM,
        exact: original.exact,
        nativeHalfspacesCertified: 12,
        idealRoundedMidpoint: rounded,
        selectedDistanceSquaredExact: fractionString(best.score),
        selectedWordKey: best.key,
        selectedIntervals: best.intervals.map((i) => ({ lower: fractionString(i.lo), upper: fractionString(i.hi) })),
        nearTouch,
        cell: currentCell,
        nearestScope: "COMPLETE_FROZEN_27_MEMBER_CELL_ONLY"
      });
    }
    return {
      status: "HIT",
      feature,
      normal: generated.normal,
      exactNormalDirection: generated.exactNormalDirection,
      points: completedPoints,
      counts,
      sourceGeometryStatus: geometryStatus,
      geometry: "EXACT_NATIVE_WITH_DIRECT_FINITE_CELL_PRESENTATION",
      phase: "INPUT_POSES_ONLY",
      oldSingleRoundedMidpointProtocol: "UNCHANGED_NO_GO",
      globalNearest: "NOT_CLAIMED"
    };
  } catch (error) {
    if (!(error instanceof Unresolved2)) throw error;
    return {
      status: "UNRESOLVED",
      feature,
      pointId,
      reason: error.message,
      points: [],
      counts,
      completedPoints,
      currentCell,
      generatedExactConstruction: generated,
      sourceGeometryStatus: geometryStatus,
      globalInfeasibility: "NOT_CLAIMED"
    };
  }
}
export {
  quantizedContact
};
