/** Private staged experiment: project a real cached tangent before warm apply. */
export type WarmVector = readonly [number, number, number];
export declare class WarmTransportError extends Error {
    readonly reason: string;
    readonly code = "WARM_TRANSPORT_UNRESOLVED";
    constructor(reason: string);
}
export declare function transportWarmTangent(tangentNs: WarmVector, normal: WarmVector): [number, number, number];
