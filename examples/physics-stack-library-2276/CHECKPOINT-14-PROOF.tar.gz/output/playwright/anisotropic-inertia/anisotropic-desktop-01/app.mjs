// examples/physics-anisotropic-inertia-2276/scene/renderer.mjs
var sub = (a, b) => a.map((x, i) => x - b[i]);
var dot = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
var cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
var unit = (v) => v.map((x) => x / Math.hypot(...v));
function rotate(q, p) {
  const t = cross(q.slice(0, 3), p).map((x) => 2 * x), u = cross(q.slice(0, 3), t);
  return p.map((x, i) => x + q[3] * t[i] + u[i]);
}
function cameraMatrix(eye, target, aspect) {
  const z = unit(sub(eye, target)), x = unit(cross([0, 1, 0], z)), y = cross(z, x), n = 0.05, f = 100, k = 1 / Math.tan(Math.PI / 9);
  const view = [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, eye), -dot(y, eye), -dot(z, eye), 1];
  const projection = [k / aspect, 0, 0, 0, 0, k, 0, 0, 0, 0, f / (n - f), -1, 0, 0, f * n / (n - f), 0], out = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let j = 0; j < 4; j++) out[c * 4 + r] += projection[j * 4 + r] * view[c * 4 + j];
  return out;
}
var SHADER = `struct Camera { matrix:mat4x4<f32> }; @group(0) @binding(0) var<uniform> camera:Camera;
struct In { @location(0) p:vec3<f32>, @location(1) n:vec3<f32>, @location(2) c:vec4<f32> };
struct Out { @builtin(position) p:vec4<f32>, @location(0) n:vec3<f32>, @location(1) c:vec4<f32>, @location(2) world:vec3<f32> };
@vertex fn vertex(v:In)->Out { var o:Out; o.p=camera.matrix*vec4(v.p,1); o.n=v.n; o.c=v.c; o.world=v.p; return o; }
@fragment fn fragment(v:Out)->@location(0) vec4<f32> { let light=.38+.62*max(dot(normalize(v.n),normalize(vec3(-.5,1,.6))),0.); var c=v.c.rgb*light; if(v.c.a>.5) { let grid=(i32(floor(v.world.x*2))+i32(floor(v.world.z*2)))&1; c*=.93+.07*f32(grid); } return vec4(c,1); }`;
async function createRenderer(canvas, onError) {
  if (!navigator.gpu) throw Error("WebGPU\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) throw Error("GPU \uC5B4\uB311\uD130\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
  const device = await adapter.requestDevice(), context = canvas.getContext("webgpu"), format = navigator.gpu.getPreferredCanvasFormat();
  if (!context) throw Error("WebGPU canvas context unavailable");
  device.addEventListener("uncapturederror", (event) => onError(event.error));
  device.lost.then((info) => onError(Error("GPU device lost: " + info.message)));
  context.configure({ device, format, alphaMode: "opaque" });
  const shader = device.createShaderModule({ code: SHADER }), messages = await shader.getCompilationInfo();
  const errors2 = messages.messages.filter((m) => m.type === "error");
  if (errors2.length) throw Error(errors2.map((m) => m.message).join("\n"));
  const bindLayout = device.createBindGroupLayout({ entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: "uniform" } }] });
  const layout = device.createPipelineLayout({ bindGroupLayouts: [bindLayout] });
  const pipeline = device.createRenderPipeline({
    layout,
    vertex: { module: shader, entryPoint: "vertex", buffers: [{ arrayStride: 40, attributes: [
      { shaderLocation: 0, offset: 0, format: "float32x3" },
      { shaderLocation: 1, offset: 12, format: "float32x3" },
      { shaderLocation: 2, offset: 24, format: "float32x4" }
    ] }] },
    fragment: { module: shader, entryPoint: "fragment", targets: [{ format }] },
    primitive: { topology: "triangle-list", cullMode: "none" },
    depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "less" }
  });
  const markerPipeline = device.createRenderPipeline({
    layout,
    vertex: { module: shader, entryPoint: "vertex", buffers: [{ arrayStride: 40, attributes: [{ shaderLocation: 0, offset: 0, format: "float32x3" }, { shaderLocation: 1, offset: 12, format: "float32x3" }, { shaderLocation: 2, offset: 24, format: "float32x4" }] }] },
    fragment: { module: shader, entryPoint: "fragment", targets: [{ format }] },
    primitive: { topology: "triangle-list", cullMode: "none" },
    depthStencil: { format: "depth24plus", depthWriteEnabled: false, depthCompare: "always" }
  });
  const vertex = device.createBuffer({ size: 65536, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  const uniform = device.createBuffer({ size: 64, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  const bindings = device.createBindGroup({ layout: bindLayout, entries: [{ binding: 0, resource: { buffer: uniform } }] });
  let depth = null, vertices = 0, bodyCount = 0, markerCount = 0, draws = 0, yaw = 0.65, elevation = 0.38, distance = 11, markers = true, lastBodies = [], submittedVertices = [], submittedMarkerCenters = [];
  function resize() {
    const r = canvas.getBoundingClientRect(), d = Math.min(2, devicePixelRatio || 1), w = Math.max(1, Math.round(r.width * d)), h = Math.max(1, Math.round(r.height * d));
    if (canvas.width === w && canvas.height === h && depth) return;
    canvas.width = w;
    canvas.height = h;
    depth?.destroy();
    depth = device.createTexture({ size: [w, h], format: "depth24plus", usage: GPUTextureUsage.RENDER_ATTACHMENT });
  }
  function present2(state2, model) {
    const data = [], colors = [[0.18, 0.43, 0.75], [0.15, 0.51, 0.76], [0.2, 0.57, 0.74], [0.22, 0.62, 0.7], [0.28, 0.65, 0.65], [0.39, 0.65, 0.58], [0.54, 0.66, 0.53], [0.7, 0.68, 0.49]];
    function box(position, rotation, half, color) {
      for (let axis = 0; axis < 3; axis++) for (const sign of [-1, 1]) {
        const normal = [0, 0, 0];
        normal[axis] = sign;
        const n = rotate(rotation, normal), face = [];
        for (const [u, v] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
          const p = [0, 0, 0];
          p[axis] = sign * half[axis];
          p[(axis + 1) % 3] = u * half[(axis + 1) % 3];
          p[(axis + 2) % 3] = v * half[(axis + 2) % 3];
          face.push(rotate(rotation, p).map((x, i) => x + position[i]));
        }
        for (const i of [0, 1, 2, 0, 2, 3]) data.push(...face[i], ...n, ...color);
      }
    }
    let index = 0;
    lastBodies = [];
    for (const body of state2.bodies) {
      const input = model.bodies.find((b) => b.id === body.id), shape = model.colliders.find((c) => c.bodyId === body.id).geometry;
      box(body.positionM, body.orientationXYZW, shape.halfExtentsM, input.kind === "static" ? [0.78, 0.82, 0.88, 1] : [...colors[index++ % colors.length], 0]);
      lastBodies.push({ id: body.id, positionM: [...body.positionM], orientationXYZW: [...body.orientationXYZW], halfExtentsM: [...shape.halfExtentsM] });
    }
    markerCount = markers ? state2.contacts.length : 0;
    if (markers) for (const contact of state2.contacts) box(contact.pointM, [0, 0, 0, 1], [0.017, 0.017, 0.017], [0.15, 0.85, 0.35, 0]);
    const array = new Float32Array(data);
    if (array.byteLength > 65536) throw Error("Display vertex budget");
    submittedVertices = lastBodies.map((body, index2) => ({ id: body.id, worldM: Array.from(array.subarray(index2 * 360, index2 * 360 + 3)) }));
    submittedMarkerCenters = Array.from({ length: markerCount }, (_, index2) => {
      const mean = [0, 0, 0], offset = (state2.bodies.length + index2) * 360;
      for (let v = 0; v < 36; v++) for (let k = 0; k < 3; k++) mean[k] += array[offset + v * 10 + k] / 36;
      return mean;
    });
    device.queue.writeBuffer(vertex, 0, array);
    vertices = data.length / 10;
    bodyCount = state2.bodies.length;
  }
  function updateCamera() {
    const target = [0, 2.3, 0], eye = [Math.sin(yaw) * Math.cos(elevation) * distance, 2.3 + Math.sin(elevation) * distance, Math.cos(yaw) * Math.cos(elevation) * distance];
    device.queue.writeBuffer(uniform, 0, cameraMatrix(eye, target, canvas.width / canvas.height));
  }
  function encodePass(encoder, colorView, depthView) {
    const pass = encoder.beginRenderPass({ colorAttachments: [{ view: colorView, clearValue: { r: 0.95, g: 0.965, b: 0.985, a: 1 }, loadOp: "clear", storeOp: "store" }], depthStencilAttachment: { view: depthView, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } });
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindings);
    pass.setVertexBuffer(0, vertex);
    pass.draw(bodyCount * 36);
    if (markerCount) {
      pass.setPipeline(markerPipeline);
      pass.setBindGroup(0, bindings);
      pass.draw(markerCount * 36, 1, bodyCount * 36);
    }
    pass.end();
  }
  function draw() {
    resize();
    updateCamera();
    const encoder = device.createCommandEncoder();
    encodePass(encoder, context.getCurrentTexture().createView(), depth.createView());
    device.queue.submit([encoder.finish()]);
    draws++;
  }
  let reading = false;
  async function readPixels() {
    if (reading) throw Error("Only one GPU readback may be outstanding");
    reading = true;
    let color = null, copyDepth = null, readback = null, mapped = false;
    try {
      if (format !== "bgra8unorm" && format !== "rgba8unorm") throw Error("Unsupported observer texture format");
      resize();
      updateCamera();
      color = device.createTexture({ size: [640, 360], format, usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC });
      copyDepth = device.createTexture({ size: [640, 360], format: "depth24plus", usage: GPUTextureUsage.RENDER_ATTACHMENT });
      readback = device.createBuffer({ size: 921600, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
      const encoder = device.createCommandEncoder();
      encodePass(encoder, color.createView(), copyDepth.createView());
      encoder.copyTextureToBuffer({ texture: color }, { buffer: readback, bytesPerRow: 2560, rowsPerImage: 360 }, [640, 360]);
      device.queue.submit([encoder.finish()]);
      await readback.mapAsync(GPUMapMode.READ);
      mapped = true;
      const rgba = new Uint8Array(readback.getMappedRange().slice(0));
      if (format === "bgra8unorm") for (let i = 0; i < rgba.length; i += 4) {
        const blue = rgba[i];
        rgba[i] = rgba[i + 2];
        rgba[i + 2] = blue;
      }
      return { width: 640, height: 360, rgba, format: "rgba8unorm", sourceFormat: format, bytesPerRow: 2560 };
    } finally {
      if (mapped) readback.unmap();
      readback?.destroy();
      color?.destroy();
      copyDepth?.destroy();
      reading = false;
    }
  }
  let pointer = null;
  canvas.addEventListener("pointerdown", (event) => {
    pointer = [event.clientX, event.clientY];
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!pointer) return;
    yaw += (event.clientX - pointer[0]) * 6e-3;
    elevation = Math.max(0.08, Math.min(1.25, elevation + (event.clientY - pointer[1]) * 4e-3));
    pointer = [event.clientX, event.clientY];
  });
  canvas.addEventListener("pointerup", () => pointer = null);
  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    distance = Math.max(4, Math.min(14, distance * Math.exp(event.deltaY * 1e-3)));
  }, { passive: false });
  return { present: present2, draw, readPixels, home() {
    yaw = 0.65;
    elevation = 0.38;
    distance = 11;
  }, setMarkers(value) {
    markers = value;
  }, snapshot() {
    return { kind: "WebGPU", bodyCount, markerCount, vertices, draws, width: canvas.width, height: canvas.height, device: adapter.info ? { vendor: adapter.info.vendor, architecture: adapter.info.architecture, description: adapter.info.description } : null, bodies: structuredClone(lastBodies), submittedVertices: structuredClone(submittedVertices), submittedMarkerCenters: structuredClone(submittedMarkerCenters), camera: { yaw, elevation, distance } };
  } };
}

// examples/physics-anisotropic-inertia-2276/scene/transport.mjs
function numericWordsHex(value) {
  let nodes = 0, count = 0;
  const out = [], buffer = new ArrayBuffer(8), view = new DataView(buffer), bytes = new Uint8Array(buffer);
  function visit(x, depth) {
    if (++nodes > 262144 || depth > 64) throw Error("numeric transport node/depth bound");
    if (typeof x === "number") {
      if (!Number.isFinite(x) || ++count > 65536) throw Error("numeric transport finite/count bound");
      view.setFloat64(0, x, true);
      let hex = "";
      for (const b of bytes) hex += b.toString(16).padStart(2, "0");
      out.push(hex);
    } else if (Array.isArray(x)) {
      for (const v of x) visit(v, depth + 1);
    } else if (x && typeof x === "object") {
      for (const key of Object.keys(x)) visit(x[key], depth + 1);
    }
  }
  visit(value, 0);
  return out.join("");
}
function packet(data) {
  return { format: "anisotropic-inertia-public-v1", data, numericWordsF64leHex: numericWordsHex(data) };
}

// examples/physics-anisotropic-inertia-2276/scene/app.mjs
var $ = (id) => document.getElementById(id);
var worker = new Worker("./worker.mjs", { type: "module" });
var pending = /* @__PURE__ */ new Map();
var errors = [];
var seq = 0;
var epoch = 0;
var models;
var scenario;
var worlds = 0;
var calls = 0;
var state;
var renderer;
var running = false;
var active = null;
var resetting = false;
var states = [];
var commandTrace = [];
var firstImpacts = {};
var fail = (e) => {
  errors.push(String(e?.message ?? e));
  running = false;
  $("error").hidden = false;
  $("error").textContent = errors.at(-1);
  $("status").textContent = "\uC624\uB958";
  $("play").disabled = true;
};
worker.onerror = (e) => {
  for (const p of pending.values()) p.reject(Error(e.message));
  pending.clear();
  fail(Error(e.message));
};
worker.onmessage = (e) => {
  const p = pending.get(e.data.id);
  if (!p) {
    fail(Error("unexpected physics response"));
    return;
  }
  pending.delete(e.data.id);
  e.data.error ? p.reject(Object.assign(Error(e.data.error.message), e.data.error)) : p.resolve(e.data);
};
function request(type, fields = {}) {
  if (pending.size) throw Error("only one outstanding physics request");
  return new Promise((resolve, reject) => {
    const id = ++seq;
    pending.set(id, { resolve, reject });
    worker.postMessage({ id, type, ...fields });
  });
}
function rotate2(q, v) {
  const cross2 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], t = cross2(q.slice(0, 3), v).map((x) => 2 * x), u = cross2(q.slice(0, 3), t);
  return v.map((x, i) => x + q[3] * t[i] + u[i]);
}
function energy() {
  let translationalJ = 0, rotationalJ = 0, potentialJ = 0;
  for (const b of state.bodies) {
    const m = scenario.model.bodies.find((x) => x.id === b.id);
    if (m.kind !== "dynamic") continue;
    translationalJ += 0.5 * m.massKg * b.velocityMps.reduce((s, v) => s + v * v, 0);
    const shape = scenario.model.colliders.find((c) => c.bodyId === b.id).geometry, h = shape.halfExtentsM, norm = Math.hypot(...b.orientationXYZW), q = b.orientationXYZW.map((x) => x / norm), omega = rotate2([-q[0], -q[1], -q[2], q[3]], b.angularVelocityRadps);
    for (let k = 0; k < 3; k++) rotationalJ += 0.5 * (m.massKg / 3 * (h[(k + 1) % 3] ** 2 + h[(k + 2) % 3] ** 2)) * omega[k] ** 2;
    potentialJ -= m.massKg * scenario.model.gravityMps2.reduce((s, g, k) => s + g * b.positionM[k], 0);
  }
  return { kineticJ: translationalJ + rotationalJ, translationalJ, rotationalJ, potentialJ };
}
function retain() {
  if (states.length !== state.stepIndex) throw Error("noncontiguous public trace");
  states.push(state);
  for (const body of scenario.model.bodies) {
    if (body.kind !== "dynamic" || firstImpacts[body.id]) continue;
    if (state.contacts.some((c) => c.normalImpulseNs > 0 && (c.bodyAId === body.id || c.bodyBId === body.id))) firstImpacts[body.id] = { stepIndex: state.stepIndex, before: states.at(-2), after: state };
  }
}
function present() {
  renderer.present(state, scenario.model);
  const e = energy();
  $("clock").textContent = state.timeSeconds.toFixed(3);
  $("frame").textContent = String(state.stepIndex);
  $("contacts").textContent = "\uC811\uCD09 " + state.contacts.length;
  $("kinetic").textContent = e.kineticJ.toFixed(6);
  $("potential").textContent = e.potentialJ.toFixed(6);
  $("status").textContent = state.stepIndex === 64 ? "\uC644\uB8CC" : running ? "\uC2E4\uD589 \uC911" : "\uC815\uC9C0";
  $("step").disabled = running || !!active || resetting || state.stepIndex === 64;
  $("play").disabled = resetting || state.stepIndex === 64;
  $("play").textContent = running ? "\uC815\uC9C0" : "\uC2E4\uD589";
  $("scene").disabled = resetting;
  $("reset").disabled = resetting;
}
async function reset() {
  running = false;
  epoch++;
  resetting = true;
  if (state) present();
  try {
    if (active) await active;
    const nextScenario = structuredClone(models[$("scene").value]);
    const reply = await request("reset", { model: nextScenario.model, options: nextScenario.options, commands: nextScenario.commands });
    scenario = nextScenario;
    worlds = reply.worlds;
    calls = 0;
    state = reply.state;
    states = [];
    commandTrace = [];
    firstImpacts = {};
    retain();
  } finally {
    resetting = false;
    if (state) present();
  }
}
function step() {
  if (active) return active;
  if (calls === 64) return Promise.resolve();
  active = request("step").then((reply) => {
    state = reply.state;
    calls = reply.calls;
    commandTrace.push(reply.commands);
    retain();
    if (calls === 64) running = false;
    present();
  }).finally(() => {
    active = null;
    present();
  });
  present();
  return active;
}
function pump(e) {
  if (!running || e !== epoch) return;
  step().then(() => {
    if (running && e === epoch) requestAnimationFrame(() => pump(e));
  }).catch(fail);
}
try {
  let frame = function() {
    try {
      renderer.draw();
    } catch (e) {
      fail(e);
    }
    requestAnimationFrame(frame);
  };
  frame2 = frame;
  models = await fetch("/models").then((r) => {
    if (!r.ok) throw Error("model load");
    return r.json();
  });
  renderer = await createRenderer($("canvas"), fail);
  await reset();
  $("home").disabled = false;
  $("step").onclick = () => step().catch(fail);
  $("play").onclick = () => {
    running = !running;
    const e = ++epoch;
    present();
    if (running) pump(e);
  };
  $("reset").onclick = () => reset().catch(fail);
  $("scene").onchange = () => reset().catch(fail);
  $("home").onclick = () => renderer.home();
  $("markers").onchange = () => {
    renderer.setMarkers($("markers").checked);
    present();
  };
  requestAnimationFrame(frame);
  window.dynamicLab = { readPixels: () => renderer.readPixels(), snapshot: () => ({ ready: true, caseId: scenario.caseId, worlds, calls, frames: states.length, running, busy: pending.size > 0 || resetting, state: structuredClone(state), firstImpacts: structuredClone(firstImpacts), energy: energy(), renderer: renderer.snapshot(), errors: [...errors] }), trace: () => packet({ caseId: scenario.caseId, model: scenario.model, options: scenario.options, commands: commandTrace, states }) };
  document.body.dataset.ready = "true";
} catch (e) {
  fail(e);
  document.body.dataset.ready = "failed";
}
var frame2;
window.addEventListener("pagehide", () => worker.terminate(), { once: true });
