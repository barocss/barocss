# Private finite-cell witness experiment

Authored; no build or numerical execution has run by this author.

The old feature/presentation folder remains immutable. This new candidate
recomputes generic exact geometry from boxes through its hash-pinned private
constructor. No saved expected witness enters the candidate.

For each native midpoint, `quantizedContact({id,a,b})` evaluates the complete
27-member predecessor/nearest-even/successor coordinate cell with its fixed
public normal. It chooses the exact nearest feasible member with lexical word
ties, or returns typed `UNRESOLVED` with its cell evidence. It does not expand
the cell or claim a global optimum. The old single-rounded-line NO_GO remains.

Root may run these commands inside the existing180s heavy guard after review
and source freeze:

```sh
node examples/physics-box-quantized-witness-2276/build.mjs build-01
node examples/physics-box-quantized-witness-2276/run.mjs build-01 run-01
python3 -B examples/physics-box-quantized-witness-2276/reference.py examples/physics-box-quantized-witness-2276/evidence/run-01
```

The SAME20cases include all32 original rows. The runner saves raw-word inputs
and outputs before checks and compares Source/strict NodeNext graphs. The
independent Hamilton/Fraction observer verifies native certificates, every cell
member, and the finite-cell optimum. Raw original-point equality and movement
are separate from population retention. No geometry verdict qualifies force,
work, solver phase, public integration or P4 stack dynamics.
