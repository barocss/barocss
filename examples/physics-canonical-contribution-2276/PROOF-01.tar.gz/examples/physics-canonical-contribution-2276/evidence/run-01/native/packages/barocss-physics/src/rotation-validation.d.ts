import type { FreeRotationResult } from './rigid-free-rotation.js';
/** Validate both prepared angular outputs before either candidate field is assigned. */
export declare function validateRotationResult(result: FreeRotationResult, dt: number): void;
