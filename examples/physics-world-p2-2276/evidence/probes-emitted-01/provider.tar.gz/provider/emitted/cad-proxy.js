export { admitCadSurfaceProxy, assertCadProxyCurrent } from './cad-proxy-admission.js';
export { cadProxyPose } from './cad-proxy-pose.js';
