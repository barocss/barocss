// D325 baseline: actual SDK pixels and public CPU picking for one authored packet.
// No internal GPU pick, staged application document or GPU/result substitution is used.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url)), root = path.resolve(here, '../../..');
const html = '<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#000}canvas{display:block;width:320px;height:240px}</style><canvas id="c" width="320" height="240"></canvas>';

test('D325 SDK displayed clipping agrees with public CPU pick', { timeout: 180000 }, async t => {
  assert.ok(process.env.CHROME && process.env.PW_DIR && process.env.VIEWER_D325_ARTIFACT_DIR, 'Actual Chrome, Playwright and artifact directory required; no silent skip');
  const output = process.env.VIEWER_D325_ARTIFACT_DIR; await mkdir(output, { recursive: true });
  const report = { status: 'RUNNING', baseline: 'd85558ce0031d812341d5871743f8535520eb8d4', worktree: root, runnerProcess: process.pid, samples: [], errors: [], fixture: 'Original audit/audit_patch public authored square packet, not a user file or Studio UI-generated document.', pickPath: 'Public SDK CPU pick; internal GPU pick NOT_RUN' };
  const persist = () => writeFile(path.join(output, 'receipt.json'), JSON.stringify(report, null, 2));
  let server, browser, context, page, phase = 'source bundle', measured = false;
  try {
    const critical = [];
    for (const name of ['packages/barocss-viewer/src/index.ts', 'packages/barocss-viewer/src/presenter.ts', 'packages/barocss-gpu/src/viewer/viewer.ts', 'packages/barocss-gpu/src/viewer/scene.ts']) {
      const bytes = await readFile(path.join(root, name)); critical.push({ path: name, sha256: createHash('sha256').update(bytes).digest('hex') });
    }
    const bundle = await build({ entryPoints: [path.join(here, '../src/index.ts')], bundle: true, format: 'esm', write: false, platform: 'browser', target: 'es2022', metafile: true });
    report.bundle = { critical, inputCount: Object.keys(bundle.metafile.inputs).length, sha256: createHash('sha256').update(bundle.outputFiles[0].contents).digest('hex'), source: 'Current worktree SDK source esbuild; no dist rebuild or source patch' }; await persist();
    server = createServer((request, response) => {
      if (request.url === '/favicon.ico') { response.writeHead(204); response.end(); return; }
      if (request.url === '/') { response.writeHead(200, { 'content-type': 'text/html' }); response.end(html); return; }
      if (request.url === '/viewer.js') { response.writeHead(200, { 'content-type': 'text/javascript' }); response.end(bundle.outputFiles[0].contents); return; }
      response.writeHead(404); response.end();
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const { chromium } = createRequire(path.join(process.env.PW_DIR, 'package.json'))('playwright');
    browser = await chromium.launch({ executablePath: process.env.CHROME, headless: true, args: ['--enable-unsafe-webgpu'] });
    context = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 }); page = await context.newPage();
    page.on('pageerror', error => report.errors.push(String(error))); page.on('console', message => { if (message.type() === 'error') report.errors.push(message.text()); });
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    report.browser = browser.version();
    report.adapter = await page.evaluate(async () => { const adapter = await navigator.gpu?.requestAdapter(); return adapter ? { vendor: adapter.info?.vendor, architecture: adapter.info?.architecture } : null; });
    if (!report.adapter) { report.status = 'SKIP_NO_NATIVE_ADAPTER'; await persist(); t.skip('No actual WebGPU adapter; no native clipping proof'); return; }
    phase = 'public authored packet admission';
    await page.evaluate(async () => {
      const { createViewer } = await import('/viewer.js');
      const background = [0.035, 0.055, 0.09];
      const packet = { version: 0, surfaceId: 'audit_patch', revision: 0, lengthUnit: 'mm', coordinateSystem: 'right-handed-z-up', winding: 'ccw',
        positions: [-1,-1,0, 1,-1,0, 1,1,0, -1,1,0], normals: [0,0,1, 0,0,1, 0,0,1, 0,0,1], indices: [0,1,2, 0,2,3],
        parameters: [0,0, 1,0, 1,1, 0,1], bounds: { min: [-1,-1,0], max: [1,1,0] } };
      const viewer = await createViewer(document.querySelector('canvas'), { mmToSceneUnit: 1, background });
      window.__d325 = { viewer, background }; viewer.setPackets([{ modelId: 'audit', packet }]);
    });
    for (const [label, near, far] of [['control', 0.01, 100], ['near-excludes', 7, 100], ['far-excludes', 0.01, 5]]) {
      phase = `observe ${label}`;
      const sample = await page.evaluate(async ({ label, near, far }) => {
        const { viewer, background } = window.__d325, camera = { eye: [0,0,6], target: [0,0,0], up: [0,1,0], fovY: 45, near, far };
        viewer.setView(camera); const pixels = await viewer.readPixels(), bg = background.map(value => Math.round(value * 255)); let covered = 0;
        for (let i = 0; i < pixels.length; i += 4) if (Math.abs(pixels[i] - bg[0]) + Math.abs(pixels[i + 1] - bg[1]) + Math.abs(pixels[i + 2] - bg[2]) > 12) covered++;
        return { label, requestedCamera: camera, byteLength: pixels.length, covered, centerRGBA: Array.from(pixels.slice((120 * 320 + 160) * 4, (120 * 320 + 160) * 4 + 4)), pick: viewer.pick(160, 120) };
      }, { label, near, far });
      report.samples.push(sample); await persist(); await page.locator('canvas').screenshot({ path: path.join(output, `${label}.png`) });
      if (label === 'control') {
        assert.ok(sample.covered > 100 && sample.pick !== null, 'actual visible control must render and return a public CPU hit');
        assert.ok(Math.abs(sample.pick.distanceScene - 6) < 1e-8, 'positive public CPU hit must retain depth-six distance');
      }
    }
    measured = true;
    const control = report.samples[0];
    report.mismatches = report.samples.slice(1).filter(sample => sample.covered > 100 && sample.pick === null).map(sample => ({ label: sample.label, covered: sample.covered, centerRGBA: sample.centerRGBA, cpuPick: sample.pick,
      sameCoverageAsControl: sample.covered === control.covered, sameCenterRGBAAsControl: JSON.stringify(sample.centerRGBA) === JSON.stringify(control.centerRGBA) }));
    report.status = report.mismatches.length ? 'BASELINE_REPRODUCED_PRODUCT_FAIL' : 'OBSERVATIONS_COMPLETE'; await persist();
    phase = 'safe display and CPU clipping assertions after all native observations';
    for (const sample of report.samples.slice(1)) {
      assert.equal(sample.pick, null, `${sample.label}: excluded square must not be CPU selectable`);
      assert.equal(sample.covered, 0, `${sample.label}: CPU-excluded square must also be absent from actual display`);
    }
    assert.deepEqual(report.errors, []); report.status = 'SAFE_CONTRACT_PASS'; await persist();
  } catch (error) {
    report.failureClass = measured ? 'SAFE_CLIPPING_CONTRACT_FAILURE' : 'SETUP_OR_POSITIVE_CONTROL_FAILURE'; if (!measured) report.status = 'SETUP_OR_POSITIVE_CONTROL_FAILURE';
    report.failure = { phase, message: error.message, stack: error.stack }; await persist(); throw error;
  } finally {
    if (page && !page.isClosed()) await page.evaluate(() => window.__d325?.viewer.dispose()).catch(error => { report.errors.push(`Viewer cleanup: ${error}`); });
    if (context) await context.close(); if (browser) await browser.close(); if (server) await new Promise(resolve => server.close(resolve));
    report.cleanup = 'OWN_VIEWER_CONTEXT_BROWSER_SERVER_CLOSED'; await persist();
  }
});
