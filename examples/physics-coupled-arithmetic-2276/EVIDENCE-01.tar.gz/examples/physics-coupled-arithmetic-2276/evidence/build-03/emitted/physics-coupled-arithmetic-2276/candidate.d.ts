import type { CoupledInput, CoupledResult } from './types.js';
export type { CoupledInput, CoupledResult, DynamicCertificate, DynamicCounts, RootCertificate } from './types.js';
export declare function coupledContactTarget(input: CoupledInput): CoupledResult;
