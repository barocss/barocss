"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.norm = exports.scale = exports.add = exports.dot = void 0;
exports.clone = clone;
const dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);
exports.dot = dot;
const add = (a, b) => a.map((value, index) => value + b[index]);
exports.add = add;
const scale = (a, factor) => a.map(value => value * factor);
exports.scale = scale;
const norm = (a) => Math.hypot(...a);
exports.norm = norm;
/** Clone only admitted private records and arrays. Preserve all numeric bits. */
function clone(value) {
    if (Array.isArray(value))
        return value.map(item => clone(item));
    if (value !== null && typeof value === 'object') {
        const result = {};
        for (const key of Object.keys(value))
            result[key] = clone(value[key]);
        return result;
    }
    return value;
}
