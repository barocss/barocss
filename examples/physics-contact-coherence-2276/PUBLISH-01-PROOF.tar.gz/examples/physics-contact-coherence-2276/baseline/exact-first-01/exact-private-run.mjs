// Root executes this frozen private bank under one existing180s outer group.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, copyFileSync, openSync, readSync, closeSync, realpathSync, statSync } from 'node:fs';
import { resolve, join, dirname, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const here=import.meta.dirname,root=resolve(here,'../..'),pkg=join(root,'packages/barocss-physics');
const entry=join(here,'candidate-exact-island.ts'),coreEntry=join(here,'candidate-exact-normal.ts');
if(process.argv[2]==='--bundle-source'){
 assert.equal(process.argv.length,4);assert.equal(process.env.ESBUILD_BINARY_PATH,undefined);
 const {build}=await import('esbuild');
 const result=await build({absWorkingDir:root,entryPoints:{'exact-island':entry,'exact-normal':coreEntry},
  outdir:resolve(process.argv[3]),outExtension:{'.js':'.mjs'},bundle:true,platform:'node',format:'esm',target:'node22',metafile:true,logLevel:'silent'});
 for(const file of Object.keys(result.metafile.inputs)){const p=resolve(root,file);assert.ok(p===entry||p===coreEntry||p.startsWith(join(pkg,'src')+'/'));}
 writeFileSync(join(resolve(process.argv[3]),'source-metafile.json'),JSON.stringify(result.metafile,null,2)+'\n',{flag:'wx'});process.exit(0);
}
const id=process.argv[2];assert.ok(process.argv.length===3&&/^[a-z0-9-]+$/.test(id??''),'node exact-private-run.mjs fresh-id');
mkdirSync(join(here,'evidence'),{recursive:true});const out=join(here,'evidence',id);mkdirSync(out);
const deadline=Date.now()+170000,python='/opt/homebrew/Cellar/python@3.13/3.13.5/Frameworks/Python.framework/Versions/3.13/bin/python3.13';
const frozen={},reports={},commands=[],errors=[],evidenceBytes={source:0,native:0};
let graph=null,phase='freeze',integrity='NOT_RUN';

function hash(path) {
  const fd = openSync(path, 'r'), digest = createHash('sha256'), buffer = Buffer.alloc(65536);
  try {
    let n;
    while ((n = readSync(fd, buffer, 0, buffer.length, null))) digest.update(buffer.subarray(0, n));
  } finally { closeSync(fd); }
  return digest.digest('hex');
}
function pin(path, expected) {
  const absolute = resolve(path), actual = hash(absolute);
  if (expected !== undefined) assert.equal(actual, expected, 'pinned input ' + absolute);
  frozen[absolute] = actual;
}
function scan(path) {
  for (const item of readdirSync(path, { withFileTypes: true })) {
    const next = join(path, item.name);
    if (item.isDirectory()) scan(next);
    else if (item.isFile()) pin(next);
    else throw new Error('Unexpected nonfile source input ' + next);
  }
}
function time() { assert.ok(Date.now() < deadline, '170s includes child work and final authentication'); }
function put(name, value, owner = graph) {
  const bytes = Buffer.from(typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n');
  assert.ok(bytes.length <= 2 * 1024 * 1024, '2MiB artifact cap ' + name);
  for (const scope of owner ? [owner] : ['source', 'native']) {
    evidenceBytes[scope] += bytes.length;
    assert.ok(evidenceBytes[scope] <= 16 * 1024 * 1024, '16MiB graph evidence cap');
  }
  writeFileSync(join(out, name), bytes, { flag: 'wx' });
}
function fail(error) {
  const failure = { graph, phase, name: error?.name ?? typeof error, code: error?.code ?? null,
    message: String(error?.message ?? error), stack: error?.stack ?? null };
  errors.push(failure);
  return failure;
}
function child(label, executable, args, input) {
  time();
  phase = label;
  const result = spawnSync(executable, args, { cwd: root, input, encoding: 'utf8',
    timeout: Math.max(1, deadline - Date.now()), maxBuffer: 2 * 1024 * 1024,
    env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' } });
  put(label + '.stdout', result.stdout ?? '');
  put(label + '.stderr', result.stderr ?? '');
  commands.push({ graph, label, executable, args, exit: result.status, signal: result.signal,
    error: result.error?.message ?? null });
  assert.ok(result.status === 0 && !result.signal && !result.error && (result.stderr ?? '') === '', label + ' child failed');
  time();
  return result.stdout;
}
function numericWordsHex(value) {
  const chunks = [];
  let count = 0, nodes = 0;
  function visit(item, depth) {
    assert.ok(++nodes <= 262144 && depth <= 32, 'bounded numeric tree');
    if (typeof item === 'number') {
      assert.ok(Number.isFinite(item) && ++count <= 65536, 'finite word bound');
      const buffer = Buffer.alloc(8); buffer.writeDoubleLE(item); chunks.push(buffer);
    } else if (Array.isArray(item)) item.forEach(child => visit(child, depth + 1));
    else if (item !== null && typeof item === 'object') Object.values(item).forEach(child => visit(child, depth + 1));
    else assert.ok(item === null || typeof item === 'string' || typeof item === 'boolean');
  }
  visit(value, 0);
  return Buffer.concat(chunks, count * 8).toString('hex');
}
function packet(data) { return { format: 'coherence-exact-private-v1', data, numericWordsF64leHex: numericWordsHex(data) }; }
function restore(packet) {
  assert.match(packet.numericWordsF64leHex, /^(?:[0-9a-f]{16})*$/);
  const raw = Buffer.from(packet.numericWordsF64leHex, 'hex');
  assert.ok(raw.length <= 512 * 1024);
  let at = 0, nodes = 0;
  function visit(value, depth) {
    assert.ok(++nodes <= 262144 && depth <= 32);
    if (typeof value === 'number') {
      assert.ok(at + 8 <= raw.length);
      const actual = raw.readDoubleLE(at); at += 8;
      assert.ok(Number.isFinite(actual) && actual === value, 'finite numeric word mismatch');
      return actual;
    }
    if (Array.isArray(value)) return value.map(item => visit(item, depth + 1));
    if (value !== null && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, visit(item, depth + 1)]));
    assert.ok(value === null || typeof value === 'string' || typeof value === 'boolean');
    return value;
  }
  const data = visit(packet.data, 0);
  assert.equal(at, raw.length, 'full word consumption');
  assert.equal(numericWordsHex(data), packet.numericWordsF64leHex, 'restored complete words');
  return data;
}
function copyMjs(source, destination) {
  for (const item of readdirSync(source, { withFileTypes: true })) {
    const from = join(source, item.name), to = join(destination, item.name);
    if (item.isDirectory()) copyMjs(from, to);
    else if (item.isFile() && item.name.endsWith('.mjs')) {
      mkdirSync(dirname(to), { recursive: true }); copyFileSync(from, to);
    }
  }
}
function observed(module, input, label, countKey) {
  phase = graph + '-' + label;
  const before = structuredClone(input), beforeWords = numericWordsHex(input);
  const observation = { value: null, error: null, inputUnchanged: null };
  reports[graph][countKey]++;
  try { observation.value = module.prepareFrictionlessIsland(input.freeBodies, input.pairs, input.context); }
  catch (error) {
    observation.error = { name: error?.name ?? typeof error, code: error?.code ?? null,
      message: String(error?.message ?? error), diagnostics: error?.diagnostics ?? null };
  }
  observation.inputUnchanged = numericWordsHex(input) === beforeWords;
  put(graph + '-' + label + '.json', packet({ input, observation }));
  assert.deepEqual(input, before, label + ' retains complete input');
  assert.ok(observation.inputUnchanged, label + ' retains input words');
  time();
  return observation;
}

function algebraicControls(api) {
  function make(inverseMass=3, velocity=-1, point=[0,0,0]) {
    const body={id:'moving',kind:'dynamic',shape:{kind:'box',halfExtentsM:[1,1,1]},positionM:[0,0,0],
      velocityMps:[-0,velocity,0],angularVelocityRadps:[0,0,0],orientation:[0,0,0,1],
      inverseMass,inverseInertiaLocal:[1,1,1],restitution:0,frictionStatic:0,frictionDynamic:0,sensor:false};
    const floor={...structuredClone(body),id:'prescribed',kind:'static',inverseMass:0,inverseInertiaLocal:[0,0,0],velocityMps:[0,0,0]};
    const bodies=[floor,body],problem={bodies:bodies.map(value=>({id:value.id,positionM:[...value.positionM],velocityMps:[...value.velocityMps],
      angularVelocityRadps:[...value.angularVelocityRadps],inverseMass:value.inverseMass,
      inverseInertiaWorld:value.inverseMass===0?[[0,0,0],[0,0,0],[0,0,0]]:[[1,0,0],[0,1,0],[0,0,1]]})),
      points:[{id:'one',aId:'prescribed',bId:'moving',pointM:point,normalAtoB:[0,1,0]}]};
    return {problem,bodies,hint:[1]};
  }
  const definitions=[
    ['third-rne-equation-zero',()=>make(),false],
    ['offset-nonzero-optimum',()=>make(1,-1,[1,0,0]),false],
    ['half-subnormal-report',()=>make(2,-Number.MIN_VALUE),false],
    ['unsupported-empty-support',()=>{const value=make();value.hint=[0];return value;},true],
    ['asymmetric-metric',()=>{const value=make();value.problem.bodies[1].inverseInertiaWorld[0][1]=.25;return value;},true],
    ['zero-physical-quaternion',()=>{const value=make();value.bodies[1].orientation=[0,0,0,0];return value;},true],
  ];
  for(const [name,makeInput,refusal] of definitions){
    const input=makeInput(),before=structuredClone(input),beforeWords=numericWordsHex(input);
    let value=null,error=null;reports[graph].algebraicCoreCalls++;
    try{value=api.refineExactNormal(input.problem,input.bodies,input.hint);}catch(caught){error=caught;}
    put(graph+'-algebraic-'+name+'.json',packet({scope:'ALGEBRAIC_ONLY_NO_WORLD_OR_GEOMETRY_CLAIM',input,value,error:error?{name:error.name,code:error.code??null,message:error.message,stats:error.stats??null}:null}));
    assert.deepEqual(input,before);assert.equal(numericWordsHex(input),beforeWords);
    if(refusal){assert.ok(error instanceof api.ExactNormalFailure);assert.equal(error.code,'NUMERIC_LIMIT');assert.equal(value,null);continue;}
    assert.equal(error,null);assert.equal(value.certificate.exactKkt,true);assert.ok(Object.is(value.appliedBodies[1].velocityMps[0],-0),'zero aggregate retains -0');
    if(name==='third-rne-equation-zero'){assert.deepEqual(value.lambdaNs,[{n:'1',d:'3'}]);assert.equal(value.roundedReporting.normalImpulsesNs[0],1/3);assert.equal(value.appliedBodies[1].velocityMps[1],0);}
    if(name==='offset-nonzero-optimum'){assert.deepEqual(value.lambdaNs,[{n:'1',d:'2'}]);assert.equal(value.appliedBodies[1].velocityMps[1],-.5);assert.equal(value.appliedBodies[1].angularVelocityRadps[2],.5);}
    if(name==='half-subnormal-report'){assert.ok(Object.is(value.roundedReporting.normalImpulsesNs[0],0));assert.notEqual(value.lambdaNs[0].n,'0');assert.equal(value.appliedBodies[1].velocityMps[1],0);}
    time();
  }
  assert.equal(reports[graph].algebraicCoreCalls,6);
}

function registerArtifacts(directory,owner){
  for(const item of readdirSync(directory,{withFileTypes:true})){
    const path=join(directory,item.name);
    if(item.isDirectory())registerArtifacts(path,owner);
    else{assert.ok(item.isFile());const size=statSync(path).size;assert.ok(size<=2*1024*1024);evidenceBytes[owner]+=size;assert.ok(evidenceBytes[owner]<=16*1024*1024);pin(path);}
  }
}

try {
  const sealPath=join(here,'EXACT-SOURCE-SEAL.json');pin(sealPath);
  const seal=JSON.parse(readFileSync(sealPath,'utf8'));assert.equal(seal.status,'SOURCE_ONLY_FROZEN_BEFORE_EXECUTION');
  for(const [name,sha]of Object.entries(seal.files))pin(join(here,name),sha);
  pin(join(pkg,'src/stack/frictionless-island.ts'),'b064c35dbbbfec85ce91f6140adc9e98fb0efeac754ce65768a69c56ae910880');
  pin(join(pkg,'src/stack/strict-line.ts'),'eb24b03efa39b5beb4d4fe132bfa723b7273d4c30ce81d51c989dcc5d1925b53');
  const strict=readFileSync(join(pkg,'src/stack/strict-line.ts'),'utf8'),core=readFileSync(coreEntry,'utf8');
  const qualified=strict.slice(strict.indexOf('class Arithmetic {'),strict.indexOf('/** Exact normalized quaternion OBB context'));
  const copied=core.slice(core.indexOf('class Arithmetic {'),core.indexOf('export interface ExactRatio'));
  assert.equal(copied.trimEnd(),qualified.trimEnd(),'qualified Arithmetic body unchanged');
  const captureHome=join(here,'evidence/exact-inputs-01'),captureResultPath=join(captureHome,'result.json');
  pin(captureResultPath,'fe436118ebf27c6c65b302200b3ef58444d1fb4c3893adeadff7b9abb14a6a1d');
  const capture=JSON.parse(readFileSync(captureResultPath,'utf8'));
  assert.equal(capture.status,'COHERENCE_ACTUAL_SOURCE_INPUTS1_27_CAPTURED');assert.equal(capture.sourceIntegrity,'PASS');assert.equal(capture.failure,null);
  assert.equal(capture.report.worlds,1);assert.equal(capture.report.attempts,27);assert.equal(capture.report.returnedSteps,26);assert.equal(capture.nativeInternalCapture,false);
  const bank=[];
  for(const [step,caseId,sha]of [[1,'support1','4862872082557ecd2f3f9358e102cee219e44bc82582179107115bfc160c1e9c'],[27,'impact27','f9ef97df676e13f062b9171129e727675573226631344a2fba68fd7b27d3acbd']]){
    const path=join(captureHome,'source-step-'+step+'-input.json');pin(path,sha);
    const p=JSON.parse(readFileSync(path,'utf8'));assert.equal(p.format,'coherence-exact-inputs-v1');const input=restore(p);assert.equal(input.step,step);bank.push({caseId,input});
  }
  const historical=join(root,'examples/physics-contact-convergence-2276/evidence/capture-490-01/actual-490.json');
  pin(historical,'7f9b41090c22ef2aac33d00e86d8606a08fcf13c27cc08689c652961769f03ee');
  pin(join(dirname(historical),'result.json'),'0dbd53a68f5a954ec7059d353eb2bdea22cf148fc52493bf06d723d444d3c7ee');
  const saved=restore(JSON.parse(readFileSync(historical,'utf8'))).observer.capture;
  bank.push({caseId:'tilted490',input:{step:490,beforeBodies:saved.beforeBodies,freeBodies:saved.freeBodies,pairs:saved.pairs,context:saved.context}});
  for(const name of ['inputs.json','transform.json','source-public-prefix.json','source-marker-owner.json'])pin(join(captureHome,name));
  const buildPath=resolve(capture.buildManifest),build=JSON.parse(readFileSync(buildPath,'utf8'));pin(buildPath);
  assert.equal(build.status,'PUBLIC_WORLD_SOURCE_AND_ACTUAL_CANONICAL_PREPARED');assert.equal(build.firstFailure,null);assert.equal(build.sourceIntegrity,true);
  for(const map of [build.sourcePins,build.nativePins])for(const [name,sha]of Object.entries(map))pin(resolve(root,name),sha);
  scan(join(pkg,'src'));pin(join(here,'package.json'));pin(join(here,'oracle.py'),'65d26e05a8f0971005104437403d075ad044252f7137edfe2df85e799aa47a6a');
  pin(process.execPath);pin(realpathSync(process.execPath));pin(python);pin(realpathSync(python));pin(resolve(dirname(python),'../Python'));
  const require=createRequire(import.meta.url),tsc=require.resolve('typescript/bin/tsc'),esbuild=require.resolve('esbuild');
  pin(tsc);scan(join(dirname(tsc),'../lib'));pin(esbuild);pin(createRequire(realpathSync(esbuild)).resolve('@esbuild/darwin-arm64/bin/esbuild'));
  pin(join(root,'package.json'));pin(join(pkg,'package.json'));
  put('inputs.json',{frozen,actualCases:bank.map(row=>row.caseId),capturePrerequisite:captureResultPath,buildManifest:buildPath,
    plannedPerGraph:{worlds:0,physicalKernelCalls:3,positionSolves:3,qrProposals:3,physicalExactRefinements:3,algebraicCoreCalls:6,references:3},
    nativeInputsAreSourceCapturedWords:true},null);
  const native=join(out,'native');mkdirSync(native);writeFileSync(join(native,'package.json'),'{"type":"module"}\n',{flag:'wx'});
  const config={compilerOptions:{target:'ES2022',module:'NodeNext',moduleResolution:'NodeNext',lib:['ES2022'],strict:true,declaration:false,skipLibCheck:true,rootDir:root,outDir:native},files:[entry]};
  put('private-tsconfig.json',config,null);child('strict-private-nodenext',process.execPath,[tsc,'-p',join(out,'private-tsconfig.json')]);
  copyMjs(join(pkg,'src'),join(native,'packages/barocss-physics/src'));
  const source=join(out,'source');mkdirSync(source);child('bundle-private-source',process.execPath,[import.meta.filename,'--bundle-source',source]);
  registerArtifacts(native,'native');registerArtifacts(source,'source');
  const nativeIsland=join(native,'examples/physics-contact-coherence-2276/candidate-exact-island.js'),nativeCore=join(native,'examples/physics-contact-coherence-2276/candidate-exact-normal.js');
  for(const name of [nativeIsland,nativeCore,join(source,'exact-island.mjs'),join(source,'exact-normal.mjs')])pin(name);
  const parity={};
  for(const which of ['source','native']){
    graph=which;reports[graph]={worlds:0,candidateCalls:0,algebraicCoreCalls:0,referenceCalls:0,acceptedSteps:0,status:'RUNNING'};
    const api=await import(pathToFileURL(which==='source'?join(source,'exact-island.mjs'):nativeIsland));
    const arithmetic=await import(pathToFileURL(which==='source'?join(source,'exact-normal.mjs'):nativeCore));
    algebraicControls(arithmetic);parity[graph]=[];
    for(const {caseId,input}of bank){
      const observation=observed(api,structuredClone(input),caseId,'candidateCalls');
      assert.equal(observation.error,null,'actual exact candidate '+caseId);assert.ok(observation.value);
      const request=packet({caseId,input,candidate:observation.value}),wire=JSON.stringify(request)+'\n';assert.ok(Buffer.byteLength(wire)<=2*1024*1024);
      put(graph+'-'+caseId+'-reference-request.json',wire);reports[graph].referenceCalls++;
      const raw=child(graph+'-'+caseId+'-reference',python,['-B',join(here,'exact-oracle.py')],wire);assert.ok(Buffer.byteLength(raw)<=65536);
      const reply=JSON.parse(raw.trim());put(graph+'-'+caseId+'-reference.json',reply);
      assert.ok(reply.ok===true&&reply.resolved===true&&reply.executionFailure===false,'independent exact certificate '+JSON.stringify(reply));
      parity[graph].push(request);reports[graph][caseId]=reply;
    }
    assert.equal(reports[graph].candidateCalls,3);assert.equal(reports[graph].referenceCalls,3);reports[graph].status='THREE_ACTUAL_EXACT_INPUTS_CONFIRMED';
    put(graph+'-result.json',reports[graph]);
  }
  assert.deepEqual(parity.source,parity.native,'complete actual exact output ratios/JSON/ALLwords SourceNative');
} catch(error) { if(graph&&reports[graph])reports[graph].status='NO_GO';fail(error); }
finally {
  graph=null;
  try{for(const [path,sha]of Object.entries(frozen))assert.equal(hash(path),sha,'input changed '+path);time();integrity='PASS';}
  catch(error){integrity='FAIL';fail(error);}
  const pass=errors.length===0&&integrity==='PASS';
  put('result.json',{status:pass?'PRIVATE_EXACT_NORMAL_SOURCE_NATIVE_CONFIRMED':'PRIVATE_EXACT_NORMAL_NO_GO',firstFailure:errors[0]??null,failures:errors,reports,commands,sourceIntegrity:integrity,evidenceBytes,
    worldCalls:0,independentTrajectoryTransitionsAdded:0,publicWorldAdopted:false,desktop:'NOT_RUN',mobile:false,publication:false},null);
  if(!pass)process.exitCode=1;
}

