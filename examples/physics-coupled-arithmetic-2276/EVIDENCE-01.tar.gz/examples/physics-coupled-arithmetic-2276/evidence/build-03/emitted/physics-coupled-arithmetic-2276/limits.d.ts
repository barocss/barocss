export interface ArithmeticLimits {
    bits: number;
    rationals: number;
    integerOps: number;
    gcdSteps: number;
    subdivisions: number;
    exponent: number;
    initialExponent: number;
}
export declare const PRODUCTION_LIMITS: Readonly<ArithmeticLimits>;
