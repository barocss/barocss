/** Private exact stationary-chain candidate. Not adopted by the normal bridge. */
import type { NormalBody, NormalProblem } from './normal-solver.js';
type Six = [number, number, number, number, number, number];
export declare const STATIONARY_LIMITS: Readonly<{
    rationalOperations: 200000;
    integerOperations: 2000000;
    integerBits: 16384;
    triangleTrials: 32;
}>;
export type StationaryStatus = 'SOLVED_STATIONARY_WITNESS' | 'INVALID_INPUT' | 'UNSUPPORTED_PROFILE' | 'NO_WITNESS' | 'RESOURCE_LIMIT' | 'NUMERIC_LIMIT';
export interface StationaryStats {
    rationalOperations: number;
    integerOperations: number;
    peakIntegerBits: number;
    triangleTrials: number;
    interfacesProcessed: number;
}
export interface Ratio {
    n: string;
    d: string;
}
interface Endpoint {
    bodyId: string;
    coefficients: Six;
    words: string[];
}
export interface StationaryResult {
    ok: boolean;
    status: StationaryStatus;
    reason: string | null;
    bodies: readonly NormalBody[];
    normalImpulsesNs: number[] | null;
    exactApplied: null | {
        format: 'STATIONARY_FLOAT_J_RATIOS_V1';
        points: {
            id: string;
            a: Endpoint;
            b: Endpoint;
            lambda: Ratio;
            roundedWord: string;
        }[];
        dynamicResiduals: {
            bodyId: string;
            values: Ratio[];
        }[];
        allRowsPrimalZero: true;
        allRowsComplementarityZero: true;
        nonnegative: true;
    };
    roundedReconstruction: null | {
        maxVelocityErrorMps: number;
        maxAngularVelocityErrorRadps: number;
        maxUnscaledMassWeightedResidualSqrtJ: number;
    };
    stats: StationaryStats;
}
/** Sole production entry: no bridge or public World imports this candidate yet. */
export declare function solveStationaryNormal(problem: NormalProblem): StationaryResult;
export {};
