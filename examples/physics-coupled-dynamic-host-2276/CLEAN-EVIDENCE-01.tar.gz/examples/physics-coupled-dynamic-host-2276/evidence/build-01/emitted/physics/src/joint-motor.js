"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.driveHingeMotor = driveHingeMotor;
exports.driveDynamicHingeMotor = driveDynamicHingeMotor;
const math_js_1 = require("./math.js");
function driveHingeMotor(joint, body, angleRad) {
    const motor = joint.motor;
    const axis = joint.axisWorld;
    const [low, high] = joint.limitRad;
    if ((angleRad <= low && motor.targetSpeedRadps < 0) ||
        (angleRad >= high && motor.targetSpeedRadps > 0))
        return 0;
    const inverseAxisInertia = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(body, axis));
    const speed = (0, math_js_1.dot)(body.angularVelocityRadps, axis);
    const needed = (motor.targetSpeedRadps - speed) / inverseAxisInertia;
    const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
    body.angularVelocityRadps = (0, math_js_1.add)(body.angularVelocityRadps, (0, math_js_1.inverseInertia)(body, (0, math_js_1.scale)(axis, impulse)));
    return impulse;
}
function driveDynamicHingeMotor(joint, a, b, angleRad) {
    const motor = joint.motor;
    const axis = joint.axisWorld;
    const [low, high] = joint.limitRad;
    if ((angleRad <= low && motor.targetSpeedRadps < 0) ||
        (angleRad >= high && motor.targetSpeedRadps > 0))
        return 0;
    const inverseSum = (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(a, axis)) +
        (0, math_js_1.dot)(axis, (0, math_js_1.inverseInertia)(b, axis));
    const speed = (0, math_js_1.dot)((0, math_js_1.sub)(b.angularVelocityRadps, a.angularVelocityRadps), axis);
    const needed = (motor.targetSpeedRadps - speed) / inverseSum;
    const impulse = Math.max(-motor.maxImpulseNms, Math.min(motor.maxImpulseNms, needed));
    a.angularVelocityRadps = (0, math_js_1.sub)(a.angularVelocityRadps, (0, math_js_1.inverseInertia)(a, (0, math_js_1.scale)(axis, impulse)));
    b.angularVelocityRadps = (0, math_js_1.add)(b.angularVelocityRadps, (0, math_js_1.inverseInertia)(b, (0, math_js_1.scale)(axis, impulse)));
    return impulse;
}
