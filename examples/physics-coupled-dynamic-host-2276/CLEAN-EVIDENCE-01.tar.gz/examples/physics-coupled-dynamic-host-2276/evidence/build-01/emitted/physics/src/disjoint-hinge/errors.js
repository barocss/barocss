"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GATE = exports.ERRORS = void 0;
exports.fail = fail;
exports.exactFields = exactFields;
exports.dense = dense;
exports.matrix = matrix;
exports.finiteData = finiteData;
exports.readProblem = readProblem;
const validation_js_1 = require("../validation.js");
exports.ERRORS = {
    pose: 'hinge pose state is invalid',
    result: 'hinge projection result is invalid',
    linear: 'hinge velocity problem is invalid',
    system: 'hinge velocity system is singular or unsafe',
    certificate: 'hinge velocity certificate is invalid',
};
exports.GATE = 1e-10;
function fail(kind) { return (0, validation_js_1.error)('NUMERIC_LIMIT', exports.ERRORS[kind]); }
function exactFields(value, keys) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null)
        return false;
    const own = Reflect.ownKeys(value);
    return own.length === keys.length && own.every(k => typeof k === 'string' && keys.includes(k) && Object.hasOwn(Object.getOwnPropertyDescriptor(value, k), 'value'));
}
function dense(value, size) {
    return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === size && Reflect.ownKeys(value).length === size + 1 && Array.from({ length: size }, (_, i) => i).every(i => Object.hasOwn(value, i) && typeof value[i] === 'number' && Number.isFinite(value[i]));
}
function matrix(value, rows, columns) {
    return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length === rows && Reflect.ownKeys(value).length === rows + 1 && Array.from({ length: rows }, (_, i) => i).every(i => Object.hasOwn(value, i) && dense(value[i], columns));
}
function finiteData(value) {
    if (typeof value === 'number')
        return Number.isFinite(value);
    if (typeof value === 'string' || typeof value === 'boolean')
        return true;
    if (Array.isArray(value))
        return Object.getPrototypeOf(value) === Array.prototype && Reflect.ownKeys(value).length === value.length + 1 && Array.from({ length: value.length }, (_, i) => i).every(i => Object.hasOwn(value, i) && finiteData(value[i]));
    if (value === null || typeof value !== 'object')
        return false;
    const proto = Object.getPrototypeOf(value);
    return (proto === Object.prototype || proto === null) && Reflect.ownKeys(value).every(k => typeof k === 'string' && finiteData(value[k]));
}
function readProblem(value) {
    if (!exactFields(value, ['a', 'b', 'h', 'y0', 'stopKind', 'stopRow']) || !matrix(value.a, 11, 12) || !dense(value.b, 11) || !dense(value.h, 12) || value.h.some(x => x <= 0) || !dense(value.y0, 12))
        fail('linear');
    if (value.stopKind !== 'none' && value.stopKind !== 'upper' && value.stopKind !== 'lower')
        fail('linear');
    if (!dense(value.stopRow, value.stopKind === 'none' ? 0 : 12))
        fail('linear');
    return structuredClone(value);
}
